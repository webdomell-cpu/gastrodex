// GastroDex Bilingual Master Quiz Questions
const MASTER_QUIZ = [
  {
    "id": "q_spirits_01",
    "category": "spirits",
    "questionEn": "What is the legal minimum corn percentage for Bourbon Whiskey?",
    "questionDe": "Wie hoch ist der gesetzliche Mindestanteil an Mais für Bourbon Whiskey?",
    "optionsEn": [
      "75%",
      "51%",
      "100%",
      "33%"
    ],
    "optionsDe": [
      "75%",
      "51%",
      "100%",
      "33%"
    ],
    "correctIndex": 1,
    "explanationEn": "US law mandates at least 51% corn in the mash bill for Bourbon.",
    "explanationDe": "Nach US-Bundesrecht muss Bourbon zu mindestens 51% aus Mais gebrannt werden.",
    "qEn": "What is the legal minimum corn percentage for Bourbon Whiskey?",
    "qDe": "Wie hoch ist der gesetzliche Mindestanteil an Mais für Bourbon Whiskey?",
    "optEn": [
      "75%",
      "51%",
      "100%",
      "33%"
    ],
    "optDe": [
      "75%",
      "51%",
      "100%",
      "33%"
    ],
    "correct": 1,
    "expEn": "US law mandates at least 51% corn in the mash bill for Bourbon.",
    "expDe": "Nach US-Bundesrecht muss Bourbon zu mindestens 51% aus Mais gebrannt werden."
  },
  {
    "id": "q_spirits_02",
    "category": "spirits",
    "questionEn": "What causes the milky Louche effect in Ouzo or Rakı?",
    "questionDe": "Was verursacht den milchigen Louche-Effekt in Ouzo oder Rakı?",
    "optionsEn": [
      "Anethole oil from anise precipitates as microscopic droplets when water is added",
      "Added milk powder",
      "Ice crystallization",
      "Sugar precipitation"
    ],
    "optionsDe": [
      "Anisöl (Anethol) fällt bei Wasserzugabe als mikroskopische Tröpfchen aus",
      "Zusatz von Milchpulver",
      "Eiskristallbildung",
      "Zuckerausfällung"
    ],
    "correctIndex": 0,
    "explanationEn": "Anethole is soluble only in high alcohol; diluting forces spontaneous micro-emulsification.",
    "explanationDe": "Anethol ist nur in hochprozentigem Alkohol löslich und emulgiert bei Wasserzugabe.",
    "qEn": "What causes the milky Louche effect in Ouzo or Rakı?",
    "qDe": "Was verursacht den milchigen Louche-Effekt in Ouzo oder Rakı?",
    "optEn": [
      "Anethole oil from anise precipitates as microscopic droplets when water is added",
      "Added milk powder",
      "Ice crystallization",
      "Sugar precipitation"
    ],
    "optDe": [
      "Anisöl (Anethol) fällt bei Wasserzugabe als mikroskopische Tröpfchen aus",
      "Zusatz von Milchpulver",
      "Eiskristallbildung",
      "Zuckerausfällung"
    ],
    "correct": 0,
    "expEn": "Anethole is soluble only in high alcohol; diluting forces spontaneous micro-emulsification.",
    "expDe": "Anethol ist nur in hochprozentigem Alkohol löslich und emulgiert bei Wasserzugabe."
  },
  {
    "id": "q_spirits_03",
    "category": "spirits",
    "questionEn": "What is Rhum Agricole distilled from?",
    "questionDe": "Woraus wird Rhum Agricole (AOC Martinique) destilliert?",
    "optionsEn": [
      "Barley mash",
      "Sugarcane molasses",
      "Beet syrup",
      "Fresh pressed sugarcane juice"
    ],
    "optionsDe": [
      "Gerstenmaische",
      "Zuckerrohrmelasse",
      "Rübensirup",
      "Frischem Zuckerrohrsaft"
    ],
    "correctIndex": 3,
    "explanationEn": "Rhum Agricole uses 100% pure fresh sugarcane juice, giving herbal terroir notes.",
    "explanationDe": "Rhum Agricole wird direkt aus frischem Zuckerrohrsaft gebrannt.",
    "qEn": "What is Rhum Agricole distilled from?",
    "qDe": "Woraus wird Rhum Agricole (AOC Martinique) destilliert?",
    "optEn": [
      "Barley mash",
      "Sugarcane molasses",
      "Beet syrup",
      "Fresh pressed sugarcane juice"
    ],
    "optDe": [
      "Gerstenmaische",
      "Zuckerrohrmelasse",
      "Rübensirup",
      "Frischem Zuckerrohrsaft"
    ],
    "correct": 3,
    "expEn": "Rhum Agricole uses 100% pure fresh sugarcane juice, giving herbal terroir notes.",
    "expDe": "Rhum Agricole wird direkt aus frischem Zuckerrohrsaft gebrannt."
  },
  {
    "id": "q_spirits_04",
    "category": "spirits",
    "questionEn": "Which agave species is legally required for 100% Tequila?",
    "questionDe": "Welche Agavenart ist für 100% Tequila vorgeschrieben?",
    "optionsEn": [
      "Agave Tobalá",
      "Agave Espadín",
      "Blue Agave (Agave tequilana Weber)",
      "Agave Americana"
    ],
    "optionsDe": [
      "Agave Tobalá",
      "Agave Espadín",
      "Blaue Agave (Agave tequilana Weber)",
      "Agave Americana"
    ],
    "correctIndex": 2,
    "explanationEn": "Only Blue Agave Weber is permitted under the Tequila DOT denomination.",
    "explanationDe": "Für Tequila ist ausschließlich die Blaue Agave Weber zugelassen.",
    "qEn": "Which agave species is legally required for 100% Tequila?",
    "qDe": "Welche Agavenart ist für 100% Tequila vorgeschrieben?",
    "optEn": [
      "Agave Tobalá",
      "Agave Espadín",
      "Blue Agave (Agave tequilana Weber)",
      "Agave Americana"
    ],
    "optDe": [
      "Agave Tobalá",
      "Agave Espadín",
      "Blaue Agave (Agave tequilana Weber)",
      "Agave Americana"
    ],
    "correct": 2,
    "expEn": "Only Blue Agave Weber is permitted under the Tequila DOT denomination.",
    "expDe": "Für Tequila ist ausschließlich die Blaue Agave Weber zugelassen."
  },
  {
    "id": "q_spirits_05",
    "category": "spirits",
    "questionEn": "What defines Single Malt Scotch Whisky?",
    "questionDe": "Was bedeutet Single Malt Scotch Whisky gesetzlich?",
    "optionsEn": [
      "Single grain from one harvest",
      "100% malted barley from a single distillery, pot still distilled, aged 3+ years in Scotland",
      "Unblended single cask only",
      "Distilled from rye and corn"
    ],
    "optionsDe": [
      "Aus einer einzigen Getreideernte",
      "100% gemälzte Gerste aus einer einzigen Destillerie, Kupferblase, mind. 3 Jahre Reife",
      "Aus einem unverschnittenen Einzelfass",
      "Aus Roggen und Mais"
    ],
    "correctIndex": 1,
    "explanationEn": "'Single' means one distillery; 'Malt' means 100% malted barley.",
    "explanationDe": "'Single' bezeichnet eine einzige Brennerei und 'Malt' gemälzte Gerste.",
    "qEn": "What defines Single Malt Scotch Whisky?",
    "qDe": "Was bedeutet Single Malt Scotch Whisky gesetzlich?",
    "optEn": [
      "Single grain from one harvest",
      "100% malted barley from a single distillery, pot still distilled, aged 3+ years in Scotland",
      "Unblended single cask only",
      "Distilled from rye and corn"
    ],
    "optDe": [
      "Aus einer einzigen Getreideernte",
      "100% gemälzte Gerste aus einer einzigen Destillerie, Kupferblase, mind. 3 Jahre Reife",
      "Aus einem unverschnittenen Einzelfass",
      "Aus Roggen und Mais"
    ],
    "correct": 1,
    "expEn": "'Single' means one distillery; 'Malt' means 100% malted barley.",
    "expDe": "'Single' bezeichnet eine einzige Brennerei und 'Malt' gemälzte Gerste."
  },
  {
    "id": "q_spirits_06",
    "category": "spirits",
    "questionEn": "What is the maximum sugar addition permitted in London Dry Gin after distillation?",
    "questionDe": "Wie viel Zucker darf London Dry Gin nach der Destillation maximal zugesetzt werden?",
    "optionsEn": [
      "0.1 g/L",
      "10 g/L",
      "50 g/L",
      "Unlimited"
    ],
    "optionsDe": [
      "0,1 g/L",
      "10 g/L",
      "50 g/L",
      "Unbegrenzt"
    ],
    "correctIndex": 0,
    "explanationEn": "London Dry permits virtually zero sugar (max 0.1g/L) and no artificial flavors post-distillation.",
    "explanationDe": "London Dry erlaubt maximal 0,1 g/L Zucker und keinerlei nachträgliche Aromazusätze.",
    "qEn": "What is the maximum sugar addition permitted in London Dry Gin after distillation?",
    "qDe": "Wie viel Zucker darf London Dry Gin nach der Destillation maximal zugesetzt werden?",
    "optEn": [
      "0.1 g/L",
      "10 g/L",
      "50 g/L",
      "Unlimited"
    ],
    "optDe": [
      "0,1 g/L",
      "10 g/L",
      "50 g/L",
      "Unbegrenzt"
    ],
    "correct": 0,
    "expEn": "London Dry permits virtually zero sugar (max 0.1g/L) and no artificial flavors post-distillation.",
    "expDe": "London Dry erlaubt maximal 0,1 g/L Zucker und keinerlei nachträgliche Aromazusätze."
  },
  {
    "id": "q_spirits_07",
    "category": "spirits",
    "questionEn": "Which region is the Premier Cru of Cognac?",
    "questionDe": "Welche Lage ist das Premier Cru von Cognac?",
    "optionsEn": [
      "Fins Bois",
      "Petite Champagne",
      "Borderies",
      "Grande Champagne"
    ],
    "optionsDe": [
      "Fins Bois",
      "Petite Champagne",
      "Borderies",
      "Grande Champagne"
    ],
    "correctIndex": 3,
    "explanationEn": "Grande Champagne has the chalkiest soil, yielding refined, long-aging spirits.",
    "explanationDe": "Grande Champagne besitzt die kalkreichsten Böden für langlebigen Cognac.",
    "qEn": "Which region is the Premier Cru of Cognac?",
    "qDe": "Welche Lage ist das Premier Cru von Cognac?",
    "optEn": [
      "Fins Bois",
      "Petite Champagne",
      "Borderies",
      "Grande Champagne"
    ],
    "optDe": [
      "Fins Bois",
      "Petite Champagne",
      "Borderies",
      "Grande Champagne"
    ],
    "correct": 3,
    "expEn": "Grande Champagne has the chalkiest soil, yielding refined, long-aging spirits.",
    "expDe": "Grande Champagne besitzt die kalkreichsten Böden für langlebigen Cognac."
  },
  {
    "id": "q_spirits_08",
    "category": "spirits",
    "questionEn": "What is Italian Grappa distilled from?",
    "questionDe": "Woraus wird italienische Grappa destilliert?",
    "optionsEn": [
      "Dried raisins",
      "Whole fermented wine",
      "Grape pomace (skins, seeds, stems after pressing)",
      "Cider"
    ],
    "optionsDe": [
      "Rosinen",
      "Vollwein",
      "Traubentrester (Schalen, Kerne, Stiele nach dem Keltern)",
      "Apfelmost"
    ],
    "correctIndex": 2,
    "explanationEn": "Grappa is a pomace spirit distilled from solid residues of wine pressing.",
    "explanationDe": "Grappa wird ausschließlich aus den festen Rückständen der Traubenpressung gebrannt.",
    "qEn": "What is Italian Grappa distilled from?",
    "qDe": "Woraus wird italienische Grappa destilliert?",
    "optEn": [
      "Dried raisins",
      "Whole fermented wine",
      "Grape pomace (skins, seeds, stems after pressing)",
      "Cider"
    ],
    "optDe": [
      "Rosinen",
      "Vollwein",
      "Traubentrester (Schalen, Kerne, Stiele nach dem Keltern)",
      "Apfelmost"
    ],
    "correct": 2,
    "expEn": "Grappa is a pomace spirit distilled from solid residues of wine pressing.",
    "expDe": "Grappa wird ausschließlich aus den festen Rückständen der Traubenpressung gebrannt."
  },
  {
    "id": "q_spirits_09",
    "category": "spirits",
    "questionEn": "How does Islay Scotch acquire its intense peaty smoky aroma?",
    "questionDe": "Wodurch entsteht das rauchig-torfige Aroma in Islay Scotch Whiskys?",
    "optionsEn": [
      "Adding liquid smoke",
      "Drying damp malted barley over peat fires in kilns",
      "Aging in charred pine barrels",
      "Charcoal filtration"
    ],
    "optionsDe": [
      "Zugabe von Raucharoma",
      "Darren des feuchten Grünmalzes über schwelendem Torffeuer (Peat Kiln)",
      "Reifung in Kiefernholzfässern",
      "Kohlefiltration"
    ],
    "correctIndex": 1,
    "explanationEn": "Peat smoke phenols bind to moist malt during kiln drying.",
    "explanationDe": "Phenole aus dem Torfrauch binden sich während des Trocknens an die feuchte Gerste.",
    "qEn": "How does Islay Scotch acquire its intense peaty smoky aroma?",
    "qDe": "Wodurch entsteht das rauchig-torfige Aroma in Islay Scotch Whiskys?",
    "optEn": [
      "Adding liquid smoke",
      "Drying damp malted barley over peat fires in kilns",
      "Aging in charred pine barrels",
      "Charcoal filtration"
    ],
    "optDe": [
      "Zugabe von Raucharoma",
      "Darren des feuchten Grünmalzes über schwelendem Torffeuer (Peat Kiln)",
      "Reifung in Kiefernholzfässern",
      "Kohlefiltration"
    ],
    "correct": 1,
    "expEn": "Peat smoke phenols bind to moist malt during kiln drying.",
    "expDe": "Phenole aus dem Torfrauch binden sich während des Trocknens an die feuchte Gerste."
  },
  {
    "id": "q_spirits_10",
    "category": "spirits",
    "questionEn": "What is the primary fruit base of French Calvados AOC from Normandy?",
    "questionDe": "Was ist die primäre Fruchtbasis von französischem Calvados AOC?",
    "optionsEn": [
      "Cider apples and perry pears",
      "Plums",
      "Cherries",
      "Grapes"
    ],
    "optionsDe": [
      "Cidre-Äpfel und Mostbirnen",
      "Pflaumen",
      "Sauerkirschen",
      "Weintrauben"
    ],
    "correctIndex": 0,
    "explanationEn": "Calvados is an apple brandy distilled from fermented cider and perry.",
    "explanationDe": "Calvados wird aus vergorenem Apfelcidre und Mostbirnen destilliert.",
    "qEn": "What is the primary fruit base of French Calvados AOC from Normandy?",
    "qDe": "Was ist die primäre Fruchtbasis von französischem Calvados AOC?",
    "optEn": [
      "Cider apples and perry pears",
      "Plums",
      "Cherries",
      "Grapes"
    ],
    "optDe": [
      "Cidre-Äpfel und Mostbirnen",
      "Pflaumen",
      "Sauerkirschen",
      "Weintrauben"
    ],
    "correct": 0,
    "expEn": "Calvados is an apple brandy distilled from fermented cider and perry.",
    "expDe": "Calvados wird aus vergorenem Apfelcidre und Mostbirnen destilliert."
  },
  {
    "id": "q_spirits_11",
    "category": "spirits",
    "questionEn": "Why is premium vodka traditionally filtered through activated birch charcoal?",
    "questionDe": "Warum wird Wodka mehrfach über Birken-Aktivkohle filtriert?",
    "optionsEn": [
      "To reduce alcohol proof",
      "To turn red raw spirit clear",
      "To infuse birch sweetness",
      "To adsorb trace fusel oils and aldehydes for neutral purity"
    ],
    "optionsDe": [
      "Um Alkohol abzubauen",
      "Um roten Rohbrand zu entfärben",
      "Um Birkensüße einzutragen",
      "Um Fuselöle und Aldehyde zu binden und maximale Reinheit zu erzielen"
    ],
    "correctIndex": 3,
    "explanationEn": "Activated charcoal binds long-chain impurities without stripping character.",
    "explanationDe": "Aktivkohle adsorbiert Verunreinigungen und Begleitöle für samtige Milde.",
    "qEn": "Why is premium vodka traditionally filtered through activated birch charcoal?",
    "qDe": "Warum wird Wodka mehrfach über Birken-Aktivkohle filtriert?",
    "optEn": [
      "To reduce alcohol proof",
      "To turn red raw spirit clear",
      "To infuse birch sweetness",
      "To adsorb trace fusel oils and aldehydes for neutral purity"
    ],
    "optDe": [
      "Um Alkohol abzubauen",
      "Um roten Rohbrand zu entfärben",
      "Um Birkensüße einzutragen",
      "Um Fuselöle und Aldehyde zu binden und maximale Reinheit zu erzielen"
    ],
    "correct": 3,
    "expEn": "Activated charcoal binds long-chain impurities without stripping character.",
    "expDe": "Aktivkohle adsorbiert Verunreinigungen und Begleitöle für samtige Milde."
  },
  {
    "id": "q_spirits_12",
    "category": "spirits",
    "questionEn": "Which herb supplies the compound thujone to authentic Absinthe?",
    "questionDe": "Welche Heilpflanze liefert das wirksame Terpen Thujon im traditionellen Absinth?",
    "optionsEn": [
      "Star anise",
      "Fennel seed",
      "Grande Wormwood (Artemisia absinthium)",
      "Hyssop"
    ],
    "optionsDe": [
      "Sternanis",
      "Fenchelsamen",
      "Echter Wermut (Artemisia absinthium)",
      "Ysop"
    ],
    "correctIndex": 2,
    "explanationEn": "Grande Wormwood is macerated and distilled alongside anise and fennel.",
    "explanationDe": "Echter Wermut bildet mit Anis und Fenchel die Heilige Dreifaltigkeit des Absinths.",
    "qEn": "Which herb supplies the compound thujone to authentic Absinthe?",
    "qDe": "Welche Heilpflanze liefert das wirksame Terpen Thujon im traditionellen Absinth?",
    "optEn": [
      "Star anise",
      "Fennel seed",
      "Grande Wormwood (Artemisia absinthium)",
      "Hyssop"
    ],
    "optDe": [
      "Sternanis",
      "Fenchelsamen",
      "Echter Wermut (Artemisia absinthium)",
      "Ysop"
    ],
    "correct": 2,
    "expEn": "Grande Wormwood is macerated and distilled alongside anise and fennel.",
    "expDe": "Echter Wermut bildet mit Anis und Fenchel die Heilige Dreifaltigkeit des Absinths."
  },
  {
    "id": "q_spirits_13",
    "category": "spirits",
    "questionEn": "How is Armagnac traditionally distilled differently than Cognac?",
    "questionDe": "Wie unterscheidet sich die Destillation von Armagnac im Vergleich zu Cognac?",
    "optionsEn": [
      "Double pot still distillation",
      "Single continuous distillation in column stills (alambic armagnacais)",
      "Cold vacuum distillation",
      "Triple pot still"
    ],
    "optionsDe": [
      "Zweifache Destillation in Kupferblasen",
      "Einfache kontinuierliche Destillation im Alambic Armagnacais",
      "Kaltvakuumdestillation",
      "Dreifache Brennblase"
    ],
    "correctIndex": 1,
    "explanationEn": "Armagnac column distillation retains heavier aromatic esters and fruit congeners.",
    "explanationDe": "Die Säulendestillation im Alambic Armagnacais erhält mehr schwere Fruchtaromen.",
    "qEn": "How is Armagnac traditionally distilled differently than Cognac?",
    "qDe": "Wie unterscheidet sich die Destillation von Armagnac im Vergleich zu Cognac?",
    "optEn": [
      "Double pot still distillation",
      "Single continuous distillation in column stills (alambic armagnacais)",
      "Cold vacuum distillation",
      "Triple pot still"
    ],
    "optDe": [
      "Zweifache Destillation in Kupferblasen",
      "Einfache kontinuierliche Destillation im Alambic Armagnacais",
      "Kaltvakuumdestillation",
      "Dreifache Brennblase"
    ],
    "correct": 1,
    "expEn": "Armagnac column distillation retains heavier aromatic esters and fruit congeners.",
    "expDe": "Die Säulendestillation im Alambic Armagnacais erhält mehr schwere Fruchtaromen."
  },
  {
    "id": "q_spirits_14",
    "category": "spirits",
    "questionEn": "What is the mandatory principal botanical in Scandinavian Aquavit?",
    "questionDe": "Welches Gewürz ist das gesetzlich vorgeschriebene Leitgewürz in Aquavit?",
    "optionsEn": [
      "Caraway and/or dill seed",
      "Juniper berry",
      "Cinnamon",
      "Cardamom"
    ],
    "optionsDe": [
      "Kümmel (Carum carvi) und/oder Dillsamen",
      "Wacholderbeere",
      "Zimt",
      "Kardamom"
    ],
    "correctIndex": 0,
    "explanationEn": "EU law mandates caraway or dill as predominant flavor in Aquavit.",
    "explanationDe": "Nach EU-Recht muss der vorherrschende Geschmack aus Kümmel- oder Dillsamen stammen.",
    "qEn": "What is the mandatory principal botanical in Scandinavian Aquavit?",
    "qDe": "Welches Gewürz ist das gesetzlich vorgeschriebene Leitgewürz in Aquavit?",
    "optEn": [
      "Caraway and/or dill seed",
      "Juniper berry",
      "Cinnamon",
      "Cardamom"
    ],
    "optDe": [
      "Kümmel (Carum carvi) und/oder Dillsamen",
      "Wacholderbeere",
      "Zimt",
      "Kardamom"
    ],
    "correct": 0,
    "expEn": "EU law mandates caraway or dill as predominant flavor in Aquavit.",
    "expDe": "Nach EU-Recht muss der vorherrschende Geschmack aus Kümmel- oder Dillsamen stammen."
  },
  {
    "id": "q_spirits_15",
    "category": "spirits",
    "questionEn": "Why does artisanal Mezcal taste smoky compared to Tequila?",
    "questionDe": "Warum schmeckt traditioneller Mezcal rauchig im Vergleich zu Tequila?",
    "optionsEn": [
      "Matured in burned coal silos",
      "Liquid smoke added during bottling",
      "Boiled in steel smokeboxes",
      "Agave hearts are roasted in underground stone pits over wood fire"
    ],
    "optionsDe": [
      "In Kohlesilos gelagert",
      "Raucharoma wird bei der Abfüllung zugegeben",
      "In Rauchkammern gekocht",
      "Agavenherzen (Piñas) werden in Grubenöfen über Holzfeuer und Stein geröstet"
    ],
    "correctIndex": 3,
    "explanationEn": "Underground pit cooking infuses deep wood smoke into agave fibers.",
    "explanationDe": "Das Rösten in Erdgruben imprägniert die Agavenfasern mit tiefem Rauch.",
    "qEn": "Why does artisanal Mezcal taste smoky compared to Tequila?",
    "qDe": "Warum schmeckt traditioneller Mezcal rauchig im Vergleich zu Tequila?",
    "optEn": [
      "Matured in burned coal silos",
      "Liquid smoke added during bottling",
      "Boiled in steel smokeboxes",
      "Agave hearts are roasted in underground stone pits over wood fire"
    ],
    "optDe": [
      "In Kohlesilos gelagert",
      "Raucharoma wird bei der Abfüllung zugegeben",
      "In Rauchkammern gekocht",
      "Agavenherzen (Piñas) werden in Grubenöfen über Holzfeuer und Stein geröstet"
    ],
    "correct": 3,
    "expEn": "Underground pit cooking infuses deep wood smoke into agave fibers.",
    "expDe": "Das Rösten in Erdgruben imprägniert die Agavenfasern mit tiefem Rauch."
  },
  {
    "id": "q_spirits_16",
    "category": "spirits",
    "questionEn": "What is Brazilian Cachaça legally distilled from?",
    "questionDe": "Woraus wird brasilianischer Cachaça gesetzlich gebrannt?",
    "optionsEn": [
      "Grain alcohol",
      "Cane molasses",
      "Fresh fermented sugarcane juice (38–48% ABV)",
      "Fruit syrup"
    ],
    "optionsDe": [
      "Getreidealkohol",
      "Zuckerrohrmelasse",
      "Frischem fermentiertem Zuckerrohrsaft (38–48% Vol.)",
      "Fruchtsirup"
    ],
    "correctIndex": 2,
    "explanationEn": "Cachaça is a protected Brazilian spirit made from fresh pressed cane juice.",
    "explanationDe": "Cachaça ist eine geschützte brasilianische Spirituose aus frischem Rohrsaft.",
    "qEn": "What is Brazilian Cachaça legally distilled from?",
    "qDe": "Woraus wird brasilianischer Cachaça gesetzlich gebrannt?",
    "optEn": [
      "Grain alcohol",
      "Cane molasses",
      "Fresh fermented sugarcane juice (38–48% ABV)",
      "Fruit syrup"
    ],
    "optDe": [
      "Getreidealkohol",
      "Zuckerrohrmelasse",
      "Frischem fermentiertem Zuckerrohrsaft (38–48% Vol.)",
      "Fruchtsirup"
    ],
    "correct": 2,
    "expEn": "Cachaça is a protected Brazilian spirit made from fresh pressed cane juice.",
    "expDe": "Cachaça ist eine geschützte brasilianische Spirituose aus frischem Rohrsaft."
  },
  {
    "id": "q_spirits_17",
    "category": "spirits",
    "questionEn": "How is authentic Peruvian Pisco produced regarding proof and aging?",
    "questionDe": "Wie wird peruanischer Pisco bezüglich Trinkstärke und Reifung hergestellt?",
    "optionsEn": [
      "Aged 12 years in charred oak",
      "Distilled directly to bottle proof without water dilution or oak contact",
      "Sweetened with sugar syrup",
      "Diluted with spring water"
    ],
    "optionsDe": [
      "12 Jahre im Eichenfass",
      "Direkt auf Trinkstärke gebrannt; kein Wasserzusatz, kein Holzfasskontakt",
      "Mit Zuckersirup gesüßt",
      "Mit Quellwasser gestreckt"
    ],
    "correctIndex": 1,
    "explanationEn": "Peruvian Pisco is rested in neutral vessels and never diluted.",
    "explanationDe": "Peruanischer Pisco wird direkt auf Trinkstärke gebrannt und ruht in neutralen Tanks.",
    "qEn": "How is authentic Peruvian Pisco produced regarding proof and aging?",
    "qDe": "Wie wird peruanischer Pisco bezüglich Trinkstärke und Reifung hergestellt?",
    "optEn": [
      "Aged 12 years in charred oak",
      "Distilled directly to bottle proof without water dilution or oak contact",
      "Sweetened with sugar syrup",
      "Diluted with spring water"
    ],
    "optDe": [
      "12 Jahre im Eichenfass",
      "Direkt auf Trinkstärke gebrannt; kein Wasserzusatz, kein Holzfasskontakt",
      "Mit Zuckersirup gesüßt",
      "Mit Quellwasser gestreckt"
    ],
    "correct": 1,
    "expEn": "Peruvian Pisco is rested in neutral vessels and never diluted.",
    "expDe": "Peruanischer Pisco wird direkt auf Trinkstärke gebrannt und ruht in neutralen Tanks."
  },
  {
    "id": "q_spirits_18",
    "category": "spirits",
    "questionEn": "Where does the subtle almond note in Black Forest Kirschwasser originate?",
    "questionDe": "Woher stammt die feine Mandelnote in Schwarzwälder Kirschwasser?",
    "optionsEn": [
      "Crushed cherry pits releasing benzaldehyde during fermentation",
      "Almond extract infusion",
      "Almond wood casks",
      "Added marzipan paste"
    ],
    "optionsDe": [
      "Ein kontrollierter Anteil angequetschter Kirschkerne setzt Benzaldehyd frei",
      "Zusatz von Bittermandelöl",
      "Fässer aus Mandelbaumholz",
      "Zugabe von Marzipanpaste"
    ],
    "correctIndex": 0,
    "explanationEn": "Cherry stones release amygdalin, converting to aromatic benzaldehyde.",
    "explanationDe": "Die Kirschsteine enthalten Amygdalin, das zu feinem Benzaldehyd gespalten wird.",
    "qEn": "Where does the subtle almond note in Black Forest Kirschwasser originate?",
    "qDe": "Woher stammt die feine Mandelnote in Schwarzwälder Kirschwasser?",
    "optEn": [
      "Crushed cherry pits releasing benzaldehyde during fermentation",
      "Almond extract infusion",
      "Almond wood casks",
      "Added marzipan paste"
    ],
    "optDe": [
      "Ein kontrollierter Anteil angequetschter Kirschkerne setzt Benzaldehyd frei",
      "Zusatz von Bittermandelöl",
      "Fässer aus Mandelbaumholz",
      "Zugabe von Marzipanpaste"
    ],
    "correct": 0,
    "expEn": "Cherry stones release amygdalin, converting to aromatic benzaldehyde.",
    "expDe": "Die Kirschsteine enthalten Amygdalin, das zu feinem Benzaldehyd gespalten wird."
  },
  {
    "id": "q_wine_01",
    "category": "wine",
    "questionEn": "Why does Asti Spumante DOCG retain high sweetness and low alcohol?",
    "questionDe": "Warum hat Asti Spumante DOCG viel Restsüße und wenig Alkohol?",
    "optionsEn": [
      "Grapes grown in dark shade",
      "Cane sugar added",
      "Grape juice mixed with neutral spirits",
      "Fermentation is stopped early by refrigeration and pressure filtration"
    ],
    "optionsDe": [
      "Ohne Sonne angebaut",
      "Rohrzucker beigemischt",
      "Traubensaft mit Alkohol versetzt",
      "Gärung wird vorzeitig durch Kälte und Druckfiltration gestoppt"
    ],
    "correctIndex": 3,
    "explanationEn": "Asti method arrests fermentation at 7% ABV to capture natural grape sugar.",
    "explanationDe": "Kälte stoppt die Hefe vorzeitig ab, um natürliche Fruktose zu erhalten.",
    "qEn": "Why does Asti Spumante DOCG retain high sweetness and low alcohol?",
    "qDe": "Warum hat Asti Spumante DOCG viel Restsüße und wenig Alkohol?",
    "optEn": [
      "Grapes grown in dark shade",
      "Cane sugar added",
      "Grape juice mixed with neutral spirits",
      "Fermentation is stopped early by refrigeration and pressure filtration"
    ],
    "optDe": [
      "Ohne Sonne angebaut",
      "Rohrzucker beigemischt",
      "Traubensaft mit Alkohol versetzt",
      "Gärung wird vorzeitig durch Kälte und Druckfiltration gestoppt"
    ],
    "correct": 3,
    "expEn": "Asti method arrests fermentation at 7% ABV to capture natural grape sugar.",
    "expDe": "Kälte stoppt die Hefe vorzeitig ab, um natürliche Fruktose zu erhalten."
  },
  {
    "id": "q_wine_02",
    "category": "wine",
    "questionEn": "What is the function of the Liqueur de dosage in Champagne?",
    "questionDe": "Welche Funktion hat die Versanddosage beim Champagner?",
    "optionsEn": [
      "Colors wine red",
      "Kills yeast with sulfur",
      "Balances acidity and establishes the final sweetness style (Brut, Extra Dry)",
      "Creates the initial bubbles"
    ],
    "optionsDe": [
      "Färbt den Wein rot",
      "Tötet Hefe mit Schwefel",
      "Stellt die finale Geschmacksstufe (Brut, Extra Dry) und Süße-Balance ein",
      "Erzeugt die ersten Bläschen"
    ],
    "correctIndex": 2,
    "explanationEn": "Dosage balances high acidity after disgorgement.",
    "explanationDe": "Die Dosage gleicht Säure aus und definiert die Süßestufe.",
    "qEn": "What is the function of the Liqueur de dosage in Champagne?",
    "qDe": "Welche Funktion hat die Versanddosage beim Champagner?",
    "optEn": [
      "Colors wine red",
      "Kills yeast with sulfur",
      "Balances acidity and establishes the final sweetness style (Brut, Extra Dry)",
      "Creates the initial bubbles"
    ],
    "optDe": [
      "Färbt den Wein rot",
      "Tötet Hefe mit Schwefel",
      "Stellt die finale Geschmacksstufe (Brut, Extra Dry) und Süße-Balance ein",
      "Erzeugt die ersten Bläschen"
    ],
    "correct": 2,
    "expEn": "Dosage balances high acidity after disgorgement.",
    "expDe": "Die Dosage gleicht Säure aus und definiert die Süßestufe."
  },
  {
    "id": "q_wine_03",
    "category": "wine",
    "questionEn": "Why decant a young, tannic Barolo or Cabernet Sauvignon?",
    "questionDe": "Warum dekantiert man einen jungen, gerbstoffreichen Barolo?",
    "optionsEn": [
      "To extract sugar crystals",
      "Aeration softens aggressive tannins and releases volatile bouquet aromas",
      "To warm it to boiling",
      "To remove alcohol"
    ],
    "optionsDe": [
      "Um Zucker abzuscheiden",
      "Sauerstoffkontakt mildert schroffe Tannine und öffnet Bukettaromen",
      "Um ihn zu kochen",
      "Um Alkohol zu entziehen"
    ],
    "correctIndex": 1,
    "explanationEn": "Oxygen promotes polymerization of harsh catechin tannins.",
    "explanationDe": "Sauerstoff bindet scharfe Tannine und setzt Aromen frei.",
    "qEn": "Why decant a young, tannic Barolo or Cabernet Sauvignon?",
    "qDe": "Warum dekantiert man einen jungen, gerbstoffreichen Barolo?",
    "optEn": [
      "To extract sugar crystals",
      "Aeration softens aggressive tannins and releases volatile bouquet aromas",
      "To warm it to boiling",
      "To remove alcohol"
    ],
    "optDe": [
      "Um Zucker abzuscheiden",
      "Sauerstoffkontakt mildert schroffe Tannine und öffnet Bukettaromen",
      "Um ihn zu kochen",
      "Um Alkohol zu entziehen"
    ],
    "correct": 1,
    "expEn": "Oxygen promotes polymerization of harsh catechin tannins.",
    "expDe": "Sauerstoff bindet scharfe Tannine und setzt Aromen frei."
  },
  {
    "id": "q_wine_04",
    "category": "wine",
    "questionEn": "Which three grape varieties dominate traditional Champagne?",
    "questionDe": "Welche drei Rebsorten dominieren traditionellen Champagner?",
    "optionsEn": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "optionsDe": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "correctIndex": 0,
    "explanationEn": "These three varieties form over 99% of Champagne plantings.",
    "explanationDe": "Diese drei Sorten bilden das Rückgrat der Champagne.",
    "qEn": "Which three grape varieties dominate traditional Champagne?",
    "qDe": "Welche drei Rebsorten dominieren traditionellen Champagner?",
    "optEn": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "optDe": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "correct": 0,
    "expEn": "These three varieties form over 99% of Champagne plantings.",
    "expDe": "Diese drei Sorten bilden das Rückgrat der Champagne."
  },
  {
    "id": "q_wine_05",
    "category": "wine",
    "questionEn": "What happens during Malolactic Fermentation (MLF)?",
    "questionDe": "Was geschieht bei der Malolaktischen Gärung (BSA)?",
    "optionsEn": [
      "Acid precipitates as diamonds",
      "Sugar turns into alcohol",
      "Tannins turn to vinegar",
      "Sharp malic acid is converted by lactic bacteria into softer lactic acid and diacetyl"
    ],
    "optionsDe": [
      "Säure kristallisiert",
      "Zucker wird Alkohol",
      "Gerbstoff wird Essig",
      "Scharfe Äpfelsäure wird in milde Milchsäure und buttriges Diacetyl umgewandelt"
    ],
    "correctIndex": 3,
    "explanationEn": "MLF reduces perceived tartness and adds round creamy mouthfeel.",
    "explanationDe": "Milchsäurebakterien mildern die aggressive Äpfelsäure ab.",
    "qEn": "What happens during Malolactic Fermentation (MLF)?",
    "qDe": "Was geschieht bei der Malolaktischen Gärung (BSA)?",
    "optEn": [
      "Acid precipitates as diamonds",
      "Sugar turns into alcohol",
      "Tannins turn to vinegar",
      "Sharp malic acid is converted by lactic bacteria into softer lactic acid and diacetyl"
    ],
    "optDe": [
      "Säure kristallisiert",
      "Zucker wird Alkohol",
      "Gerbstoff wird Essig",
      "Scharfe Äpfelsäure wird in milde Milchsäure und buttriges Diacetyl umgewandelt"
    ],
    "correct": 3,
    "expEn": "MLF reduces perceived tartness and adds round creamy mouthfeel.",
    "expDe": "Milchsäurebakterien mildern die aggressive Äpfelsäure ab."
  },
  {
    "id": "q_wine_06",
    "category": "wine",
    "questionEn": "How does Botrytis cinerea create Sauternes and Trockenbeerenauslese?",
    "questionDe": "Wie erzeugt Botrytis cinerea Weltklasse-Edelsüßweine?",
    "optionsEn": [
      "Freezes grapes on vine",
      "Converts alcohol to sugar",
      "Fungus perforates grape skins, evaporating water and concentrating sugars and nectar",
      "Dyes grapes amber"
    ],
    "optionsDe": [
      "Lässt Beeren gefrieren",
      "Wandelt Alkohol in Zucker um",
      "Der Pilz perforiert Schalen, Wasser verdunstet, Zucker und Säure konzentrieren sich",
      "Färbt Beeren bernsteinfarben"
    ],
    "correctIndex": 2,
    "explanationEn": "Noble rot dehydrates berries while concentrating acids and honeyed aromatics.",
    "explanationDe": "Edelfäule lässt Wasser verdunsten und konzentriert Zucker und Aromen.",
    "qEn": "How does Botrytis cinerea create Sauternes and Trockenbeerenauslese?",
    "qDe": "Wie erzeugt Botrytis cinerea Weltklasse-Edelsüßweine?",
    "optEn": [
      "Freezes grapes on vine",
      "Converts alcohol to sugar",
      "Fungus perforates grape skins, evaporating water and concentrating sugars and nectar",
      "Dyes grapes amber"
    ],
    "optDe": [
      "Lässt Beeren gefrieren",
      "Wandelt Alkohol in Zucker um",
      "Der Pilz perforiert Schalen, Wasser verdunstet, Zucker und Säure konzentrieren sich",
      "Färbt Beeren bernsteinfarben"
    ],
    "correct": 2,
    "expEn": "Noble rot dehydrates berries while concentrating acids and honeyed aromatics.",
    "expDe": "Edelfäule lässt Wasser verdunsten und konzentriert Zucker und Aromen."
  },
  {
    "id": "q_wine_07",
    "category": "wine",
    "questionEn": "At what temperature must grapes be picked and pressed for German Eiswein?",
    "questionDe": "Bei welcher Mindestkälte müssen Eisweintrauben gelesen und gepresst werden?",
    "optionsEn": [
      "At 0°C",
      "At -7°C or colder",
      "At +4°C",
      "At -25°C strictly"
    ],
    "optionsDe": [
      "Bei 0°C",
      "Bei mindestens -7°C oder kälter",
      "Bei +4°C",
      "Bei exakt -25°C"
    ],
    "correctIndex": 1,
    "explanationEn": "Freezing leaves ice in the press, concentrating rich sugar syrup.",
    "explanationDe": "Das Wasser bleibt als Eis in der Kelter zurück; zuckersüßer Most fließt ab.",
    "qEn": "At what temperature must grapes be picked and pressed for German Eiswein?",
    "qDe": "Bei welcher Mindestkälte müssen Eisweintrauben gelesen und gepresst werden?",
    "optEn": [
      "At 0°C",
      "At -7°C or colder",
      "At +4°C",
      "At -25°C strictly"
    ],
    "optDe": [
      "Bei 0°C",
      "Bei mindestens -7°C oder kälter",
      "Bei +4°C",
      "Bei exakt -25°C"
    ],
    "correct": 1,
    "expEn": "Freezing leaves ice in the press, concentrating rich sugar syrup.",
    "expDe": "Das Wasser bleibt als Eis in der Kelter zurück; zuckersüßer Most fließt ab."
  },
  {
    "id": "q_wine_08",
    "category": "wine",
    "questionEn": "Why does tannic red wine pair brilliantly with marbled beef steak?",
    "questionDe": "Warum passt gerbstoffbetonter Rotwein ideal zu marmoriertem Steak?",
    "optionsEn": [
      "Meat fats and proteins bind to astringent saliva-coating tannins",
      "Fat neutralizes alcohol into water",
      "Wine dissolves meat fibers",
      "Tannins cook the meat"
    ],
    "optionsDe": [
      "Fett und Eiweiß binden herbe Gerbstoffe und mildern Adstringenz",
      "Fett macht Alkohol zu Wasser",
      "Wein löst Fleischfasern auf",
      "Tannine garen das Fleisch"
    ],
    "correctIndex": 0,
    "explanationEn": "Proteins buffer oral tannin perception, smoothing the mouthfeel.",
    "explanationDe": "Fleischeiweiße neutralisieren die pelzige Wirkung der Gerbstoffe am Gaumen.",
    "qEn": "Why does tannic red wine pair brilliantly with marbled beef steak?",
    "qDe": "Warum passt gerbstoffbetonter Rotwein ideal zu marmoriertem Steak?",
    "optEn": [
      "Meat fats and proteins bind to astringent saliva-coating tannins",
      "Fat neutralizes alcohol into water",
      "Wine dissolves meat fibers",
      "Tannins cook the meat"
    ],
    "optDe": [
      "Fett und Eiweiß binden herbe Gerbstoffe und mildern Adstringenz",
      "Fett macht Alkohol zu Wasser",
      "Wein löst Fleischfasern auf",
      "Tannine garen das Fleisch"
    ],
    "correct": 0,
    "expEn": "Proteins buffer oral tannin perception, smoothing the mouthfeel.",
    "expDe": "Fleischeiweiße neutralisieren die pelzige Wirkung der Gerbstoffe am Gaumen."
  },
  {
    "id": "q_wine_09",
    "category": "wine",
    "questionEn": "What is meant by 'Terroir' in viticulture?",
    "questionDe": "Was umfasst der französische Begriff 'Terroir'?",
    "optionsEn": [
      "Fertilizer brand used",
      "Only bottle glass design",
      "Only vineyard land price",
      "Interplay of soil, climate, topography, and human craftsmanship"
    ],
    "optionsDe": [
      "Die Düngermarke",
      "Nur das Flaschendesign",
      "Nur den Hektarpreis",
      "Zusammenspiel von Boden, Mikroklima, Hangneigung und Winzerhandwerk"
    ],
    "correctIndex": 3,
    "explanationEn": "Terroir represents the holistic identity of geographical origin.",
    "explanationDe": "Terroir vereint natürliche Gegebenheiten und menschliche Tradition.",
    "qEn": "What is meant by 'Terroir' in viticulture?",
    "qDe": "Was umfasst der französische Begriff 'Terroir'?",
    "optEn": [
      "Fertilizer brand used",
      "Only bottle glass design",
      "Only vineyard land price",
      "Interplay of soil, climate, topography, and human craftsmanship"
    ],
    "optDe": [
      "Die Düngermarke",
      "Nur das Flaschendesign",
      "Nur den Hektarpreis",
      "Zusammenspiel von Boden, Mikroklima, Hangneigung und Winzerhandwerk"
    ],
    "correct": 3,
    "expEn": "Terroir represents the holistic identity of geographical origin.",
    "expDe": "Terroir vereint natürliche Gegebenheiten und menschliche Tradition."
  },
  {
    "id": "q_wine_10",
    "category": "wine",
    "questionEn": "How does the Solera blending system work for Jerez Sherry?",
    "questionDe": "Wie funktioniert das Solera-System beim andalusischen Sherry?",
    "optionsEn": [
      "Straw mat dried raisins only",
      "Heated in ovens for months",
      "Wine drawn from bottom barrels is refreshed continuously from younger tiers above",
      "Aged 100 years untouched"
    ],
    "optionsDe": [
      "Auf Strohmatten getrocknet",
      "Im Heißofen erwärmt",
      "Entnommener Wein der untersten Reihe wird schrittweise von oben nachgefüllt",
      "100 Jahre unberührt"
    ],
    "correctIndex": 2,
    "explanationEn": "Fractional blending maintains stylistic continuity over generations.",
    "explanationDe": "Kaskadierendes Verschneiden garantiert über Jahrzehnte gleichbleibende Güte.",
    "qEn": "How does the Solera blending system work for Jerez Sherry?",
    "qDe": "Wie funktioniert das Solera-System beim andalusischen Sherry?",
    "optEn": [
      "Straw mat dried raisins only",
      "Heated in ovens for months",
      "Wine drawn from bottom barrels is refreshed continuously from younger tiers above",
      "Aged 100 years untouched"
    ],
    "optDe": [
      "Auf Strohmatten getrocknet",
      "Im Heißofen erwärmt",
      "Entnommener Wein der untersten Reihe wird schrittweise von oben nachgefüllt",
      "100 Jahre unberührt"
    ],
    "correct": 2,
    "expEn": "Fractional blending maintains stylistic continuity over generations.",
    "expDe": "Kaskadierendes Verschneiden garantiert über Jahrzehnte gleichbleibende Güte."
  },
  {
    "id": "q_wine_11",
    "category": "wine",
    "questionEn": "What is 'Flor' yeast in Sherry production?",
    "questionDe": "Was ist der 'Flor' beim Fino-Sherry?",
    "optionsEn": [
      "Raisin syrup additive",
      "Biological yeast veil floating on wine surface preventing oxidation",
      "Wood rot fungus",
      "Artificial chemical"
    ],
    "optionsDe": [
      "Rosinensirup",
      "Schwimmende Hefedecke, die den Wein hermetisch vor Sauerstoff schützt",
      "Holzpilz",
      "Chemisches Pulver"
    ],
    "correctIndex": 1,
    "explanationEn": "Flor shields Fino from oxygen and creates crisp nutty saline flavors.",
    "explanationDe": "Flor schützt vor Luft und schenkt Noten von Mandeln und Meersalz.",
    "qEn": "What is 'Flor' yeast in Sherry production?",
    "qDe": "Was ist der 'Flor' beim Fino-Sherry?",
    "optEn": [
      "Raisin syrup additive",
      "Biological yeast veil floating on wine surface preventing oxidation",
      "Wood rot fungus",
      "Artificial chemical"
    ],
    "optDe": [
      "Rosinensirup",
      "Schwimmende Hefedecke, die den Wein hermetisch vor Sauerstoff schützt",
      "Holzpilz",
      "Chemisches Pulver"
    ],
    "correct": 1,
    "expEn": "Flor shields Fino from oxygen and creates crisp nutty saline flavors.",
    "expDe": "Flor schützt vor Luft und schenkt Noten von Mandeln und Meersalz."
  },
  {
    "id": "q_wine_12",
    "category": "wine",
    "questionEn": "Which compound causes the 'Cork Taint' fault?",
    "questionDe": "Welche Verbindung verursacht den typischen 'Korkschmecker'?",
    "optionsEn": [
      "2,4,6-Trichloroanisole (TCA)",
      "Ethyl acetate",
      "Sulfur dioxide",
      "Lactic acid"
    ],
    "optionsDe": [
      "2,4,6-Trichloranisol (TCA)",
      "Ethylacetat",
      "Schwefeldioxid",
      "Milchsäure"
    ],
    "correctIndex": 0,
    "explanationEn": "TCA causes musty damp cardboard smells at tiny parts-per-trillion.",
    "explanationDe": "TCA erzeugt selbst in Nanogrammen Geruch nach feuchtem Kellerkarton.",
    "qEn": "Which compound causes the 'Cork Taint' fault?",
    "qDe": "Welche Verbindung verursacht den typischen 'Korkschmecker'?",
    "optEn": [
      "2,4,6-Trichloroanisole (TCA)",
      "Ethyl acetate",
      "Sulfur dioxide",
      "Lactic acid"
    ],
    "optDe": [
      "2,4,6-Trichloranisol (TCA)",
      "Ethylacetat",
      "Schwefeldioxid",
      "Milchsäure"
    ],
    "correct": 0,
    "expEn": "TCA causes musty damp cardboard smells at tiny parts-per-trillion.",
    "expDe": "TCA erzeugt selbst in Nanogrammen Geruch nach feuchtem Kellerkarton."
  },
  {
    "id": "q_wine_13",
    "category": "wine",
    "questionEn": "Why is Pinot Noir considered the most terroir-transparent grape?",
    "questionDe": "Warum gilt Pinot Noir als die terroir-empfindlichste Rebsorte?",
    "optionsEn": [
      "Requires artificial yeast",
      "Grows in volcanic soil only",
      "Never ripens fully",
      "Thin skins and low pigment directly transmit soil and microclimate nuances"
    ],
    "optionsDe": [
      "Braucht Reinzuchthefen",
      "Wächst nur auf Vulkanboden",
      "Wird nie reif",
      "Dünne Beerenhaut und feine Pigmente spiegeln Boden und Klima präzise wider"
    ],
    "correctIndex": 3,
    "explanationEn": "Its delicate anthocyanins and low tannin expose subtle site differences.",
    "explanationDe": "Wegen feiner Tannine schmeckt man kleinste Lagenunterschiede sofort heraus.",
    "qEn": "Why is Pinot Noir considered the most terroir-transparent grape?",
    "qDe": "Warum gilt Pinot Noir als die terroir-empfindlichste Rebsorte?",
    "optEn": [
      "Requires artificial yeast",
      "Grows in volcanic soil only",
      "Never ripens fully",
      "Thin skins and low pigment directly transmit soil and microclimate nuances"
    ],
    "optDe": [
      "Braucht Reinzuchthefen",
      "Wächst nur auf Vulkanboden",
      "Wird nie reif",
      "Dünne Beerenhaut und feine Pigmente spiegeln Boden und Klima präzise wider"
    ],
    "correct": 3,
    "expEn": "Its delicate anthocyanins and low tannin expose subtle site differences.",
    "expDe": "Wegen feiner Tannine schmeckt man kleinste Lagenunterschiede sofort heraus."
  },
  {
    "id": "q_wine_14",
    "category": "wine",
    "questionEn": "Why must mature Vintage Port be decanted through a fine strainer?",
    "questionDe": "Warum muss reifer Vintage Port filtriert und dekantiert werden?",
    "optionsEn": [
      "To lower alcohol vapor",
      "To separate sugar crystals",
      "Bottled unfiltered after 2 years, casting heavy sediment over decades",
      "Cork dissolves inside"
    ],
    "optionsDe": [
      "Um Alkohol zu senken",
      "Um Zucker abzuscheiden",
      "Nach nur 2 Jahren unfiltriert abgefüllt; bildet massives Flaschendepot",
      "Kork löst sich auf"
    ],
    "correctIndex": 2,
    "explanationEn": "Polymerized tannins fall out as thick crust over 20-50 years in glass.",
    "explanationDe": "Gerbstoffe und Farbstoffe flocken über Jahrzehnte als schweres Depot aus.",
    "qEn": "Why must mature Vintage Port be decanted through a fine strainer?",
    "qDe": "Warum muss reifer Vintage Port filtriert und dekantiert werden?",
    "optEn": [
      "To lower alcohol vapor",
      "To separate sugar crystals",
      "Bottled unfiltered after 2 years, casting heavy sediment over decades",
      "Cork dissolves inside"
    ],
    "optDe": [
      "Um Alkohol zu senken",
      "Um Zucker abzuscheiden",
      "Nach nur 2 Jahren unfiltriert abgefüllt; bildet massives Flaschendepot",
      "Kork löst sich auf"
    ],
    "correct": 2,
    "expEn": "Polymerized tannins fall out as thick crust over 20-50 years in glass.",
    "expDe": "Gerbstoffe und Farbstoffe flocken über Jahrzehnte als schweres Depot aus."
  },
  {
    "id": "q_wine_15",
    "category": "wine",
    "questionEn": "What is the Appassimento method in Amarone della Valpolicella?",
    "questionDe": "Was ist das Appassimento-Verfahren beim Amarone?",
    "optionsEn": [
      "Freezing in mountain snow",
      "Drying harvested grapes on wooden trays for months to concentrate sugar and extract",
      "Fortifying must with brandy",
      "Boiling grape juice"
    ],
    "optionsDe": [
      "Im Schnee gefrieren",
      "Monatelanges Antrocknen der Trauben auf Holzgestellen zur Saftkonzentration",
      "Mit Weingeist aufspriten",
      "Most einkochen"
    ],
    "correctIndex": 1,
    "explanationEn": "Grapes lose 30-40% water weight, producing rich dry wines with high extract.",
    "explanationDe": "Trauben verlieren bis zu 40% Wasser; der konzentrierte Most vergärt trocken.",
    "qEn": "What is the Appassimento method in Amarone della Valpolicella?",
    "qDe": "Was ist das Appassimento-Verfahren beim Amarone?",
    "optEn": [
      "Freezing in mountain snow",
      "Drying harvested grapes on wooden trays for months to concentrate sugar and extract",
      "Fortifying must with brandy",
      "Boiling grape juice"
    ],
    "optDe": [
      "Im Schnee gefrieren",
      "Monatelanges Antrocknen der Trauben auf Holzgestellen zur Saftkonzentration",
      "Mit Weingeist aufspriten",
      "Most einkochen"
    ],
    "correct": 1,
    "expEn": "Grapes lose 30-40% water weight, producing rich dry wines with high extract.",
    "expDe": "Trauben verlieren bis zu 40% Wasser; der konzentrierte Most vergärt trocken."
  },
  {
    "id": "q_wine_16",
    "category": "wine",
    "questionEn": "Why can German Mosel Riesling age for 30+ years despite low alcohol?",
    "questionDe": "Warum altert Mosel-Riesling trotz geringen Alkohols exzellent über Jahrzehnte?",
    "optionsEn": [
      "High natural fruit acidity, mineral extract, and residual sugar preserve it",
      "Fortified with neutral brandy",
      "Sealed with hot wax",
      "Aged in deep new oak"
    ],
    "optionsDe": [
      "Hohe natürliche Weinsäure, Mineralität und harmonischer Zucker konservieren",
      "Mit Schnaps aufgespritet",
      "Mit Wachs versiegelt",
      "Im Neuholz gereift"
    ],
    "correctIndex": 0,
    "explanationEn": "Low pH and vibrant acids resist oxidation for decades.",
    "explanationDe": "Hohe Weinsäure und niedriger pH-Wert schützen vor dem Verfall.",
    "qEn": "Why can German Mosel Riesling age for 30+ years despite low alcohol?",
    "qDe": "Warum altert Mosel-Riesling trotz geringen Alkohols exzellent über Jahrzehnte?",
    "optEn": [
      "High natural fruit acidity, mineral extract, and residual sugar preserve it",
      "Fortified with neutral brandy",
      "Sealed with hot wax",
      "Aged in deep new oak"
    ],
    "optDe": [
      "Hohe natürliche Weinsäure, Mineralität und harmonischer Zucker konservieren",
      "Mit Schnaps aufgespritet",
      "Mit Wachs versiegelt",
      "Im Neuholz gereift"
    ],
    "correct": 0,
    "expEn": "Low pH and vibrant acids resist oxidation for decades.",
    "expDe": "Hohe Weinsäure und niedriger pH-Wert schützen vor dem Verfall."
  },
  {
    "id": "q_wine_17",
    "category": "wine",
    "questionEn": "How is Prosecco Superiore DOCG made sparkling?",
    "questionDe": "Wie entsteht die Kohlensäure bei Prosecco Superiore DOCG?",
    "optionsEn": [
      "Dry ice added",
      "Bottle fermentation like Champagne",
      "Injected CO2 gas",
      "Secondary fermentation in stainless steel pressure autoclaves (Charmat method)"
    ],
    "optionsDe": [
      "Trockeneiszugabe",
      "Flaschengärung wie Champagner",
      "Kohlensäure eingepumpt",
      "Zweite Gärung im Edelstahldrucktank (Charmat-/Martinotti-Verfahren)"
    ],
    "correctIndex": 3,
    "explanationEn": "Tank fermentation preserves fresh floral and fruit aromatics of Glera.",
    "explanationDe": "Die Tankgärung bewahrt die frischen Primäraromen der Glera-Traube.",
    "qEn": "How is Prosecco Superiore DOCG made sparkling?",
    "qDe": "Wie entsteht die Kohlensäure bei Prosecco Superiore DOCG?",
    "optEn": [
      "Dry ice added",
      "Bottle fermentation like Champagne",
      "Injected CO2 gas",
      "Secondary fermentation in stainless steel pressure autoclaves (Charmat method)"
    ],
    "optDe": [
      "Trockeneiszugabe",
      "Flaschengärung wie Champagner",
      "Kohlensäure eingepumpt",
      "Zweite Gärung im Edelstahldrucktank (Charmat-/Martinotti-Verfahren)"
    ],
    "correct": 3,
    "expEn": "Tank fermentation preserves fresh floral and fruit aromatics of Glera.",
    "expDe": "Die Tankgärung bewahrt die frischen Primäraromen der Glera-Traube."
  },
  {
    "id": "q_wine_18",
    "category": "wine",
    "questionEn": "What defines Orange Wine?",
    "questionDe": "Was kennzeichnet sogenannten Orange Wine?",
    "optionsEn": [
      "Fermented Spanish oranges",
      "White wine with orange zest",
      "White grapes fermented with skins and seeds for weeks/months like red wine",
      "Red wine bleached with charcoal"
    ],
    "optionsDe": [
      "Aus Orangen vergoren",
      "Weißwein mit Zitrusschale",
      "Weißweintrauben werden wie Rotwein lange auf der Maische (Schalen) vergoren",
      "Mit Kohle entfärbter Rotwein"
    ],
    "correctIndex": 2,
    "explanationEn": "Skin contact gives amber hue and tannic structure to white grapes.",
    "explanationDe": "Die Maischegärung verleiht dem Weißwein Gerbstoffe und Bernsteinfarbe.",
    "qEn": "What defines Orange Wine?",
    "qDe": "Was kennzeichnet sogenannten Orange Wine?",
    "optEn": [
      "Fermented Spanish oranges",
      "White wine with orange zest",
      "White grapes fermented with skins and seeds for weeks/months like red wine",
      "Red wine bleached with charcoal"
    ],
    "optDe": [
      "Aus Orangen vergoren",
      "Weißwein mit Zitrusschale",
      "Weißweintrauben werden wie Rotwein lange auf der Maische (Schalen) vergoren",
      "Mit Kohle entfärbter Rotwein"
    ],
    "correct": 2,
    "expEn": "Skin contact gives amber hue and tannic structure to white grapes.",
    "expDe": "Die Maischegärung verleiht dem Weißwein Gerbstoffe und Bernsteinfarbe."
  },
  {
    "id": "q_tea_01",
    "category": "tea",
    "questionEn": "Which essential oil gives Earl Grey tea its citrus aroma?",
    "questionDe": "Welches ätherische Öl aromatisiert klassischen Earl Grey Tee?",
    "optionsEn": [
      "Lemon grass oil",
      "Bergamot orange peel oil",
      "Orange blossom water",
      "Lime leaf oil"
    ],
    "optionsDe": [
      "Zitronengrasöl",
      "Öl aus der Schale der Bergamotte",
      "Orangenblütenwasser",
      "Limettenblattöl"
    ],
    "correctIndex": 1,
    "explanationEn": "Earl Grey is black tea scented with oil of Citrus bergamia.",
    "explanationDe": "Earl Grey wird mit kaltgepresstem Bergamottöl aromatisiert.",
    "qEn": "Which essential oil gives Earl Grey tea its citrus aroma?",
    "qDe": "Welches ätherische Öl aromatisiert klassischen Earl Grey Tee?",
    "optEn": [
      "Lemon grass oil",
      "Bergamot orange peel oil",
      "Orange blossom water",
      "Lime leaf oil"
    ],
    "optDe": [
      "Zitronengrasöl",
      "Öl aus der Schale der Bergamotte",
      "Orangenblütenwasser",
      "Limettenblattöl"
    ],
    "correct": 1,
    "expEn": "Earl Grey is black tea scented with oil of Citrus bergamia.",
    "expDe": "Earl Grey wird mit kaltgepresstem Bergamottöl aromatisiert."
  },
  {
    "id": "q_tea_02",
    "category": "tea",
    "questionEn": "Why are Matcha tea bushes shaded before harvest?",
    "questionDe": "Warum werden Matcha-Teesträucher vor der Ernte wochenlang beschattet?",
    "optionsEn": [
      "Increases chlorophyll and L-theanine for intense umami and sweet notes",
      "Protects against hail",
      "Dries leaves on bush",
      "Reduces caffeine to zero"
    ],
    "optionsDe": [
      "Fördert Chlorophyll und L-Theanin für tiefes Umami und mindert Bitterkeit",
      "Schützt vor Hagel",
      "Dörrt Blätter am Strauch",
      "Senkt Koffein auf null"
    ],
    "correctIndex": 0,
    "explanationEn": "Shading blocks photosynthesis, preserving savory theanine amino acids.",
    "explanationDe": "Lichtentzug verhindert den Abbau von süßem L-Theanin zu herben Catechinen.",
    "qEn": "Why are Matcha tea bushes shaded before harvest?",
    "qDe": "Warum werden Matcha-Teesträucher vor der Ernte wochenlang beschattet?",
    "optEn": [
      "Increases chlorophyll and L-theanine for intense umami and sweet notes",
      "Protects against hail",
      "Dries leaves on bush",
      "Reduces caffeine to zero"
    ],
    "optDe": [
      "Fördert Chlorophyll und L-Theanin für tiefes Umami und mindert Bitterkeit",
      "Schützt vor Hagel",
      "Dörrt Blätter am Strauch",
      "Senkt Koffein auf null"
    ],
    "correct": 0,
    "expEn": "Shading blocks photosynthesis, preserving savory theanine amino acids.",
    "expDe": "Lichtentzug verhindert den Abbau von süßem L-Theanin zu herben Catechinen."
  },
  {
    "id": "q_tea_03",
    "category": "tea",
    "questionEn": "Why should high-grade Japanese green tea (Gyokuro) never be brewed with 100°C water?",
    "questionDe": "Warum darf edler Gyokuro-Grüntee nicht mit kochendem 100°C Wasser gebrüht werden?",
    "optionsEn": [
      "Leaves dissolve completely",
      "Boiling destroys caffeine",
      "Tea cup cracks",
      "Boiling water scalds leaves and extracts bitter catechins excessively"
    ],
    "optionsDe": [
      "Blätter lösen sich auf",
      "Kochen zerstört Koffein",
      "Tassen zerspringen",
      "Kochendes Wasser löst aggressive Bitterstoffe und zerstört zartes Umami"
    ],
    "correctIndex": 3,
    "explanationEn": "60°C to 70°C gently extracts amino acids without bitter tannin astringency.",
    "explanationDe": "Ideale Temperaturen von 60-70°C lösen Aminosäuren ohne aggressive Herbe.",
    "qEn": "Why should high-grade Japanese green tea (Gyokuro) never be brewed with 100°C water?",
    "qDe": "Warum darf edler Gyokuro-Grüntee nicht mit kochendem 100°C Wasser gebrüht werden?",
    "optEn": [
      "Leaves dissolve completely",
      "Boiling destroys caffeine",
      "Tea cup cracks",
      "Boiling water scalds leaves and extracts bitter catechins excessively"
    ],
    "optDe": [
      "Blätter lösen sich auf",
      "Kochen zerstört Koffein",
      "Tassen zerspringen",
      "Kochendes Wasser löst aggressive Bitterstoffe und zerstört zartes Umami"
    ],
    "correct": 3,
    "expEn": "60°C to 70°C gently extracts amino acids without bitter tannin astringency.",
    "expDe": "Ideale Temperaturen von 60-70°C lösen Aminosäuren ohne aggressive Herbe."
  },
  {
    "id": "q_tea_04",
    "category": "tea",
    "questionEn": "What defines Oolong tea in processing?",
    "questionDe": "Was zeichnet Oolong-Tee verarbeitungstechnisch aus?",
    "optionsEn": [
      "Smoked over pine wood",
      "Underground vinegar fermented",
      "Semi-oxidized (partially fermented) between green and black tea (15-80%)",
      "100% white tea buds"
    ],
    "optionsDe": [
      "Über Kiefernholz geräuchert",
      "Mit Essig fermentiert",
      "Teilfermentiert (teiloxidiert) zwischen Grün- und Schwarztee (15-80%)",
      "Reine weiße Knospen"
    ],
    "correctIndex": 2,
    "explanationEn": "Controlled bruising and roasting create complex floral and roasted fruit nuances.",
    "explanationDe": "Durch gezieltes Anschlagen der Blattränder wird der Oxidationsgrad präzise gesteuert.",
    "qEn": "What defines Oolong tea in processing?",
    "qDe": "Was zeichnet Oolong-Tee verarbeitungstechnisch aus?",
    "optEn": [
      "Smoked over pine wood",
      "Underground vinegar fermented",
      "Semi-oxidized (partially fermented) between green and black tea (15-80%)",
      "100% white tea buds"
    ],
    "optDe": [
      "Über Kiefernholz geräuchert",
      "Mit Essig fermentiert",
      "Teilfermentiert (teiloxidiert) zwischen Grün- und Schwarztee (15-80%)",
      "Reine weiße Knospen"
    ],
    "correct": 2,
    "expEn": "Controlled bruising and roasting create complex floral and roasted fruit nuances.",
    "expDe": "Durch gezieltes Anschlagen der Blattränder wird der Oxidationsgrad präzise gesteuert."
  },
  {
    "id": "q_tea_05",
    "category": "tea",
    "questionEn": "What distinguishes Darjeeling First Flush from Second Flush?",
    "questionDe": "Was unterscheidet Darjeeling First Flush von Second Flush?",
    "optionsEn": [
      "First Flush is mint tea",
      "First Flush is spring harvested, pale, brisk, and floral; Second Flush is amber and muscatel",
      "First Flush has zero caffeine",
      "Second Flush is artificially flavored"
    ],
    "optionsDe": [
      "First Flush ist Kräutertee",
      "First Flush (Frühjahr) ist spritzig-hell und blumig; Second Flush ist bernsteinfarben mit Muskatellernote",
      "First Flush hat kein Koffein",
      "Second Flush ist künstlich aromatisiert"
    ],
    "correctIndex": 1,
    "explanationEn": "Spring flushes yield fresh green brightness; summer sun develops ripe muscatel notes.",
    "explanationDe": "Die Frühjahrsernte bringt zarte Frische, die Sommersonne reife Muskatellertöne.",
    "qEn": "What distinguishes Darjeeling First Flush from Second Flush?",
    "qDe": "Was unterscheidet Darjeeling First Flush von Second Flush?",
    "optEn": [
      "First Flush is mint tea",
      "First Flush is spring harvested, pale, brisk, and floral; Second Flush is amber and muscatel",
      "First Flush has zero caffeine",
      "Second Flush is artificially flavored"
    ],
    "optDe": [
      "First Flush ist Kräutertee",
      "First Flush (Frühjahr) ist spritzig-hell und blumig; Second Flush ist bernsteinfarben mit Muskatellernote",
      "First Flush hat kein Koffein",
      "Second Flush ist künstlich aromatisiert"
    ],
    "correct": 1,
    "expEn": "Spring flushes yield fresh green brightness; summer sun develops ripe muscatel notes.",
    "expDe": "Die Frühjahrsernte bringt zarte Frische, die Sommersonne reife Muskatellertöne."
  },
  {
    "id": "q_tea_06",
    "category": "tea",
    "questionEn": "Where is caffeine-free Rooibos tea cultivated?",
    "questionDe": "Wo wird der koffeinfreie Rooibos-Tee angebaut?",
    "optionsEn": [
      "Cederberg mountains of South Africa",
      "Mount Fuji in Japan",
      "Argentine pampas",
      "Atlas mountains in Morocco"
    ],
    "optionsDe": [
      "Cederberge in Südafrika",
      "Fuji in Japan",
      "Argentinische Pampa",
      "Atlasgebirge in Marokko"
    ],
    "correctIndex": 0,
    "explanationEn": "Aspalathus linearis is endemic to the Western Cape of South Africa.",
    "explanationDe": "Rooibos wächst als endemischer Rotbusch ausschließlich in Südafrika.",
    "qEn": "Where is caffeine-free Rooibos tea cultivated?",
    "qDe": "Wo wird der koffeinfreie Rooibos-Tee angebaut?",
    "optEn": [
      "Cederberg mountains of South Africa",
      "Mount Fuji in Japan",
      "Argentine pampas",
      "Atlas mountains in Morocco"
    ],
    "optDe": [
      "Cederberge in Südafrika",
      "Fuji in Japan",
      "Argentinische Pampa",
      "Atlasgebirge in Marokko"
    ],
    "correct": 0,
    "expEn": "Aspalathus linearis is endemic to the Western Cape of South Africa.",
    "expDe": "Rooibos wächst als endemischer Rotbusch ausschließlich in Südafrika."
  },
  {
    "id": "q_tea_07",
    "category": "tea",
    "questionEn": "What describes Pai Mu Tan (White Peony) processing?",
    "questionDe": "Was kennzeichnet die Herstellung von Weißem Tee (Pai Mu Tan)?",
    "optionsEn": [
      "Smoked in bamboo baskets",
      "Heavy charcoal roasting",
      "Crushed by rollers",
      "Minimal processing: young silvery buds and leaves naturally sun-withered without rolling"
    ],
    "optionsDe": [
      "In Bambus geräuchert",
      "Starke Röstung",
      "Maschinell zerkleinert",
      "Minimale Verarbeitung: zarte Knospen werden nur sonnengetrocknet, ohne Rollen oder Hitze"
    ],
    "correctIndex": 3,
    "explanationEn": "White tea is the least processed tea, retaining silvery down hairs and sweet melon notes.",
    "explanationDe": "Weißer Tee wird kaum bearbeitet und behält seinen samtig-milden Charakter.",
    "qEn": "What describes Pai Mu Tan (White Peony) processing?",
    "qDe": "Was kennzeichnet die Herstellung von Weißem Tee (Pai Mu Tan)?",
    "optEn": [
      "Smoked in bamboo baskets",
      "Heavy charcoal roasting",
      "Crushed by rollers",
      "Minimal processing: young silvery buds and leaves naturally sun-withered without rolling"
    ],
    "optDe": [
      "In Bambus geräuchert",
      "Starke Röstung",
      "Maschinell zerkleinert",
      "Minimale Verarbeitung: zarte Knospen werden nur sonnengetrocknet, ohne Rollen oder Hitze"
    ],
    "correct": 3,
    "expEn": "White tea is the least processed tea, retaining silvery down hairs and sweet melon notes.",
    "expDe": "Weißer Tee wird kaum bearbeitet und behält seinen samtig-milden Charakter."
  },
  {
    "id": "q_tea_08",
    "category": "tea",
    "questionEn": "How is Chinese Jasmine tea naturally scented?",
    "questionDe": "Wie wird traditioneller Jasmintee aromatisiert?",
    "optionsEn": [
      "Boiled in jasmine water",
      "Jasmine oil is sprayed",
      "Fresh night-blooming jasmine blossoms are layered with green tea leaves repeatedly",
      "Stored in jasmine wood"
    ],
    "optionsDe": [
      "In Jasminwasser gekocht",
      "Jasminöl wird aufgesprüht",
      "Frische, nachts duftende Jasminblüten werden schichtweise mit Teeblättern vermengt",
      "In Jasmingefäßen gelagert"
    ],
    "correctIndex": 2,
    "explanationEn": "Green tea leaves absorb the natural essential oils of opening flowers.",
    "explanationDe": "Teeblätter nehmen das ätherische Öl frisch aufblühender Jasminblüten auf.",
    "qEn": "How is Chinese Jasmine tea naturally scented?",
    "qDe": "Wie wird traditioneller Jasmintee aromatisiert?",
    "optEn": [
      "Boiled in jasmine water",
      "Jasmine oil is sprayed",
      "Fresh night-blooming jasmine blossoms are layered with green tea leaves repeatedly",
      "Stored in jasmine wood"
    ],
    "optDe": [
      "In Jasminwasser gekocht",
      "Jasminöl wird aufgesprüht",
      "Frische, nachts duftende Jasminblüten werden schichtweise mit Teeblättern vermengt",
      "In Jasmingefäßen gelagert"
    ],
    "correct": 2,
    "expEn": "Green tea leaves absorb the natural essential oils of opening flowers.",
    "expDe": "Teeblätter nehmen das ätherische Öl frisch aufblühender Jasminblüten auf."
  },
  {
    "id": "q_tea_09",
    "category": "tea",
    "questionEn": "What transformation occurs during aging of Pu-Erh tea?",
    "questionDe": "Was passiert während der Reifung von Pu-Erh-Tee?",
    "optionsEn": [
      "Alcoholic fermentation into beer",
      "True post-fermentation driven by microbial fungi and bacteria over years",
      "Carbonation by yeast",
      "Dairy yogurt fermentation"
    ],
    "optionsDe": [
      "Alkoholische Gärung",
      "Echte mikrobielle Nachfermentation durch Edelschimmel und Bakterien über Jahre",
      "Kohlensäurebildung",
      "Milchsäuregärung"
    ],
    "correctIndex": 1,
    "explanationEn": "Pu-Erh matures living cultures, developing earthy, forest floor and leather aromatics.",
    "explanationDe": "Pu-Erh reift mikrobiell und entwickelt tiefe erdige, holzige Noten.",
    "qEn": "What transformation occurs during aging of Pu-Erh tea?",
    "qDe": "Was passiert während der Reifung von Pu-Erh-Tee?",
    "optEn": [
      "Alcoholic fermentation into beer",
      "True post-fermentation driven by microbial fungi and bacteria over years",
      "Carbonation by yeast",
      "Dairy yogurt fermentation"
    ],
    "optDe": [
      "Alkoholische Gärung",
      "Echte mikrobielle Nachfermentation durch Edelschimmel und Bakterien über Jahre",
      "Kohlensäurebildung",
      "Milchsäuregärung"
    ],
    "correct": 1,
    "expEn": "Pu-Erh matures living cultures, developing earthy, forest floor and leather aromatics.",
    "expDe": "Pu-Erh reift mikrobiell und entwickelt tiefe erdige, holzige Noten."
  },
  {
    "id": "q_tea_10",
    "category": "tea",
    "questionEn": "Which tea region gives English Breakfast its bold malty body?",
    "questionDe": "Welche Teeregion schenkt dem English Breakfast seinen malzigen Körper?",
    "optionsEn": [
      "Assam in India",
      "Darjeeling",
      "Japanese Shizuoka",
      "Fujian white tea"
    ],
    "optionsDe": [
      "Assam in Indien",
      "Darjeeling",
      "Shizuoka in Japan",
      "Fujian in China"
    ],
    "correctIndex": 0,
    "explanationEn": "Assam black tea provides deep malty strength that cuts through whole milk.",
    "explanationDe": "Assam liefert den kräftigen Malzkörper, der perfekt mit Milch harmoniert.",
    "qEn": "Which tea region gives English Breakfast its bold malty body?",
    "qDe": "Welche Teeregion schenkt dem English Breakfast seinen malzigen Körper?",
    "optEn": [
      "Assam in India",
      "Darjeeling",
      "Japanese Shizuoka",
      "Fujian white tea"
    ],
    "optDe": [
      "Assam in Indien",
      "Darjeeling",
      "Shizuoka in Japan",
      "Fujian in China"
    ],
    "correct": 0,
    "expEn": "Assam black tea provides deep malty strength that cuts through whole milk.",
    "expDe": "Assam liefert den kräftigen Malzkörper, der perfekt mit Milch harmoniert."
  },
  {
    "id": "q_tea_11",
    "category": "tea",
    "questionEn": "How is Lapsang Souchong smoked?",
    "questionDe": "Wie wird Lapsang Souchong geräuchert?",
    "optionsEn": [
      "In peated whisky barrels",
      "With liquid hickory smoke",
      "Over volcanic coals",
      "Over burning pine wood fires (Pinus massoniana)"
    ],
    "optionsDe": [
      "In Torffässern",
      "Mit künstlichem Raucharoma",
      "Über Vulkankohle",
      "Über brennendem harzreichem Kiefernholzfeuer"
    ],
    "correctIndex": 3,
    "explanationEn": "Pine resin smoke permeates the tea cells with campfire and dried prune notes.",
    "explanationDe": "Kiefernharzfeuer verleiht dem Tee harzige Rauch- und Teernoten.",
    "qEn": "How is Lapsang Souchong smoked?",
    "qDe": "Wie wird Lapsang Souchong geräuchert?",
    "optEn": [
      "In peated whisky barrels",
      "With liquid hickory smoke",
      "Over volcanic coals",
      "Over burning pine wood fires (Pinus massoniana)"
    ],
    "optDe": [
      "In Torffässern",
      "Mit künstlichem Raucharoma",
      "Über Vulkankohle",
      "Über brennendem harzreichem Kiefernholzfeuer"
    ],
    "correct": 3,
    "expEn": "Pine resin smoke permeates the tea cells with campfire and dried prune notes.",
    "expDe": "Kiefernharzfeuer verleiht dem Tee harzige Rauch- und Teernoten."
  },
  {
    "id": "q_tea_12",
    "category": "tea",
    "questionEn": "Why use a bamboo whisk (Chasen) for Matcha?",
    "questionDe": "Warum schlägt man Matcha mit dem Bambusbesen (Chasen)?",
    "optionsEn": [
      "Strains leaves",
      "Measures temperature",
      "Creates a micro-foamed silky suspension of powdered leaf in water",
      "Sweetens the drink"
    ],
    "optionsDe": [
      "Filtert Blätter",
      "Misst Temperatur",
      "Schlägt das feine Blattpulver zu einer sämigen Emulsion mit feinstem Schaum auf",
      "Süßt den Tee"
    ],
    "correctIndex": 2,
    "explanationEn": "Matcha is ingested as whole ground leaf, requiring mechanical aeration.",
    "explanationDe": "Der Chasen emulgiert das unlösliche Teepulver zu einer sämigen Schaumkrone.",
    "qEn": "Why use a bamboo whisk (Chasen) for Matcha?",
    "qDe": "Warum schlägt man Matcha mit dem Bambusbesen (Chasen)?",
    "optEn": [
      "Strains leaves",
      "Measures temperature",
      "Creates a micro-foamed silky suspension of powdered leaf in water",
      "Sweetens the drink"
    ],
    "optDe": [
      "Filtert Blätter",
      "Misst Temperatur",
      "Schlägt das feine Blattpulver zu einer sämigen Emulsion mit feinstem Schaum auf",
      "Süßt den Tee"
    ],
    "correct": 2,
    "expEn": "Matcha is ingested as whole ground leaf, requiring mechanical aeration.",
    "expDe": "Der Chasen emulgiert das unlösliche Teepulver zu einer sämigen Schaumkrone."
  },
  {
    "id": "q_tea_13",
    "category": "tea",
    "questionEn": "How is Japanese green tea enzyme activity halted?",
    "questionDe": "Wie wird die Fermentation bei japanischem Grüntee gestoppt?",
    "optionsEn": [
      "Pan-firing in woks",
      "Brief steaming (preserving green color and maritime vegetal flavor)",
      "Sun-basking",
      "Smoking"
    ],
    "optionsDe": [
      "Rösten im Wok",
      "Kurzes Dämpfen mit heißem Wasserdampf (erhält smaragdgrüne Farbe)",
      "Sonnenbad",
      "Räuchern"
    ],
    "correctIndex": 1,
    "explanationEn": "Steaming preserves chlorophyll and marine grassy sweetness.",
    "explanationDe": "Wasserdampf schont das Chlorophyll und erzeugt das maritime Grasprofil.",
    "qEn": "How is Japanese green tea enzyme activity halted?",
    "qDe": "Wie wird die Fermentation bei japanischem Grüntee gestoppt?",
    "optEn": [
      "Pan-firing in woks",
      "Brief steaming (preserving green color and maritime vegetal flavor)",
      "Sun-basking",
      "Smoking"
    ],
    "optDe": [
      "Rösten im Wok",
      "Kurzes Dämpfen mit heißem Wasserdampf (erhält smaragdgrüne Farbe)",
      "Sonnenbad",
      "Räuchern"
    ],
    "correct": 1,
    "expEn": "Steaming preserves chlorophyll and marine grassy sweetness.",
    "expDe": "Wasserdampf schont das Chlorophyll und erzeugt das maritime Grasprofil."
  },
  {
    "id": "q_tea_14",
    "category": "tea",
    "questionEn": "What grain is added to Genmaicha?",
    "questionDe": "Welches Getreide wird japanischem Genmaicha beigemischt?",
    "optionsEn": [
      "Roasted brown rice grains (partly popped)",
      "Toasted sesame seeds",
      "Puffed barley",
      "Fried corn"
    ],
    "optionsDe": [
      "Gerösteter Naturreis (teilweise gepoppt)",
      "Gerösteter Sesam",
      "Gerste",
      "Maisflocken"
    ],
    "correctIndex": 0,
    "explanationEn": "Roasted brown rice adds warm popcorn and nutty toast flavors.",
    "explanationDe": "Gerösteter Naturreis schenkt eine nussige, wärmende Getreidenote.",
    "qEn": "What grain is added to Genmaicha?",
    "qDe": "Welches Getreide wird japanischem Genmaicha beigemischt?",
    "optEn": [
      "Roasted brown rice grains (partly popped)",
      "Toasted sesame seeds",
      "Puffed barley",
      "Fried corn"
    ],
    "optDe": [
      "Gerösteter Naturreis (teilweise gepoppt)",
      "Gerösteter Sesam",
      "Gerste",
      "Maisflocken"
    ],
    "correct": 0,
    "expEn": "Roasted brown rice adds warm popcorn and nutty toast flavors.",
    "expDe": "Gerösteter Naturreis schenkt eine nussige, wärmende Getreidenote."
  },
  {
    "id": "q_tea_15",
    "category": "tea",
    "questionEn": "Which base tea is used in Moroccan mint tea?",
    "questionDe": "Welcher Basis-Tee wird für marokkanischen Minztee verwendet?",
    "optionsEn": [
      "English Breakfast",
      "Matcha powder",
      "Silver Needle",
      "Chinese Gunpowder green tea"
    ],
    "optionsDe": [
      "Schwarztee",
      "Matcha-Pulver",
      "Weißer Tee",
      "Chinesischer Gunpowder-Grüntee (gerollte Kügelchen)"
    ],
    "correctIndex": 3,
    "explanationEn": "Pelletized Gunpowder holds up to boiling water and fresh Nana mint.",
    "explanationDe": "Fest gerollter Gunpowder verträgt das Aufkochen mit Minze und Zucker.",
    "qEn": "Which base tea is used in Moroccan mint tea?",
    "qDe": "Welcher Basis-Tee wird für marokkanischen Minztee verwendet?",
    "optEn": [
      "English Breakfast",
      "Matcha powder",
      "Silver Needle",
      "Chinese Gunpowder green tea"
    ],
    "optDe": [
      "Schwarztee",
      "Matcha-Pulver",
      "Weißer Tee",
      "Chinesischer Gunpowder-Grüntee (gerollte Kügelchen)"
    ],
    "correct": 3,
    "expEn": "Pelletized Gunpowder holds up to boiling water and fresh Nana mint.",
    "expDe": "Fest gerollter Gunpowder verträgt das Aufkochen mit Minze und Zucker."
  },
  {
    "id": "q_tea_16",
    "category": "tea",
    "questionEn": "Why does oversteeped black tea taste bitter and dry?",
    "questionDe": "Warum wird Schwarztee nach mehr als 5 Minuten bitter und pelzig?",
    "optionsEn": [
      "All oxygen escapes",
      "Water turns into syrup",
      "Heavy polyphenolic tannins leach out continuously after initial caffeine release",
      "Calcium precipitates"
    ],
    "optionsDe": [
      "Sauerstoff fehlt",
      "Wasser verdampft",
      "Schwere Gerbstoffe (Tannine) diffundieren nach den ersten Minuten massiv aus",
      "Kalk flockt aus"
    ],
    "correctIndex": 2,
    "explanationEn": "After 3 minutes, bitter tannins dominate the liquor and bind to tongue proteins.",
    "explanationDe": "Nach 3 Minuten lösen sich schwere Gerbsäuren, die den Mund austrocknen.",
    "qEn": "Why does oversteeped black tea taste bitter and dry?",
    "qDe": "Warum wird Schwarztee nach mehr als 5 Minuten bitter und pelzig?",
    "optEn": [
      "All oxygen escapes",
      "Water turns into syrup",
      "Heavy polyphenolic tannins leach out continuously after initial caffeine release",
      "Calcium precipitates"
    ],
    "optDe": [
      "Sauerstoff fehlt",
      "Wasser verdampft",
      "Schwere Gerbstoffe (Tannine) diffundieren nach den ersten Minuten massiv aus",
      "Kalk flockt aus"
    ],
    "correct": 2,
    "expEn": "After 3 minutes, bitter tannins dominate the liquor and bind to tongue proteins.",
    "expDe": "Nach 3 Minuten lösen sich schwere Gerbsäuren, die den Mund austrocknen."
  },
  {
    "id": "q_tea_17",
    "category": "tea",
    "questionEn": "Which whole spices belong in classic Indian Masala Chai?",
    "questionDe": "Welche Gewürze gehören in traditionellen indischen Masala Chai?",
    "optionsEn": [
      "Vanilla, chili, and nutmeg",
      "Cardamom, fresh ginger, cinnamon, cloves, and black pepper",
      "Cumin, coriander, and garlic",
      "Dill and bay leaves"
    ],
    "optionsDe": [
      "Vanille, Chili und Muskat",
      "Kardamom, Ingwer, Zimt, Nelken und schwarzer Pfeffer",
      "Kreuzkümmel und Knoblauch",
      "Dill und Lorbeer"
    ],
    "correctIndex": 1,
    "explanationEn": "Simmering spices with full-fat milk and black tea creates comforting emulsified warmth.",
    "explanationDe": "In Milch ausgekochte Gewürze ergeben das wärmende Chai-Aroma.",
    "qEn": "Which whole spices belong in classic Indian Masala Chai?",
    "qDe": "Welche Gewürze gehören in traditionellen indischen Masala Chai?",
    "optEn": [
      "Vanilla, chili, and nutmeg",
      "Cardamom, fresh ginger, cinnamon, cloves, and black pepper",
      "Cumin, coriander, and garlic",
      "Dill and bay leaves"
    ],
    "optDe": [
      "Vanille, Chili und Muskat",
      "Kardamom, Ingwer, Zimt, Nelken und schwarzer Pfeffer",
      "Kreuzkümmel und Knoblauch",
      "Dill und Lorbeer"
    ],
    "correct": 1,
    "expEn": "Simmering spices with full-fat milk and black tea creates comforting emulsified warmth.",
    "expDe": "In Milch ausgekochte Gewürze ergeben das wärmende Chai-Aroma."
  },
  {
    "id": "q_tea_18",
    "category": "tea",
    "questionEn": "Why is Cold Brew tea naturally sweeter than iced hot tea?",
    "questionDe": "Warum schmeckt Cold-Brew-Tee süßer und milder als abgekühlter Heißtee?",
    "optionsEn": [
      "Cold water extracts sweet amino acids while leaving bitter tannins trapped in leaves",
      "Refrigerators add sugar",
      "Cold destroys caffeine",
      "Acid evaporates in the fridge"
    ],
    "optionsDe": [
      "Kaltes Wasser löst süße Aminosäuren, während herbe Gerbstoffe im Blatt bleiben",
      "Kälte bildet Zucker",
      "Koffein wird zerstört",
      "Säure verdampft"
    ],
    "correctIndex": 0,
    "explanationEn": "Tannins require hot water to dissolve; cold extraction yields silky sweetness.",
    "explanationDe": "Gerbstoffe brauchen Hitze; im kalten Wasser diffundieren nur milde Aromen.",
    "qEn": "Why is Cold Brew tea naturally sweeter than iced hot tea?",
    "qDe": "Warum schmeckt Cold-Brew-Tee süßer und milder als abgekühlter Heißtee?",
    "optEn": [
      "Cold water extracts sweet amino acids while leaving bitter tannins trapped in leaves",
      "Refrigerators add sugar",
      "Cold destroys caffeine",
      "Acid evaporates in the fridge"
    ],
    "optDe": [
      "Kaltes Wasser löst süße Aminosäuren, während herbe Gerbstoffe im Blatt bleiben",
      "Kälte bildet Zucker",
      "Koffein wird zerstört",
      "Säure verdampft"
    ],
    "correct": 0,
    "expEn": "Tannins require hot water to dissolve; cold extraction yields silky sweetness.",
    "expDe": "Gerbstoffe brauchen Hitze; im kalten Wasser diffundieren nur milde Aromen."
  },
  {
    "id": "q_cof_01",
    "category": "coffee",
    "questionEn": "What defines authentic Italian espresso brewing parameters?",
    "questionDe": "Was sind die Richtwerte für klassischen italienischen Espresso (INIE)?",
    "optionsEn": [
      "Instant powder dissolved in boiling water",
      "100ml in 1 minute from 20g",
      "50ml in 10 seconds at 2 bar",
      "25ml extracted in 25 seconds from 7g coffee at 9 bar pressure"
    ],
    "optionsDe": [
      "Löslicher Kaffee mit kochendem Wasser",
      "100 ml in 1 Minute aus 20g",
      "50 ml in 10 Sekunden bei 2 bar",
      "25 ml Extraktion in 25 Sekunden aus 7g Mahlgut bei 9 bar Brühdruck"
    ],
    "correctIndex": 3,
    "explanationEn": "The Italian Espresso National Institute defines 25ml ± 2.5ml in 25 seconds at 9 bar and 88-92°C.",
    "explanationDe": "Das Istituto Nazionale Espresso Italiano definiert 25 ml in 25 Sekunden bei 9 bar Druck.",
    "qEn": "What defines authentic Italian espresso brewing parameters?",
    "qDe": "Was sind die Richtwerte für klassischen italienischen Espresso (INIE)?",
    "optEn": [
      "Instant powder dissolved in boiling water",
      "100ml in 1 minute from 20g",
      "50ml in 10 seconds at 2 bar",
      "25ml extracted in 25 seconds from 7g coffee at 9 bar pressure"
    ],
    "optDe": [
      "Löslicher Kaffee mit kochendem Wasser",
      "100 ml in 1 Minute aus 20g",
      "50 ml in 10 Sekunden bei 2 bar",
      "25 ml Extraktion in 25 Sekunden aus 7g Mahlgut bei 9 bar Brühdruck"
    ],
    "correct": 3,
    "expEn": "The Italian Espresso National Institute defines 25ml ± 2.5ml in 25 seconds at 9 bar and 88-92°C.",
    "expDe": "Das Istituto Nazionale Espresso Italiano definiert 25 ml in 25 Sekunden bei 9 bar Druck."
  },
  {
    "id": "q_cof_02",
    "category": "coffee",
    "questionEn": "What creates the golden crema layer on an espresso?",
    "questionDe": "Woraus besteht die goldbraune Crema auf einem Espresso?",
    "optionsEn": [
      "Caramelized sugar syrup",
      "Milk foam added on top",
      "Carbon dioxide gas emulsified with coffee oils and microscopic solids under pressure",
      "Chemical froth agents"
    ],
    "optionsDe": [
      "Karamellisierter Zuckersirup",
      "Milchschaum",
      "Unter Druck emulgierte Kaffeeöle und CO2-Gasbläschen mit Schwebstoffen",
      "Künstlicher Schaumbildner"
    ],
    "correctIndex": 2,
    "explanationEn": "High brewing pressure forces roasted CO2 and aromatic lipids into a velvety micro-foam emulsion.",
    "explanationDe": "Der Brühdruck emulgiert Röstgase (CO2) mit den Kaffeeölen zu feinstem Schaum.",
    "qEn": "What creates the golden crema layer on an espresso?",
    "qDe": "Woraus besteht die goldbraune Crema auf einem Espresso?",
    "optEn": [
      "Caramelized sugar syrup",
      "Milk foam added on top",
      "Carbon dioxide gas emulsified with coffee oils and microscopic solids under pressure",
      "Chemical froth agents"
    ],
    "optDe": [
      "Karamellisierter Zuckersirup",
      "Milchschaum",
      "Unter Druck emulgierte Kaffeeöle und CO2-Gasbläschen mit Schwebstoffen",
      "Künstlicher Schaumbildner"
    ],
    "correct": 2,
    "expEn": "High brewing pressure forces roasted CO2 and aromatic lipids into a velvety micro-foam emulsion.",
    "expDe": "Der Brühdruck emulgiert Röstgase (CO2) mit den Kaffeeölen zu feinstem Schaum."
  },
  {
    "id": "q_cof_03",
    "category": "coffee",
    "questionEn": "What distinguishes Arabica from Robusta coffee beans chemically?",
    "questionDe": "Was unterscheidet Arabica von Robusta-Kaffeebohnen chemisch?",
    "optionsEn": [
      "Arabica has zero caffeine",
      "Arabica has more aromatic lipids and sucrose; Robusta has almost double caffeine and chlorogenic acids",
      "Robusta has no crema",
      "Arabica is always roasted black"
    ],
    "optionsDe": [
      "Arabica hat kein Koffein",
      "Arabica besitzt mehr aromatische Öle und Zucker; Robusta hat fast doppelt so viel Koffein und Chlorogensäure",
      "Robusta bildet nie Crema",
      "Arabica wird nur dunkel geröstet"
    ],
    "correctIndex": 1,
    "explanationEn": "Arabica delivers complex acidity and sweetness; Robusta provides heavy body, crema stability, and caffeine punch.",
    "explanationDe": "Arabica glänzt durch feine Säuren und Süße; Robusta bringt kräftigen Körper, Crema und Bitterstoffe.",
    "qEn": "What distinguishes Arabica from Robusta coffee beans chemically?",
    "qDe": "Was unterscheidet Arabica von Robusta-Kaffeebohnen chemisch?",
    "optEn": [
      "Arabica has zero caffeine",
      "Arabica has more aromatic lipids and sucrose; Robusta has almost double caffeine and chlorogenic acids",
      "Robusta has no crema",
      "Arabica is always roasted black"
    ],
    "optDe": [
      "Arabica hat kein Koffein",
      "Arabica besitzt mehr aromatische Öle und Zucker; Robusta hat fast doppelt so viel Koffein und Chlorogensäure",
      "Robusta bildet nie Crema",
      "Arabica wird nur dunkel geröstet"
    ],
    "correct": 1,
    "expEn": "Arabica delivers complex acidity and sweetness; Robusta provides heavy body, crema stability, and caffeine punch.",
    "expDe": "Arabica glänzt durch feine Säuren und Süße; Robusta bringt kräftigen Körper, Crema und Bitterstoffe."
  },
  {
    "id": "q_cof_04",
    "category": "coffee",
    "questionEn": "What is an Espresso Doppio?",
    "questionDe": "Was ist ein Espresso Doppio?",
    "optionsEn": [
      "A double shot of espresso (approx. 50-60ml from 14-18g ground coffee)",
      "Espresso with double sugar",
      "Espresso with double milk foam",
      "Cold espresso over ice"
    ],
    "optionsDe": [
      "Ein doppelter Espresso (ca. 50–60 ml aus 14–18g gemahlenem Kaffee)",
      "Espresso mit doppeltem Zucker",
      "Espresso mit doppelter Milchhaube",
      "Kalter Espresso auf Eis"
    ],
    "correctIndex": 0,
    "explanationEn": "Doppio means double espresso extracted through a two-spout portafilter.",
    "explanationDe": "Ein Doppio ist ein doppelter Bezug mit doppelter Kaffeemehlmenge.",
    "qEn": "What is an Espresso Doppio?",
    "qDe": "Was ist ein Espresso Doppio?",
    "optEn": [
      "A double shot of espresso (approx. 50-60ml from 14-18g ground coffee)",
      "Espresso with double sugar",
      "Espresso with double milk foam",
      "Cold espresso over ice"
    ],
    "optDe": [
      "Ein doppelter Espresso (ca. 50–60 ml aus 14–18g gemahlenem Kaffee)",
      "Espresso mit doppeltem Zucker",
      "Espresso mit doppelter Milchhaube",
      "Kalter Espresso auf Eis"
    ],
    "correct": 0,
    "expEn": "Doppio means double espresso extracted through a two-spout portafilter.",
    "expDe": "Ein Doppio ist ein doppelter Bezug mit doppelter Kaffeemehlmenge."
  },
  {
    "id": "q_cof_05",
    "category": "coffee",
    "questionEn": "How does an Espresso Macchiato differ from a Cortado?",
    "questionDe": "Wie unterscheidet sich ein Espresso Macchiato von einem Cortado?",
    "optionsEn": [
      "Macchiato has cold water",
      "Macchiato is made with chocolate",
      "Cortado has no caffeine",
      "Macchiato has just a dollop of textured milk foam; Cortado has equal parts espresso and warm steamed milk (1:1)"
    ],
    "optionsDe": [
      "Macchiato wird mit Wasser gestreckt",
      "Macchiato enthält Schokolade",
      "Cortado ist koffeinfrei",
      "Macchiato erhält nur einen kleinen Tupfer Milchschaum ('gefleckt'); Cortado besteht zu 1:1 aus Espresso und warmer Milch"
    ],
    "correctIndex": 3,
    "explanationEn": "Macchiato translates to 'stained' or 'spotted' with micro-foam.",
    "explanationDe": "'Macchiato' bedeutet 'gefleckt'; der Cortado 'schneidet' den Espresso 1:1 mit Milch.",
    "qEn": "How does an Espresso Macchiato differ from a Cortado?",
    "qDe": "Wie unterscheidet sich ein Espresso Macchiato von einem Cortado?",
    "optEn": [
      "Macchiato has cold water",
      "Macchiato is made with chocolate",
      "Cortado has no caffeine",
      "Macchiato has just a dollop of textured milk foam; Cortado has equal parts espresso and warm steamed milk (1:1)"
    ],
    "optDe": [
      "Macchiato wird mit Wasser gestreckt",
      "Macchiato enthält Schokolade",
      "Cortado ist koffeinfrei",
      "Macchiato erhält nur einen kleinen Tupfer Milchschaum ('gefleckt'); Cortado besteht zu 1:1 aus Espresso und warmer Milch"
    ],
    "correct": 3,
    "expEn": "Macchiato translates to 'stained' or 'spotted' with micro-foam.",
    "expDe": "'Macchiato' bedeutet 'gefleckt'; der Cortado 'schneidet' den Espresso 1:1 mit Milch."
  },
  {
    "id": "q_cof_06",
    "category": "coffee",
    "questionEn": "How is traditional Turkish coffee brewed in a Cezve/Ibrik?",
    "questionDe": "Wie wird traditioneller türkischer Mokka in der Cezve zubereitet?",
    "optionsEn": [
      "Pressed in a French press",
      "Extracted through paper drip cone",
      "Ultra-fine pulverized coffee and water simmered gently together without filtering",
      "Steamed under 15 bar pressure"
    ],
    "optionsDe": [
      "In der Stempelkanne gepresst",
      "Durch Papierfilter getropft",
      "Staubfein gemahlener Kaffee wird mit Wasser in der Cezve erhitzt und unfiltriert serviert",
      "Mit 15 bar Dampfdruck gebrüht"
    ],
    "correctIndex": 2,
    "explanationEn": "Turkish coffee is unfiltered; grounds settle naturally at the bottom of the fincan cup.",
    "explanationDe": "Der Mokka wird unfiltriert getrunken; der Satz setzt sich am Tassenboden ab.",
    "qEn": "How is traditional Turkish coffee brewed in a Cezve/Ibrik?",
    "qDe": "Wie wird traditioneller türkischer Mokka in der Cezve zubereitet?",
    "optEn": [
      "Pressed in a French press",
      "Extracted through paper drip cone",
      "Ultra-fine pulverized coffee and water simmered gently together without filtering",
      "Steamed under 15 bar pressure"
    ],
    "optDe": [
      "In der Stempelkanne gepresst",
      "Durch Papierfilter getropft",
      "Staubfein gemahlener Kaffee wird mit Wasser in der Cezve erhitzt und unfiltriert serviert",
      "Mit 15 bar Dampfdruck gebrüht"
    ],
    "correct": 2,
    "expEn": "Turkish coffee is unfiltered; grounds settle naturally at the bottom of the fincan cup.",
    "expDe": "Der Mokka wird unfiltriert getrunken; der Satz setzt sich am Tassenboden ab."
  },
  {
    "id": "q_cof_07",
    "category": "coffee",
    "questionEn": "What makes Vietnamese Iced Coffee (Cà phê sữa đá) unique?",
    "questionDe": "Was macht vietnamesischen Cà phê sữa đá unverwechselbar?",
    "optionsEn": [
      "Espresso with coconut water only",
      "Dark roasted Robusta brewed through a metal Phin filter over sweetened condensed milk and ice",
      "Filtered Arabica with whipped butter",
      "Green raw coffee with mint"
    ],
    "optionsDe": [
      "Espresso nur mit Kokoswasser",
      "Dunkler Robusta-Kaffee tropft durch einen Phin-Metallfilter auf gezuckerte Kondensmilch und Eis",
      "Arabica mit geschlagener Butter",
      "Grüner Rohkaffee mit Minze"
    ],
    "correctIndex": 1,
    "explanationEn": "Sweet condensed milk cuts the intense, chocolatey bitterness of drip-brewed Robusta.",
    "explanationDe": "Gezuckerte Dickmilch puffert die schokoladige Bitterkeit des kräftigen Robusta perfekt ab.",
    "qEn": "What makes Vietnamese Iced Coffee (Cà phê sữa đá) unique?",
    "qDe": "Was macht vietnamesischen Cà phê sữa đá unverwechselbar?",
    "optEn": [
      "Espresso with coconut water only",
      "Dark roasted Robusta brewed through a metal Phin filter over sweetened condensed milk and ice",
      "Filtered Arabica with whipped butter",
      "Green raw coffee with mint"
    ],
    "optDe": [
      "Espresso nur mit Kokoswasser",
      "Dunkler Robusta-Kaffee tropft durch einen Phin-Metallfilter auf gezuckerte Kondensmilch und Eis",
      "Arabica mit geschlagener Butter",
      "Grüner Rohkaffee mit Minze"
    ],
    "correct": 1,
    "expEn": "Sweet condensed milk cuts the intense, chocolatey bitterness of drip-brewed Robusta.",
    "expDe": "Gezuckerte Dickmilch puffert die schokoladige Bitterkeit des kräftigen Robusta perfekt ab."
  },
  {
    "id": "q_cof_08",
    "category": "coffee",
    "questionEn": "What is the difference between a Flat White and a Cappuccino?",
    "questionDe": "Was unterscheidet einen Flat White von einem Cappuccino?",
    "optionsEn": [
      "Flat White uses double espresso (or ristretto) with silky microfoam poured flat; Cappuccino has airy dry foam crown",
      "Flat White has whipped cream",
      "Cappuccino has cinnamon only",
      "Flat White is served cold"
    ],
    "optionsDe": [
      "Flat White nutzt doppelten Ristretto mit samtigem Mikroschaum ohne dicke Schaumkrone",
      "Flat White enthält Schlagsahne",
      "Cappuccino darf keinen Espresso haben",
      "Flat White wird kalt serviert"
    ],
    "correctIndex": 0,
    "explanationEn": "Flat White focuses on integrated silky microfoam that blends seamlessly with the crema.",
    "explanationDe": "Der Mikroschaum des Flat White verschmilzt homogen mit dem Kaffee ohne trennende Schaumhaube.",
    "qEn": "What is the difference between a Flat White and a Cappuccino?",
    "qDe": "Was unterscheidet einen Flat White von einem Cappuccino?",
    "optEn": [
      "Flat White uses double espresso (or ristretto) with silky microfoam poured flat; Cappuccino has airy dry foam crown",
      "Flat White has whipped cream",
      "Cappuccino has cinnamon only",
      "Flat White is served cold"
    ],
    "optDe": [
      "Flat White nutzt doppelten Ristretto mit samtigem Mikroschaum ohne dicke Schaumkrone",
      "Flat White enthält Schlagsahne",
      "Cappuccino darf keinen Espresso haben",
      "Flat White wird kalt serviert"
    ],
    "correct": 0,
    "expEn": "Flat White focuses on integrated silky microfoam that blends seamlessly with the crema.",
    "expDe": "Der Mikroschaum des Flat White verschmilzt homogen mit dem Kaffee ohne trennende Schaumhaube."
  },
  {
    "id": "q_cof_09",
    "category": "coffee",
    "questionEn": "What happens during the 'First Crack' in coffee roasting?",
    "questionDe": "Was geschieht beim 'First Crack' während der Kaffeeröstung?",
    "optionsEn": [
      "Beans turn white",
      "Beans burn to charcoal",
      "Caffeine escapes as gas",
      "Trapped moisture vaporizes, expanding the bean and cracking cellulose walls audibly"
    ],
    "optionsDe": [
      "Bohnen werden weiß",
      "Bohnen verbrennen zu Asche",
      "Koffein entweicht als Gas",
      "Verdampfendes Wasser und Gase sprengen hörbar die Zellstruktur der Bohne auf"
    ],
    "correctIndex": 3,
    "explanationEn": "First crack signals light roast territory (Cinnamon/City roast) with developed fruit acids.",
    "explanationDe": "Der erste Knackpunkt markiert den Beginn der genießbaren Röststufen mit lebendigen Fruchtsäuren.",
    "qEn": "What happens during the 'First Crack' in coffee roasting?",
    "qDe": "Was geschieht beim 'First Crack' während der Kaffeeröstung?",
    "optEn": [
      "Beans turn white",
      "Beans burn to charcoal",
      "Caffeine escapes as gas",
      "Trapped moisture vaporizes, expanding the bean and cracking cellulose walls audibly"
    ],
    "optDe": [
      "Bohnen werden weiß",
      "Bohnen verbrennen zu Asche",
      "Koffein entweicht als Gas",
      "Verdampfendes Wasser und Gase sprengen hörbar die Zellstruktur der Bohne auf"
    ],
    "correct": 3,
    "expEn": "First crack signals light roast territory (Cinnamon/City roast) with developed fruit acids.",
    "expDe": "Der erste Knackpunkt markiert den Beginn der genießbaren Röststufen mit lebendigen Fruchtsäuren."
  },
  {
    "id": "q_cof_10",
    "category": "coffee",
    "questionEn": "What is an Americano compared to a Long Black?",
    "questionDe": "Was unterscheidet einen Americano von einem Long Black?",
    "optionsEn": [
      "Long Black has brewed drip coffee",
      "Americano has cold milk",
      "Americano adds hot water to espresso; Long Black pours espresso over hot water preserving crema",
      "Americano is decaf"
    ],
    "optionsDe": [
      "Long Black ist Filterkaffee",
      "Americano hat kalte Milch",
      "Beim Americano wird heißes Wasser auf Espresso gegossen; beim Long Black Espresso auf heißes Wasser (erhält Crema)",
      "Americano ist entkoffeiniert"
    ],
    "correctIndex": 2,
    "explanationEn": "Pouring espresso directly onto hot water maintains the unbroken golden crema layer in Australasia.",
    "explanationDe": "Beim Long Black bleibt die Crema unzerstört, da der Espresso auf das Wasser läuft.",
    "qEn": "What is an Americano compared to a Long Black?",
    "qDe": "Was unterscheidet einen Americano von einem Long Black?",
    "optEn": [
      "Long Black has brewed drip coffee",
      "Americano has cold milk",
      "Americano adds hot water to espresso; Long Black pours espresso over hot water preserving crema",
      "Americano is decaf"
    ],
    "optDe": [
      "Long Black ist Filterkaffee",
      "Americano hat kalte Milch",
      "Beim Americano wird heißes Wasser auf Espresso gegossen; beim Long Black Espresso auf heißes Wasser (erhält Crema)",
      "Americano ist entkoffeiniert"
    ],
    "correct": 2,
    "expEn": "Pouring espresso directly onto hot water maintains the unbroken golden crema layer in Australasia.",
    "expDe": "Beim Long Black bleibt die Crema unzerstört, da der Espresso auf das Wasser läuft."
  },
  {
    "id": "q_cof_11",
    "category": "coffee",
    "questionEn": "Why does Cold Brew coffee have lower perceived acidity than hot-brewed coffee?",
    "questionDe": "Warum hat Cold Brew Kaffee spürbar weniger Säure als heiß gebrühter Kaffee?",
    "optionsEn": [
      "Cold brew has added baking soda",
      "Cold water extracts fewer volatile chlorogenic and quinic acids",
      "Cold destroys caffeine",
      "Ice neutralizes all pH"
    ],
    "optionsDe": [
      "Natron wird beigemischt",
      "Kaltes Wasser löst weniger temperaturempfindliche Chlorogensäuren heraus",
      "Kälte baut Koffein ab",
      "Eis neutralisiert die Säure"
    ],
    "correctIndex": 1,
    "explanationEn": "Cold water steeping (12-24h) minimizes bitter and sour acids while highlighting chocolate notes.",
    "explanationDe": "Die Kaltwasser-Extraktion schont den Magen, da aggressive Frucht- und Röstsäuren im Mehl bleiben.",
    "qEn": "Why does Cold Brew coffee have lower perceived acidity than hot-brewed coffee?",
    "qDe": "Warum hat Cold Brew Kaffee spürbar weniger Säure als heiß gebrühter Kaffee?",
    "optEn": [
      "Cold brew has added baking soda",
      "Cold water extracts fewer volatile chlorogenic and quinic acids",
      "Cold destroys caffeine",
      "Ice neutralizes all pH"
    ],
    "optDe": [
      "Natron wird beigemischt",
      "Kaltes Wasser löst weniger temperaturempfindliche Chlorogensäuren heraus",
      "Kälte baut Koffein ab",
      "Eis neutralisiert die Säure"
    ],
    "correct": 1,
    "expEn": "Cold water steeping (12-24h) minimizes bitter and sour acids while highlighting chocolate notes.",
    "expDe": "Die Kaltwasser-Extraktion schont den Magen, da aggressive Frucht- und Röstsäuren im Mehl bleiben."
  },
  {
    "id": "q_cof_12",
    "category": "coffee",
    "questionEn": "What is a Ristretto?",
    "questionDe": "Was ist ein Ristretto?",
    "optionsEn": [
      "A short restricted espresso shot (approx. 15-20ml) extracting only early sweet aromatics",
      "Espresso with extra hot water",
      "Triple shot of espresso",
      "Espresso with lemon juice"
    ],
    "optionsDe": [
      "Ein verkürzter Espresso (ca. 15–20 ml), der vor allem die süßen Erstaromen löst",
      "Espresso mit viel Wasser",
      "Dreifacher Espressobezug",
      "Espresso mit Zitronensaft"
    ],
    "correctIndex": 0,
    "explanationEn": "Ristretto stops before bitter polyphenols and astringent compounds extract in the tail.",
    "explanationDe": "Ein Ristretto bricht den Bezug frühzeitig ab, um Bitterstoffe der Endphase zu vermeiden.",
    "qEn": "What is a Ristretto?",
    "qDe": "Was ist ein Ristretto?",
    "optEn": [
      "A short restricted espresso shot (approx. 15-20ml) extracting only early sweet aromatics",
      "Espresso with extra hot water",
      "Triple shot of espresso",
      "Espresso with lemon juice"
    ],
    "optDe": [
      "Ein verkürzter Espresso (ca. 15–20 ml), der vor allem die süßen Erstaromen löst",
      "Espresso mit viel Wasser",
      "Dreifacher Espressobezug",
      "Espresso mit Zitronensaft"
    ],
    "correct": 0,
    "expEn": "Ristretto stops before bitter polyphenols and astringent compounds extract in the tail.",
    "expDe": "Ein Ristretto bricht den Bezug frühzeitig ab, um Bitterstoffe der Endphase zu vermeiden."
  },
  {
    "id": "q_cof_13",
    "category": "coffee",
    "questionEn": "What does 'Washed Process' (wet process) highlight in coffee beans?",
    "questionDe": "Welches Geschmacksprofil betont die nasse Aufbereitung (Washed Coffee)?",
    "optionsEn": [
      "Burnt sugar notes",
      "Heavy earthy body and low acidity",
      "Fermented boozy fruit notes",
      "Clean, bright cup clarity with pronounced fruit acidity and floral notes"
    ],
    "optionsDe": [
      "Verbrannter Zuckergeschmack",
      "Erdiger, schwerer Körper ohne Säure",
      "Starke alkoholische Fermentnoten",
      "Klare Tasse mit ausgeprägter, spritziger Säure und floralen Noten"
    ],
    "correctIndex": 3,
    "explanationEn": "Removing fruit pulp before fermentation washes away sugar mucilage, accentuating pure terroir acids.",
    "explanationDe": "Das Entpulpen und Waschen vor dem Trocknen hebt die reine Sortensäure und Terroirtöne hervor.",
    "qEn": "What does 'Washed Process' (wet process) highlight in coffee beans?",
    "qDe": "Welches Geschmacksprofil betont die nasse Aufbereitung (Washed Coffee)?",
    "optEn": [
      "Burnt sugar notes",
      "Heavy earthy body and low acidity",
      "Fermented boozy fruit notes",
      "Clean, bright cup clarity with pronounced fruit acidity and floral notes"
    ],
    "optDe": [
      "Verbrannter Zuckergeschmack",
      "Erdiger, schwerer Körper ohne Säure",
      "Starke alkoholische Fermentnoten",
      "Klare Tasse mit ausgeprägter, spritziger Säure und floralen Noten"
    ],
    "correct": 3,
    "expEn": "Removing fruit pulp before fermentation washes away sugar mucilage, accentuating pure terroir acids.",
    "expDe": "Das Entpulpen und Waschen vor dem Trocknen hebt die reine Sortensäure und Terroirtöne hervor."
  },
  {
    "id": "q_cof_14",
    "category": "coffee",
    "questionEn": "What is 'Natural Process' (dry process) coffee?",
    "questionDe": "Was versteht man unter 'Natural Coffee' (trockener Aufbereitung)?",
    "optionsEn": [
      "Beans are dried in gas ovens",
      "Beans are washed with detergent",
      "Whole coffee cherries are sun-dried intact on raised beds, allowing pulp sugars to soak into beans",
      "Green coffee is roasted raw"
    ],
    "optionsDe": [
      "Trocknung im Gasofen",
      "Bohnen werden mit Lauge gewaschen",
      "Ganze Kaffeekirschen werden mit Fruchtfleisch an der Sonne getrocknet; Fruchtzucker zieht in die Bohne",
      "Rohkaffee wird ungeschält geröstet"
    ],
    "correctIndex": 2,
    "explanationEn": "Naturals yield heavy body, sweet tropical fruit notes, and berry jam aromatics.",
    "explanationDe": "Naturals entwickeln fruchtige, beerenartige Süße und üppigen Körper durch das getrocknete Fruchtfleisch.",
    "qEn": "What is 'Natural Process' (dry process) coffee?",
    "qDe": "Was versteht man unter 'Natural Coffee' (trockener Aufbereitung)?",
    "optEn": [
      "Beans are dried in gas ovens",
      "Beans are washed with detergent",
      "Whole coffee cherries are sun-dried intact on raised beds, allowing pulp sugars to soak into beans",
      "Green coffee is roasted raw"
    ],
    "optDe": [
      "Trocknung im Gasofen",
      "Bohnen werden mit Lauge gewaschen",
      "Ganze Kaffeekirschen werden mit Fruchtfleisch an der Sonne getrocknet; Fruchtzucker zieht in die Bohne",
      "Rohkaffee wird ungeschält geröstet"
    ],
    "correct": 2,
    "expEn": "Naturals yield heavy body, sweet tropical fruit notes, and berry jam aromatics.",
    "expDe": "Naturals entwickeln fruchtige, beerenartige Süße und üppigen Körper durch das getrocknete Fruchtfleisch."
  },
  {
    "id": "q_cof_15",
    "category": "coffee",
    "questionEn": "What is the optimum milk steaming temperature for latte art?",
    "questionDe": "Welche Milchtemperatur ist ideal beim Aufschäumen für Latte Art?",
    "optionsEn": [
      "85°C to 95°C",
      "60°C to 65°C (140°F to 150°F)",
      "30°C to 35°C",
      "100°C boiling point"
    ],
    "optionsDe": [
      "85°C bis 95°C",
      "60°C bis 65°C",
      "30°C bis 35°C",
      "100°C kochend"
    ],
    "correctIndex": 1,
    "explanationEn": "Above 70°C, whey proteins denature, lactose loses perceived sweetness, and milk develops a scalded taste.",
    "explanationDe": "Über 68°C gerinnt das Milcheiweiß, die natürliche Süße der Laktose leidet und der Schaum wird grob.",
    "qEn": "What is the optimum milk steaming temperature for latte art?",
    "qDe": "Welche Milchtemperatur ist ideal beim Aufschäumen für Latte Art?",
    "optEn": [
      "85°C to 95°C",
      "60°C to 65°C (140°F to 150°F)",
      "30°C to 35°C",
      "100°C boiling point"
    ],
    "optDe": [
      "85°C bis 95°C",
      "60°C bis 65°C",
      "30°C bis 35°C",
      "100°C kochend"
    ],
    "correct": 1,
    "expEn": "Above 70°C, whey proteins denature, lactose loses perceived sweetness, and milk develops a scalded taste.",
    "expDe": "Über 68°C gerinnt das Milcheiweiß, die natürliche Süße der Laktose leidet und der Schaum wird grob."
  },
  {
    "id": "q_cof_16",
    "category": "coffee",
    "questionEn": "What causes 'Channeling' during espresso extraction?",
    "questionDe": "Was versteht man unter 'Channeling' beim Espressobezug?",
    "optionsEn": [
      "Water finds paths of least resistance through cracks or uneven grounds, causing under- and over-extraction",
      "Water pipes leak",
      "Pump vibrates",
      "Grinder stops spinning"
    ],
    "optionsDe": [
      "Wasser sucht sich Risse im Kaffeepuck, schießt ungleichmäßig durch und extrahiert fehlerhaft",
      "Wasserrohre sind undicht",
      "Pumpe vibriert zu stark",
      "Mahlwerk blockiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Uneven tamping or clumping causes water jets, producing a watery, astringent, and bitter cup.",
    "explanationDe": "Ungleichmäßiges Tampen führt zu Rissen im Kaffeemehl, durch die Wasser zu schnell herausschießt.",
    "qEn": "What causes 'Channeling' during espresso extraction?",
    "qDe": "Was versteht man unter 'Channeling' beim Espressobezug?",
    "optEn": [
      "Water finds paths of least resistance through cracks or uneven grounds, causing under- and over-extraction",
      "Water pipes leak",
      "Pump vibrates",
      "Grinder stops spinning"
    ],
    "optDe": [
      "Wasser sucht sich Risse im Kaffeepuck, schießt ungleichmäßig durch und extrahiert fehlerhaft",
      "Wasserrohre sind undicht",
      "Pumpe vibriert zu stark",
      "Mahlwerk blockiert"
    ],
    "correct": 0,
    "expEn": "Uneven tamping or clumping causes water jets, producing a watery, astringent, and bitter cup.",
    "expDe": "Ungleichmäßiges Tampen führt zu Rissen im Kaffeemehl, durch die Wasser zu schnell herausschießt."
  },
  {
    "id": "q_cof_17",
    "category": "coffee",
    "questionEn": "Why must freshly roasted coffee beans rest for several days before espresso brewing?",
    "questionDe": "Warum müssen frisch geröstete Kaffeebohnen vor dem Espressobezug einige Tage ausgasen (degassen)?",
    "optionsEn": [
      "To turn dark brown",
      "To absorb moisture from air",
      "To grow yeast cultures",
      "Excess carbon dioxide gas interferes with water contact, creating turbulent, bubbly, and bitter crema"
    ],
    "optionsDe": [
      "Um dunkel zu werden",
      "Um Luftfeuchte aufzunehmen",
      "Damit Hefe wächst",
      "Überschüssiges CO2-Röstgas stört den Wasserkontakt und lässt die Crema unruhig aufschäumen"
    ],
    "correctIndex": 3,
    "explanationEn": "Coffee releases CO2 for 5-14 days; brewing too fresh produces gassy, sour, and unstable shots.",
    "explanationDe": "Frisch gerösteter Kaffee gast CO2 aus; ohne Ruhepause stören die Blasen die Extraktion massiv.",
    "qEn": "Why must freshly roasted coffee beans rest for several days before espresso brewing?",
    "qDe": "Warum müssen frisch geröstete Kaffeebohnen vor dem Espressobezug einige Tage ausgasen (degassen)?",
    "optEn": [
      "To turn dark brown",
      "To absorb moisture from air",
      "To grow yeast cultures",
      "Excess carbon dioxide gas interferes with water contact, creating turbulent, bubbly, and bitter crema"
    ],
    "optDe": [
      "Um dunkel zu werden",
      "Um Luftfeuchte aufzunehmen",
      "Damit Hefe wächst",
      "Überschüssiges CO2-Röstgas stört den Wasserkontakt und lässt die Crema unruhig aufschäumen"
    ],
    "correct": 3,
    "expEn": "Coffee releases CO2 for 5-14 days; brewing too fresh produces gassy, sour, and unstable shots.",
    "expDe": "Frisch gerösteter Kaffee gast CO2 aus; ohne Ruhepause stören die Blasen die Extraktion massiv."
  },
  {
    "id": "q_cof_18",
    "category": "coffee",
    "questionEn": "Which coffee brewing method uses total immersion followed by gentle air pressure?",
    "questionDe": "Welche Brühmethode kombiniert Vollimmersion mit sanftem manuellem Luftdruck?",
    "optionsEn": [
      "Chemex",
      "V60 pour over",
      "AeroPress",
      "Moka pot"
    ],
    "optionsDe": [
      "Chemex",
      "V60 Handfilter",
      "AeroPress",
      "Bialetti Espressokocher"
    ],
    "correctIndex": 2,
    "explanationEn": "The AeroPress steeps grounds completely before pressing through a paper or metal filter with a plunger.",
    "explanationDe": "Die AeroPress zieht wie eine French Press und wird dann mit einem Kolben sanft durchgedrückt.",
    "qEn": "Which coffee brewing method uses total immersion followed by gentle air pressure?",
    "qDe": "Welche Brühmethode kombiniert Vollimmersion mit sanftem manuellem Luftdruck?",
    "optEn": [
      "Chemex",
      "V60 pour over",
      "AeroPress",
      "Moka pot"
    ],
    "optDe": [
      "Chemex",
      "V60 Handfilter",
      "AeroPress",
      "Bialetti Espressokocher"
    ],
    "correct": 2,
    "expEn": "The AeroPress steeps grounds completely before pressing through a paper or metal filter with a plunger.",
    "expDe": "Die AeroPress zieht wie eine French Press und wird dann mit einem Kolben sanft durchgedrückt."
  },
  {
    "id": "q_pas_01",
    "category": "pasta_rice",
    "questionEn": "Why is bronze die extrusion ('trafilata al bronzo') prized for dry pasta?",
    "questionDe": "Warum wird Pasta, die durch Bronzeformen gezogen wurde ('trafilata al bronzo'), so geschätzt?",
    "optionsEn": [
      "Makes pasta cook in 1 minute",
      "Creates a rough, porous, chalky surface that clings tenaciously to sauces and emulsions",
      "Adds yellow food coloring",
      "Prevents pasta from breaking in box"
    ],
    "optionsDe": [
      "Lässt Pasta in 1 Minute gar werden",
      "Erzeugt eine raue, poröse Oberfläche, an der Saucen und Emulsionen perfekt haften",
      "Färbt die Pasta gelb",
      "Verhindert Bruch beim Transport"
    ],
    "correctIndex": 1,
    "explanationEn": "Teflon dies leave pasta slick and shiny; bronze dies create micro-ridges that hold sauce.",
    "explanationDe": "Teflonformen machen Nudeln glatt; Bronze hinterlässt eine raue Struktur, die Sauce bindet.",
    "qEn": "Why is bronze die extrusion ('trafilata al bronzo') prized for dry pasta?",
    "qDe": "Warum wird Pasta, die durch Bronzeformen gezogen wurde ('trafilata al bronzo'), so geschätzt?",
    "optEn": [
      "Makes pasta cook in 1 minute",
      "Creates a rough, porous, chalky surface that clings tenaciously to sauces and emulsions",
      "Adds yellow food coloring",
      "Prevents pasta from breaking in box"
    ],
    "optDe": [
      "Lässt Pasta in 1 Minute gar werden",
      "Erzeugt eine raue, poröse Oberfläche, an der Saucen und Emulsionen perfekt haften",
      "Färbt die Pasta gelb",
      "Verhindert Bruch beim Transport"
    ],
    "correct": 1,
    "expEn": "Teflon dies leave pasta slick and shiny; bronze dies create micro-ridges that hold sauce.",
    "expDe": "Teflonformen machen Nudeln glatt; Bronze hinterlässt eine raue Struktur, die Sauce bindet."
  },
  {
    "id": "q_pas_02",
    "category": "pasta_rice",
    "questionEn": "What does 'Al Dente' mean in culinary pasta preparation?",
    "questionDe": "Was bedeutet 'Al Dente' bei der Pastazubereitung genau?",
    "optionsEn": [
      "Firm to the tooth with a tiny ungelatinized starch core, offering chew resistance",
      "Completely soft and mushy",
      "Crunchy raw in the center",
      "Cooked until it sticks to the wall"
    ],
    "optionsDe": [
      "Fest im Biss mit einem winzigen, stärkehaltigen Kern, der angenehmen Widerstand leistet",
      "Vollständig weich gekocht",
      "Innen steinhart und roh",
      "So weich, dass sie an der Wand klebt"
    ],
    "correctIndex": 0,
    "explanationEn": "Al dente ensures a pleasant bite, slower glycemic absorption, and pasta that won't turn to mush in sauce.",
    "explanationDe": "Pasta mit Biss behält Struktur, lässt sich perfekt in der Pfanne fertig garen und sättigt länger.",
    "qEn": "What does 'Al Dente' mean in culinary pasta preparation?",
    "qDe": "Was bedeutet 'Al Dente' bei der Pastazubereitung genau?",
    "optEn": [
      "Firm to the tooth with a tiny ungelatinized starch core, offering chew resistance",
      "Completely soft and mushy",
      "Crunchy raw in the center",
      "Cooked until it sticks to the wall"
    ],
    "optDe": [
      "Fest im Biss mit einem winzigen, stärkehaltigen Kern, der angenehmen Widerstand leistet",
      "Vollständig weich gekocht",
      "Innen steinhart und roh",
      "So weich, dass sie an der Wand klebt"
    ],
    "correct": 0,
    "expEn": "Al dente ensures a pleasant bite, slower glycemic absorption, and pasta that won't turn to mush in sauce.",
    "expDe": "Pasta mit Biss behält Struktur, lässt sich perfekt in der Pfanne fertig garen und sättigt länger."
  },
  {
    "id": "q_pas_03",
    "category": "pasta_rice",
    "questionEn": "Why should pasta cooking water ('acqua di cottura') always be reserved for finishing sauce?",
    "questionDe": "Warum sollte man beim Abgießen von Nudeln immer Pastawasser aufbewahren?",
    "optionsEn": [
      "To drink as warm broth",
      "To wash the pan afterwards",
      "To cool the pasta down",
      "The suspended gelatinized starch and warm salt water bind fats and liquids into a glossy emulsion ('mantecatura')"
    ],
    "optionsDe": [
      "Als Brühe zum Trinken",
      "Um den Topf zu spülen",
      "Um die Nudeln abzukühlen",
      "Die gelöste Stärke emulgiert Fette und Saucen zu einer sämigen, glänzenden Hülle (Mantecatura)"
    ],
    "correctIndex": 3,
    "explanationEn": "Starchy water bridges oil/butter and cooking liquids, creating cohesive cling without added flour.",
    "explanationDe": "Die Stärke im Kochwasser bindet Fett und Wasser zu einer perfekten Emulsion ohne Mehlbindung.",
    "qEn": "Why should pasta cooking water ('acqua di cottura') always be reserved for finishing sauce?",
    "qDe": "Warum sollte man beim Abgießen von Nudeln immer Pastawasser aufbewahren?",
    "optEn": [
      "To drink as warm broth",
      "To wash the pan afterwards",
      "To cool the pasta down",
      "The suspended gelatinized starch and warm salt water bind fats and liquids into a glossy emulsion ('mantecatura')"
    ],
    "optDe": [
      "Als Brühe zum Trinken",
      "Um den Topf zu spülen",
      "Um die Nudeln abzukühlen",
      "Die gelöste Stärke emulgiert Fette und Saucen zu einer sämigen, glänzenden Hülle (Mantecatura)"
    ],
    "correct": 3,
    "expEn": "Starchy water bridges oil/butter and cooking liquids, creating cohesive cling without added flour.",
    "expDe": "Die Stärke im Kochwasser bindet Fett und Wasser zu einer perfekten Emulsion ohne Mehlbindung."
  },
  {
    "id": "q_pas_04",
    "category": "pasta_rice",
    "questionEn": "Which classic Roman pasta features Pecorino Romano and cracked black pepper exclusively?",
    "questionDe": "Welches klassische römische Pastagericht besteht ausschließlich aus Pecorino Romano und schwarzem Pfeffer?",
    "optionsEn": [
      "Amatriciana",
      "Carbonara",
      "Cacio e Pepe",
      "Pasta alla Gricia"
    ],
    "optionsDe": [
      "Amatriciana",
      "Carbonara",
      "Cacio e Pepe",
      "Pasta alla Gricia"
    ],
    "correctIndex": 2,
    "explanationEn": "Cacio e Pepe emulsifies finely grated sheep cheese with starchy water and toasted black peppercorns.",
    "explanationDe": "Cacio e Pepe bindet Pecorino und frisch gemahlenen Pfeffer allein durch stärkehaltiges Nudelwasser.",
    "qEn": "Which classic Roman pasta features Pecorino Romano and cracked black pepper exclusively?",
    "qDe": "Welches klassische römische Pastagericht besteht ausschließlich aus Pecorino Romano und schwarzem Pfeffer?",
    "optEn": [
      "Amatriciana",
      "Carbonara",
      "Cacio e Pepe",
      "Pasta alla Gricia"
    ],
    "optDe": [
      "Amatriciana",
      "Carbonara",
      "Cacio e Pepe",
      "Pasta alla Gricia"
    ],
    "correct": 2,
    "expEn": "Cacio e Pepe emulsifies finely grated sheep cheese with starchy water and toasted black peppercorns.",
    "expDe": "Cacio e Pepe bindet Pecorino und frisch gemahlenen Pfeffer allein durch stärkehaltiges Nudelwasser."
  },
  {
    "id": "q_pas_05",
    "category": "pasta_rice",
    "questionEn": "Which pasta shape is traditionally paired with Cime di Rapa in Puglia?",
    "questionDe": "Welche Pastaform wird in Apulien traditionell zu Stängelkohl (Cime di Rapa) gereicht?",
    "optionsEn": [
      "Spaghetti",
      "Orecchiette",
      "Penne",
      "Farfalle"
    ],
    "optionsDe": [
      "Spaghetti",
      "Orecchiette ('Öhrchen')",
      "Penne",
      "Farfalle"
    ],
    "correctIndex": 1,
    "explanationEn": "The concave dome of Orecchiette scoops up tender greens, anchovy, and crumbled sausage meat.",
    "explanationDe": "Die Wölbung der Orecchiette schaufelt bitteres Gemüse, Knoblauch und Salsiccia ideal auf.",
    "qEn": "Which pasta shape is traditionally paired with Cime di Rapa in Puglia?",
    "qDe": "Welche Pastaform wird in Apulien traditionell zu Stängelkohl (Cime di Rapa) gereicht?",
    "optEn": [
      "Spaghetti",
      "Orecchiette",
      "Penne",
      "Farfalle"
    ],
    "optDe": [
      "Spaghetti",
      "Orecchiette ('Öhrchen')",
      "Penne",
      "Farfalle"
    ],
    "correct": 1,
    "expEn": "The concave dome of Orecchiette scoops up tender greens, anchovy, and crumbled sausage meat.",
    "expDe": "Die Wölbung der Orecchiette schaufelt bitteres Gemüse, Knoblauch und Salsiccia ideal auf."
  },
  {
    "id": "q_pas_06",
    "category": "pasta_rice",
    "questionEn": "Why is Carnaroli often called the 'King of Risotto Rices' over Arborio?",
    "questionDe": "Warum gilt Carnaroli-Reis als der König für perfektes Risotto im Vergleich zu Arborio?",
    "optionsEn": [
      "Higher amylose content and firm grain structure yield creaminess while staying resiliently al dente",
      "Cooks in 5 minutes",
      "Sweetest rice grain",
      "Zero starch on exterior"
    ],
    "optionsDe": [
      "Höherer Amylosegehalt und fester Kornkern sorgen für sämigen Schmelz bei perfektem Kernbiss",
      "Gart in 5 Minuten",
      "Süßeste Reissorte",
      "Hat keine Stärke"
    ],
    "correctIndex": 0,
    "explanationEn": "Carnaroli releases surface amylopectin for creaminess without the grain breaking down or becoming soggy.",
    "explanationDe": "Carnaroli quillt cremig auf, behält aber im Kern seinen festen Biss und verkocht nicht.",
    "qEn": "Why is Carnaroli often called the 'King of Risotto Rices' over Arborio?",
    "qDe": "Warum gilt Carnaroli-Reis als der König für perfektes Risotto im Vergleich zu Arborio?",
    "optEn": [
      "Higher amylose content and firm grain structure yield creaminess while staying resiliently al dente",
      "Cooks in 5 minutes",
      "Sweetest rice grain",
      "Zero starch on exterior"
    ],
    "optDe": [
      "Höherer Amylosegehalt und fester Kornkern sorgen für sämigen Schmelz bei perfektem Kernbiss",
      "Gart in 5 Minuten",
      "Süßeste Reissorte",
      "Hat keine Stärke"
    ],
    "correct": 0,
    "expEn": "Carnaroli releases surface amylopectin for creaminess without the grain breaking down or becoming soggy.",
    "expDe": "Carnaroli quillt cremig auf, behält aber im Kern seinen festen Biss und verkocht nicht."
  },
  {
    "id": "q_pas_07",
    "category": "pasta_rice",
    "questionEn": "What gives Basmati rice its distinctive floral, nutty fragrance?",
    "questionDe": "Was verleiht echtem Basmati-Reis sein typisches blumig-nussiges Aroma?",
    "optionsEn": [
      "Artificial vanilla flavoring",
      "Added rosewater perfume",
      "Toasting grains in sesame oil",
      "Natural compound 2-Acetyl-1-pyrroline (2AP) developed during Himalayan soil growth and aging"
    ],
    "optionsDe": [
      "Künstliches Vanillin",
      "Zusatz von Rosenwasser",
      "Rösten in Sesamöl",
      "Die aromatische Verbindung 2-Acetyl-1-pyrrolin (2AP) sowie traditionelle Reifelagerung"
    ],
    "correctIndex": 3,
    "explanationEn": "Aged Basmati concentrates 2AP, which creates the celebrated popcorn/pandan aroma.",
    "explanationDe": "Echter Himalaya-Basmati lagert oft monatelang; die Reifung verstärkt das nussige Duftaroma.",
    "qEn": "What gives Basmati rice its distinctive floral, nutty fragrance?",
    "qDe": "Was verleiht echtem Basmati-Reis sein typisches blumig-nussiges Aroma?",
    "optEn": [
      "Artificial vanilla flavoring",
      "Added rosewater perfume",
      "Toasting grains in sesame oil",
      "Natural compound 2-Acetyl-1-pyrroline (2AP) developed during Himalayan soil growth and aging"
    ],
    "optDe": [
      "Künstliches Vanillin",
      "Zusatz von Rosenwasser",
      "Rösten in Sesamöl",
      "Die aromatische Verbindung 2-Acetyl-1-pyrrolin (2AP) sowie traditionelle Reifelagerung"
    ],
    "correct": 3,
    "expEn": "Aged Basmati concentrates 2AP, which creates the celebrated popcorn/pandan aroma.",
    "expDe": "Echter Himalaya-Basmati lagert oft monatelang; die Reifung verstärkt das nussige Duftaroma."
  },
  {
    "id": "q_pas_08",
    "category": "pasta_rice",
    "questionEn": "Why is Parboiled rice more nutritious than regular polished white rice?",
    "questionDe": "Warum enthält Parboiled Reis mehr Nährstoffe als geschliffener weißer Reis?",
    "optionsEn": [
      "Soaked in fruit juice",
      "Enriched with synthetic vitamin powder",
      "Hydrothermal steam pressure forces vitamins and minerals from the bran into the endosperm before milling",
      "Genetically modified"
    ],
    "optionsDe": [
      "In Saft eingeweicht",
      "Mit synthetischem Vitaminpulver besprüht",
      "Druckdampf presst vor dem Schleifen wasserlösliche Vitamine und Mineralstoffe aus der Schale ins Korn",
      "Gentechnisch verändert"
    ],
    "correctIndex": 2,
    "explanationEn": "Parboiling migrates B vitamins into the starchy kernel, gelatinizing starch for non-sticky grains.",
    "explanationDe": "Das Parboiling-Verfahren drückt wertvolle Nährstoffe aus dem Silberhäutchen ins Korninnere.",
    "qEn": "Why is Parboiled rice more nutritious than regular polished white rice?",
    "qDe": "Warum enthält Parboiled Reis mehr Nährstoffe als geschliffener weißer Reis?",
    "optEn": [
      "Soaked in fruit juice",
      "Enriched with synthetic vitamin powder",
      "Hydrothermal steam pressure forces vitamins and minerals from the bran into the endosperm before milling",
      "Genetically modified"
    ],
    "optDe": [
      "In Saft eingeweicht",
      "Mit synthetischem Vitaminpulver besprüht",
      "Druckdampf presst vor dem Schleifen wasserlösliche Vitamine und Mineralstoffe aus der Schale ins Korn",
      "Gentechnisch verändert"
    ],
    "correct": 2,
    "expEn": "Parboiling migrates B vitamins into the starchy kernel, gelatinizing starch for non-sticky grains.",
    "expDe": "Das Parboiling-Verfahren drückt wertvolle Nährstoffe aus dem Silberhäutchen ins Korninnere."
  },
  {
    "id": "q_pas_09",
    "category": "pasta_rice",
    "questionEn": "What distinguishes Jasmine rice from Basmati rice in texture?",
    "questionDe": "Wie unterscheidet sich Jasminreis in der Konsistenz von Basmatireis?",
    "optionsEn": [
      "Jasmine rice stays crunchy like gravel",
      "Jasmine rice is higher in amylopectin, cooking slightly soft, moist, and gently sticky; Basmati cooks firm and separate",
      "Basmati melts into porridge",
      "Jasmine rice has no aroma"
    ],
    "optionsDe": [
      "Jasminreis bleibt steinhart",
      "Jasminreis enthält mehr Amylopektin, wird weicher, feuchter und leicht klebrig; Basmati bleibt trocken-körnig",
      "Basmati wird Brei",
      "Jasminreis hat keinen Duft"
    ],
    "correctIndex": 1,
    "explanationEn": "Jasmine rice grains cling slightly, ideal for picking up with chopsticks or scooping curries.",
    "explanationDe": "Thailändischer Jasminreis haftet sanft zusammen und eignet sich perfekt für asiatische Currys.",
    "qEn": "What distinguishes Jasmine rice from Basmati rice in texture?",
    "qDe": "Wie unterscheidet sich Jasminreis in der Konsistenz von Basmatireis?",
    "optEn": [
      "Jasmine rice stays crunchy like gravel",
      "Jasmine rice is higher in amylopectin, cooking slightly soft, moist, and gently sticky; Basmati cooks firm and separate",
      "Basmati melts into porridge",
      "Jasmine rice has no aroma"
    ],
    "optDe": [
      "Jasminreis bleibt steinhart",
      "Jasminreis enthält mehr Amylopektin, wird weicher, feuchter und leicht klebrig; Basmati bleibt trocken-körnig",
      "Basmati wird Brei",
      "Jasminreis hat keinen Duft"
    ],
    "correct": 1,
    "expEn": "Jasmine rice grains cling slightly, ideal for picking up with chopsticks or scooping curries.",
    "expDe": "Thailändischer Jasminreis haftet sanft zusammen und eignet sich perfekt für asiatische Currys."
  },
  {
    "id": "q_pas_10",
    "category": "pasta_rice",
    "questionEn": "Which traditional rice is essential for Spanish Paella Valenciana?",
    "questionDe": "Welcher Reis ist unverzichtbar für eine authentische Paella Valenciana?",
    "optionsEn": [
      "Arroz Bomba (or Senia)",
      "Basmati",
      "Long grain Patna",
      "Jasmine"
    ],
    "optionsDe": [
      "Arroz Bomba (oder Senia)",
      "Basmati",
      "Langkornreis Patna",
      "Jasminreis"
    ],
    "correctIndex": 0,
    "explanationEn": "Bomba rice absorbs up to 3 times its volume in flavorful saffron broth without bursting.",
    "explanationDe": "Bomba-Reis saugt das Dreifache seines Volumens an Brühe auf, ohne seine Form zu verlieren.",
    "qEn": "Which traditional rice is essential for Spanish Paella Valenciana?",
    "qDe": "Welcher Reis ist unverzichtbar für eine authentische Paella Valenciana?",
    "optEn": [
      "Arroz Bomba (or Senia)",
      "Basmati",
      "Long grain Patna",
      "Jasmine"
    ],
    "optDe": [
      "Arroz Bomba (oder Senia)",
      "Basmati",
      "Langkornreis Patna",
      "Jasminreis"
    ],
    "correct": 0,
    "expEn": "Bomba rice absorbs up to 3 times its volume in flavorful saffron broth without bursting.",
    "expDe": "Bomba-Reis saugt das Dreifache seines Volumens an Brühe auf, ohne seine Form zu verlieren."
  },
  {
    "id": "q_pas_11",
    "category": "pasta_rice",
    "questionEn": "What is 'Socarrat' in authentic paella cooking?",
    "questionDe": "Was versteht man unter 'Socarrat' bei einer perfekten Paella?",
    "optionsEn": [
      "The lemon wedge garnish",
      "The raw chicken used",
      "The saffron broth",
      "The crispy, deeply caramelized, golden-brown crust of rice formed at the bottom of the pan"
    ],
    "optionsDe": [
      "Die Zitronenschnitze",
      "Das rohe Fleisch",
      "Die Safransuppe",
      "Die knusprige, karamellisierte Reiskruste am flachen Boden der Paellapfanne"
    ],
    "correctIndex": 3,
    "explanationEn": "Gentle rendering of olive oil and broth at the end crisps the bottom rice into a prize crunchy delicacy.",
    "explanationDe": "Das kurze Anrösten am Ende karamellisiert Stärke und Fett zu einer aromatischen Knusperschicht.",
    "qEn": "What is 'Socarrat' in authentic paella cooking?",
    "qDe": "Was versteht man unter 'Socarrat' bei einer perfekten Paella?",
    "optEn": [
      "The lemon wedge garnish",
      "The raw chicken used",
      "The saffron broth",
      "The crispy, deeply caramelized, golden-brown crust of rice formed at the bottom of the pan"
    ],
    "optDe": [
      "Die Zitronenschnitze",
      "Das rohe Fleisch",
      "Die Safransuppe",
      "Die knusprige, karamellisierte Reiskruste am flachen Boden der Paellapfanne"
    ],
    "correct": 3,
    "expEn": "Gentle rendering of olive oil and broth at the end crisps the bottom rice into a prize crunchy delicacy.",
    "expDe": "Das kurze Anrösten am Ende karamellisiert Stärke und Fett zu einer aromatischen Knusperschicht."
  },
  {
    "id": "q_pas_12",
    "category": "pasta_rice",
    "questionEn": "Why is short-grain Japonica rice used for Sushi (Koshihikari)?",
    "questionDe": "Warum wird für Sushi ausschließlich Rundkornreis (Japonica, z.B. Koshihikari) verwendet?",
    "optionsEn": [
      "It cooks in 3 minutes",
      "It is yellow naturally",
      "High amylopectin content provides cohesion that holds shaped nigiri together while dissolving gently in mouth",
      "It has zero carbohydrates"
    ],
    "optionsDe": [
      "Gart in 3 Minuten",
      "Er ist von Natur aus gelb",
      "Hoher Amylopektinanteil schenkt optimale Klebrigkeit für geformte Nigiri ohne zähen Matsch",
      "Hat keine Kohlenhydrate"
    ],
    "correctIndex": 2,
    "explanationEn": "Seasoned with rice vinegar, sugar, and salt, Japonica grains stick without needing heavy pressing.",
    "explanationDe": "Gewürzt mit Sushizu halten die Reiskörner zusammen, schmelzen aber am Gaumen locker auseinander.",
    "qEn": "Why is short-grain Japonica rice used for Sushi (Koshihikari)?",
    "qDe": "Warum wird für Sushi ausschließlich Rundkornreis (Japonica, z.B. Koshihikari) verwendet?",
    "optEn": [
      "It cooks in 3 minutes",
      "It is yellow naturally",
      "High amylopectin content provides cohesion that holds shaped nigiri together while dissolving gently in mouth",
      "It has zero carbohydrates"
    ],
    "optDe": [
      "Gart in 3 Minuten",
      "Er ist von Natur aus gelb",
      "Hoher Amylopektinanteil schenkt optimale Klebrigkeit für geformte Nigiri ohne zähen Matsch",
      "Hat keine Kohlenhydrate"
    ],
    "correct": 2,
    "expEn": "Seasoned with rice vinegar, sugar, and salt, Japonica grains stick without needing heavy pressing.",
    "expDe": "Gewürzt mit Sushizu halten die Reiskörner zusammen, schmelzen aber am Gaumen locker auseinander."
  },
  {
    "id": "q_pas_13",
    "category": "pasta_rice",
    "questionEn": "What is Wild Rice botanically?",
    "questionDe": "Was ist Wildreis aus botanischer Sicht?",
    "optionsEn": [
      "Charred black Asian rice",
      "The aquatic seed of North American water grass (Zizania palustris), not a true Oryza rice",
      "Wild wheat grain",
      "Artificially dyed rice"
    ],
    "optionsDe": [
      "Verkohlter Basmatireis",
      "Samen eines nordamerikanischen Süßgrases (Zizania palustris), kein echter Reis",
      "Wilder Urweizen",
      "Eingefärbter Reis"
    ],
    "correctIndex": 1,
    "explanationEn": "Wild rice is an aquatic marsh grass seed celebrated for its firm chew and smoky tea-like aroma.",
    "explanationDe": "Wildreis ist ein Wassergras mit festem Biss und nussig-erdigem, rauchigem Geschmack.",
    "qEn": "What is Wild Rice botanically?",
    "qDe": "Was ist Wildreis aus botanischer Sicht?",
    "optEn": [
      "Charred black Asian rice",
      "The aquatic seed of North American water grass (Zizania palustris), not a true Oryza rice",
      "Wild wheat grain",
      "Artificially dyed rice"
    ],
    "optDe": [
      "Verkohlter Basmatireis",
      "Samen eines nordamerikanischen Süßgrases (Zizania palustris), kein echter Reis",
      "Wilder Urweizen",
      "Eingefärbter Reis"
    ],
    "correct": 1,
    "expEn": "Wild rice is an aquatic marsh grass seed celebrated for its firm chew and smoky tea-like aroma.",
    "expDe": "Wildreis ist ein Wassergras mit festem Biss und nussig-erdigem, rauchigem Geschmack."
  },
  {
    "id": "q_pas_14",
    "category": "pasta_rice",
    "questionEn": "Why is rinsing white rice prior to cooking recommended?",
    "questionDe": "Warum sollte weißer Reis vor dem Kochen gründlich gewaschen werden?",
    "optionsEn": [
      "Removes excess surface flour and loose starch granules, preventing a gluey, gummy texture",
      "Kills bacteria",
      "Adds water weight",
      "Extracts salt"
    ],
    "optionsDe": [
      "Spült lose Oberflächenstärke ab, damit die Körner beim Kochen nicht klebrig verkleistern",
      "Tötet Bakterien ab",
      "Macht ihn schwerer",
      "Entzieht Salz"
    ],
    "correctIndex": 0,
    "explanationEn": "Rinsing until the water runs clear ensures fluffy, distinct, and individual grains.",
    "explanationDe": "Das Waschen bis zum klaren Ablauf verhindert, dass freie Stärke den Reis in Brei verwandelt.",
    "qEn": "Why is rinsing white rice prior to cooking recommended?",
    "qDe": "Warum sollte weißer Reis vor dem Kochen gründlich gewaschen werden?",
    "optEn": [
      "Removes excess surface flour and loose starch granules, preventing a gluey, gummy texture",
      "Kills bacteria",
      "Adds water weight",
      "Extracts salt"
    ],
    "optDe": [
      "Spült lose Oberflächenstärke ab, damit die Körner beim Kochen nicht klebrig verkleistern",
      "Tötet Bakterien ab",
      "Macht ihn schwerer",
      "Entzieht Salz"
    ],
    "correct": 0,
    "expEn": "Rinsing until the water runs clear ensures fluffy, distinct, and individual grains.",
    "expDe": "Das Waschen bis zum klaren Ablauf verhindert, dass freie Stärke den Reis in Brei verwandelt."
  },
  {
    "id": "q_pas_15",
    "category": "pasta_rice",
    "questionEn": "Which sauce style pairs best with broad ribbon Tagliatelle / Pappardelle?",
    "questionDe": "Welche Sauce harmoniert ideal mit breiten Bandnudeln (Tagliatelle, Pappardelle)?",
    "optionsEn": [
      "Melted fruit jelly",
      "Light olive oil and garlic",
      "Clear consommé",
      "Rich meat ragùs, wild boar, and braised mushroom sauces"
    ],
    "optionsDe": [
      "Fruchtgelee",
      "Dünnes Knoblauchöl",
      "Klare Brühe",
      "Reichhaltige Fleischragùs (Bolognese, Wildschwein) und dichte Pilzsaucen"
    ],
    "correctIndex": 3,
    "explanationEn": "Broad rough egg ribbons provide the surface area required to suspend heavy meat pieces and emulsified braises.",
    "explanationDe": "Breite Nudeln bieten die nötige Tragfläche für stückige Fleischsaucen und Pilzragùs.",
    "qEn": "Which sauce style pairs best with broad ribbon Tagliatelle / Pappardelle?",
    "qDe": "Welche Sauce harmoniert ideal mit breiten Bandnudeln (Tagliatelle, Pappardelle)?",
    "optEn": [
      "Melted fruit jelly",
      "Light olive oil and garlic",
      "Clear consommé",
      "Rich meat ragùs, wild boar, and braised mushroom sauces"
    ],
    "optDe": [
      "Fruchtgelee",
      "Dünnes Knoblauchöl",
      "Klare Brühe",
      "Reichhaltige Fleischragùs (Bolognese, Wildschwein) und dichte Pilzsaucen"
    ],
    "correct": 3,
    "expEn": "Broad rough egg ribbons provide the surface area required to suspend heavy meat pieces and emulsified braises.",
    "expDe": "Breite Nudeln bieten die nötige Tragfläche für stückige Fleischsaucen und Pilzragùs."
  },
  {
    "id": "q_pas_16",
    "category": "pasta_rice",
    "questionEn": "What is the defining meat in authentic Carbonara and Amatriciana?",
    "questionDe": "Welches Fleischstück ist Pflicht für echte Carbonara und Amatriciana?",
    "optionsEn": [
      "Cooked ham",
      "Pancetta (pork belly)",
      "Guanciale (cured pork jowl / cheek)",
      "Smoked bacon strips"
    ],
    "optionsDe": [
      "Kochschinken",
      "Pancetta (Bauchspeck)",
      "Guanciale (luftgetrocknete Schweinebacke)",
      "Geräucherter Speck"
    ],
    "correctIndex": 2,
    "explanationEn": "Guanciale contains rich intramuscular fat and peppery curing spices, rendering clear, savory liquid gold.",
    "explanationDe": "Schweinebacke schmilzt zart, hat ein feines Aroma und liefert das unersetzliche Schmalz.",
    "qEn": "What is the defining meat in authentic Carbonara and Amatriciana?",
    "qDe": "Welches Fleischstück ist Pflicht für echte Carbonara und Amatriciana?",
    "optEn": [
      "Cooked ham",
      "Pancetta (pork belly)",
      "Guanciale (cured pork jowl / cheek)",
      "Smoked bacon strips"
    ],
    "optDe": [
      "Kochschinken",
      "Pancetta (Bauchspeck)",
      "Guanciale (luftgetrocknete Schweinebacke)",
      "Geräucherter Speck"
    ],
    "correct": 2,
    "expEn": "Guanciale contains rich intramuscular fat and peppery curing spices, rendering clear, savory liquid gold.",
    "expDe": "Schweinebacke schmilzt zart, hat ein feines Aroma und liefert das unersetzliche Schmalz."
  },
  {
    "id": "q_pas_17",
    "category": "pasta_rice",
    "questionEn": "Why should freshly made egg pasta (Pasta Fresca) never be rinsed with cold water after boiling?",
    "questionDe": "Warum darf frische Eierteigware nach dem Kochen keinesfalls mit kaltem Wasser abgeschreckt werden?",
    "optionsEn": [
      "Pasta turns toxic",
      "Cold water washes away starchy surface film and causes temperature shock, preventing sauce binding",
      "Pasta melts completely",
      "Eggs coagulate into leather"
    ],
    "optionsDe": [
      "Nudeln werden giftig",
      "Abschrecken spült den Stärkefilm ab und kühlt die Nudel ab, wodurch keine Sauce mehr haftet",
      "Sie lösen sich auf",
      "Das Ei wird zäh"
    ],
    "correctIndex": 1,
    "explanationEn": "Rinsing removes the microscopic starch coating that forms a velvet emulsion with sauce.",
    "explanationDe": "Nudeln niemals abschrecken; sie müssen dampfend heiß direkt in die heiße Sauce wandern.",
    "qEn": "Why should freshly made egg pasta (Pasta Fresca) never be rinsed with cold water after boiling?",
    "qDe": "Warum darf frische Eierteigware nach dem Kochen keinesfalls mit kaltem Wasser abgeschreckt werden?",
    "optEn": [
      "Pasta turns toxic",
      "Cold water washes away starchy surface film and causes temperature shock, preventing sauce binding",
      "Pasta melts completely",
      "Eggs coagulate into leather"
    ],
    "optDe": [
      "Nudeln werden giftig",
      "Abschrecken spült den Stärkefilm ab und kühlt die Nudel ab, wodurch keine Sauce mehr haftet",
      "Sie lösen sich auf",
      "Das Ei wird zäh"
    ],
    "correct": 1,
    "expEn": "Rinsing removes the microscopic starch coating that forms a velvet emulsion with sauce.",
    "expDe": "Nudeln niemals abschrecken; sie müssen dampfend heiß direkt in die heiße Sauce wandern."
  },
  {
    "id": "q_pas_18",
    "category": "pasta_rice",
    "questionEn": "What distinguishes Rigatoni from Penne?",
    "questionDe": "Was unterscheidet Rigatoni von Penne Rigate?",
    "optionsEn": [
      "Rigatoni are straight cut with wide round cylinder openings; Penne are cut diagonally with pointed quills",
      "Rigatoni have no ridges",
      "Penne are made of potatoes",
      "Rigatoni are stuffed"
    ],
    "optionsDe": [
      "Rigatoni sind gerade geschnitten mit weiter Öffnung; Penne sind schräg angespitzt ('Federkiel')",
      "Rigatoni haben keine Rillen",
      "Penne bestehen aus Kartoffeln",
      "Rigatoni sind gefüllt"
    ],
    "correctIndex": 0,
    "explanationEn": "Rigatoni ('ridged') have straight cut ends and a wide tube that captures sausage and peas inside.",
    "explanationDe": "Penne sind wie antike Schreibfedern schräg gekappt; Rigatoni fangen Saucenstückchen im Hohlraum ein.",
    "qEn": "What distinguishes Rigatoni from Penne?",
    "qDe": "Was unterscheidet Rigatoni von Penne Rigate?",
    "optEn": [
      "Rigatoni are straight cut with wide round cylinder openings; Penne are cut diagonally with pointed quills",
      "Rigatoni have no ridges",
      "Penne are made of potatoes",
      "Rigatoni are stuffed"
    ],
    "optDe": [
      "Rigatoni sind gerade geschnitten mit weiter Öffnung; Penne sind schräg angespitzt ('Federkiel')",
      "Rigatoni haben keine Rillen",
      "Penne bestehen aus Kartoffeln",
      "Rigatoni sind gefüllt"
    ],
    "correct": 0,
    "expEn": "Rigatoni ('ridged') have straight cut ends and a wide tube that captures sausage and peas inside.",
    "expDe": "Penne sind wie antike Schreibfedern schräg gekappt; Rigatoni fangen Saucenstückchen im Hohlraum ein."
  },
  {
    "id": "q_sau_01",
    "category": "sauces_condiments",
    "questionEn": "What type of chemical emulsion is real Mayonnaise?",
    "questionDe": "Welche Art von chemischer Emulsion ist echte Mayonnaise?",
    "optionsEn": [
      "Suspension of solid fats",
      "Water-in-oil emulsion",
      "Gas emulsion",
      "Oil-in-water emulsion stabilized by egg yolk lecithin"
    ],
    "optionsDe": [
      "Suspension fester Fette",
      "Wasser-in-Öl-Emulsion",
      "Gasemulsion",
      "Öl-in-Wasser-Emulsion, stabilisiert durch Eidotter-Lecithin"
    ],
    "correctIndex": 3,
    "explanationEn": "Lecithin in egg yolk coats dispersed oil micro-droplets, preventing them from coalescing into oil slicks.",
    "explanationDe": "Lecithin im Eigelb bindet die feinen Öltröpfchen im Wasseranteil zu einer stabilen Creme.",
    "qEn": "What type of chemical emulsion is real Mayonnaise?",
    "qDe": "Welche Art von chemischer Emulsion ist echte Mayonnaise?",
    "optEn": [
      "Suspension of solid fats",
      "Water-in-oil emulsion",
      "Gas emulsion",
      "Oil-in-water emulsion stabilized by egg yolk lecithin"
    ],
    "optDe": [
      "Suspension fester Fette",
      "Wasser-in-Öl-Emulsion",
      "Gasemulsion",
      "Öl-in-Wasser-Emulsion, stabilisiert durch Eidotter-Lecithin"
    ],
    "correct": 3,
    "expEn": "Lecithin in egg yolk coats dispersed oil micro-droplets, preventing them from coalescing into oil slicks.",
    "expDe": "Lecithin im Eigelb bindet die feinen Öltröpfchen im Wasseranteil zu einer stabilen Creme."
  },
  {
    "id": "q_sau_02",
    "category": "sauces_condiments",
    "questionEn": "What gives Japanese Kewpie Mayonnaise its richer taste and velvety texture?",
    "questionDe": "Was verleiht japanischer Kewpie-Mayonnaise ihren reicheren Geschmack und Schmelz?",
    "optionsEn": [
      "Contains sweet cream",
      "Uses olive oil exclusively",
      "Uses only egg yolks (no whites), rice vinegar, and monosodium glutamate (MSG)",
      "Is cooked like custard"
    ],
    "optionsDe": [
      "Enthält flüssige Sahne",
      "Basiert nur auf Olivenöl",
      "Verwendet nur reines Eigelb (kein Eiklar), milden Reisessig und einen Hauch MSG",
      "Wird wie Pudding gekocht"
    ],
    "correctIndex": 2,
    "explanationEn": "Using exclusively egg yolks doubles phospholipid density, yielding deeper yellow color and umami depth.",
    "explanationDe": "Das ausschließliche Eigelb sorgt für samtigen Schmelz und typischen Umami-Körper.",
    "qEn": "What gives Japanese Kewpie Mayonnaise its richer taste and velvety texture?",
    "qDe": "Was verleiht japanischer Kewpie-Mayonnaise ihren reicheren Geschmack und Schmelz?",
    "optEn": [
      "Contains sweet cream",
      "Uses olive oil exclusively",
      "Uses only egg yolks (no whites), rice vinegar, and monosodium glutamate (MSG)",
      "Is cooked like custard"
    ],
    "optDe": [
      "Enthält flüssige Sahne",
      "Basiert nur auf Olivenöl",
      "Verwendet nur reines Eigelb (kein Eiklar), milden Reisessig und einen Hauch MSG",
      "Wird wie Pudding gekocht"
    ],
    "correct": 2,
    "expEn": "Using exclusively egg yolks doubles phospholipid density, yielding deeper yellow color and umami depth.",
    "expDe": "Das ausschließliche Eigelb sorgt für samtigen Schmelz und typischen Umami-Körper."
  },
  {
    "id": "q_sau_03",
    "category": "sauces_condiments",
    "questionEn": "At what temperature does Sauce Hollandaise break (curdle) if overheated?",
    "questionDe": "Bei welcher Temperatur gerinnt Sauce Hollandaise, wenn sie zu heiß geschlagen wird?",
    "optionsEn": [
      "Above 100°C",
      "Above 68°C to 70°C (155°F - 158°F)",
      "Above 45°C",
      "At 30°C"
    ],
    "optionsDe": [
      "Erst über 100°C",
      "Ab ca. 68°C bis 70°C",
      "Bereits ab 45°C",
      "Bei 30°C"
    ],
    "correctIndex": 1,
    "explanationEn": "Egg proteins coagulate above 68°C, squeezing out bound butter fat into an oily curdled mess.",
    "explanationDe": "Ab 68°C stockt das Eigelb unumkehrbar; die Fett-Wasser-Bindung bricht schlagartig zusammen.",
    "qEn": "At what temperature does Sauce Hollandaise break (curdle) if overheated?",
    "qDe": "Bei welcher Temperatur gerinnt Sauce Hollandaise, wenn sie zu heiß geschlagen wird?",
    "optEn": [
      "Above 100°C",
      "Above 68°C to 70°C (155°F - 158°F)",
      "Above 45°C",
      "At 30°C"
    ],
    "optDe": [
      "Erst über 100°C",
      "Ab ca. 68°C bis 70°C",
      "Bereits ab 45°C",
      "Bei 30°C"
    ],
    "correct": 1,
    "expEn": "Egg proteins coagulate above 68°C, squeezing out bound butter fat into an oily curdled mess.",
    "expDe": "Ab 68°C stockt das Eigelb unumkehrbar; die Fett-Wasser-Bindung bricht schlagartig zusammen."
  },
  {
    "id": "q_sau_04",
    "category": "sauces_condiments",
    "questionEn": "What liquid base is traditionally used in authentic French Dijon Mustard instead of plain vinegar?",
    "questionDe": "Welche traditionelle Flüssigkeit wird für echten Dijonsenf statt billigem Essig verwendet?",
    "optionsEn": [
      "Verjus (unripe green grape juice) or white wine",
      "Apple cider",
      "Distilled malt vinegar",
      "Lemon water"
    ],
    "optionsDe": [
      "Verjus (Säuresaft unreifer Trauben) oder trockener Weißwein",
      "Apfelmost",
      "Malzessig",
      "Zitronenwasser"
    ],
    "correctIndex": 0,
    "explanationEn": "Brown Brassica juncea seeds soaked in sour verjus create Dijon's clean, piercing sinus heat.",
    "explanationDe": "Verjus oder Weißwein verleiht Dijonsenf seine scharfe, feine und ungesüßte Frische.",
    "qEn": "What liquid base is traditionally used in authentic French Dijon Mustard instead of plain vinegar?",
    "qDe": "Welche traditionelle Flüssigkeit wird für echten Dijonsenf statt billigem Essig verwendet?",
    "optEn": [
      "Verjus (unripe green grape juice) or white wine",
      "Apple cider",
      "Distilled malt vinegar",
      "Lemon water"
    ],
    "optDe": [
      "Verjus (Säuresaft unreifer Trauben) oder trockener Weißwein",
      "Apfelmost",
      "Malzessig",
      "Zitronenwasser"
    ],
    "correct": 0,
    "expEn": "Brown Brassica juncea seeds soaked in sour verjus create Dijon's clean, piercing sinus heat.",
    "expDe": "Verjus oder Weißwein verleiht Dijonsenf seine scharfe, feine und ungesüßte Frische."
  },
  {
    "id": "q_sau_05",
    "category": "sauces_condiments",
    "questionEn": "What imparts the distinctive sweet-spicy character to Bavarian Sweet Mustard (Weißwurstsenf)?",
    "questionDe": "Was verleiht bayerischem süßem Senf (Weißwurstsenf) seinen typischen Charakter?",
    "optionsEn": [
      "Sweet milk",
      "Honey and chili flakes",
      "Molasses and tomato paste",
      "Coarsely crushed yellow and brown seeds, caramelized brown sugar, and apple sauce/spices"
    ],
    "optionsDe": [
      "Süße Milch",
      "Reiner Bienenhonig und Chili",
      "Melasse und Tomatenmark",
      "Grob geschrotete Senfsaat, karamellisierter Zucker und feine Gewürze"
    ],
    "correctIndex": 3,
    "explanationEn": "Traditional Weißwurstsenf balances coarse crunch with caramelized sugar syrup and mild vinegar.",
    "explanationDe": "Der karamellisierte Zucker puffert die Schärfe der Senfkörner harmonisch zur Weißwurst ab.",
    "qEn": "What imparts the distinctive sweet-spicy character to Bavarian Sweet Mustard (Weißwurstsenf)?",
    "qDe": "Was verleiht bayerischem süßem Senf (Weißwurstsenf) seinen typischen Charakter?",
    "optEn": [
      "Sweet milk",
      "Honey and chili flakes",
      "Molasses and tomato paste",
      "Coarsely crushed yellow and brown seeds, caramelized brown sugar, and apple sauce/spices"
    ],
    "optDe": [
      "Süße Milch",
      "Reiner Bienenhonig und Chili",
      "Melasse und Tomatenmark",
      "Grob geschrotete Senfsaat, karamellisierter Zucker und feine Gewürze"
    ],
    "correct": 3,
    "expEn": "Traditional Weißwurstsenf balances coarse crunch with caramelized sugar syrup and mild vinegar.",
    "expDe": "Der karamellisierte Zucker puffert die Schärfe der Senfkörner harmonisch zur Weißwurst ab."
  },
  {
    "id": "q_sau_06",
    "category": "sauces_condiments",
    "questionEn": "How is authentic McIlhenny Tabasco sauce aged?",
    "questionDe": "Wie reift originale Tabasco Pepper Sauce?",
    "optionsEn": [
      "Sun-dried in clay pots",
      "Boiled in steel tanks with vinegar",
      "Tabasco chili mash is salted and aged for up to 3 years in white oak whiskey barrels",
      "Fermented under water"
    ],
    "optionsDe": [
      "In Tonkrügen getrocknet",
      "In Stahltanks gekocht",
      "Chili-Maische reift bis zu 3 Jahre mit Salz in ausgebrannten Eichenfässern",
      "Unter Wasser vergoren"
    ],
    "correctIndex": 2,
    "explanationEn": "Three years of oak barrel aging develop complex fermented fruity acids before vinegar blending.",
    "explanationDe": "Die dreijährige Holzfassreife erzeugt das unverwechselbare fermentierte Holzaroma.",
    "qEn": "How is authentic McIlhenny Tabasco sauce aged?",
    "qDe": "Wie reift originale Tabasco Pepper Sauce?",
    "optEn": [
      "Sun-dried in clay pots",
      "Boiled in steel tanks with vinegar",
      "Tabasco chili mash is salted and aged for up to 3 years in white oak whiskey barrels",
      "Fermented under water"
    ],
    "optDe": [
      "In Tonkrügen getrocknet",
      "In Stahltanks gekocht",
      "Chili-Maische reift bis zu 3 Jahre mit Salz in ausgebrannten Eichenfässern",
      "Unter Wasser vergoren"
    ],
    "correct": 2,
    "expEn": "Three years of oak barrel aging develop complex fermented fruity acids before vinegar blending.",
    "expDe": "Die dreijährige Holzfassreife erzeugt das unverwechselbare fermentierte Holzaroma."
  },
  {
    "id": "q_sau_07",
    "category": "sauces_condiments",
    "questionEn": "What key ingredients define classic Thai Sriracha sauce?",
    "questionDe": "Welche Kernzutaten prägen originale Sriracha Chilisauce?",
    "optionsEn": [
      "Habanero and mango",
      "Sun-ripened red jalapeño chilis, fresh garlic, vinegar, sugar, and salt",
      "Dried chipotle and chocolate",
      "Black pepper and soy sauce"
    ],
    "optionsDe": [
      "Habanero und Mango",
      "Rote reife Jalapeño-Chilis, frischer Knoblauch, Essig, Zucker und Salz",
      "Chipotle und Schokolade",
      "Schwarzer Pfeffer und Sojasauce"
    ],
    "correctIndex": 1,
    "explanationEn": "Sriracha balances fermented garlic tang with sweet heat, originating in Si Racha, Thailand.",
    "explanationDe": "Die Balance aus frischem Knoblauch, feiner Säure und Chilisüße macht Sriracha weltberühmt.",
    "qEn": "What key ingredients define classic Thai Sriracha sauce?",
    "qDe": "Welche Kernzutaten prägen originale Sriracha Chilisauce?",
    "optEn": [
      "Habanero and mango",
      "Sun-ripened red jalapeño chilis, fresh garlic, vinegar, sugar, and salt",
      "Dried chipotle and chocolate",
      "Black pepper and soy sauce"
    ],
    "optDe": [
      "Habanero und Mango",
      "Rote reife Jalapeño-Chilis, frischer Knoblauch, Essig, Zucker und Salz",
      "Chipotle und Schokolade",
      "Schwarzer Pfeffer und Sojasauce"
    ],
    "correct": 1,
    "expEn": "Sriracha balances fermented garlic tang with sweet heat, originating in Si Racha, Thailand.",
    "expDe": "Die Balance aus frischem Knoblauch, feiner Säure und Chilisüße macht Sriracha weltberühmt."
  },
  {
    "id": "q_sau_08",
    "category": "sauces_condiments",
    "questionEn": "What ingredients characterize Kansas City-style Barbecue sauce?",
    "questionDe": "Was zeichnet Barbecue-Sauce im Kansas City-Stil aus?",
    "optionsEn": [
      "Thick tomato/ketchup base, dark molasses or brown sugar, apple cider vinegar, and liquid smoke",
      "Pure yellow mustard and vinegar",
      "White mayonnaise base",
      "Soy sauce and mirin"
    ],
    "optionsDe": [
      "Dicke Tomatenbasis, dunkle Melasse oder brauner Zucker, Apfelessig und Rauchnote",
      "Reiner Senf und Essig",
      "Weiße Mayonnaisebasis",
      "Sojasauce und Mirin"
    ],
    "correctIndex": 0,
    "explanationEn": "Kansas City BBQ sauce is sweet, sticky, and smoky, clinging to smoked ribs and brisket.",
    "explanationDe": "Süß, rauchig und dickflüssig: Melasse und Tomate karamellisieren perfekt auf Rippchen.",
    "qEn": "What ingredients characterize Kansas City-style Barbecue sauce?",
    "qDe": "Was zeichnet Barbecue-Sauce im Kansas City-Stil aus?",
    "optEn": [
      "Thick tomato/ketchup base, dark molasses or brown sugar, apple cider vinegar, and liquid smoke",
      "Pure yellow mustard and vinegar",
      "White mayonnaise base",
      "Soy sauce and mirin"
    ],
    "optDe": [
      "Dicke Tomatenbasis, dunkle Melasse oder brauner Zucker, Apfelessig und Rauchnote",
      "Reiner Senf und Essig",
      "Weiße Mayonnaisebasis",
      "Sojasauce und Mirin"
    ],
    "correct": 0,
    "expEn": "Kansas City BBQ sauce is sweet, sticky, and smoky, clinging to smoked ribs and brisket.",
    "expDe": "Süß, rauchig und dickflüssig: Melasse und Tomate karamellisieren perfekt auf Rippchen."
  },
  {
    "id": "q_sau_09",
    "category": "sauces_condiments",
    "questionEn": "What distinguishes Mexican Salsa Verde from Salsa Roja?",
    "questionDe": "Was unterscheidet mexikanische Salsa Verde grundlegend von Salsa Roja?",
    "optionsEn": [
      "Salsa Roja uses red wine",
      "Salsa Verde is colored with spinach",
      "Salsa Verde has no chilis",
      "Salsa Verde uses tart green Tomatillos (Physalis philadelphica); Salsa Roja uses ripe red tomatoes"
    ],
    "optionsDe": [
      "Salsa Roja enthält Rotwein",
      "Salsa Verde wird mit Spinat gefärbt",
      "Salsa Verde hat keine Chilis",
      "Salsa Verde basiert auf säuerlichen grünen Tomatillos; Salsa Roja auf reifen roten Tomaten"
    ],
    "correctIndex": 3,
    "explanationEn": "Tomatillos are husked tart nightshades providing herbal citrus tang unlike sweeter red tomatoes.",
    "explanationDe": "Tomatillos besitzen eine spritzige Fruchtsäure und verleihen Salsa Verde ihren herben Kick.",
    "qEn": "What distinguishes Mexican Salsa Verde from Salsa Roja?",
    "qDe": "Was unterscheidet mexikanische Salsa Verde grundlegend von Salsa Roja?",
    "optEn": [
      "Salsa Roja uses red wine",
      "Salsa Verde is colored with spinach",
      "Salsa Verde has no chilis",
      "Salsa Verde uses tart green Tomatillos (Physalis philadelphica); Salsa Roja uses ripe red tomatoes"
    ],
    "optDe": [
      "Salsa Roja enthält Rotwein",
      "Salsa Verde wird mit Spinat gefärbt",
      "Salsa Verde hat keine Chilis",
      "Salsa Verde basiert auf säuerlichen grünen Tomatillos; Salsa Roja auf reifen roten Tomaten"
    ],
    "correct": 3,
    "expEn": "Tomatillos are husked tart nightshades providing herbal citrus tang unlike sweeter red tomatoes.",
    "expDe": "Tomatillos besitzen eine spritzige Fruchtsäure und verleihen Salsa Verde ihren herben Kick."
  },
  {
    "id": "q_sau_10",
    "category": "sauces_condiments",
    "questionEn": "What is the classic culinary ratio for a French Vinaigrette?",
    "questionDe": "Was ist das klassische Grundverhältnis für eine französische Vinaigrette?",
    "optionsEn": [
      "Equal parts oil and vinegar (1:1)",
      "1 part oil to 3 parts vinegar",
      "3 parts oil to 1 part vinegar (or acid)",
      "5 parts vinegar to 1 part oil"
    ],
    "optionsDe": [
      "Zu gleichen Teilen (1:1)",
      "1 Teil Öl auf 3 Teile Essig",
      "3 Teile Öl auf 1 Teil Essig (oder Säure)",
      "5 Teile Essig auf 1 Teil Öl"
    ],
    "correctIndex": 2,
    "explanationEn": "The 3:1 ratio provides enough fat to coat salad leaves without overpowering tart acidity.",
    "explanationDe": "Drei Teile Öl binden einen Teil Säure zu einer harmonischen, mundfüllenden Salatsauce.",
    "qEn": "What is the classic culinary ratio for a French Vinaigrette?",
    "qDe": "Was ist das klassische Grundverhältnis für eine französische Vinaigrette?",
    "optEn": [
      "Equal parts oil and vinegar (1:1)",
      "1 part oil to 3 parts vinegar",
      "3 parts oil to 1 part vinegar (or acid)",
      "5 parts vinegar to 1 part oil"
    ],
    "optDe": [
      "Zu gleichen Teilen (1:1)",
      "1 Teil Öl auf 3 Teile Essig",
      "3 Teile Öl auf 1 Teil Essig (oder Säure)",
      "5 Teile Essig auf 1 Teil Öl"
    ],
    "correct": 2,
    "expEn": "The 3:1 ratio provides enough fat to coat salad leaves without overpowering tart acidity.",
    "expDe": "Drei Teile Öl binden einen Teil Säure zu einer harmonischen, mundfüllenden Salatsauce."
  },
  {
    "id": "q_sau_11",
    "category": "sauces_condiments",
    "questionEn": "Which essential ingredients create the iconic Caesar Dressing emulsification?",
    "questionDe": "Welche Zutaten sind unverzichtbar für ein authentisches Caesar Dressing?",
    "optionsEn": [
      "Yogurt, dill, and cucumber",
      "Egg yolk, salted anchovies, garlic, Parmesan, lemon juice, Dijon mustard, and Worcestershire sauce",
      "Tomato paste and paprika",
      "Sour cream and sugar"
    ],
    "optionsDe": [
      "Joghurt, Dill und Gurke",
      "Eigelb, Sardellenfilets, Knoblauch, Parmesan, Zitronensaft, Dijon und Worcestershire-Sauce",
      "Tomatenmark und Paprika",
      "Schmand und Zucker"
    ],
    "correctIndex": 1,
    "explanationEn": "Anchovies and aged Parmigiano-Reggiano provide the powerful natural glutamates (umami).",
    "explanationDe": "Sardellen und Parmesan liefern das typische, dichte Umami auf knackigem Römersalat.",
    "qEn": "Which essential ingredients create the iconic Caesar Dressing emulsification?",
    "qDe": "Welche Zutaten sind unverzichtbar für ein authentisches Caesar Dressing?",
    "optEn": [
      "Yogurt, dill, and cucumber",
      "Egg yolk, salted anchovies, garlic, Parmesan, lemon juice, Dijon mustard, and Worcestershire sauce",
      "Tomato paste and paprika",
      "Sour cream and sugar"
    ],
    "optDe": [
      "Joghurt, Dill und Gurke",
      "Eigelb, Sardellenfilets, Knoblauch, Parmesan, Zitronensaft, Dijon und Worcestershire-Sauce",
      "Tomatenmark und Paprika",
      "Schmand und Zucker"
    ],
    "correct": 1,
    "expEn": "Anchovies and aged Parmigiano-Reggiano provide the powerful natural glutamates (umami).",
    "expDe": "Sardellen und Parmesan liefern das typische, dichte Umami auf knackigem Römersalat."
  },
  {
    "id": "q_sau_12",
    "category": "sauces_condiments",
    "questionEn": "What is the base of authentic Italian Basil Pesto alla Genovese DOP?",
    "questionDe": "Woraus besteht echtes Pesto alla Genovese DOP?",
    "optionsEn": [
      "Fresh Genovese basil, pine nuts, garlic, Parmigiano, Pecorino Fiore Sardo, and extra virgin olive oil",
      "Parsley, walnuts, butter, and cream",
      "Coriander, cashews, and canola oil",
      "Basil, heavy cream, and cheddar"
    ],
    "optionsDe": [
      "Basilikum Genovese DOP, Pinienkerne, Knoblauch, Parmesan, Pecorino Sardo und Olivenöl",
      "Petersilie, Walnüsse und Sahne",
      "Koriander, Cashews und Rapsöl",
      "Basilikum, Sahne und Gouda"
    ],
    "correctIndex": 0,
    "explanationEn": "Traditionally pounded with a marble mortar and wooden pestle without friction heat.",
    "explanationDe": "Im Mörser zerstoßen bleiben ätherische Öle leuchtend grün und intensiv aromatisch.",
    "qEn": "What is the base of authentic Italian Basil Pesto alla Genovese DOP?",
    "qDe": "Woraus besteht echtes Pesto alla Genovese DOP?",
    "optEn": [
      "Fresh Genovese basil, pine nuts, garlic, Parmigiano, Pecorino Fiore Sardo, and extra virgin olive oil",
      "Parsley, walnuts, butter, and cream",
      "Coriander, cashews, and canola oil",
      "Basil, heavy cream, and cheddar"
    ],
    "optDe": [
      "Basilikum Genovese DOP, Pinienkerne, Knoblauch, Parmesan, Pecorino Sardo und Olivenöl",
      "Petersilie, Walnüsse und Sahne",
      "Koriander, Cashews und Rapsöl",
      "Basilikum, Sahne und Gouda"
    ],
    "correct": 0,
    "expEn": "Traditionally pounded with a marble mortar and wooden pestle without friction heat.",
    "expDe": "Im Mörser zerstoßen bleiben ätherische Öle leuchtend grün und intensiv aromatisch."
  },
  {
    "id": "q_sau_13",
    "category": "sauces_condiments",
    "questionEn": "Why does freshly made Bearnaise Sauce feature tarragon and chervil?",
    "questionDe": "Was unterscheidet Sauce Béarnaise geschmacklich von Sauce Hollandaise?",
    "optionsEn": [
      "Béarnaise uses olive oil",
      "Béarnaise contains tomato paste",
      "Béarnaise contains curry powder",
      "Béarnaise incorporates a tarragon, chervil, shallot, and white wine vinegar reduction"
    ],
    "optionsDe": [
      "Béarnaise basiert auf Olivenöl",
      "Béarnaise enthält Tomatenmark",
      "Béarnaise wird mit Curry gewürzt",
      "Béarnaise enthält eine Reduktion aus Estragon, Kerbel, Schalotten und Weißweinessig"
    ],
    "correctIndex": 3,
    "explanationEn": "The anise-herbal note of tarragon pairs exquisitely with grilled steak and tournedos.",
    "explanationDe": "Die Estragon-Kerbel-Reduktion schenkt der warmen Buttersauce ihre feine Frische.",
    "qEn": "Why does freshly made Bearnaise Sauce feature tarragon and chervil?",
    "qDe": "Was unterscheidet Sauce Béarnaise geschmacklich von Sauce Hollandaise?",
    "optEn": [
      "Béarnaise uses olive oil",
      "Béarnaise contains tomato paste",
      "Béarnaise contains curry powder",
      "Béarnaise incorporates a tarragon, chervil, shallot, and white wine vinegar reduction"
    ],
    "optDe": [
      "Béarnaise basiert auf Olivenöl",
      "Béarnaise enthält Tomatenmark",
      "Béarnaise wird mit Curry gewürzt",
      "Béarnaise enthält eine Reduktion aus Estragon, Kerbel, Schalotten und Weißweinessig"
    ],
    "correct": 3,
    "expEn": "The anise-herbal note of tarragon pairs exquisitely with grilled steak and tournedos.",
    "expDe": "Die Estragon-Kerbel-Reduktion schenkt der warmen Buttersauce ihre feine Frische."
  },
  {
    "id": "q_sau_14",
    "category": "sauces_condiments",
    "questionEn": "What is the defining umami ingredient in Worcestershire Sauce?",
    "questionDe": "Was ist der entscheidende Umami-Bringer in echter Worcestershire-Sauce?",
    "optionsEn": [
      "Mushroom extract",
      "MSG crystals",
      "Fermented whole anchovies aged in vinegar and molasses casks",
      "Beef bouillon"
    ],
    "optionsDe": [
      "Pilzextrakt",
      "Künstliches Glutamat",
      "Fermentierte ganze Sardellen, die jahrelang in Holzfässern mit Essig und Melasse reifen",
      "Rinderbrühe"
    ],
    "correctIndex": 2,
    "explanationEn": "Lea & Perrins ages anchovies for 18 months, creating deep savory depth.",
    "explanationDe": "Fassgereifte Sardellen schenken der Sauce ihre unvergleichliche Würztiefe.",
    "qEn": "What is the defining umami ingredient in Worcestershire Sauce?",
    "qDe": "Was ist der entscheidende Umami-Bringer in echter Worcestershire-Sauce?",
    "optEn": [
      "Mushroom extract",
      "MSG crystals",
      "Fermented whole anchovies aged in vinegar and molasses casks",
      "Beef bouillon"
    ],
    "optDe": [
      "Pilzextrakt",
      "Künstliches Glutamat",
      "Fermentierte ganze Sardellen, die jahrelang in Holzfässern mit Essig und Melasse reifen",
      "Rinderbrühe"
    ],
    "correct": 2,
    "expEn": "Lea & Perrins ages anchovies for 18 months, creating deep savory depth.",
    "expDe": "Fassgereifte Sardellen schenken der Sauce ihre unvergleichliche Würztiefe."
  },
  {
    "id": "q_sau_15",
    "category": "sauces_condiments",
    "questionEn": "What is French Remoulade sauce?",
    "questionDe": "Was ist eine klassische französische Remouladensauce?",
    "optionsEn": [
      "Warm tomato sauce",
      "Mayonnaise blended with capers, chopped gherkins, fresh herbs, and anchovy essence",
      "Sour cream with horseradish",
      "Hollandaise with red wine"
    ],
    "optionsDe": [
      "Warme Tomatensauce",
      "Mayonnaise verfeinert mit gehackten Kapern, Essiggurken, Kräutern und Sardellenpaste",
      "Sauerrahm mit Kren",
      "Hollandaise mit Rotwein"
    ],
    "correctIndex": 1,
    "explanationEn": "Remoulade provides piquant acid and herbal crunch, pairing traditionally with cold roast beef or fried fish.",
    "explanationDe": "Kapern und Cornichons bringen Säure und Textur zu Roastbeef oder Backfisch.",
    "qEn": "What is French Remoulade sauce?",
    "qDe": "Was ist eine klassische französische Remouladensauce?",
    "optEn": [
      "Warm tomato sauce",
      "Mayonnaise blended with capers, chopped gherkins, fresh herbs, and anchovy essence",
      "Sour cream with horseradish",
      "Hollandaise with red wine"
    ],
    "optDe": [
      "Warme Tomatensauce",
      "Mayonnaise verfeinert mit gehackten Kapern, Essiggurken, Kräutern und Sardellenpaste",
      "Sauerrahm mit Kren",
      "Hollandaise mit Rotwein"
    ],
    "correct": 1,
    "expEn": "Remoulade provides piquant acid and herbal crunch, pairing traditionally with cold roast beef or fried fish.",
    "expDe": "Kapern und Cornichons bringen Säure und Textur zu Roastbeef oder Backfisch."
  },
  {
    "id": "q_sau_16",
    "category": "sauces_condiments",
    "questionEn": "How is authentic Argentine Chimichurri prepared?",
    "questionDe": "Wie wird authentisches argentinisches Chimichurri zubereitet?",
    "optionsEn": [
      "Finely chopped flat-leaf parsley, garlic, oregano, red pepper flakes, olive oil, and red wine vinegar",
      "Cooked tomato and beef gravy",
      "Pureed avocado with lime",
      "Cilantro and coconut milk"
    ],
    "optionsDe": [
      "Gehackte glatte Petersilie, Knoblauch, Oregano, Chiliflocken, Olivenöl und Rotweinessig",
      "Gekochte Bratensauce",
      "Avocado-Püree mit Limette",
      "Koriander mit Kokosmilch"
    ],
    "correctIndex": 0,
    "explanationEn": "Chimichurri is a raw, tangy herb sauce that cuts through fatty Asado grilled meats.",
    "explanationDe": "Die frische Kräutersäure des Chimichurri durchbricht das reichhaltige Fett gegrillten Rindfleischs.",
    "qEn": "How is authentic Argentine Chimichurri prepared?",
    "qDe": "Wie wird authentisches argentinisches Chimichurri zubereitet?",
    "optEn": [
      "Finely chopped flat-leaf parsley, garlic, oregano, red pepper flakes, olive oil, and red wine vinegar",
      "Cooked tomato and beef gravy",
      "Pureed avocado with lime",
      "Cilantro and coconut milk"
    ],
    "optDe": [
      "Gehackte glatte Petersilie, Knoblauch, Oregano, Chiliflocken, Olivenöl und Rotweinessig",
      "Gekochte Bratensauce",
      "Avocado-Püree mit Limette",
      "Koriander mit Kokosmilch"
    ],
    "correct": 0,
    "expEn": "Chimichurri is a raw, tangy herb sauce that cuts through fatty Asado grilled meats.",
    "expDe": "Die frische Kräutersäure des Chimichurri durchbricht das reichhaltige Fett gegrillten Rindfleischs."
  },
  {
    "id": "q_sau_17",
    "category": "sauces_condiments",
    "questionEn": "What gives English Colman's Mustard its fiery nostril punch?",
    "questionDe": "Was erzeugt die stechende Nasenschärfe in englischem Colman's Senf?",
    "optionsEn": [
      "Concentrated vinegar",
      "Added capsaicin from chili",
      "Black pepper oil",
      "Enzyme myrosinase converting glucosinolates into volatile allyl isothiocyanate upon mixing with water"
    ],
    "optionsDe": [
      "Konzentrierte Essigsäure",
      "Zusatz von reinem Chili-Capsaicin",
      "Schwarzer Pfefferextrakt",
      "Das Enzym Myrosinase spaltet Senfölglykoside beim Anrühren mit Wasser in Allylisothiocyanat"
    ],
    "correctIndex": 3,
    "explanationEn": "Allyl isothiocyanate is volatile, rising into nasal passages similarly to wasabi.",
    "explanationDe": "Flüchtiges Senföl steigt sofort in die Nebenhöhlen und sorgt für intensive Schärfe.",
    "qEn": "What gives English Colman's Mustard its fiery nostril punch?",
    "qDe": "Was erzeugt die stechende Nasenschärfe in englischem Colman's Senf?",
    "optEn": [
      "Concentrated vinegar",
      "Added capsaicin from chili",
      "Black pepper oil",
      "Enzyme myrosinase converting glucosinolates into volatile allyl isothiocyanate upon mixing with water"
    ],
    "optDe": [
      "Konzentrierte Essigsäure",
      "Zusatz von reinem Chili-Capsaicin",
      "Schwarzer Pfefferextrakt",
      "Das Enzym Myrosinase spaltet Senfölglykoside beim Anrühren mit Wasser in Allylisothiocyanat"
    ],
    "correct": 3,
    "expEn": "Allyl isothiocyanate is volatile, rising into nasal passages similarly to wasabi.",
    "expDe": "Flüchtiges Senföl steigt sofort in die Nebenhöhlen und sorgt für intensive Schärfe."
  },
  {
    "id": "q_sau_18",
    "category": "sauces_condiments",
    "questionEn": "Why is Honey-Mustard dressing so stable compared to plain oil-and-vinegar?",
    "questionDe": "Warum ist Honig-Senf-Dressing stabiler als reine Essig-Öl-Mischungen?",
    "optionsEn": [
      "Vinegar boils the oil",
      "Honey freezes the dressing",
      "Mustard mucilage and honey sugars act as natural emulsifiers, preventing oil droplet coalescence",
      "Salt dissolves all fat"
    ],
    "optionsDe": [
      "Essig kocht das Öl auf",
      "Honig lässt das Dressing gefrieren",
      "Schleimstoffe im Senf und zähe Honigzucker wirken als natürliche Emulgatoren",
      "Salz löst Fett auf"
    ],
    "correctIndex": 2,
    "explanationEn": "Polysaccharides in mustard coat oil globules, maintaining a silky, creamy emulsion.",
    "explanationDe": "Senfschleimstoffe stabilisieren die Tröpfchen und verhindern das Entmischen.",
    "qEn": "Why is Honey-Mustard dressing so stable compared to plain oil-and-vinegar?",
    "qDe": "Warum ist Honig-Senf-Dressing stabiler als reine Essig-Öl-Mischungen?",
    "optEn": [
      "Vinegar boils the oil",
      "Honey freezes the dressing",
      "Mustard mucilage and honey sugars act as natural emulsifiers, preventing oil droplet coalescence",
      "Salt dissolves all fat"
    ],
    "optDe": [
      "Essig kocht das Öl auf",
      "Honig lässt das Dressing gefrieren",
      "Schleimstoffe im Senf und zähe Honigzucker wirken als natürliche Emulgatoren",
      "Salz löst Fett auf"
    ],
    "correct": 2,
    "expEn": "Polysaccharides in mustard coat oil globules, maintaining a silky, creamy emulsion.",
    "expDe": "Senfschleimstoffe stabilisieren die Tröpfchen und verhindern das Entmischen."
  },
  {
    "id": "q_sft_01",
    "category": "soft_drinks",
    "questionEn": "Which bitter alkaloid defines authentic Tonic Water?",
    "questionDe": "Welches Bitteralkaloid kennzeichnet echtes Tonic Water?",
    "optionsEn": [
      "Caffeine",
      "Quinine extracted from Cinchona bark",
      "Theobromine",
      "Capsaicin"
    ],
    "optionsDe": [
      "Koffein",
      "Chinin aus der Rinde des Chinarindenbaums",
      "Theobromin",
      "Capsaicin"
    ],
    "correctIndex": 1,
    "explanationEn": "Quinine was originally taken by British officers against malaria; it fluoresces bright blue under UV light.",
    "explanationDe": "Chinin stammt aus der Chinarinde und leuchtet unter ultraviolettem Schwarzlicht bläulich.",
    "qEn": "Which bitter alkaloid defines authentic Tonic Water?",
    "qDe": "Welches Bitteralkaloid kennzeichnet echtes Tonic Water?",
    "optEn": [
      "Caffeine",
      "Quinine extracted from Cinchona bark",
      "Theobromine",
      "Capsaicin"
    ],
    "optDe": [
      "Koffein",
      "Chinin aus der Rinde des Chinarindenbaums",
      "Theobromin",
      "Capsaicin"
    ],
    "correct": 1,
    "expEn": "Quinine was originally taken by British officers against malaria; it fluoresces bright blue under UV light.",
    "expDe": "Chinin stammt aus der Chinarinde und leuchtet unter ultraviolettem Schwarzlicht bläulich."
  },
  {
    "id": "q_sft_02",
    "category": "soft_drinks",
    "questionEn": "Why does Tonic Water fluoresce bright blue under ultraviolet blacklight?",
    "questionDe": "Warum leuchtet Tonic Water unter UV-Schwarzlicht bläulich?",
    "optionsEn": [
      "Quinine molecules absorb UV photons and re-emit visible blue light (fluorescence)",
      "Artificial blue food dye",
      "Dissolved carbon dioxide bubbles",
      "Sugar crystallization"
    ],
    "optionsDe": [
      "Chininmoleküle absorbieren UV-Strahlung und emittieren blaues Licht (Fluoreszenz)",
      "Blauer Lebensmittelfarbstoff",
      "Gelöste CO2-Bläschen",
      "Zuckerkristalle"
    ],
    "correctIndex": 0,
    "explanationEn": "Quinine contains a quinoline ring that naturally fluoresces at 450nm.",
    "explanationDe": "Die Molekülstruktur des Chinins regt natürliche Fluoreszenz bei UV-Licht an.",
    "qEn": "Why does Tonic Water fluoresce bright blue under ultraviolet blacklight?",
    "qDe": "Warum leuchtet Tonic Water unter UV-Schwarzlicht bläulich?",
    "optEn": [
      "Quinine molecules absorb UV photons and re-emit visible blue light (fluorescence)",
      "Artificial blue food dye",
      "Dissolved carbon dioxide bubbles",
      "Sugar crystallization"
    ],
    "optDe": [
      "Chininmoleküle absorbieren UV-Strahlung und emittieren blaues Licht (Fluoreszenz)",
      "Blauer Lebensmittelfarbstoff",
      "Gelöste CO2-Bläschen",
      "Zuckerkristalle"
    ],
    "correct": 0,
    "expEn": "Quinine contains a quinoline ring that naturally fluoresces at 450nm.",
    "expDe": "Die Molekülstruktur des Chinins regt natürliche Fluoreszenz bei UV-Licht an."
  },
  {
    "id": "q_sft_03",
    "category": "soft_drinks",
    "questionEn": "What is the difference between Ginger Ale and Ginger Beer?",
    "questionDe": "Was unterscheidet Ginger Ale von echtem Ginger Beer?",
    "optionsEn": [
      "Ginger Ale is black",
      "Ginger Ale contains 10% alcohol",
      "Ginger Beer contains hops",
      "Ginger Beer is brewed and fermented with real ginger roots (cloudy, spicy heat); Ginger Ale is carbonated sweet ginger soda"
    ],
    "optionsDe": [
      "Ginger Ale ist dunkel wie Cola",
      "Ginger Ale enthält Alkohol",
      "Ginger Beer enthält Hopfen",
      "Ginger Beer wird aus Ingwerwurzel fermentiert (trüb, scharf); Ginger Ale ist eine milde, klare Ingwer-Limonade"
    ],
    "correctIndex": 3,
    "explanationEn": "Ginger Beer provides the sharp, fiery kick required for Moscow Mules and Dark 'n Stormy cocktails.",
    "explanationDe": "Echtes Ginger Beer bringt authentische Ingwerschärfe und feine Trübung ins Glas.",
    "qEn": "What is the difference between Ginger Ale and Ginger Beer?",
    "qDe": "Was unterscheidet Ginger Ale von echtem Ginger Beer?",
    "optEn": [
      "Ginger Ale is black",
      "Ginger Ale contains 10% alcohol",
      "Ginger Beer contains hops",
      "Ginger Beer is brewed and fermented with real ginger roots (cloudy, spicy heat); Ginger Ale is carbonated sweet ginger soda"
    ],
    "optDe": [
      "Ginger Ale ist dunkel wie Cola",
      "Ginger Ale enthält Alkohol",
      "Ginger Beer enthält Hopfen",
      "Ginger Beer wird aus Ingwerwurzel fermentiert (trüb, scharf); Ginger Ale ist eine milde, klare Ingwer-Limonade"
    ],
    "correct": 3,
    "expEn": "Ginger Beer provides the sharp, fiery kick required for Moscow Mules and Dark 'n Stormy cocktails.",
    "expDe": "Echtes Ginger Beer bringt authentische Ingwerschärfe und feine Trübung ins Glas."
  },
  {
    "id": "q_sft_04",
    "category": "soft_drinks",
    "questionEn": "What plant seed gave original Cola drinks their name and caffeine?",
    "questionDe": "Welcher afrikanische Baumsamen gab Cola-Getränken ihren Namen und Koffein?",
    "optionsEn": [
      "Coffee cherry",
      "Cocoa bean",
      "Kola nut (Cola acuminata)",
      "Nutmeg"
    ],
    "optionsDe": [
      "Kaffeekirsche",
      "Kakaobohne",
      "Kolanuss (Cola acuminata)",
      "Muskatnuss"
    ],
    "correctIndex": 2,
    "explanationEn": "Kola nuts contain caffeine and theobromine, traditionally chewed in West Africa.",
    "explanationDe": "Die afrikanische Kolanuss lieferte das ursprüngliche Koffein für Cola-Sirup.",
    "qEn": "What plant seed gave original Cola drinks their name and caffeine?",
    "qDe": "Welcher afrikanische Baumsamen gab Cola-Getränken ihren Namen und Koffein?",
    "optEn": [
      "Coffee cherry",
      "Cocoa bean",
      "Kola nut (Cola acuminata)",
      "Nutmeg"
    ],
    "optDe": [
      "Kaffeekirsche",
      "Kakaobohne",
      "Kolanuss (Cola acuminata)",
      "Muskatnuss"
    ],
    "correct": 2,
    "expEn": "Kola nuts contain caffeine and theobromine, traditionally chewed in West Africa.",
    "expDe": "Die afrikanische Kolanuss lieferte das ursprüngliche Koffein für Cola-Sirup."
  },
  {
    "id": "q_sft_05",
    "category": "soft_drinks",
    "questionEn": "What amino acid is standard in modern Energy Drinks?",
    "questionDe": "Welche Aminosulfonsäure ist ein Standardbestandteil in Energy Drinks?",
    "optionsEn": [
      "Creatine",
      "Taurine (2-aminoethanesulfonic acid)",
      "Lysine",
      "Glutamine"
    ],
    "optionsDe": [
      "Kreatin",
      "Taurin (2-Aminoethansulfonsäure)",
      "Lysin",
      "Glutamin"
    ],
    "correctIndex": 1,
    "explanationEn": "Taurine supports bile acid conjugation and membrane stabilization in metabolic pathways.",
    "explanationDe": "Taurin reguliert den Flüssigkeitshaushalt und stärkt die Wirkung von Koffein.",
    "qEn": "What amino acid is standard in modern Energy Drinks?",
    "qDe": "Welche Aminosulfonsäure ist ein Standardbestandteil in Energy Drinks?",
    "optEn": [
      "Creatine",
      "Taurine (2-aminoethanesulfonic acid)",
      "Lysine",
      "Glutamine"
    ],
    "optDe": [
      "Kreatin",
      "Taurin (2-Aminoethansulfonsäure)",
      "Lysin",
      "Glutamin"
    ],
    "correct": 1,
    "expEn": "Taurine supports bile acid conjugation and membrane stabilization in metabolic pathways.",
    "expDe": "Taurin reguliert den Flüssigkeitshaushalt und stärkt die Wirkung von Koffein."
  },
  {
    "id": "q_sft_06",
    "category": "soft_drinks",
    "questionEn": "What is Club Soda compared to Seltzer Water?",
    "questionDe": "Was unterscheidet Club Soda von reinem Seltzer-Wasser?",
    "optionsEn": [
      "Club Soda contains added mineral salts (potassium bicarbonate, sodium chloride) for clean crispness; Seltzer is plain carbonated water",
      "Club Soda has alcohol",
      "Seltzer contains lemon juice",
      "Club Soda is sweetened with honey"
    ],
    "optionsDe": [
      "Club Soda enthält zugesetzte Mineralsalze für weichen Geschmack; Seltzer ist reines Sprudelwasser",
      "Club Soda hat Alkohol",
      "Seltzer hat Zitronensaft",
      "Club Soda ist gesüßt"
    ],
    "correctIndex": 0,
    "explanationEn": "Mineral salts replicate natural spring water taste and buffer acidity in cocktails.",
    "explanationDe": "Mineralien im Club Soda puffern die Säure von Spirituosen und Zitrusfrüchten ab.",
    "qEn": "What is Club Soda compared to Seltzer Water?",
    "qDe": "Was unterscheidet Club Soda von reinem Seltzer-Wasser?",
    "optEn": [
      "Club Soda contains added mineral salts (potassium bicarbonate, sodium chloride) for clean crispness; Seltzer is plain carbonated water",
      "Club Soda has alcohol",
      "Seltzer contains lemon juice",
      "Club Soda is sweetened with honey"
    ],
    "optDe": [
      "Club Soda enthält zugesetzte Mineralsalze für weichen Geschmack; Seltzer ist reines Sprudelwasser",
      "Club Soda hat Alkohol",
      "Seltzer hat Zitronensaft",
      "Club Soda ist gesüßt"
    ],
    "correct": 0,
    "expEn": "Mineral salts replicate natural spring water taste and buffer acidity in cocktails.",
    "expDe": "Mineralien im Club Soda puffern die Säure von Spirituosen und Zitrusfrüchten ab."
  },
  {
    "id": "q_sft_07",
    "category": "soft_drinks",
    "questionEn": "What acid provides the characteristic sharp bite in dark Cola beverages?",
    "questionDe": "Welche Säure erzeugt den typischen herben Biss in dunklen Cola-Getränken?",
    "optionsEn": [
      "Lactic acid",
      "Citric acid only",
      "Acetic acid",
      "Phosphoric acid (H3PO4)"
    ],
    "optionsDe": [
      "Milchsäure",
      "Reine Zitronensäure",
      "Essigsäure",
      "Phosphorsäure (H3PO4)"
    ],
    "correctIndex": 3,
    "explanationEn": "Phosphoric acid delivers an astringent tartness that cuts through heavy sugar sweetness.",
    "explanationDe": "Phosphorsäure verleiht Cola ihre typische trockene Säure und verhindert klebrigen Nachgeschmack.",
    "qEn": "What acid provides the characteristic sharp bite in dark Cola beverages?",
    "qDe": "Welche Säure erzeugt den typischen herben Biss in dunklen Cola-Getränken?",
    "optEn": [
      "Lactic acid",
      "Citric acid only",
      "Acetic acid",
      "Phosphoric acid (H3PO4)"
    ],
    "optDe": [
      "Milchsäure",
      "Reine Zitronensäure",
      "Essigsäure",
      "Phosphorsäure (H3PO4)"
    ],
    "correct": 3,
    "expEn": "Phosphoric acid delivers an astringent tartness that cuts through heavy sugar sweetness.",
    "expDe": "Phosphorsäure verleiht Cola ihre typische trockene Säure und verhindert klebrigen Nachgeschmack."
  },
  {
    "id": "q_sft_08",
    "category": "soft_drinks",
    "questionEn": "What is Bitter Lemon?",
    "questionDe": "Was ist Bitter Lemon?",
    "optionsEn": [
      "Limoncello liqueur",
      "Unsweetened squeezed lemon",
      "A carbonated soft drink combining tart lemon juice with bitter quinine",
      "Fermented lime juice"
    ],
    "optionsDe": [
      "Limoncello-Likör",
      "Ungesüßter Zitronensaft",
      "Ein kohlensäurehaltiges Erfrischungsgetränk aus Zitronensaft und bitterem Chinin",
      "Vergorener Limettensaft"
    ],
    "correctIndex": 2,
    "explanationEn": "The contrast between citric tartness and chinine bitterness makes it a classic highball mixer.",
    "explanationDe": "Die Liaison aus saurer Zitrone und bitterem Chinin macht Bitter Lemon zum Bar-Klassiker.",
    "qEn": "What is Bitter Lemon?",
    "qDe": "Was ist Bitter Lemon?",
    "optEn": [
      "Limoncello liqueur",
      "Unsweetened squeezed lemon",
      "A carbonated soft drink combining tart lemon juice with bitter quinine",
      "Fermented lime juice"
    ],
    "optDe": [
      "Limoncello-Likör",
      "Ungesüßter Zitronensaft",
      "Ein kohlensäurehaltiges Erfrischungsgetränk aus Zitronensaft und bitterem Chinin",
      "Vergorener Limettensaft"
    ],
    "correct": 2,
    "expEn": "The contrast between citric tartness and chinine bitterness makes it a classic highball mixer.",
    "expDe": "Die Liaison aus saurer Zitrone und bitterem Chinin macht Bitter Lemon zum Bar-Klassiker."
  },
  {
    "id": "q_sft_09",
    "category": "soft_drinks",
    "questionEn": "What tree bark extract provides the foamy head on Root Beer?",
    "questionDe": "Welcher pflanzliche Extrakt erzeugte traditionell den stabilen Schaum auf Root Beer?",
    "optionsEn": [
      "Oak bark",
      "Sarsaparilla root or Sassafras bark (and yucca extract)",
      "Willow bark",
      "Pine needles"
    ],
    "optionsDe": [
      "Eichenrinde",
      "Sarsaparilla-Wurzel oder Sassafras-Rinde (sowie Yucca-Extrakt)",
      "Weidenrinde",
      "Kiefernnadeln"
    ],
    "correctIndex": 1,
    "explanationEn": "Saponins in sarsaparilla and yucca froth into thick, creamy root beer foam.",
    "explanationDe": "Saponine in Wurzelkräutern schäumen cremig auf und duften nach Wintergrün.",
    "qEn": "What tree bark extract provides the foamy head on Root Beer?",
    "qDe": "Welcher pflanzliche Extrakt erzeugte traditionell den stabilen Schaum auf Root Beer?",
    "optEn": [
      "Oak bark",
      "Sarsaparilla root or Sassafras bark (and yucca extract)",
      "Willow bark",
      "Pine needles"
    ],
    "optDe": [
      "Eichenrinde",
      "Sarsaparilla-Wurzel oder Sassafras-Rinde (sowie Yucca-Extrakt)",
      "Weidenrinde",
      "Kiefernnadeln"
    ],
    "correct": 1,
    "expEn": "Saponins in sarsaparilla and yucca froth into thick, creamy root beer foam.",
    "expDe": "Saponine in Wurzelkräutern schäumen cremig auf und duften nach Wintergrün."
  },
  {
    "id": "q_sft_08b",
    "category": "soft_drinks",
    "questionEn": "What is Mexican Coke celebrated for among beverage connoisseurs?",
    "questionDe": "Wofür wird mexikanische Coca-Cola von Kennern geschätzt?",
    "optionsEn": [
      "Sweetened with 100% natural cane sugar instead of High Fructose Corn Syrup (HFCS)",
      "Contains real cocaine",
      "Contains green lime juice",
      "Is triple carbonated"
    ],
    "optionsDe": [
      "Mit 100% echtem Rohrzucker gesüßt statt mit Maisstärkesirup (HFCS)",
      "Enthält echtes Kokain",
      "Enthält Limettensaft",
      "Ist dreifach kohlensäurehaltig"
    ],
    "correctIndex": 0,
    "explanationEn": "Pure cane sugar provides a cleaner mouthfeel and crisper finish without cloying corn syrup viscosity.",
    "explanationDe": "Echter Rohrzucker sorgt für ein klares Mundgefühl ohne klebrigen Nachgeschmack.",
    "qEn": "What is Mexican Coke celebrated for among beverage connoisseurs?",
    "qDe": "Wofür wird mexikanische Coca-Cola von Kennern geschätzt?",
    "optEn": [
      "Sweetened with 100% natural cane sugar instead of High Fructose Corn Syrup (HFCS)",
      "Contains real cocaine",
      "Contains green lime juice",
      "Is triple carbonated"
    ],
    "optDe": [
      "Mit 100% echtem Rohrzucker gesüßt statt mit Maisstärkesirup (HFCS)",
      "Enthält echtes Kokain",
      "Enthält Limettensaft",
      "Ist dreifach kohlensäurehaltig"
    ],
    "correct": 0,
    "expEn": "Pure cane sugar provides a cleaner mouthfeel and crisper finish without cloying corn syrup viscosity.",
    "expDe": "Echter Rohrzucker sorgt für ein klares Mundgefühl ohne klebrigen Nachgeschmack."
  },
  {
    "id": "q_sft_11",
    "category": "soft_drinks",
    "questionEn": "What gives San Pellegrino Aranciata Rossa its color and flavor?",
    "questionDe": "Was verleiht italienischer Aranciata Rossa ihr Aroma?",
    "optionsEn": [
      "Cherry syrup",
      "Red food dye #40",
      "Beet juice extract only",
      "Blood orange juice (Moro, Tarocco, or Sanguinello from Sicily)"
    ],
    "optionsDe": [
      "Kirschsirup",
      "Roter synthetischer Farbstoff",
      "Rote-Bete-Saft",
      "Sizilianischer Blutorangensaft (Moro, Tarocco oder Sanguinello)"
    ],
    "correctIndex": 3,
    "explanationEn": "Anthocyanin pigments in Sicilian blood oranges deliver raspberry-citrus complexity.",
    "explanationDe": "Sizilianische Blutorangen enthalten Anthocyane mit herbsüßem Beerenaroma.",
    "qEn": "What gives San Pellegrino Aranciata Rossa its color and flavor?",
    "qDe": "Was verleiht italienischer Aranciata Rossa ihr Aroma?",
    "optEn": [
      "Cherry syrup",
      "Red food dye #40",
      "Beet juice extract only",
      "Blood orange juice (Moro, Tarocco, or Sanguinello from Sicily)"
    ],
    "optDe": [
      "Kirschsirup",
      "Roter synthetischer Farbstoff",
      "Rote-Bete-Saft",
      "Sizilianischer Blutorangensaft (Moro, Tarocco oder Sanguinello)"
    ],
    "correct": 3,
    "expEn": "Anthocyanin pigments in Sicilian blood oranges deliver raspberry-citrus complexity.",
    "expDe": "Sizilianische Blutorangen enthalten Anthocyane mit herbsüßem Beerenaroma."
  },
  {
    "id": "q_sft_12",
    "category": "soft_drinks",
    "questionEn": "What is Kombucha biologically?",
    "questionDe": "Was ist Kombucha aus biologischer Sicht?",
    "optionsEn": [
      "Pasteurized green tea soda",
      "Distilled herbal wine",
      "A fermented sweet tea drink cultured with a symbiotic culture of bacteria and yeast (SCOBY)",
      "Mushroom tea without sugar"
    ],
    "optionsDe": [
      "Pasteurisierte Grüntee-Limo",
      "Destillierter Kräuterwein",
      "Ein fermentierter süßer Tee, vergoren mit einer Kultur aus Bakterien und Hefen (SCOBY)",
      "Pilztee ohne Zucker"
    ],
    "correctIndex": 2,
    "explanationEn": "Yeasts produce ethanol; acetic acid bacteria convert it to tart gluconic and acetic acids.",
    "explanationDe": "Die Lebensgemeinschaft aus Hefen und Essigsäurebakterien erzeugt prickelnde Säure.",
    "qEn": "What is Kombucha biologically?",
    "qDe": "Was ist Kombucha aus biologischer Sicht?",
    "optEn": [
      "Pasteurized green tea soda",
      "Distilled herbal wine",
      "A fermented sweet tea drink cultured with a symbiotic culture of bacteria and yeast (SCOBY)",
      "Mushroom tea without sugar"
    ],
    "optDe": [
      "Pasteurisierte Grüntee-Limo",
      "Destillierter Kräuterwein",
      "Ein fermentierter süßer Tee, vergoren mit einer Kultur aus Bakterien und Hefen (SCOBY)",
      "Pilztee ohne Zucker"
    ],
    "correct": 2,
    "expEn": "Yeasts produce ethanol; acetic acid bacteria convert it to tart gluconic and acetic acids.",
    "expDe": "Die Lebensgemeinschaft aus Hefen und Essigsäurebakterien erzeugt prickelnde Säure."
  },
  {
    "id": "q_sft_13",
    "category": "soft_drinks",
    "questionEn": "What gives Chinotto, the Italian bittersweet soda, its dark color and herbal flavor?",
    "questionDe": "Woraus wird die italienische Kult-Kräuterlimonade Chinotto gewonnen?",
    "optionsEn": [
      "Dark roasted malt",
      "Extract of small, bitter myrtle-leaved orange fruit (Citrus myrtifolia)",
      "Black licorice root",
      "Caramelized onions"
    ],
    "optionsDe": [
      "Dunkles Röstmalz",
      "Extrakt der kleinen, herben Bitterorange Chinotto (Citrus myrtifolia)",
      "Schwarze Lakritzwurzel",
      "Karamellisierte Zwiebeln"
    ],
    "correctIndex": 1,
    "explanationEn": "Chinotto delivers complex alpine herbs and bitter orange zest flavors.",
    "explanationDe": "Die bitteren Zwergorangen aus Ligurien schmecken feinherb, krautig und erfrischend.",
    "qEn": "What gives Chinotto, the Italian bittersweet soda, its dark color and herbal flavor?",
    "qDe": "Woraus wird die italienische Kult-Kräuterlimonade Chinotto gewonnen?",
    "optEn": [
      "Dark roasted malt",
      "Extract of small, bitter myrtle-leaved orange fruit (Citrus myrtifolia)",
      "Black licorice root",
      "Caramelized onions"
    ],
    "optDe": [
      "Dunkles Röstmalz",
      "Extrakt der kleinen, herben Bitterorange Chinotto (Citrus myrtifolia)",
      "Schwarze Lakritzwurzel",
      "Karamellisierte Zwiebeln"
    ],
    "correct": 1,
    "expEn": "Chinotto delivers complex alpine herbs and bitter orange zest flavors.",
    "expDe": "Die bitteren Zwergorangen aus Ligurien schmecken feinherb, krautig und erfrischend."
  },
  {
    "id": "q_sft_14",
    "category": "soft_drinks",
    "questionEn": "Why does soda lose carbonation faster when warm than when chilled?",
    "questionDe": "Warum perlt warme Limonade viel schneller aus als eisgekühlte?",
    "optionsEn": [
      "Carbon dioxide solubility in water decreases as liquid temperature rises",
      "Heat destroys the CO2 molecule",
      "Warm cans have holes",
      "Sugar turns gas into syrup"
    ],
    "optionsDe": [
      "Die Löslichkeit von Kohlendioxid in Wasser sinkt mit steigender Temperatur drastisch",
      "Hitze zerstört Kohlensäure",
      "Warme Dosen sind undicht",
      "Zucker schluckt das Gas"
    ],
    "correctIndex": 0,
    "explanationEn": "Cold water molecules pack tighter, trapping gaseous CO2 in hydrated liquid solution.",
    "explanationDe": "Kaltes Wasser kann deutlich mehr CO2 physikalisch binden als warme Flüssigkeit.",
    "qEn": "Why does soda lose carbonation faster when warm than when chilled?",
    "qDe": "Warum perlt warme Limonade viel schneller aus als eisgekühlte?",
    "optEn": [
      "Carbon dioxide solubility in water decreases as liquid temperature rises",
      "Heat destroys the CO2 molecule",
      "Warm cans have holes",
      "Sugar turns gas into syrup"
    ],
    "optDe": [
      "Die Löslichkeit von Kohlendioxid in Wasser sinkt mit steigender Temperatur drastisch",
      "Hitze zerstört Kohlensäure",
      "Warme Dosen sind undicht",
      "Zucker schluckt das Gas"
    ],
    "correct": 0,
    "expEn": "Cold water molecules pack tighter, trapping gaseous CO2 in hydrated liquid solution.",
    "expDe": "Kaltes Wasser kann deutlich mehr CO2 physikalisch binden als warme Flüssigkeit."
  },
  {
    "id": "q_sft_15",
    "category": "soft_drinks",
    "questionEn": "What is an Italian 'Aperitivo Soda' (e.g. Sanbittèr, Crodino)?",
    "questionDe": "Was zeichnet alkoholfreie italienische Bitter-Sodas (Sanbittèr, Crodino) aus?",
    "optionsEn": [
      "Sweet cherry soda",
      "Pure grapefruit juice",
      "Red sparkling wine with alcohol removed",
      "Bittersweet sparkling infusion of gentian root, orange peel, and botanical herbs"
    ],
    "optionsDe": [
      "Süße Kirschlimonade",
      "Reiner Grapefruitsaft",
      "Alkoholfreier Schaumwein",
      "Feinherbe, kohlensäurehaltige Kräuterauszüge aus Enzian, Bitterorange und Kräutern"
    ],
    "correctIndex": 3,
    "explanationEn": "Designed to stimulate stomach gastric juices before a meal without any alcohol.",
    "explanationDe": "Die enthaltenen Bitterstoffe regen Appetit und Magensaftproduktion ideal an.",
    "qEn": "What is an Italian 'Aperitivo Soda' (e.g. Sanbittèr, Crodino)?",
    "qDe": "Was zeichnet alkoholfreie italienische Bitter-Sodas (Sanbittèr, Crodino) aus?",
    "optEn": [
      "Sweet cherry soda",
      "Pure grapefruit juice",
      "Red sparkling wine with alcohol removed",
      "Bittersweet sparkling infusion of gentian root, orange peel, and botanical herbs"
    ],
    "optDe": [
      "Süße Kirschlimonade",
      "Reiner Grapefruitsaft",
      "Alkoholfreier Schaumwein",
      "Feinherbe, kohlensäurehaltige Kräuterauszüge aus Enzian, Bitterorange und Kräutern"
    ],
    "correct": 3,
    "expEn": "Designed to stimulate stomach gastric juices before a meal without any alcohol.",
    "expDe": "Die enthaltenen Bitterstoffe regen Appetit und Magensaftproduktion ideal an."
  },
  {
    "id": "q_sft_16",
    "category": "soft_drinks",
    "questionEn": "What flavor profile defines Horchata de Chufa in Valencia?",
    "questionDe": "Was prägt die spanische Horchata de Chufa aus Valencia?",
    "optionsEn": [
      "Almond marzipan drink",
      "Rice and cinnamon milk",
      "Creamy, nutty plant milk made from soaked tiger nuts (chufa tubers), water, and sugar",
      "Coconut milk shake"
    ],
    "optionsDe": [
      "Mandelmarzipantrank",
      "Reis-Zimt-Milch",
      "Cremige Erdmandelmilch aus Chufa-Knollen, Wasser und feinem Zucker",
      "Kokosnuss-Shake"
    ],
    "correctIndex": 2,
    "explanationEn": "Tiger nuts (Cyperus esculentus) yield rich, naturally sweet plant lipids without dairy.",
    "explanationDe": "Chufas sind Erdmandeln und liefern eine nussige, erfrischende Pflanzenmilch.",
    "qEn": "What flavor profile defines Horchata de Chufa in Valencia?",
    "qDe": "Was prägt die spanische Horchata de Chufa aus Valencia?",
    "optEn": [
      "Almond marzipan drink",
      "Rice and cinnamon milk",
      "Creamy, nutty plant milk made from soaked tiger nuts (chufa tubers), water, and sugar",
      "Coconut milk shake"
    ],
    "optDe": [
      "Mandelmarzipantrank",
      "Reis-Zimt-Milch",
      "Cremige Erdmandelmilch aus Chufa-Knollen, Wasser und feinem Zucker",
      "Kokosnuss-Shake"
    ],
    "correct": 2,
    "expEn": "Tiger nuts (Cyperus esculentus) yield rich, naturally sweet plant lipids without dairy.",
    "expDe": "Chufas sind Erdmandeln und liefern eine nussige, erfrischende Pflanzenmilch."
  },
  {
    "id": "q_sft_17",
    "category": "soft_drinks",
    "questionEn": "What gives cream soda its distinctive mouthfeel and dessert aroma?",
    "questionDe": "Was verleiht Cream Soda sein typisches Dessertaroma und weiches Mundgefühl?",
    "optionsEn": [
      "Heavy whipping cream",
      "Natural vanilla extract and smooth micro-carbonation",
      "Butter solids",
      "Egg white meringue"
    ],
    "optionsDe": [
      "Reine flüssige Sahne",
      "Natürliches Vanille-Aroma und feinperlige Kohlensäure",
      "Geschmolzene Butter",
      "Eischnee"
    ],
    "correctIndex": 1,
    "explanationEn": "Vanilla aroma simulates melted ice cream notes without requiring dairy fats.",
    "explanationDe": "Vanillearomen erwecken die Assoziation von cremigem Vanilleeis.",
    "qEn": "What gives cream soda its distinctive mouthfeel and dessert aroma?",
    "qDe": "Was verleiht Cream Soda sein typisches Dessertaroma und weiches Mundgefühl?",
    "optEn": [
      "Heavy whipping cream",
      "Natural vanilla extract and smooth micro-carbonation",
      "Butter solids",
      "Egg white meringue"
    ],
    "optDe": [
      "Reine flüssige Sahne",
      "Natürliches Vanille-Aroma und feinperlige Kohlensäure",
      "Geschmolzene Butter",
      "Eischnee"
    ],
    "correct": 1,
    "expEn": "Vanilla aroma simulates melted ice cream notes without requiring dairy fats.",
    "expDe": "Vanillearomen erwecken die Assoziation von cremigem Vanilleeis."
  },
  {
    "id": "q_sft_18",
    "category": "soft_drinks",
    "questionEn": "What natural plant pigment creates the ruby hue in Hibiscus Iced Tea (Karkadeh)?",
    "questionDe": "Welcher Pflanzenfarbstoff färbt Hibiskustee (Karkadeh) leuchtend rubinrot?",
    "optionsEn": [
      "Anthocyanins in dried Hibiscus sabdariffa calyces",
      "Carotene",
      "Chlorophyll",
      "Lycopene"
    ],
    "optionsDe": [
      "Anthocyane in den getrockneten Blütenkelchen von Hibiscus sabdariffa",
      "Carotin",
      "Chlorophyll",
      "Lycopin"
    ],
    "correctIndex": 0,
    "explanationEn": "Anthocyanins provide cranberry-like tartness and stunning natural crimson color.",
    "explanationDe": "Die Blütenkelche enthalten fruchtige Fruchtsäuren und natürliche rote Pflanzenpigmente.",
    "qEn": "What natural plant pigment creates the ruby hue in Hibiscus Iced Tea (Karkadeh)?",
    "qDe": "Welcher Pflanzenfarbstoff färbt Hibiskustee (Karkadeh) leuchtend rubinrot?",
    "optEn": [
      "Anthocyanins in dried Hibiscus sabdariffa calyces",
      "Carotene",
      "Chlorophyll",
      "Lycopene"
    ],
    "optDe": [
      "Anthocyane in den getrockneten Blütenkelchen von Hibiscus sabdariffa",
      "Carotin",
      "Chlorophyll",
      "Lycopin"
    ],
    "correct": 0,
    "expEn": "Anthocyanins provide cranberry-like tartness and stunning natural crimson color.",
    "expDe": "Die Blütenkelche enthalten fruchtige Fruchtsäuren und natürliche rote Pflanzenpigmente."
  },
  {
    "id": "q_dai_01",
    "category": "dairy",
    "questionEn": "What is the legal minimum milk fat content of German 'Vollmilch' (whole milk)?",
    "questionDe": "Wie hoch ist der gesetzliche Mindestfettgehalt für Vollmilch in Deutschland?",
    "optionsEn": [
      "10% fat",
      "1.5% fat",
      "0.3% fat",
      "3.5% fat (or natural fat content typically 3.8-4.2%)"
    ],
    "optionsDe": [
      "10% Fett",
      "1,5% Fett",
      "0,3% Fett",
      "Mindestens 3,5% Fett (bzw. natürlicher Fettgehalt 3,8–4,2%)"
    ],
    "correctIndex": 3,
    "explanationEn": "Standardized whole milk is adjusted to 3.5% milk fat; raw milk contains 3.8-4.2%.",
    "explanationDe": "Standardisierte Vollmilch enthält 3,5% Fett; fettarme Milch liegt bei 1,5–1,8%.",
    "qEn": "What is the legal minimum milk fat content of German 'Vollmilch' (whole milk)?",
    "qDe": "Wie hoch ist der gesetzliche Mindestfettgehalt für Vollmilch in Deutschland?",
    "optEn": [
      "10% fat",
      "1.5% fat",
      "0.3% fat",
      "3.5% fat (or natural fat content typically 3.8-4.2%)"
    ],
    "optDe": [
      "10% Fett",
      "1,5% Fett",
      "0,3% Fett",
      "Mindestens 3,5% Fett (bzw. natürlicher Fettgehalt 3,8–4,2%)"
    ],
    "correct": 3,
    "expEn": "Standardized whole milk is adjusted to 3.5% milk fat; raw milk contains 3.8-4.2%.",
    "expDe": "Standardisierte Vollmilch enthält 3,5% Fett; fettarme Milch liegt bei 1,5–1,8%."
  },
  {
    "id": "q_dai_02",
    "category": "dairy",
    "questionEn": "What happens during milk homogenization?",
    "questionDe": "Was geschieht bei der Homogenisierung von Milch?",
    "optionsEn": [
      "Fat is removed completely",
      "Milk is boiled for 2 hours",
      "Milk is forced through tiny nozzles under 200 bar pressure, shattering fat globules so cream doesn't separate",
      "Sugar is added"
    ],
    "optionsDe": [
      "Fett wird abzentrifugiert",
      "Milch wird 2 Stunden gekocht",
      "Milch wird unter hohem Druck (ca. 200 bar) durch feine Düsen gepresst; Fettkügelchen zerteilen sich",
      "Milchzucker wird zugefügt"
    ],
    "correctIndex": 2,
    "explanationEn": "Micro-sized fat globules stay suspended evenly, preventing a cream plug from rising to the surface.",
    "explanationDe": "Durch das Zerkleinern der Fettkügelchen rahmt die Milch in der Flasche nicht mehr auf.",
    "qEn": "What happens during milk homogenization?",
    "qDe": "Was geschieht bei der Homogenisierung von Milch?",
    "optEn": [
      "Fat is removed completely",
      "Milk is boiled for 2 hours",
      "Milk is forced through tiny nozzles under 200 bar pressure, shattering fat globules so cream doesn't separate",
      "Sugar is added"
    ],
    "optDe": [
      "Fett wird abzentrifugiert",
      "Milch wird 2 Stunden gekocht",
      "Milch wird unter hohem Druck (ca. 200 bar) durch feine Düsen gepresst; Fettkügelchen zerteilen sich",
      "Milchzucker wird zugefügt"
    ],
    "correct": 2,
    "expEn": "Micro-sized fat globules stay suspended evenly, preventing a cream plug from rising to the surface.",
    "expDe": "Durch das Zerkleinern der Fettkügelchen rahmt die Milch in der Flasche nicht mehr auf."
  },
  {
    "id": "q_dai_03",
    "category": "dairy",
    "questionEn": "What defines UHT (Ultra-High Temperature) milk processing?",
    "questionDe": "Was zeichnet H-Milch (Ultrahocherhitzung) verfahrenstechnisch aus?",
    "optionsEn": [
      "Boiled at 100°C for 30 minutes",
      "Heated to 135°C–150°C for 2–4 seconds to destroy all microorganisms and bacterial spores",
      "Frozen to -40°C",
      "Filtered through paper"
    ],
    "optionsDe": [
      "Kochen bei 100°C für 30 Minuten",
      "Erhitzung auf 135°C bis 150°C für 2 bis 4 Sekunden zur Sterilisation",
      "Einfrieren auf -40°C",
      "Kaltfiltration"
    ],
    "correctIndex": 1,
    "explanationEn": "Aseptic packaging allows unopened UHT milk to be stored unrefrigerated for months.",
    "explanationDe": "Das Blitz-Erhitzen tötet alle Keime und Sporen ab; die Milch ist ungekühlt haltbar.",
    "qEn": "What defines UHT (Ultra-High Temperature) milk processing?",
    "qDe": "Was zeichnet H-Milch (Ultrahocherhitzung) verfahrenstechnisch aus?",
    "optEn": [
      "Boiled at 100°C for 30 minutes",
      "Heated to 135°C–150°C for 2–4 seconds to destroy all microorganisms and bacterial spores",
      "Frozen to -40°C",
      "Filtered through paper"
    ],
    "optDe": [
      "Kochen bei 100°C für 30 Minuten",
      "Erhitzung auf 135°C bis 150°C für 2 bis 4 Sekunden zur Sterilisation",
      "Einfrieren auf -40°C",
      "Kaltfiltration"
    ],
    "correct": 1,
    "expEn": "Aseptic packaging allows unopened UHT milk to be stored unrefrigerated for months.",
    "expDe": "Das Blitz-Erhitzen tötet alle Keime und Sporen ab; die Milch ist ungekühlt haltbar."
  },
  {
    "id": "q_dai_04",
    "category": "dairy",
    "questionEn": "What sugar is unique to mammal milk and causes lactose intolerance in some adults?",
    "questionDe": "Welcher Zweifachzucker kommt nur in Milch vor und verursacht bei manchen Laktoseintoleranz?",
    "optionsEn": [
      "Lactose (glucose + galactose)",
      "Fructose",
      "Sucrose",
      "Maltose"
    ],
    "optionsDe": [
      "Laktose (Milchzucker aus Glukose und Galaktose)",
      "Fruktose",
      "Saccharose",
      "Maltose"
    ],
    "correctIndex": 0,
    "explanationEn": "Insufficient lactase enzyme in the small intestine leaves lactose unabsorbed, causing fermentation.",
    "explanationDe": "Fehlt das körpereigene Enzym Laktase, kann der Milchzucker im Dünndarm nicht gespalten werden.",
    "qEn": "What sugar is unique to mammal milk and causes lactose intolerance in some adults?",
    "qDe": "Welcher Zweifachzucker kommt nur in Milch vor und verursacht bei manchen Laktoseintoleranz?",
    "optEn": [
      "Lactose (glucose + galactose)",
      "Fructose",
      "Sucrose",
      "Maltose"
    ],
    "optDe": [
      "Laktose (Milchzucker aus Glukose und Galaktose)",
      "Fruktose",
      "Saccharose",
      "Maltose"
    ],
    "correct": 0,
    "expEn": "Insufficient lactase enzyme in the small intestine leaves lactose unabsorbed, causing fermentation.",
    "expDe": "Fehlt das körpereigene Enzym Laktase, kann der Milchzucker im Dünndarm nicht gespalten werden."
  },
  {
    "id": "q_dai_05",
    "category": "dairy",
    "questionEn": "What is the primary protein family making up 80% of cow milk proteins?",
    "questionDe": "Welche Proteinfamilie stellt rund 80% des Gesamteiweißes in Kuhmilch?",
    "optionsEn": [
      "Collagen",
      "Whey albumins",
      "Gluten",
      "Caseins (alpha, beta, and kappa caseins)"
    ],
    "optionsDe": [
      "Kollagen",
      "Molkenalbumine",
      "Gluten",
      "Kaseine (Alpha-, Beta- und Kappa-Kasein)"
    ],
    "correctIndex": 3,
    "explanationEn": "Casein micelles coagulate when rennet or acid is added, forming solid cheese curds.",
    "explanationDe": "Kaseine bilden Micellen, die bei Säure oder Lab gerinnen und die Basis für Käse bilden.",
    "qEn": "What is the primary protein family making up 80% of cow milk proteins?",
    "qDe": "Welche Proteinfamilie stellt rund 80% des Gesamteiweißes in Kuhmilch?",
    "optEn": [
      "Collagen",
      "Whey albumins",
      "Gluten",
      "Caseins (alpha, beta, and kappa caseins)"
    ],
    "optDe": [
      "Kollagen",
      "Molkenalbumine",
      "Gluten",
      "Kaseine (Alpha-, Beta- und Kappa-Kasein)"
    ],
    "correct": 3,
    "expEn": "Casein micelles coagulate when rennet or acid is added, forming solid cheese curds.",
    "expDe": "Kaseine bilden Micellen, die bei Säure oder Lab gerinnen und die Basis für Käse bilden."
  },
  {
    "id": "q_dai_06",
    "category": "dairy",
    "questionEn": "What is Ghee in traditional Indian culinary science?",
    "questionDe": "Was ist Ghee aus lebensmittelchemischer Sicht?",
    "optionsEn": [
      "Fermented goat milk",
      "Whipped salted butter",
      "Clarified butterfat simmered until milk solids brown and all water evaporates (100% pure butterfat)",
      "Margarine made of palm oil"
    ],
    "optionsDe": [
      "Vergorene Ziegenmilch",
      "Geschlagene Salzkäsebutter",
      "Reines Butterfett, bei dem Wasser verdampft und Milcheiweiße nussig gebräunt und abgeseiht wurden",
      "Pflanzenmargarine"
    ],
    "correctIndex": 2,
    "explanationEn": "Ghee has a smoke point of 250°C (482°F) and keeps indefinitely without refrigeration.",
    "explanationDe": "Ghee enthält weder Wasser noch Eiweiß; es verbrennt erst bei 250°C und hält ungekühlt.",
    "qEn": "What is Ghee in traditional Indian culinary science?",
    "qDe": "Was ist Ghee aus lebensmittelchemischer Sicht?",
    "optEn": [
      "Fermented goat milk",
      "Whipped salted butter",
      "Clarified butterfat simmered until milk solids brown and all water evaporates (100% pure butterfat)",
      "Margarine made of palm oil"
    ],
    "optDe": [
      "Vergorene Ziegenmilch",
      "Geschlagene Salzkäsebutter",
      "Reines Butterfett, bei dem Wasser verdampft und Milcheiweiße nussig gebräunt und abgeseiht wurden",
      "Pflanzenmargarine"
    ],
    "correct": 2,
    "expEn": "Ghee has a smoke point of 250°C (482°F) and keeps indefinitely without refrigeration.",
    "expDe": "Ghee enthält weder Wasser noch Eiweiß; es verbrennt erst bei 250°C und hält ungekühlt."
  },
  {
    "id": "q_dai_07",
    "category": "dairy",
    "questionEn": "What distinguishes French Crème Fraîche from regular heavy cream?",
    "questionDe": "Was unterscheidet Crème fraîche von süßer Schlagsahne?",
    "optionsEn": [
      "Contains 10% sugar",
      "Cultured with lactic acid bacteria (min. 30% fat), slightly acidic, and won't curdle when boiled",
      "Is whipped into foam",
      "Made of skimmed milk"
    ],
    "optionsDe": [
      "Enthält 10% Zucker",
      "Mit Milchsäurebakterien gesäuert (mind. 30% Fett); gerinnt beim Kochen nicht",
      "Ist fertig aufgeschlagen",
      "Besteht aus Magermilch"
    ],
    "correctIndex": 1,
    "explanationEn": "High fat content and low protein prevent curdling, making Crème Fraîche ideal for hot pan reductions.",
    "explanationDe": "Dank hohem Fettgehalt und Säuerung flockt Crème fraîche in heißen Saucen nicht aus.",
    "qEn": "What distinguishes French Crème Fraîche from regular heavy cream?",
    "qDe": "Was unterscheidet Crème fraîche von süßer Schlagsahne?",
    "optEn": [
      "Contains 10% sugar",
      "Cultured with lactic acid bacteria (min. 30% fat), slightly acidic, and won't curdle when boiled",
      "Is whipped into foam",
      "Made of skimmed milk"
    ],
    "optDe": [
      "Enthält 10% Zucker",
      "Mit Milchsäurebakterien gesäuert (mind. 30% Fett); gerinnt beim Kochen nicht",
      "Ist fertig aufgeschlagen",
      "Besteht aus Magermilch"
    ],
    "correct": 1,
    "expEn": "High fat content and low protein prevent curdling, making Crème Fraîche ideal for hot pan reductions.",
    "expDe": "Dank hohem Fettgehalt und Säuerung flockt Crème fraîche in heißen Saucen nicht aus."
  },
  {
    "id": "q_dai_08",
    "category": "dairy",
    "questionEn": "What gives cultured Butter its rich hazelnut aroma compared to sweet cream butter?",
    "questionDe": "Was erzeugt das nussige Aroma in Sauerrahmbutter im Vergleich zu Süßrahmbutter?",
    "optionsEn": [
      "Diacetyl produced by lactic bacterial fermentation of citrate",
      "Added roasted hazelnuts",
      "Smoke aroma",
      "Caramelized lactose"
    ],
    "optionsDe": [
      "Diacetyl, gebildet durch Milchsäurebakterien bei der Reifung des Rahms",
      "Zusatz von Haselnussöl",
      "Raucharoma",
      "Karamellisierter Zucker"
    ],
    "correctIndex": 0,
    "explanationEn": "Fermentation of citric acid by Leuconostoc bacteria yields rich buttery diacetyl.",
    "explanationDe": "Reifungskulturen wandeln Zitronensäure in aromatisches Diacetyl um.",
    "qEn": "What gives cultured Butter its rich hazelnut aroma compared to sweet cream butter?",
    "qDe": "Was erzeugt das nussige Aroma in Sauerrahmbutter im Vergleich zu Süßrahmbutter?",
    "optEn": [
      "Diacetyl produced by lactic bacterial fermentation of citrate",
      "Added roasted hazelnuts",
      "Smoke aroma",
      "Caramelized lactose"
    ],
    "optDe": [
      "Diacetyl, gebildet durch Milchsäurebakterien bei der Reifung des Rahms",
      "Zusatz von Haselnussöl",
      "Raucharoma",
      "Karamellisierter Zucker"
    ],
    "correct": 0,
    "expEn": "Fermentation of citric acid by Leuconostoc bacteria yields rich buttery diacetyl.",
    "expDe": "Reifungskulturen wandeln Zitronensäure in aromatisches Diacetyl um."
  },
  {
    "id": "q_dai_09",
    "category": "dairy",
    "questionEn": "What is Buttermilk (echte reine Buttermilch) traditionally?",
    "questionDe": "Was ist echte reine Buttermilch im traditionellen Sinn?",
    "optionsEn": [
      "Thick yogurt shake",
      "Milk mixed with lemon juice",
      "Melted butter in water",
      "The tart, low-fat liquid remaining after churning cultured cream into solid butter"
    ],
    "optionsDe": [
      "Dickflüssiger Joghurt",
      "Milch mit Zitronensaft",
      "Geschmolzene Butter in Wasser",
      "Die säuerliche, fettarme Flüssigkeit, die beim Buttern von gereiftem Rahm abfließt"
    ],
    "correctIndex": 3,
    "explanationEn": "True buttermilk has under 1% fat, high natural lecithin, and refreshing lactic tartness.",
    "explanationDe": "Reine Buttermilch ist fast fettfrei, reich an Lecithin und herrlich erfrischend.",
    "qEn": "What is Buttermilk (echte reine Buttermilch) traditionally?",
    "qDe": "Was ist echte reine Buttermilch im traditionellen Sinn?",
    "optEn": [
      "Thick yogurt shake",
      "Milk mixed with lemon juice",
      "Melted butter in water",
      "The tart, low-fat liquid remaining after churning cultured cream into solid butter"
    ],
    "optDe": [
      "Dickflüssiger Joghurt",
      "Milch mit Zitronensaft",
      "Geschmolzene Butter in Wasser",
      "Die säuerliche, fettarme Flüssigkeit, die beim Buttern von gereiftem Rahm abfließt"
    ],
    "correct": 3,
    "expEn": "True buttermilk has under 1% fat, high natural lecithin, and refreshing lactic tartness.",
    "expDe": "Reine Buttermilch ist fast fettfrei, reich an Lecithin und herrlich erfrischend."
  },
  {
    "id": "q_dai_10",
    "category": "dairy",
    "questionEn": "What live bacterial cultures are legally required in authentic Yogurt?",
    "questionDe": "Welche Bakterienkulturen sind für echten Joghurt gesetzlich vorgeschrieben?",
    "optionsEn": [
      "Acetobacter and brettanomyces",
      "Bakers yeast and mold",
      "Lactobacillus bulgaricus and Streptococcus thermophilus",
      "Penicillium roqueforti"
    ],
    "optionsDe": [
      "Essigsäurebakterien",
      "Bäckerhefe und Schimmel",
      "Lactobacillus bulgaricus und Streptococcus thermophilus",
      "Edelschimmelpilze"
    ],
    "correctIndex": 2,
    "explanationEn": "These two thermophilic bacteria work in symbiosis, fermenting lactose into soothing lactic acid.",
    "explanationDe": "Beide Stämme wandeln Laktose bei 40–42°C in Milchsäure um und lassen das Eiweiß stocken.",
    "qEn": "What live bacterial cultures are legally required in authentic Yogurt?",
    "qDe": "Welche Bakterienkulturen sind für echten Joghurt gesetzlich vorgeschrieben?",
    "optEn": [
      "Acetobacter and brettanomyces",
      "Bakers yeast and mold",
      "Lactobacillus bulgaricus and Streptococcus thermophilus",
      "Penicillium roqueforti"
    ],
    "optDe": [
      "Essigsäurebakterien",
      "Bäckerhefe und Schimmel",
      "Lactobacillus bulgaricus und Streptococcus thermophilus",
      "Edelschimmelpilze"
    ],
    "correct": 2,
    "expEn": "These two thermophilic bacteria work in symbiosis, fermenting lactose into soothing lactic acid.",
    "expDe": "Beide Stämme wandeln Laktose bei 40–42°C in Milchsäure um und lassen das Eiweiß stocken."
  },
  {
    "id": "q_dai_11",
    "category": "dairy",
    "questionEn": "How is thick Greek Yogurt traditionally made?",
    "questionDe": "Wie wird traditioneller griechischer Joghurt hergestellt?",
    "optionsEn": [
      "Thickened with gelatin",
      "Strained through fine cloth to drain off watery whey, concentrating protein and fat",
      "Boiled with cornstarch",
      "Frozen solid"
    ],
    "optionsDe": [
      "Mit Gelatine angedickt",
      "Geseiht durch Tücher, um wässrige Molke abzutrennen; Proteine und Fette konzentrieren sich",
      "Mit Speisestärke gekocht",
      "Gefroren"
    ],
    "correctIndex": 1,
    "explanationEn": "Straining yields three times the protein per spoon and a dense, velvet spoonable texture.",
    "explanationDe": "Das Abtropfen der Molke verdreifacht den Eiweißgehalt und schenkt sahnige Festigkeit.",
    "qEn": "How is thick Greek Yogurt traditionally made?",
    "qDe": "Wie wird traditioneller griechischer Joghurt hergestellt?",
    "optEn": [
      "Thickened with gelatin",
      "Strained through fine cloth to drain off watery whey, concentrating protein and fat",
      "Boiled with cornstarch",
      "Frozen solid"
    ],
    "optDe": [
      "Mit Gelatine angedickt",
      "Geseiht durch Tücher, um wässrige Molke abzutrennen; Proteine und Fette konzentrieren sich",
      "Mit Speisestärke gekocht",
      "Gefroren"
    ],
    "correct": 1,
    "expEn": "Straining yields three times the protein per spoon and a dense, velvet spoonable texture.",
    "expDe": "Das Abtropfen der Molke verdreifacht den Eiweißgehalt und schenkt sahnige Festigkeit."
  },
  {
    "id": "q_dai_12",
    "category": "dairy",
    "questionEn": "What is Kefir and what is the 'Kefir Grain'?",
    "questionDe": "Was ist Kefir und woraus bestehen 'Kefirknollen'?",
    "optionsEn": [
      "A symbiotic grain colony of yeasts and lactic bacteria producing mild alcohol and fizz",
      "A cereal grain like wheat",
      "A chemical tablet",
      "A freeze-dried powder"
    ],
    "optionsDe": [
      "Eine gallertige Symbiose aus Hefen und Milchsäurebakterien, die Prickeln und Minialkohol erzeugt",
      "Ein Getreidekorn wie Roggen",
      "Eine Brausetablette",
      "Gefriergetrocknetes Mehl"
    ],
    "correctIndex": 0,
    "explanationEn": "Yeasts produce CO2 and trace ethanol (0.5%); bacteria produce lactic acid and polysaccharides.",
    "explanationDe": "Hefen und Bakterien bilden Kohlensäure, Vitamine und einen Hauch Gärungsalkohol.",
    "qEn": "What is Kefir and what is the 'Kefir Grain'?",
    "qDe": "Was ist Kefir und woraus bestehen 'Kefirknollen'?",
    "optEn": [
      "A symbiotic grain colony of yeasts and lactic bacteria producing mild alcohol and fizz",
      "A cereal grain like wheat",
      "A chemical tablet",
      "A freeze-dried powder"
    ],
    "optDe": [
      "Eine gallertige Symbiose aus Hefen und Milchsäurebakterien, die Prickeln und Minialkohol erzeugt",
      "Ein Getreidekorn wie Roggen",
      "Eine Brausetablette",
      "Gefriergetrocknetes Mehl"
    ],
    "correct": 0,
    "expEn": "Yeasts produce CO2 and trace ethanol (0.5%); bacteria produce lactic acid and polysaccharides.",
    "expDe": "Hefen und Bakterien bilden Kohlensäure, Vitamine und einen Hauch Gärungsalkohol."
  },
  {
    "id": "q_dai_13",
    "category": "dairy",
    "questionEn": "Why does milk foam during coffee steaming?",
    "questionDe": "Warum lässt sich Milch zu stabilem Milchschaum aufschlagen?",
    "optionsEn": [
      "Fat melts into oil",
      "Lactose boils into caramel",
      "Water evaporates",
      "Whey proteins unfold and encapsulate injected air bubbles, stabilized by milk fats below 65°C"
    ],
    "optionsDe": [
      "Fett verbrennt",
      "Milchzucker karamellisiert",
      "Wasser verdampft",
      "Molkeneiweiße entfalten sich und umhüllen Luftbläschen; Fett stabilisiert die Wandungen"
    ],
    "correctIndex": 3,
    "explanationEn": "Denaturing whey proteins form an elastic film around micro-bubbles; excess heat collapses them.",
    "explanationDe": "Die Eiweiße bilden elastische Hüllen um die Luftblasen; zu viel Hitze lässt sie platzen.",
    "qEn": "Why does milk foam during coffee steaming?",
    "qDe": "Warum lässt sich Milch zu stabilem Milchschaum aufschlagen?",
    "optEn": [
      "Fat melts into oil",
      "Lactose boils into caramel",
      "Water evaporates",
      "Whey proteins unfold and encapsulate injected air bubbles, stabilized by milk fats below 65°C"
    ],
    "optDe": [
      "Fett verbrennt",
      "Milchzucker karamellisiert",
      "Wasser verdampft",
      "Molkeneiweiße entfalten sich und umhüllen Luftbläschen; Fett stabilisiert die Wandungen"
    ],
    "correct": 3,
    "expEn": "Denaturing whey proteins form an elastic film around micro-bubbles; excess heat collapses them.",
    "expDe": "Die Eiweiße bilden elastische Hüllen um die Luftblasen; zu viel Hitze lässt sie platzen."
  },
  {
    "id": "q_dai_14",
    "category": "dairy",
    "questionEn": "What is Condensed Milk (gezuckerte Kondensmilch)?",
    "questionDe": "Was ist gezuckerte Kondensmilch?",
    "optionsEn": [
      "Cream boiled with flour",
      "Powdered milk dissolved in water",
      "Cow milk reduced by 60% water evaporation and preserved with 40-45% added sugar",
      "Soy milk syrup"
    ],
    "optionsDe": [
      "Rahm mit Mehl",
      "Milchpulver in Wasser",
      "Eingedickte Milch, der ca. 60% Wasser entzogen und reichlich Zucker zugesetzt wurde",
      "Sojasirup"
    ],
    "correctIndex": 2,
    "explanationEn": "High osmotic pressure from sugar inhibits bacterial growth without refrigeration.",
    "explanationDe": "Der hohe Zuckergehalt bindet Wasser osmotisch und konserviert die dicke Milch dauerhaft.",
    "qEn": "What is Condensed Milk (gezuckerte Kondensmilch)?",
    "qDe": "Was ist gezuckerte Kondensmilch?",
    "optEn": [
      "Cream boiled with flour",
      "Powdered milk dissolved in water",
      "Cow milk reduced by 60% water evaporation and preserved with 40-45% added sugar",
      "Soy milk syrup"
    ],
    "optDe": [
      "Rahm mit Mehl",
      "Milchpulver in Wasser",
      "Eingedickte Milch, der ca. 60% Wasser entzogen und reichlich Zucker zugesetzt wurde",
      "Sojasirup"
    ],
    "correct": 2,
    "expEn": "High osmotic pressure from sugar inhibits bacterial growth without refrigeration.",
    "expDe": "Der hohe Zuckergehalt bindet Wasser osmotisch und konserviert die dicke Milch dauerhaft."
  },
  {
    "id": "q_dai_15",
    "category": "dairy",
    "questionEn": "What causes the rich brown color and nutty flavor in Beurre Noisette (brown butter)?",
    "questionDe": "Was erzeugt die nussige Bräune in 'Beurre Noisette' (Nussbutter)?",
    "optionsEn": [
      "Added hazelnut syrup",
      "Maillard reaction between milk proteins (casein) and lactose sugars when water boils off at 120-130°C",
      "Wood smoke",
      "Caramel color dye"
    ],
    "optionsDe": [
      "Zusatz von Haselnussmus",
      "Maillard-Reaktion zwischen Milcheiweiß und Milchzucker nach dem Verdampfen des Wassers",
      "Holzrauch",
      "Zuckerkulör"
    ],
    "correctIndex": 1,
    "explanationEn": "Once the water sputters away, milk solids toast in pure butterfat, releasing nutty aromas.",
    "explanationDe": "Sobald das Wasser verdampft ist, rösten die Eiweißflöckchen im Butterfett goldbraun.",
    "qEn": "What causes the rich brown color and nutty flavor in Beurre Noisette (brown butter)?",
    "qDe": "Was erzeugt die nussige Bräune in 'Beurre Noisette' (Nussbutter)?",
    "optEn": [
      "Added hazelnut syrup",
      "Maillard reaction between milk proteins (casein) and lactose sugars when water boils off at 120-130°C",
      "Wood smoke",
      "Caramel color dye"
    ],
    "optDe": [
      "Zusatz von Haselnussmus",
      "Maillard-Reaktion zwischen Milcheiweiß und Milchzucker nach dem Verdampfen des Wassers",
      "Holzrauch",
      "Zuckerkulör"
    ],
    "correct": 1,
    "expEn": "Once the water sputters away, milk solids toast in pure butterfat, releasing nutty aromas.",
    "expDe": "Sobald das Wasser verdampft ist, rösten die Eiweißflöckchen im Butterfett goldbraun."
  },
  {
    "id": "q_dai_16",
    "category": "dairy",
    "questionEn": "What is Skyr in Nordic dairy tradition?",
    "questionDe": "Was ist traditioneller isländischer Skyr?",
    "optionsEn": [
      "A cultured fresh sour-milk cheese strained to high-protein, zero-fat creaminess",
      "A sweet dessert pudding",
      "Salted sheep butter",
      "Fermented whale fat"
    ],
    "optionsDe": [
      "Ein traditionell gereifter Sauermilchkäse mit extrem hohem Proteingehalt und kaum Fett",
      "Ein süßer Sahnepudding",
      "Gesalzene Schafbutter",
      "Vergorenes Walfett"
    ],
    "correctIndex": 0,
    "explanationEn": "Skyr is legally a fresh curd cheese made with skimmed milk, offering massive protein density.",
    "explanationDe": "Skyr ist eigentlich ein fettfreier Frischkäse mit fester Konsistenz und feiner Säure.",
    "qEn": "What is Skyr in Nordic dairy tradition?",
    "qDe": "Was ist traditioneller isländischer Skyr?",
    "optEn": [
      "A cultured fresh sour-milk cheese strained to high-protein, zero-fat creaminess",
      "A sweet dessert pudding",
      "Salted sheep butter",
      "Fermented whale fat"
    ],
    "optDe": [
      "Ein traditionell gereifter Sauermilchkäse mit extrem hohem Proteingehalt und kaum Fett",
      "Ein süßer Sahnepudding",
      "Gesalzene Schafbutter",
      "Vergorenes Walfett"
    ],
    "correct": 0,
    "expEn": "Skyr is legally a fresh curd cheese made with skimmed milk, offering massive protein density.",
    "expDe": "Skyr ist eigentlich ein fettfreier Frischkäse mit fester Konsistenz und feiner Säure."
  },
  {
    "id": "q_dai_17",
    "category": "dairy",
    "questionEn": "Why does cold cream whip into stiff peaks while warm cream turns into greasy soup?",
    "questionDe": "Warum lässt sich kalte Sahne steif schlagen, warme Sahne hingegen nicht?",
    "optionsEn": [
      "Cold cream attracts nitrogen",
      "Cold cream has more sugar",
      "Warm cream loses protein",
      "Milk fat globule membranes must remain solid and crystalline to form a rigid structural lattice around air bubbles"
    ],
    "optionsDe": [
      "Kälte bindet Stickstoff",
      "Kalte Sahne hat mehr Zucker",
      "Warme Sahne verliert Eiweiß",
      "Fettkügelchen müssen fest kristallisiert sein, um ein stabiles Gerüst um Luftbläschen zu bilden"
    ],
    "correctIndex": 3,
    "explanationEn": "Above 15°C, butterfat melts into liquid oil, which defoams and collapses whipped air bubbles.",
    "explanationDe": "Flüssiges Fett zerstört den Schaum; nur feste Fettkristalle stützen die Luftbläschen.",
    "qEn": "Why does cold cream whip into stiff peaks while warm cream turns into greasy soup?",
    "qDe": "Warum lässt sich kalte Sahne steif schlagen, warme Sahne hingegen nicht?",
    "optEn": [
      "Cold cream attracts nitrogen",
      "Cold cream has more sugar",
      "Warm cream loses protein",
      "Milk fat globule membranes must remain solid and crystalline to form a rigid structural lattice around air bubbles"
    ],
    "optDe": [
      "Kälte bindet Stickstoff",
      "Kalte Sahne hat mehr Zucker",
      "Warme Sahne verliert Eiweiß",
      "Fettkügelchen müssen fest kristallisiert sein, um ein stabiles Gerüst um Luftbläschen zu bilden"
    ],
    "correct": 3,
    "expEn": "Above 15°C, butterfat melts into liquid oil, which defoams and collapses whipped air bubbles.",
    "expDe": "Flüssiges Fett zerstört den Schaum; nur feste Fettkristalle stützen die Luftbläschen."
  },
  {
    "id": "q_dai_18",
    "category": "dairy",
    "questionEn": "What is Quark (Topfen) in Central European gastronomy?",
    "questionDe": "Was ist Quark bzw. Topfen in der Küchenpraxis?",
    "optionsEn": [
      "Fermented butter",
      "A hard mountain cheese",
      "A fresh acid-set curd cheese made by coagulating pasteurized skimmed milk with lactic cultures",
      "Whipped cream cheese with salt"
    ],
    "optionsDe": [
      "Fermentierte Butter",
      "Ein gereifter Bergkäse",
      "Ein Frischkäse, hergestellt durch Milchsäuerung und sanfte Dicklegung von Magermilch",
      "Gesalzener Rahmfrischkäse"
    ],
    "correctIndex": 2,
    "explanationEn": "Quark separates curds from acid whey, versatile for German cheesecake (Käsekuchen) or herb dips.",
    "explanationDe": "Topfen ist das gestockte Kasein der Sauermilch, ideal für Strudel, Mehlspeisen und Kräuterdips.",
    "qEn": "What is Quark (Topfen) in Central European gastronomy?",
    "qDe": "Was ist Quark bzw. Topfen in der Küchenpraxis?",
    "optEn": [
      "Fermented butter",
      "A hard mountain cheese",
      "A fresh acid-set curd cheese made by coagulating pasteurized skimmed milk with lactic cultures",
      "Whipped cream cheese with salt"
    ],
    "optDe": [
      "Fermentierte Butter",
      "Ein gereifter Bergkäse",
      "Ein Frischkäse, hergestellt durch Milchsäuerung und sanfte Dicklegung von Magermilch",
      "Gesalzener Rahmfrischkäse"
    ],
    "correct": 2,
    "expEn": "Quark separates curds from acid whey, versatile for German cheesecake (Käsekuchen) or herb dips.",
    "expDe": "Topfen ist das gestockte Kasein der Sauermilch, ideal für Strudel, Mehlspeisen und Kräuterdips."
  },
  {
    "id": "q_che_01",
    "category": "cheese",
    "questionEn": "What is the legal minimum aging time for Parmigiano Reggiano DOP?",
    "questionDe": "Wie lange muss Parmigiano Reggiano DOP mindestens reifen?",
    "optionsEn": [
      "3 months",
      "12 months (typically 24 to 36 months)",
      "6 weeks",
      "5 years"
    ],
    "optionsDe": [
      "3 Monate",
      "Mindestens 12 Monate (klassisch 24 bis 36 Monate)",
      "6 Wochen",
      "Mindestens 5 Jahre"
    ],
    "correctIndex": 1,
    "explanationEn": "Parmigiano Reggiano is inspected at 12 months with a silver hammer before receiving fire-branded certification.",
    "explanationDe": "Nach 12 Monaten prüft das Konsortium jeden Laib mit dem Klöppel auf Risse und Hohlräume.",
    "qEn": "What is the legal minimum aging time for Parmigiano Reggiano DOP?",
    "qDe": "Wie lange muss Parmigiano Reggiano DOP mindestens reifen?",
    "optEn": [
      "3 months",
      "12 months (typically 24 to 36 months)",
      "6 weeks",
      "5 years"
    ],
    "optDe": [
      "3 Monate",
      "Mindestens 12 Monate (klassisch 24 bis 36 Monate)",
      "6 Wochen",
      "Mindestens 5 Jahre"
    ],
    "correct": 1,
    "expEn": "Parmigiano Reggiano is inspected at 12 months with a silver hammer before receiving fire-branded certification.",
    "expDe": "Nach 12 Monaten prüft das Konsortium jeden Laib mit dem Klöppel auf Risse und Hohlräume."
  },
  {
    "id": "q_che_02",
    "category": "cheese",
    "questionEn": "What are the crunchy white crystals found in well-aged cheese (e.g. 36-month Parmesan or vintage Gouda)?",
    "questionDe": "Was sind die feinen Knusperkristalle in reifem Parmesan oder altem Gouda?",
    "optionsEn": [
      "Crystallized calcium lactate and tyrosine amino acid crystals",
      "Table salt (NaCl) grains",
      "Bone fragments",
      "Sugar crystals"
    ],
    "optionsDe": [
      "Ausgefallene Aminosäure-Kristalle (Tyrosin) und Calciumlactat",
      "Eingestreute Kochsalzkörner",
      "Kalkreste",
      "Rohrzuckerkristalle"
    ],
    "correctIndex": 0,
    "explanationEn": "Proteolysis breaks casein into free amino acids; insoluble tyrosine precipitates into crunchy gems.",
    "explanationDe": "Der Eiweißabbau setzt Tyrosin frei; diese Aminosäuren kristallisieren zu edlem Umami-Biss.",
    "qEn": "What are the crunchy white crystals found in well-aged cheese (e.g. 36-month Parmesan or vintage Gouda)?",
    "qDe": "Was sind die feinen Knusperkristalle in reifem Parmesan oder altem Gouda?",
    "optEn": [
      "Crystallized calcium lactate and tyrosine amino acid crystals",
      "Table salt (NaCl) grains",
      "Bone fragments",
      "Sugar crystals"
    ],
    "optDe": [
      "Ausgefallene Aminosäure-Kristalle (Tyrosin) und Calciumlactat",
      "Eingestreute Kochsalzkörner",
      "Kalkreste",
      "Rohrzuckerkristalle"
    ],
    "correct": 0,
    "expEn": "Proteolysis breaks casein into free amino acids; insoluble tyrosine precipitates into crunchy gems.",
    "expDe": "Der Eiweißabbau setzt Tyrosin frei; diese Aminosäuren kristallisieren zu edlem Umami-Biss."
  },
  {
    "id": "q_che_03",
    "category": "cheese",
    "questionEn": "What noble mold strain creates the blue veins in Roquefort and Gorgonzola?",
    "questionDe": "Welcher Edelschimmelpilz erzeugt die blauen Adern in Roquefort und Gorgonzola?",
    "optionsEn": [
      "Saccharomyces cerevisiae",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Penicillium roqueforti"
    ],
    "optionsDe": [
      "Bäckerhefe",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Penicillium roqueforti"
    ],
    "correctIndex": 3,
    "explanationEn": "Penicillium roqueforti breaks down butterfat into methyl ketones, creating spicy piquancy.",
    "explanationDe": "Der Schimmel spaltet Fette in Ketone, was den typisch pikant-würzigen Blauschimmelgeschmack erzeugt.",
    "qEn": "What noble mold strain creates the blue veins in Roquefort and Gorgonzola?",
    "qDe": "Welcher Edelschimmelpilz erzeugt die blauen Adern in Roquefort und Gorgonzola?",
    "optEn": [
      "Saccharomyces cerevisiae",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Penicillium roqueforti"
    ],
    "optDe": [
      "Bäckerhefe",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Penicillium roqueforti"
    ],
    "correct": 3,
    "expEn": "Penicillium roqueforti breaks down butterfat into methyl ketones, creating spicy piquancy.",
    "expDe": "Der Schimmel spaltet Fette in Ketone, was den typisch pikant-würzigen Blauschimmelgeschmack erzeugt."
  },
  {
    "id": "q_che_04",
    "category": "cheese",
    "questionEn": "What milk is strictly used for authentic Mozzarella di Bufala Campana DOP?",
    "questionDe": "Welche Milch ist für echte Mozzarella di Bufala Campana DOP vorgeschrieben?",
    "optionsEn": [
      "Goat milk",
      "Cow milk only",
      "Whole raw or pasteurized water buffalo milk (Bubalus bubalis)",
      "Sheep milk"
    ],
    "optionsDe": [
      "Ziegenmilch",
      "Kuhmilch",
      "Reine Wasserbüffelmilch (Bubalus bubalis)",
      "Schafsmilch"
    ],
    "correctIndex": 2,
    "explanationEn": "Water buffalo milk contains almost double the fat and protein of cow milk, yielding porcelain creaminess.",
    "explanationDe": "Büffelmilch hat ca. 8% Fett und verleiht der Mozzarella ihren saftigen, süßlich-säuerlichen Schmelz.",
    "qEn": "What milk is strictly used for authentic Mozzarella di Bufala Campana DOP?",
    "qDe": "Welche Milch ist für echte Mozzarella di Bufala Campana DOP vorgeschrieben?",
    "optEn": [
      "Goat milk",
      "Cow milk only",
      "Whole raw or pasteurized water buffalo milk (Bubalus bubalis)",
      "Sheep milk"
    ],
    "optDe": [
      "Ziegenmilch",
      "Kuhmilch",
      "Reine Wasserbüffelmilch (Bubalus bubalis)",
      "Schafsmilch"
    ],
    "correct": 2,
    "expEn": "Water buffalo milk contains almost double the fat and protein of cow milk, yielding porcelain creaminess.",
    "expDe": "Büffelmilch hat ca. 8% Fett und verleiht der Mozzarella ihren saftigen, süßlich-säuerlichen Schmelz."
  },
  {
    "id": "q_che_05",
    "category": "cheese",
    "questionEn": "What gives French Camembert and Brie their velvety white blooming rind?",
    "questionDe": "Was bildet die samtig weiße Edelschimmelrinde auf Camembert und Brie?",
    "optionsEn": [
      "Flour dust",
      "Penicillium camemberti (or Penicillium candidum)",
      "Chalk powder",
      "Baking soda"
    ],
    "optionsDe": [
      "Mehlstaub",
      "Penicillium camemberti (auch Penicillium candidum genannt)",
      "Kalküberzug",
      "Backpulver"
    ],
    "correctIndex": 1,
    "explanationEn": "Surface mold secretes enzymes that break down curd from outside inward, softening cheese into a molten core.",
    "explanationDe": "Der weiße Schimmelpilz baut das Kasein von der Rinde nach innen ab, bis der Teig fließt.",
    "qEn": "What gives French Camembert and Brie their velvety white blooming rind?",
    "qDe": "Was bildet die samtig weiße Edelschimmelrinde auf Camembert und Brie?",
    "optEn": [
      "Flour dust",
      "Penicillium camemberti (or Penicillium candidum)",
      "Chalk powder",
      "Baking soda"
    ],
    "optDe": [
      "Mehlstaub",
      "Penicillium camemberti (auch Penicillium candidum genannt)",
      "Kalküberzug",
      "Backpulver"
    ],
    "correct": 1,
    "expEn": "Surface mold secretes enzymes that break down curd from outside inward, softening cheese into a molten core.",
    "expDe": "Der weiße Schimmelpilz baut das Kasein von der Rinde nach innen ab, bis der Teig fließt."
  },
  {
    "id": "q_che_06",
    "category": "cheese",
    "questionEn": "What creates the famous round holes ('eyes') in Swiss Emmentaler AOP?",
    "questionDe": "Was verursacht die typischen großen Löcher im Schweizer Emmentaler AOP?",
    "optionsEn": [
      "Propionic acid bacteria (Propionibacterium freudenreichii) producing carbon dioxide gas bubbles",
      "Gas bubbles from boiling milk",
      "Mechanical drills",
      "Worms in aging cellar"
    ],
    "optionsDe": [
      "Propionsäurebakterien bilden Kohlendioxidgas, das im festen Teig nicht entweichen kann",
      "Kochende Blasen",
      "Mechanische Bohrer",
      "Käsemaden"
    ],
    "correctIndex": 0,
    "explanationEn": "Bacteria consume lactic acid, producing nutty propionic acid, acetic acid, and CO2 pockets.",
    "explanationDe": "Propionsäurebakterien erzeugen nussiges Aroma und Kohlendioxidgas, das die Löcher aufbläht.",
    "qEn": "What creates the famous round holes ('eyes') in Swiss Emmentaler AOP?",
    "qDe": "Was verursacht die typischen großen Löcher im Schweizer Emmentaler AOP?",
    "optEn": [
      "Propionic acid bacteria (Propionibacterium freudenreichii) producing carbon dioxide gas bubbles",
      "Gas bubbles from boiling milk",
      "Mechanical drills",
      "Worms in aging cellar"
    ],
    "optDe": [
      "Propionsäurebakterien bilden Kohlendioxidgas, das im festen Teig nicht entweichen kann",
      "Kochende Blasen",
      "Mechanische Bohrer",
      "Käsemaden"
    ],
    "correct": 0,
    "expEn": "Bacteria consume lactic acid, producing nutty propionic acid, acetic acid, and CO2 pockets.",
    "expDe": "Propionsäurebakterien erzeugen nussiges Aroma und Kohlendioxidgas, das die Löcher aufbläht."
  },
  {
    "id": "q_che_07",
    "category": "cheese",
    "questionEn": "What distinguishes authentic Feta g.U. (PDO) from generic salad cheese?",
    "questionDe": "Was unterscheidet echten griechischen Feta g.U. von herkömmlichem Hirtenkäse?",
    "optionsEn": [
      "Contains cheddar scraps",
      "Made from cow milk with palm oil",
      "Made in Denmark from skim milk",
      "Must be produced in Greece from sheep milk (min. 70%) and goat milk (max. 30%) aged in brine"
    ],
    "optionsDe": [
      "Aus Rinderfett",
      "Aus Kuhmilch mit Palmöl",
      "Aus dänischer Magermilch",
      "Traditionell in Griechenland aus Schafsmilch (mind. 70%) und Ziegenmilch gereift in Salzlake"
    ],
    "correctIndex": 3,
    "explanationEn": "EU PDO rules protect Greek terroir; cow milk imitations must be labelled 'salad block' or 'white cheese'.",
    "explanationDe": "Feta darf nur aus Schafs- und Ziegenmilch in Griechenland stammen; Kuhmilchprodukte sind Imitate.",
    "qEn": "What distinguishes authentic Feta g.U. (PDO) from generic salad cheese?",
    "qDe": "Was unterscheidet echten griechischen Feta g.U. von herkömmlichem Hirtenkäse?",
    "optEn": [
      "Contains cheddar scraps",
      "Made from cow milk with palm oil",
      "Made in Denmark from skim milk",
      "Must be produced in Greece from sheep milk (min. 70%) and goat milk (max. 30%) aged in brine"
    ],
    "optDe": [
      "Aus Rinderfett",
      "Aus Kuhmilch mit Palmöl",
      "Aus dänischer Magermilch",
      "Traditionell in Griechenland aus Schafsmilch (mind. 70%) und Ziegenmilch gereift in Salzlake"
    ],
    "correct": 3,
    "expEn": "EU PDO rules protect Greek terroir; cow milk imitations must be labelled 'salad block' or 'white cheese'.",
    "expDe": "Feta darf nur aus Schafs- und Ziegenmilch in Griechenland stammen; Kuhmilchprodukte sind Imitate."
  },
  {
    "id": "q_che_08",
    "category": "cheese",
    "questionEn": "Why is Raclette du Valais AOP the supreme melting cheese?",
    "questionDe": "Warum schmilzt echter Walliser Raclette AOP so außergewöhnlich cremig?",
    "optionsEn": [
      "Is pre-melted in factory",
      "Contains added emulsifier salts",
      "Unpasteurized mountain milk with balanced calcium-to-protein ratio and fat, melting smoothly without oil separation",
      "Contains flour"
    ],
    "optionsDe": [
      "Ist vorgekocht",
      "Enthält Schmelzsalze",
      "Rohmilch mit idealem Calcium-Kasein-Gleichgewicht; schmilzt homogen ohne Fettabsonderung",
      "Enthält Mehl"
    ],
    "correctIndex": 2,
    "explanationEn": "Ages 3-6 months with washed rind; optimal pH (5.2-5.4) allows protein strings to slide gracefully.",
    "explanationDe": "Der optimale Säure- und Fettgehalt sorgt dafür, dass das Kaseingerüst zart fließt ohne zu ölen.",
    "qEn": "Why is Raclette du Valais AOP the supreme melting cheese?",
    "qDe": "Warum schmilzt echter Walliser Raclette AOP so außergewöhnlich cremig?",
    "optEn": [
      "Is pre-melted in factory",
      "Contains added emulsifier salts",
      "Unpasteurized mountain milk with balanced calcium-to-protein ratio and fat, melting smoothly without oil separation",
      "Contains flour"
    ],
    "optDe": [
      "Ist vorgekocht",
      "Enthält Schmelzsalze",
      "Rohmilch mit idealem Calcium-Kasein-Gleichgewicht; schmilzt homogen ohne Fettabsonderung",
      "Enthält Mehl"
    ],
    "correct": 2,
    "expEn": "Ages 3-6 months with washed rind; optimal pH (5.2-5.4) allows protein strings to slide gracefully.",
    "expDe": "Der optimale Säure- und Fettgehalt sorgt dafür, dass das Kaseingerüst zart fließt ohne zu ölen."
  },
  {
    "id": "q_che_09",
    "category": "cheese",
    "questionEn": "What is Pecorino Romano made from?",
    "questionDe": "Aus welcher Milch wird echter Pecorino Romano hergestellt?",
    "optionsEn": [
      "Goat milk",
      "100% sheep milk (pecora = sheep in Italian)",
      "Cow milk",
      "Water buffalo milk"
    ],
    "optionsDe": [
      "Ziegenmilch",
      "100% Schafsmilch ('pecora' = Schaf auf Italienisch)",
      "Kuhmilch",
      "Büffelmilch"
    ],
    "correctIndex": 1,
    "explanationEn": "Dry-salted sheep curd yields sharp, pungent, savory salinity indispensable in Carbonara and Amatriciana.",
    "explanationDe": "Schafsmilch und kräftiges Trockensalzen verleihen dem Pecorino seinen pikanten, salzigen Biss.",
    "qEn": "What is Pecorino Romano made from?",
    "qDe": "Aus welcher Milch wird echter Pecorino Romano hergestellt?",
    "optEn": [
      "Goat milk",
      "100% sheep milk (pecora = sheep in Italian)",
      "Cow milk",
      "Water buffalo milk"
    ],
    "optDe": [
      "Ziegenmilch",
      "100% Schafsmilch ('pecora' = Schaf auf Italienisch)",
      "Kuhmilch",
      "Büffelmilch"
    ],
    "correct": 1,
    "expEn": "Dry-salted sheep curd yields sharp, pungent, savory salinity indispensable in Carbonara and Amatriciana.",
    "expDe": "Schafsmilch und kräftiges Trockensalzen verleihen dem Pecorino seinen pikanten, salzigen Biss."
  },
  {
    "id": "q_che_10",
    "category": "cheese",
    "questionEn": "How is French Comté AOP classified by the Juragruyère consortium?",
    "questionDe": "Wie wird französischer Comté AOP im Reifekeller beurteilt?",
    "optionsEn": [
      "Graded on a 20-point scale for rind, texture, and flavor; scores above 15 receive the green Comté Clochette band",
      "Tested by boiling",
      "Weighed on scales only",
      "Priced by color"
    ],
    "optionsDe": [
      "Auf einer 20-Punkte-Skala; Käse mit 15+ Punkten erhalten die grüne Banderole 'Comté Clochette'",
      "Wird gekocht",
      "Nur nach Gewicht",
      "Nur nach Farbe"
    ],
    "correctIndex": 0,
    "explanationEn": "Wheels scoring 12-14 points receive a brown band; flawed wheels are disqualified from the AOP label.",
    "explanationDe": "Nur Spitzenlaibe aus bester Montbéliarde-Kuhmilch mit komplexem Aroma erhalten das grüne Gütesiegel.",
    "qEn": "How is French Comté AOP classified by the Juragruyère consortium?",
    "qDe": "Wie wird französischer Comté AOP im Reifekeller beurteilt?",
    "optEn": [
      "Graded on a 20-point scale for rind, texture, and flavor; scores above 15 receive the green Comté Clochette band",
      "Tested by boiling",
      "Weighed on scales only",
      "Priced by color"
    ],
    "optDe": [
      "Auf einer 20-Punkte-Skala; Käse mit 15+ Punkten erhalten die grüne Banderole 'Comté Clochette'",
      "Wird gekocht",
      "Nur nach Gewicht",
      "Nur nach Farbe"
    ],
    "correct": 0,
    "expEn": "Wheels scoring 12-14 points receive a brown band; flawed wheels are disqualified from the AOP label.",
    "expDe": "Nur Spitzenlaibe aus bester Montbéliarde-Kuhmilch mit komplexem Aroma erhalten das grüne Gütesiegel."
  },
  {
    "id": "q_che_11",
    "category": "cheese",
    "questionEn": "What is the function of animal or microbial Rennet (Lab) in cheese making?",
    "questionDe": "Welche Funktion hat Lab (Chymosin) bei der Käseherstellung?",
    "optionsEn": [
      "Kills all bacteria",
      "Sweetens the milk",
      "Colors the curd yellow",
      "Enzymatically cleaves kappa-casein, causing milk proteins to precipitate into firm curd"
    ],
    "optionsDe": [
      "Sterilisiert die Milch",
      "Süßt die Milch",
      "Färbt den Bruch gelb",
      "Spaltet Kappa-Kasein enzymatisch, sodass die Micellen zu festem Bruch gerinnen"
    ],
    "correctIndex": 3,
    "explanationEn": "Cleaving protective hair-like kappa-casein destabilizes micelles, joining them into a solid gel net.",
    "explanationDe": "Das Enzym bricht die Schutzhülle der Kaseinteilchen auf; die Milch dickt ohne Säuerung ein.",
    "qEn": "What is the function of animal or microbial Rennet (Lab) in cheese making?",
    "qDe": "Welche Funktion hat Lab (Chymosin) bei der Käseherstellung?",
    "optEn": [
      "Kills all bacteria",
      "Sweetens the milk",
      "Colors the curd yellow",
      "Enzymatically cleaves kappa-casein, causing milk proteins to precipitate into firm curd"
    ],
    "optDe": [
      "Sterilisiert die Milch",
      "Süßt die Milch",
      "Färbt den Bruch gelb",
      "Spaltet Kappa-Kasein enzymatisch, sodass die Micellen zu festem Bruch gerinnen"
    ],
    "correct": 3,
    "expEn": "Cleaving protective hair-like kappa-casein destabilizes micelles, joining them into a solid gel net.",
    "expDe": "Das Enzym bricht die Schutzhülle der Kaseinteilchen auf; die Milch dickt ohne Säuerung ein."
  },
  {
    "id": "q_che_12",
    "category": "cheese",
    "questionEn": "What defines an authentic Dutch Gouda Noord-Hollandse BOB?",
    "questionDe": "Was zeichnet echten nordholländischen Gouda BOB aus?",
    "optionsEn": [
      "Smoked with peat",
      "Made with sheep milk in caves",
      "Made from coastal pasture cow milk, washed curd to reduce lactose, and coated with protective paraffin wax",
      "Injected with beer"
    ],
    "optionsDe": [
      "Mit Torf geräuchert",
      "Aus Schafsmilch in Höhlen",
      "Aus Weidemilch der Küstenpolder; der Bruch wird mit Wasser gewaschen, um Säure zu mildern",
      "Mit Bier geimpft"
    ],
    "correctIndex": 2,
    "explanationEn": "Washing curd flushes away excess lactose, preventing harsh sourness and fostering butterscotch sweetness.",
    "explanationDe": "Das Waschen des Bruchs senkt den Milchzucker und sorgt für den mild-karamelligen Charakter.",
    "qEn": "What defines an authentic Dutch Gouda Noord-Hollandse BOB?",
    "qDe": "Was zeichnet echten nordholländischen Gouda BOB aus?",
    "optEn": [
      "Smoked with peat",
      "Made with sheep milk in caves",
      "Made from coastal pasture cow milk, washed curd to reduce lactose, and coated with protective paraffin wax",
      "Injected with beer"
    ],
    "optDe": [
      "Mit Torf geräuchert",
      "Aus Schafsmilch in Höhlen",
      "Aus Weidemilch der Küstenpolder; der Bruch wird mit Wasser gewaschen, um Säure zu mildern",
      "Mit Bier geimpft"
    ],
    "correct": 2,
    "expEn": "Washing curd flushes away excess lactose, preventing harsh sourness and fostering butterscotch sweetness.",
    "expDe": "Das Waschen des Bruchs senkt den Milchzucker und sorgt für den mild-karamelligen Charakter."
  },
  {
    "id": "q_che_13",
    "category": "cheese",
    "questionEn": "What is Ricotta technically in the dairy lexicon?",
    "questionDe": "Was ist Ricotta aus lebensmitteltechnischer Sicht?",
    "optionsEn": [
      "A hard sheep cheese",
      "A whey cheese ('re-cooked' whey proteins albumin and globulin), not a true curd cheese",
      "Fermented butterfat",
      "A blue mold cheese"
    ],
    "optionsDe": [
      "Ein Hartkäse",
      "Ein Molkeneiweißkäse ('wiedergekochte' Albumin- und Globulinproteine der Molke)",
      "Fermentiertes Butterfett",
      "Ein Blauschimmelkäse"
    ],
    "correctIndex": 1,
    "explanationEn": "Heating leftover sweet cheese whey to 85-90°C precipitates albumin into delicate fluffy white flakes.",
    "explanationDe": "Ricotta entsteht durch Erhitzen der Restmolke; die feinen Molkenproteine gerinnen als Schaum.",
    "qEn": "What is Ricotta technically in the dairy lexicon?",
    "qDe": "Was ist Ricotta aus lebensmitteltechnischer Sicht?",
    "optEn": [
      "A hard sheep cheese",
      "A whey cheese ('re-cooked' whey proteins albumin and globulin), not a true curd cheese",
      "Fermented butterfat",
      "A blue mold cheese"
    ],
    "optDe": [
      "Ein Hartkäse",
      "Ein Molkeneiweißkäse ('wiedergekochte' Albumin- und Globulinproteine der Molke)",
      "Fermentiertes Butterfett",
      "Ein Blauschimmelkäse"
    ],
    "correct": 1,
    "expEn": "Heating leftover sweet cheese whey to 85-90°C precipitates albumin into delicate fluffy white flakes.",
    "expDe": "Ricotta entsteht durch Erhitzen der Restmolke; die feinen Molkenproteine gerinnen als Schaum."
  },
  {
    "id": "q_che_14",
    "category": "cheese",
    "questionEn": "Why does Cheddar undergo the labor-intensive 'Cheddaring' process?",
    "questionDe": "Warum durchläuft echter Cheddar das aufwendige 'Cheddaring'-Verfahren?",
    "optionsEn": [
      "Curd slabs are cut, stacked, and turned repeatedly to expel whey and stretch curd into dense fibers",
      "Curd is boiled in copper kettles",
      "Cheese is smoked over oak",
      "Wheels are soaked in wine"
    ],
    "optionsDe": [
      "Bruchblöcke werden gestapelt, gepresst und gewendet, um Molke auszutreiben und Struktur zu verdichten",
      "Bruch wird gekocht",
      "Über Eichenholz geräuchert",
      "In Wein gebadet"
    ],
    "correctIndex": 0,
    "explanationEn": "Acid buildup and warm gravity pressing fuse curd grains into a distinct crumbly-chewy melt.",
    "explanationDe": "Das Stapeln und Wenden säuert den Bruch an und schenkt traditionellem Farmhouse Cheddar seinen Biss.",
    "qEn": "Why does Cheddar undergo the labor-intensive 'Cheddaring' process?",
    "qDe": "Warum durchläuft echter Cheddar das aufwendige 'Cheddaring'-Verfahren?",
    "optEn": [
      "Curd slabs are cut, stacked, and turned repeatedly to expel whey and stretch curd into dense fibers",
      "Curd is boiled in copper kettles",
      "Cheese is smoked over oak",
      "Wheels are soaked in wine"
    ],
    "optDe": [
      "Bruchblöcke werden gestapelt, gepresst und gewendet, um Molke auszutreiben und Struktur zu verdichten",
      "Bruch wird gekocht",
      "Über Eichenholz geräuchert",
      "In Wein gebadet"
    ],
    "correct": 0,
    "expEn": "Acid buildup and warm gravity pressing fuse curd grains into a distinct crumbly-chewy melt.",
    "expDe": "Das Stapeln und Wenden säuert den Bruch an und schenkt traditionellem Farmhouse Cheddar seinen Biss."
  },
  {
    "id": "q_che_15",
    "category": "cheese",
    "questionEn": "What imparts the orange-red rind and pungent barnyard aroma to Munster or Taleggio?",
    "questionDe": "Was erzeugt die orangerote Schmiere und den kräftigen Duft bei Münster oder Taleggio?",
    "optionsEn": [
      "Synthetic red color",
      "Paprika powder dusting",
      "Carrot juice bath",
      "Brevibacterium linens (red smear bacteria) washed periodically with salt water brine"
    ],
    "optionsDe": [
      "Künstlicher Farbstoff",
      "Paprikapulver",
      "Karottensaftbad",
      "Rotschmiere-Bakterien (Brevibacterium linens), gefördert durch Waschen mit Salzlake"
    ],
    "correctIndex": 3,
    "explanationEn": "B. linens thrives in alkaline, moist salt conditions, digesting proteins into savory sulfurous aromatics.",
    "explanationDe": "Die Rotschmiere baut Eiweiß intensiv ab; der Käse duftet streng, schmeckt aber sahnig-mild.",
    "qEn": "What imparts the orange-red rind and pungent barnyard aroma to Munster or Taleggio?",
    "qDe": "Was erzeugt die orangerote Schmiere und den kräftigen Duft bei Münster oder Taleggio?",
    "optEn": [
      "Synthetic red color",
      "Paprika powder dusting",
      "Carrot juice bath",
      "Brevibacterium linens (red smear bacteria) washed periodically with salt water brine"
    ],
    "optDe": [
      "Künstlicher Farbstoff",
      "Paprikapulver",
      "Karottensaftbad",
      "Rotschmiere-Bakterien (Brevibacterium linens), gefördert durch Waschen mit Salzlake"
    ],
    "correct": 3,
    "expEn": "B. linens thrives in alkaline, moist salt conditions, digesting proteins into savory sulfurous aromatics.",
    "expDe": "Die Rotschmiere baut Eiweiß intensiv ab; der Käse duftet streng, schmeckt aber sahnig-mild."
  },
  {
    "id": "q_che_16",
    "category": "cheese",
    "questionEn": "What plant gives English Gloucester and Red Leicester cheeses their vibrant orange color?",
    "questionDe": "Welcher natürliche Pflanzenfarbstoff färbt englischen Red Leicester oder Cheddar leuchtend orange?",
    "optionsEn": [
      "Saffron",
      "Turmeric",
      "Annatto seed extract (Bixa orellana)",
      "Beetroot juice"
    ],
    "optionsDe": [
      "Safran",
      "Kurkuma",
      "Annatto-Samenextrakt (Bixa orellana)",
      "Rote-Bete-Saft"
    ],
    "correctIndex": 2,
    "explanationEn": "South American achiote tree seeds provide natural bixin carotenoids without altering flavor.",
    "explanationDe": "Annatto ist ein geschmacksneutraler Pflanzensamen aus den Tropen mit sonnengelbem Carotinoid.",
    "qEn": "What plant gives English Gloucester and Red Leicester cheeses their vibrant orange color?",
    "qDe": "Welcher natürliche Pflanzenfarbstoff färbt englischen Red Leicester oder Cheddar leuchtend orange?",
    "optEn": [
      "Saffron",
      "Turmeric",
      "Annatto seed extract (Bixa orellana)",
      "Beetroot juice"
    ],
    "optDe": [
      "Safran",
      "Kurkuma",
      "Annatto-Samenextrakt (Bixa orellana)",
      "Rote-Bete-Saft"
    ],
    "correct": 2,
    "expEn": "South American achiote tree seeds provide natural bixin carotenoids without altering flavor.",
    "expDe": "Annatto ist ein geschmacksneutraler Pflanzensamen aus den Tropen mit sonnengelbem Carotinoid."
  },
  {
    "id": "q_che_17",
    "category": "cheese",
    "questionEn": "What is the primary difference between Parmigiano Reggiano and Grana Padano?",
    "questionDe": "Was ist der Hauptunterschied zwischen Parmigiano Reggiano und Grana Padano?",
    "optionsEn": [
      "Grana Padano is made from sheep milk",
      "Parmigiano cows are fed strictly fresh grass and hay (zero silage); Grana Padano permits controlled corn silage and lysozyme",
      "Parmigiano is made in Germany",
      "Grana is never aged"
    ],
    "optionsDe": [
      "Grana Padano ist aus Schafsmilch",
      "Parmigiano-Kühe fressen ausschließlich Gras und Heu (keine Silage); Grana erlaubt Silagefutter",
      "Parmigiano kommt aus Deutschland",
      "Grana reift nie"
    ],
    "correctIndex": 1,
    "explanationEn": "Parmigiano forbids silage and preservatives; Grana Padano uses egg white lysozyme to inhibit late gas blowing.",
    "explanationDe": "Der Verzicht auf Gärfutter (Silage) ist das strikte Qualitätsgeheimnis des Parmigiano Reggiano.",
    "qEn": "What is the primary difference between Parmigiano Reggiano and Grana Padano?",
    "qDe": "Was ist der Hauptunterschied zwischen Parmigiano Reggiano und Grana Padano?",
    "optEn": [
      "Grana Padano is made from sheep milk",
      "Parmigiano cows are fed strictly fresh grass and hay (zero silage); Grana Padano permits controlled corn silage and lysozyme",
      "Parmigiano is made in Germany",
      "Grana is never aged"
    ],
    "optDe": [
      "Grana Padano ist aus Schafsmilch",
      "Parmigiano-Kühe fressen ausschließlich Gras und Heu (keine Silage); Grana erlaubt Silagefutter",
      "Parmigiano kommt aus Deutschland",
      "Grana reift nie"
    ],
    "correct": 1,
    "expEn": "Parmigiano forbids silage and preservatives; Grana Padano uses egg white lysozyme to inhibit late gas blowing.",
    "expDe": "Der Verzicht auf Gärfutter (Silage) ist das strikte Qualitätsgeheimnis des Parmigiano Reggiano."
  },
  {
    "id": "q_che_18",
    "category": "cheese",
    "questionEn": "Why should cheese be removed from the refrigerator 1 hour before serving?",
    "questionDe": "Warum sollte Käse mindestens 1 Stunde vor dem Verzehr temperiert werden?",
    "optionsEn": [
      "Chilled butterfat is hard and masks volatile aroma esters; room temp (18-20°C) softens fat and releases bouquet",
      "Cheese spoils if eaten cold",
      "To kill bacteria with air",
      "To dry out the rind"
    ],
    "optionsDe": [
      "Kaltes Milchfett ist starr und sperrt Aromen ein; bei Raumtemperatur (18–20°C) schmilzt das Bouquet auf",
      "Kalter Käse ist giftig",
      "Um Keime an der Luft zu töten",
      "Damit die Rinde austrocknet"
    ],
    "correctIndex": 0,
    "explanationEn": "Cold anesthetizes tongue receptors; ambient warmth allows lipophilic aromatic molecules to volatilize.",
    "explanationDe": "Erst bei Zimmertemperatur verflüssigen sich die Aromastoffe und entfalten ihr volles Spektrum.",
    "qEn": "Why should cheese be removed from the refrigerator 1 hour before serving?",
    "qDe": "Warum sollte Käse mindestens 1 Stunde vor dem Verzehr temperiert werden?",
    "optEn": [
      "Chilled butterfat is hard and masks volatile aroma esters; room temp (18-20°C) softens fat and releases bouquet",
      "Cheese spoils if eaten cold",
      "To kill bacteria with air",
      "To dry out the rind"
    ],
    "optDe": [
      "Kaltes Milchfett ist starr und sperrt Aromen ein; bei Raumtemperatur (18–20°C) schmilzt das Bouquet auf",
      "Kalter Käse ist giftig",
      "Um Keime an der Luft zu töten",
      "Damit die Rinde austrocknet"
    ],
    "correct": 0,
    "expEn": "Cold anesthetizes tongue receptors; ambient warmth allows lipophilic aromatic molecules to volatilize.",
    "expDe": "Erst bei Zimmertemperatur verflüssigen sich die Aromastoffe und entfalten ihr volles Spektrum."
  },
  {
    "id": "q_egg_01",
    "category": "eggs",
    "questionEn": "At what temperature does egg yolk coagulate versus egg white?",
    "questionDe": "Bei welcher Temperatur stockt Eigelb im Vergleich zu Eiklar?",
    "optionsEn": [
      "White sets at 85°C",
      "Both set at 100°C",
      "Yolk sets at 40°C",
      "White starts at 62-65°C; yolk sets firmly between 65-70°C"
    ],
    "optionsDe": [
      "Eiklar stockt erst bei 85°C",
      "Beide stocken erst bei 100°C",
      "Eigelb stockt bei 40°C",
      "Eiklar beginnt bei 62–65°C zu stocken; Eigelb bindet cremig zwischen 65–70°C"
    ],
    "correctIndex": 3,
    "explanationEn": "Ovalbumin in white begins setting lower, but yolk proteins denature completely above 68°C.",
    "explanationDe": "Eiklar gerinnt ab 62°C; Eigelb bindet zwischen 65°C und 70°C cremig für Sous-vide-Eier.",
    "qEn": "At what temperature does egg yolk coagulate versus egg white?",
    "qDe": "Bei welcher Temperatur stockt Eigelb im Vergleich zu Eiklar?",
    "optEn": [
      "White sets at 85°C",
      "Both set at 100°C",
      "Yolk sets at 40°C",
      "White starts at 62-65°C; yolk sets firmly between 65-70°C"
    ],
    "optDe": [
      "Eiklar stockt erst bei 85°C",
      "Beide stocken erst bei 100°C",
      "Eigelb stockt bei 40°C",
      "Eiklar beginnt bei 62–65°C zu stocken; Eigelb bindet cremig zwischen 65–70°C"
    ],
    "correct": 3,
    "expEn": "Ovalbumin in white begins setting lower, but yolk proteins denature completely above 68°C.",
    "expDe": "Eiklar gerinnt ab 62°C; Eigelb bindet zwischen 65°C und 70°C cremig für Sous-vide-Eier."
  },
  {
    "id": "q_egg_02",
    "category": "eggs",
    "questionEn": "What causes the green-grey ring around the yolk in hard-boiled eggs?",
    "questionDe": "Was verursacht den grün-grauen Rand um das Eigelb bei zu lange gekochten Eiern?",
    "optionsEn": [
      "Copper pollution",
      "Bacterial mold",
      "Ferrous sulfide (FeS) formed when sulfur in the white reacts with iron in the yolk",
      "Chlorine in tap water"
    ],
    "optionsDe": [
      "Kupferrückstände",
      "Schimmelbefall",
      "Eisensulfid (FeS), gebildet durch Schwefelwasserstoff aus dem Eiklar und Eisen im Eidotter",
      "Chlor im Kochwasser"
    ],
    "correctIndex": 2,
    "explanationEn": "Prolonged heat releases hydrogen sulfide from ovalbumin, which migrates inward and reacts with yolk iron.",
    "explanationDe": "Langes Kochen treibt Schwefel zum Dotter, wo er mit Eisen zu unschädlichem grauem Eisensulfid reagiert.",
    "qEn": "What causes the green-grey ring around the yolk in hard-boiled eggs?",
    "qDe": "Was verursacht den grün-grauen Rand um das Eigelb bei zu lange gekochten Eiern?",
    "optEn": [
      "Copper pollution",
      "Bacterial mold",
      "Ferrous sulfide (FeS) formed when sulfur in the white reacts with iron in the yolk",
      "Chlorine in tap water"
    ],
    "optDe": [
      "Kupferrückstände",
      "Schimmelbefall",
      "Eisensulfid (FeS), gebildet durch Schwefelwasserstoff aus dem Eiklar und Eisen im Eidotter",
      "Chlor im Kochwasser"
    ],
    "correct": 2,
    "expEn": "Prolonged heat releases hydrogen sulfide from ovalbumin, which migrates inward and reacts with yolk iron.",
    "expDe": "Langes Kochen treibt Schwefel zum Dotter, wo er mit Eisen zu unschädlichem grauem Eisensulfid reagiert."
  },
  {
    "id": "q_egg_03",
    "category": "eggs",
    "questionEn": "Why does an older egg float in a bowl of cold water?",
    "questionDe": "Warum schwimmt ein altes Ei in einem Glas kaltem Wasser oben?",
    "optionsEn": [
      "It fills with helium",
      "Water evaporates through porous shell pores and the internal air cell expands",
      "The shell becomes thicker",
      "The yolk turns into oil"
    ],
    "optionsDe": [
      "Es bildet sich Helium",
      "Wasser verdunstet durch die poröse Kalkschale und die Luftkammer vergrößert sich",
      "Die Schale wird dicker",
      "Der Dotter wird zu Öl"
    ],
    "correctIndex": 1,
    "explanationEn": "Fresh eggs have a tiny air pocket and sink; moisture loss increases buoyancy over weeks.",
    "explanationDe": "Frische Eier sinken flach zu Boden; mit zunehmendem Alter verliert das Ei Wasser und steigt auf.",
    "qEn": "Why does an older egg float in a bowl of cold water?",
    "qDe": "Warum schwimmt ein altes Ei in einem Glas kaltem Wasser oben?",
    "optEn": [
      "It fills with helium",
      "Water evaporates through porous shell pores and the internal air cell expands",
      "The shell becomes thicker",
      "The yolk turns into oil"
    ],
    "optDe": [
      "Es bildet sich Helium",
      "Wasser verdunstet durch die poröse Kalkschale und die Luftkammer vergrößert sich",
      "Die Schale wird dicker",
      "Der Dotter wird zu Öl"
    ],
    "correct": 1,
    "expEn": "Fresh eggs have a tiny air pocket and sink; moisture loss increases buoyancy over weeks.",
    "expDe": "Frische Eier sinken flach zu Boden; mit zunehmendem Alter verliert das Ei Wasser und steigt auf."
  },
  {
    "id": "q_egg_04",
    "category": "eggs",
    "questionEn": "What is the purpose of adding a splash of vinegar when poaching eggs?",
    "questionDe": "Warum gibt man einen Schuss Essig ins Wasser beim Pochieren von Eiern?",
    "optionsEn": [
      "Lowers water pH, accelerating egg white protein coagulation so it wraps neatly without dispersing",
      "Kills salmonella",
      "Bleaches the shell",
      "Adds lemon flavor"
    ],
    "optionsDe": [
      "Senkt den pH-Wert und beschleunigt das Gerinnen des Eiklars, damit es nicht zerfasert",
      "Tötet Salmonellen ab",
      "Bleicht die Eier",
      "Gibt Zitronengeschmack"
    ],
    "correctIndex": 0,
    "explanationEn": "Mild acidity neutralizes negative charges on proteins, fostering rapid firm bonding in simmering water.",
    "explanationDe": "Säure lässt die Proteine des Eiklars schlagartig fest werden, bevor sie im Wasser verwehen.",
    "qEn": "What is the purpose of adding a splash of vinegar when poaching eggs?",
    "qDe": "Warum gibt man einen Schuss Essig ins Wasser beim Pochieren von Eiern?",
    "optEn": [
      "Lowers water pH, accelerating egg white protein coagulation so it wraps neatly without dispersing",
      "Kills salmonella",
      "Bleaches the shell",
      "Adds lemon flavor"
    ],
    "optDe": [
      "Senkt den pH-Wert und beschleunigt das Gerinnen des Eiklars, damit es nicht zerfasert",
      "Tötet Salmonellen ab",
      "Bleicht die Eier",
      "Gibt Zitronengeschmack"
    ],
    "correct": 0,
    "expEn": "Mild acidity neutralizes negative charges on proteins, fostering rapid firm bonding in simmering water.",
    "expDe": "Säure lässt die Proteine des Eiklars schlagartig fest werden, bevor sie im Wasser verwehen."
  },
  {
    "id": "q_egg_05",
    "category": "eggs",
    "questionEn": "What are the Chalazae (Hagelschnüre) inside a raw egg?",
    "questionDe": "Welche Funktion haben die Hagelschnüre (Chalazae) im rohen Ei?",
    "optionsEn": [
      "Fat ligaments",
      "Embryo veins",
      "Parasites",
      "Twisted protein strands that suspend the yolk centered in the albumen"
    ],
    "optionsDe": [
      "Fettbänder",
      "Adern des Kükens",
      "Parasiten",
      "Gedrehte Eiweißstränge, die den Dotter mittig im schützenden Eiklar verankern"
    ],
    "correctIndex": 3,
    "explanationEn": "Prominent, thick chalazae indicate high egg freshness and firm albumen viscosity.",
    "explanationDe": "Ausgeprägte Hagelschnüre sind ein Qualitätsmerkmal für absolute Frische des Eies.",
    "qEn": "What are the Chalazae (Hagelschnüre) inside a raw egg?",
    "qDe": "Welche Funktion haben die Hagelschnüre (Chalazae) im rohen Ei?",
    "optEn": [
      "Fat ligaments",
      "Embryo veins",
      "Parasites",
      "Twisted protein strands that suspend the yolk centered in the albumen"
    ],
    "optDe": [
      "Fettbänder",
      "Adern des Kükens",
      "Parasiten",
      "Gedrehte Eiweißstränge, die den Dotter mittig im schützenden Eiklar verankern"
    ],
    "correct": 3,
    "expEn": "Prominent, thick chalazae indicate high egg freshness and firm albumen viscosity.",
    "expDe": "Ausgeprägte Hagelschnüre sind ein Qualitätsmerkmal für absolute Frische des Eies."
  },
  {
    "id": "q_egg_06",
    "category": "eggs",
    "questionEn": "What defines an authentic French rolled omelette?",
    "questionDe": "Was zeichnet ein klassisches französisches Omelette aus?",
    "optionsEn": [
      "Deep-fried egg pancake",
      "Crispy brown crust with cheese",
      "Pale buttery exterior without browning, rolled cylinder, creamy baveuse molten interior",
      "Baked in high oven"
    ],
    "optionsDe": [
      "Frittierter Eierkuchen",
      "Knusprig braun gebraten",
      "Goldgelb ohne Bräunung, glatte Zylinderform, innen cremig-flüssig ('baveuse')",
      "Im Ofen souffliert"
    ],
    "correctIndex": 2,
    "explanationEn": "High heat with constant vigorous stirring and cold butter folding produces a silky custard center.",
    "explanationDe": "Gleichmäßiges Rühren in schäumender Butter verhindert Bräunung und hält den Kern cremig.",
    "qEn": "What defines an authentic French rolled omelette?",
    "qDe": "Was zeichnet ein klassisches französisches Omelette aus?",
    "optEn": [
      "Deep-fried egg pancake",
      "Crispy brown crust with cheese",
      "Pale buttery exterior without browning, rolled cylinder, creamy baveuse molten interior",
      "Baked in high oven"
    ],
    "optDe": [
      "Frittierter Eierkuchen",
      "Knusprig braun gebraten",
      "Goldgelb ohne Bräunung, glatte Zylinderform, innen cremig-flüssig ('baveuse')",
      "Im Ofen souffliert"
    ],
    "correct": 2,
    "expEn": "High heat with constant vigorous stirring and cold butter folding produces a silky custard center.",
    "expDe": "Gleichmäßiges Rühren in schäumender Butter verhindert Bräunung und hält den Kern cremig."
  },
  {
    "id": "q_egg_07",
    "category": "eggs",
    "questionEn": "What does egg stamp code '0-DE-...' signify in the EU?",
    "questionDe": "Was bedeutet die Ziffer '0' auf dem EU-Ei-Erzeugerstempel (z.B. 0-DE-12345)?",
    "optionsEn": [
      "Free range (Freilandhaltung)",
      "Ecological / Organic farming (Ökologische Erzeugung / Bio)",
      "Barn housing (Bodenhaltung)",
      "Caged hens"
    ],
    "optionsDe": [
      "Freilandhaltung",
      "Ökologische Erzeugung / Bio-Haltung",
      "Bodenhaltung",
      "Käfighaltung"
    ],
    "correctIndex": 1,
    "explanationEn": "0 = Bio/Organic; 1 = Freiland/Free range; 2 = Bodenhaltung/Barn; 3 = Käfighaltung/Cage.",
    "explanationDe": "0 steht für Bio-Eier mit Auslauf und Ökofutter; 1 für Freiland; 2 für Bodenhaltung.",
    "qEn": "What does egg stamp code '0-DE-...' signify in the EU?",
    "qDe": "Was bedeutet die Ziffer '0' auf dem EU-Ei-Erzeugerstempel (z.B. 0-DE-12345)?",
    "optEn": [
      "Free range (Freilandhaltung)",
      "Ecological / Organic farming (Ökologische Erzeugung / Bio)",
      "Barn housing (Bodenhaltung)",
      "Caged hens"
    ],
    "optDe": [
      "Freilandhaltung",
      "Ökologische Erzeugung / Bio-Haltung",
      "Bodenhaltung",
      "Käfighaltung"
    ],
    "correct": 1,
    "expEn": "0 = Bio/Organic; 1 = Freiland/Free range; 2 = Bodenhaltung/Barn; 3 = Käfighaltung/Cage.",
    "expDe": "0 steht für Bio-Eier mit Auslauf und Ökofutter; 1 für Freiland; 2 für Bodenhaltung."
  },
  {
    "id": "q_egg_08",
    "category": "eggs",
    "questionEn": "Why does egg white whip into voluminous foam but fails if a drop of yolk is present?",
    "questionDe": "Warum schlägt Eiklar zu festem Eischnee, versagt aber völlig bei einem Tropfen Eigelb?",
    "optionsEn": [
      "Fats in yolk compete with albumen proteins at the air-water interface, breaking surface tension bubbles",
      "Yolk cools the bowl",
      "Yolk has too much salt",
      "Yolk absorbs air"
    ],
    "optionsDe": [
      "Fette im Eidotter stören die Proteinvernetzung an der Luft-Wasser-Grenze; Blasen kollabieren",
      "Dotter kühlt die Schüssel ab",
      "Dotter enthält zu viel Salz",
      "Dotter saugt die Luft auf"
    ],
    "correctIndex": 0,
    "explanationEn": "Lipids disrupt the hydrophobic-hydrophilic protein network required to trap air bubbles.",
    "explanationDe": "Schon Spuren von Fett verhindern, dass die Proteine ein stabiles Gerüst um Luftbläschen spannen.",
    "qEn": "Why does egg white whip into voluminous foam but fails if a drop of yolk is present?",
    "qDe": "Warum schlägt Eiklar zu festem Eischnee, versagt aber völlig bei einem Tropfen Eigelb?",
    "optEn": [
      "Fats in yolk compete with albumen proteins at the air-water interface, breaking surface tension bubbles",
      "Yolk cools the bowl",
      "Yolk has too much salt",
      "Yolk absorbs air"
    ],
    "optDe": [
      "Fette im Eidotter stören die Proteinvernetzung an der Luft-Wasser-Grenze; Blasen kollabieren",
      "Dotter kühlt die Schüssel ab",
      "Dotter enthält zu viel Salz",
      "Dotter saugt die Luft auf"
    ],
    "correct": 0,
    "expEn": "Lipids disrupt the hydrophobic-hydrophilic protein network required to trap air bubbles.",
    "expDe": "Schon Spuren von Fett verhindern, dass die Proteine ein stabiles Gerüst um Luftbläschen spannen."
  },
  {
    "id": "q_egg_09",
    "category": "eggs",
    "questionEn": "What is an Onsen Tamago in Japanese hot spring culinary tradition?",
    "questionDe": "Was ist ein traditionelles japanisches Onsen-Ei (Onsen Tamago)?",
    "optionsEn": [
      "Scrambled egg soup",
      "Boiled egg with soy sauce",
      "Raw egg over hot rice",
      "Egg slow-cooked in 65-68°C mineral waters, yielding firm silky yolk and custard-soft white"
    ],
    "optionsDe": [
      "Rühreisuppe",
      "In Sojasauce hartgekochtes Ei",
      "Rohes Ei auf Reis",
      "Bei konstanter Quelltemperatur (65–68°C) gegart: Dotter ist cremig-fest, Eiklar samtig-weich"
    ],
    "correctIndex": 3,
    "explanationEn": "Since yolk sets around 65°C and white sets fully at 80°C, low temp creates a reverse-texture egg.",
    "explanationDe": "Weil Eigelb vor dem Eiklar seine Cremigkeit bindet, ist der Dotter fester als das Eiklar.",
    "qEn": "What is an Onsen Tamago in Japanese hot spring culinary tradition?",
    "qDe": "Was ist ein traditionelles japanisches Onsen-Ei (Onsen Tamago)?",
    "optEn": [
      "Scrambled egg soup",
      "Boiled egg with soy sauce",
      "Raw egg over hot rice",
      "Egg slow-cooked in 65-68°C mineral waters, yielding firm silky yolk and custard-soft white"
    ],
    "optDe": [
      "Rühreisuppe",
      "In Sojasauce hartgekochtes Ei",
      "Rohes Ei auf Reis",
      "Bei konstanter Quelltemperatur (65–68°C) gegart: Dotter ist cremig-fest, Eiklar samtig-weich"
    ],
    "correct": 3,
    "expEn": "Since yolk sets around 65°C and white sets fully at 80°C, low temp creates a reverse-texture egg.",
    "expDe": "Weil Eigelb vor dem Eiklar seine Cremigkeit bindet, ist der Dotter fester als das Eiklar."
  },
  {
    "id": "q_egg_10",
    "category": "eggs",
    "questionEn": "What is an Egg Benedict?",
    "questionDe": "Woraus besteht ein klassisches Egg Benedict?",
    "optionsEn": [
      "Scrambled eggs with salmon",
      "Fried egg on sourdough with ketchup",
      "Toasted English muffin, Canadian bacon/ham, poached egg, and warm Hollandaise sauce",
      "Boiled egg in salad"
    ],
    "optionsDe": [
      "Rührei mit Lachs",
      "Spiegelei auf Brot mit Ketchup",
      "Getoasteter English Muffin, Schinken, pochiertes Ei und warme Sauce Hollandaise",
      "Gekochtes Ei im Salat"
    ],
    "correctIndex": 2,
    "explanationEn": "Invented in New York; the molten yolk combines with velvety butter Hollandaise.",
    "explanationDe": "Der flüssige warme Eidotter verschmilzt mit Buttersauce, Schinken und knusprigem Muffin.",
    "qEn": "What is an Egg Benedict?",
    "qDe": "Woraus besteht ein klassisches Egg Benedict?",
    "optEn": [
      "Scrambled eggs with salmon",
      "Fried egg on sourdough with ketchup",
      "Toasted English muffin, Canadian bacon/ham, poached egg, and warm Hollandaise sauce",
      "Boiled egg in salad"
    ],
    "optDe": [
      "Rührei mit Lachs",
      "Spiegelei auf Brot mit Ketchup",
      "Getoasteter English Muffin, Schinken, pochiertes Ei und warme Sauce Hollandaise",
      "Gekochtes Ei im Salat"
    ],
    "correct": 2,
    "expEn": "Invented in New York; the molten yolk combines with velvety butter Hollandaise.",
    "expDe": "Der flüssige warme Eidotter verschmilzt mit Buttersauce, Schinken und knusprigem Muffin."
  },
  {
    "id": "q_egg_11",
    "category": "eggs",
    "questionEn": "Why do scrambled eggs become watery if cooked on high heat or held on a buffet too long?",
    "questionDe": "Warum wässern Rühreier (Synerese), wenn sie zu heiß gegart oder warmgehalten werden?",
    "optionsEn": [
      "Water condenses from kitchen air",
      "Protein strands over-coagulate and contract tightly, squeezing out trapped water like a sponge",
      "Butter melts into water",
      "Salt dissolves the eggs"
    ],
    "optionsDe": [
      "Luftfeuchtigkeit kondensiert",
      "Proteine vernetzen sich zu dicht und pressen gebundenes Wasser wie ein Schwamm heraus",
      "Butter wird zu Wasser",
      "Salz löst das Ei auf"
    ],
    "correctIndex": 1,
    "explanationEn": "Syneresis occurs when tight protein matrices squeeze out liquid, leaving rubbery curds in liquid.",
    "explanationDe": "Zu starke Hitze zieht das Eiweißgitter zusammen; die eingeschlossene Flüssigkeit tritt aus.",
    "qEn": "Why do scrambled eggs become watery if cooked on high heat or held on a buffet too long?",
    "qDe": "Warum wässern Rühreier (Synerese), wenn sie zu heiß gegart oder warmgehalten werden?",
    "optEn": [
      "Water condenses from kitchen air",
      "Protein strands over-coagulate and contract tightly, squeezing out trapped water like a sponge",
      "Butter melts into water",
      "Salt dissolves the eggs"
    ],
    "optDe": [
      "Luftfeuchtigkeit kondensiert",
      "Proteine vernetzen sich zu dicht und pressen gebundenes Wasser wie ein Schwamm heraus",
      "Butter wird zu Wasser",
      "Salz löst das Ei auf"
    ],
    "correct": 1,
    "expEn": "Syneresis occurs when tight protein matrices squeeze out liquid, leaving rubbery curds in liquid.",
    "expDe": "Zu starke Hitze zieht das Eiweißgitter zusammen; die eingeschlossene Flüssigkeit tritt aus."
  },
  {
    "id": "q_egg_12",
    "category": "eggs",
    "questionEn": "What is Century Egg (Pidan) in Chinese cuisine?",
    "questionDe": "Was ist das chinesische 'Tausendjährige Ei' (Pidan)?",
    "optionsEn": [
      "Duck egg preserved in clay, ash, salt, lime, and tea for months, turning white into amber jelly and yolk dark green",
      "An egg 1000 years old",
      "Fossilized dinosaur egg",
      "Egg soaked in vinegar for a week"
    ],
    "optionsDe": [
      "In Lehm, Asche, Kalk und Salz gereiftes Entenei; Eiklar geliert bernsteinfarben, Dotter wird cremig-grün",
      "Ein 1000 Jahre altes Ei",
      "Versteinertes Vogelei",
      "In Essig eingelegtes Hühnerei"
    ],
    "correctIndex": 0,
    "explanationEn": "Alkaline curing raises pH to 9-12, breaking proteins into savory peptides without heat.",
    "explanationDe": "Durch basische Reifung denaturieren die Proteine kalt; es entstehen komplexe Umami-Noten.",
    "qEn": "What is Century Egg (Pidan) in Chinese cuisine?",
    "qDe": "Was ist das chinesische 'Tausendjährige Ei' (Pidan)?",
    "optEn": [
      "Duck egg preserved in clay, ash, salt, lime, and tea for months, turning white into amber jelly and yolk dark green",
      "An egg 1000 years old",
      "Fossilized dinosaur egg",
      "Egg soaked in vinegar for a week"
    ],
    "optDe": [
      "In Lehm, Asche, Kalk und Salz gereiftes Entenei; Eiklar geliert bernsteinfarben, Dotter wird cremig-grün",
      "Ein 1000 Jahre altes Ei",
      "Versteinertes Vogelei",
      "In Essig eingelegtes Hühnerei"
    ],
    "correct": 0,
    "expEn": "Alkaline curing raises pH to 9-12, breaking proteins into savory peptides without heat.",
    "expDe": "Durch basische Reifung denaturieren die Proteine kalt; es entstehen komplexe Umami-Noten."
  },
  {
    "id": "q_egg_13",
    "category": "eggs",
    "questionEn": "What determines the shell color of a chicken egg (white vs. brown)?",
    "questionDe": "Wodurch wird die Schalenfarbe eines Hühnereis (weiß oder braun) bestimmt?",
    "optionsEn": [
      "Feather washing",
      "The color of feed grain (corn vs. wheat)",
      "Sunlight exposure",
      "The chicken's genetic breed and earlobe color (brown pigments come from protoporphyrin)"
    ],
    "optionsDe": [
      "Reinigung der Federn",
      "Das Futter (Mais vs. Weizen)",
      "Sonnenlicht im Hühnerstall",
      "Die Genetik der Hühnerrasse (erkennbar an der Farbe der Ohrscheiben)"
    ],
    "correctIndex": 3,
    "explanationEn": "Ear lobe color correlates with pigment glands in the oviduct; feed affects only yolk hue, not shell.",
    "explanationDe": "Weiße Ohrscheiben legen meist weiße Eier; die Schalenfarbe hat keinen Einfluss auf Geschmack.",
    "qEn": "What determines the shell color of a chicken egg (white vs. brown)?",
    "qDe": "Wodurch wird die Schalenfarbe eines Hühnereis (weiß oder braun) bestimmt?",
    "optEn": [
      "Feather washing",
      "The color of feed grain (corn vs. wheat)",
      "Sunlight exposure",
      "The chicken's genetic breed and earlobe color (brown pigments come from protoporphyrin)"
    ],
    "optDe": [
      "Reinigung der Federn",
      "Das Futter (Mais vs. Weizen)",
      "Sonnenlicht im Hühnerstall",
      "Die Genetik der Hühnerrasse (erkennbar an der Farbe der Ohrscheiben)"
    ],
    "correct": 3,
    "expEn": "Ear lobe color correlates with pigment glands in the oviduct; feed affects only yolk hue, not shell.",
    "expDe": "Weiße Ohrscheiben legen meist weiße Eier; die Schalenfarbe hat keinen Einfluss auf Geschmack."
  },
  {
    "id": "q_egg_14",
    "category": "eggs",
    "questionEn": "What causes deep orange yolk color in free-range eggs?",
    "questionDe": "Was erzeugt die tief orange Dotterfarbe bei Weidehühnern?",
    "optionsEn": [
      "Chemical dyes",
      "Excess blood in yolk",
      "Carotenoids (lutein and zeaxanthin) from green grasses, marigold petals, or paprika",
      "High cholesterol content"
    ],
    "optionsDe": [
      "Künstliche Farbstoffe",
      "Blutbestandteile",
      "Carotinoide (Lutein, Zeaxanthin) aus frischem Wiesengrün, Ringelblumen oder Paprika",
      "Hoher Cholesteringehalt"
    ],
    "correctIndex": 2,
    "explanationEn": "Carotenoids are lipophilic pigments deposited directly from diet into developing yolks.",
    "explanationDe": "Hühner lagern Carotinoide aus Klee, Gras und Kräutern im fettreichen Eidotter ein.",
    "qEn": "What causes deep orange yolk color in free-range eggs?",
    "qDe": "Was erzeugt die tief orange Dotterfarbe bei Weidehühnern?",
    "optEn": [
      "Chemical dyes",
      "Excess blood in yolk",
      "Carotenoids (lutein and zeaxanthin) from green grasses, marigold petals, or paprika",
      "High cholesterol content"
    ],
    "optDe": [
      "Künstliche Farbstoffe",
      "Blutbestandteile",
      "Carotinoide (Lutein, Zeaxanthin) aus frischem Wiesengrün, Ringelblumen oder Paprika",
      "Hoher Cholesteringehalt"
    ],
    "correct": 2,
    "expEn": "Carotenoids are lipophilic pigments deposited directly from diet into developing yolks.",
    "expDe": "Hühner lagern Carotinoide aus Klee, Gras und Kräutern im fettreichen Eidotter ein."
  },
  {
    "id": "q_egg_15",
    "category": "eggs",
    "questionEn": "What is an Italian Frittata compared to a French omelette?",
    "questionDe": "Was unterscheidet eine italienische Frittata von einem französischen Omelette?",
    "optionsEn": [
      "Frittata is rolled with raw cheese",
      "Ingredients are whisked directly into eggs, cooked slowly flat in a skillet, and browned on both sides or broiled",
      "Frittata contains flour",
      "Frittata is deep-fried"
    ],
    "optionsDe": [
      "Frittata wird gerollt",
      "Zutaten werden direkt mit den Eiern verquirlt, langsam dick gestockt und gewendet oder überbacken",
      "Frittata ist ein Hefekuchen",
      "Frittata wird frittiert"
    ],
    "correctIndex": 1,
    "explanationEn": "Frittata resembles an open-faced Spanish tortilla without folding, served warm or at room temp.",
    "explanationDe": "Die Frittata wird flach gegart und in Kuchenstücke geschnitten, ideal für Buffets.",
    "qEn": "What is an Italian Frittata compared to a French omelette?",
    "qDe": "Was unterscheidet eine italienische Frittata von einem französischen Omelette?",
    "optEn": [
      "Frittata is rolled with raw cheese",
      "Ingredients are whisked directly into eggs, cooked slowly flat in a skillet, and browned on both sides or broiled",
      "Frittata contains flour",
      "Frittata is deep-fried"
    ],
    "optDe": [
      "Frittata wird gerollt",
      "Zutaten werden direkt mit den Eiern verquirlt, langsam dick gestockt und gewendet oder überbacken",
      "Frittata ist ein Hefekuchen",
      "Frittata wird frittiert"
    ],
    "correct": 1,
    "expEn": "Frittata resembles an open-faced Spanish tortilla without folding, served warm or at room temp.",
    "expDe": "Die Frittata wird flach gegart und in Kuchenstücke geschnitten, ideal für Buffets."
  },
  {
    "id": "q_egg_16",
    "category": "eggs",
    "questionEn": "What is the primary role of egg yolk in baking and pastry creams?",
    "questionDe": "Welche Funktion hat Eigelb in Cremes und Teigen in der Patisserie?",
    "optionsEn": [
      "Provides rich emulsification, silky mouthfeel, golden color, and velvety tender crumb",
      "Acts as yeast rising agent",
      "Dries out dough",
      "Adds crisp sugar crunch"
    ],
    "optionsDe": [
      "Liefert Emulgatoren (Lecithin), sahnigen Schmelz, Farbe und zarte Krumenstruktur",
      "Treibt wie Backhefe",
      "Trocknet Teige aus",
      "Macht Baiser knusprig"
    ],
    "correctIndex": 0,
    "explanationEn": "Yolk fat shortens gluten strands and binds fat-water phases in custards and brioches.",
    "explanationDe": "Fett und Lecithin machen Hefegebäck mürbe und binden Vanillesaucen samtig ab.",
    "qEn": "What is the primary role of egg yolk in baking and pastry creams?",
    "qDe": "Welche Funktion hat Eigelb in Cremes und Teigen in der Patisserie?",
    "optEn": [
      "Provides rich emulsification, silky mouthfeel, golden color, and velvety tender crumb",
      "Acts as yeast rising agent",
      "Dries out dough",
      "Adds crisp sugar crunch"
    ],
    "optDe": [
      "Liefert Emulgatoren (Lecithin), sahnigen Schmelz, Farbe und zarte Krumenstruktur",
      "Treibt wie Backhefe",
      "Trocknet Teige aus",
      "Macht Baiser knusprig"
    ],
    "correct": 0,
    "expEn": "Yolk fat shortens gluten strands and binds fat-water phases in custards and brioches.",
    "expDe": "Fett und Lecithin machen Hefegebäck mürbe und binden Vanillesaucen samtig ab."
  },
  {
    "id": "q_egg_17",
    "category": "eggs",
    "questionEn": "What is an Egg Florentine?",
    "questionDe": "Was kennzeichnet Eier Florentiner Art (Eggs Florentine)?",
    "optionsEn": [
      "Fried eggs on steak",
      "Eggs with tomato sauce",
      "Raw eggs with Parmesan",
      "Poached eggs served on a bed of buttered cooked spinach with Mornay or Hollandaise sauce"
    ],
    "optionsDe": [
      "Eier auf Rindersteak",
      "Spiegeleier mit Tomatensauce",
      "Rohe Eier mit Parmesan",
      "Pochierte Eier auf gedünstetem Blattspinat, überzogen mit Mornay- oder Hollandaisesauce"
    ],
    "correctIndex": 3,
    "explanationEn": "'Florentine' in classical French cuisine denotes dishes served with spinach.",
    "explanationDe": "In der klassischen Küche steht der Zusatz 'Florentiner Art' für Gerichte mit Spinat.",
    "qEn": "What is an Egg Florentine?",
    "qDe": "Was kennzeichnet Eier Florentiner Art (Eggs Florentine)?",
    "optEn": [
      "Fried eggs on steak",
      "Eggs with tomato sauce",
      "Raw eggs with Parmesan",
      "Poached eggs served on a bed of buttered cooked spinach with Mornay or Hollandaise sauce"
    ],
    "optDe": [
      "Eier auf Rindersteak",
      "Spiegeleier mit Tomatensauce",
      "Rohe Eier mit Parmesan",
      "Pochierte Eier auf gedünstetem Blattspinat, überzogen mit Mornay- oder Hollandaisesauce"
    ],
    "correct": 3,
    "expEn": "'Florentine' in classical French cuisine denotes dishes served with spinach.",
    "expDe": "In der klassischen Küche steht der Zusatz 'Florentiner Art' für Gerichte mit Spinat."
  },
  {
    "id": "q_egg_18",
    "category": "eggs",
    "questionEn": "Why does beating cold eggs take longer to emulsify than room-temperature eggs?",
    "questionDe": "Warum lassen sich zimmertemperierte Eier besser aufschlagen und emulgieren als kühlschrankkalte Eier?",
    "optionsEn": [
      "Warm eggs lose water",
      "Cold eggs curdle instantly",
      "Warm egg proteins have lower surface viscosity and stretch more easily, trapping micro-air bubbles",
      "Cold eggs are too sweet"
    ],
    "optionsDe": [
      "Warme Eier verlieren Wasser",
      "Kühlschrankeier gerinnen sofort",
      "Zimmertemperierte Proteine haben eine geringere Viskosität und bilden schneller elastische Schaumhäute",
      "Kälte macht Eier süß"
    ],
    "correctIndex": 2,
    "explanationEn": "Room temp (20°C) allows albumen and yolk lipids to blend and expand rapidly without curdling.",
    "explanationDe": "Bei Raumtemperatur binden Eier Emulsionen wie Mayonnaise oder Biskuitteig deutlich stabiler.",
    "qEn": "Why does beating cold eggs take longer to emulsify than room-temperature eggs?",
    "qDe": "Warum lassen sich zimmertemperierte Eier besser aufschlagen und emulgieren als kühlschrankkalte Eier?",
    "optEn": [
      "Warm eggs lose water",
      "Cold eggs curdle instantly",
      "Warm egg proteins have lower surface viscosity and stretch more easily, trapping micro-air bubbles",
      "Cold eggs are too sweet"
    ],
    "optDe": [
      "Warme Eier verlieren Wasser",
      "Kühlschrankeier gerinnen sofort",
      "Zimmertemperierte Proteine haben eine geringere Viskosität und bilden schneller elastische Schaumhäute",
      "Kälte macht Eier süß"
    ],
    "correct": 2,
    "expEn": "Room temp (20°C) allows albumen and yolk lipids to blend and expand rapidly without curdling.",
    "expDe": "Bei Raumtemperatur binden Eier Emulsionen wie Mayonnaise oder Biskuitteig deutlich stabiler."
  },
  {
    "id": "q_veg_01",
    "category": "vegetables",
    "questionEn": "What culinary compound makes Black Truffles (Tuber melanosporum) uniquely fragrant?",
    "questionDe": "Welche Duftstoffe prägen den Périgord-Schwarztruffel (Tuber melanosporum)?",
    "optionsEn": [
      "Menthol",
      "Volatile sulfur compounds like dimethyl sulfide and 2-methylbutanal",
      "Linalool",
      "Vanillin"
    ],
    "optionsDe": [
      "Menthol",
      "Flüchtige Schwefelverbindungen (Dimethylsulfid) und erdig-würzige Aldehyde",
      "Linalool",
      "Vanillin"
    ],
    "correctIndex": 1,
    "explanationEn": "Sulfur molecules evoke damp forest soil, musk, and dried mushrooms.",
    "explanationDe": "Schwefelhaltige Terpene erzeugen das typische, tief-erdige Aroma des Edelpilzes.",
    "qEn": "What culinary compound makes Black Truffles (Tuber melanosporum) uniquely fragrant?",
    "qDe": "Welche Duftstoffe prägen den Périgord-Schwarztruffel (Tuber melanosporum)?",
    "optEn": [
      "Menthol",
      "Volatile sulfur compounds like dimethyl sulfide and 2-methylbutanal",
      "Linalool",
      "Vanillin"
    ],
    "optDe": [
      "Menthol",
      "Flüchtige Schwefelverbindungen (Dimethylsulfid) und erdig-würzige Aldehyde",
      "Linalool",
      "Vanillin"
    ],
    "correct": 1,
    "expEn": "Sulfur molecules evoke damp forest soil, musk, and dried mushrooms.",
    "expDe": "Schwefelhaltige Terpene erzeugen das typische, tief-erdige Aroma des Edelpilzes."
  },
  {
    "id": "q_veg_02",
    "category": "vegetables",
    "questionEn": "Why should Chanterelle mushrooms (Pfifferlinge) never be washed in a sink of water?",
    "questionDe": "Warum sollte man frische Pfifferlinge niemals im Wasserbad waschen?",
    "optionsEn": [
      "Spongy gills soak up water like a sponge, turning rubbery and boiling in their own juice in the pan",
      "Water makes them poisonous",
      "Caps dissolve in water",
      "Color washes off completely"
    ],
    "optionsDe": [
      "Das poröse Schwammgewebe saugt Wasser auf; in der Pfanne kochen sie im Saft und werden zäh",
      "Wasser macht sie giftig",
      "Die Hüte lösen sich auf",
      "Die gelbe Farbe wäscht sich ab"
    ],
    "correctIndex": 0,
    "explanationEn": "Dry brush or trim chanterelles; wet mushrooms cannot sear properly at high frying heat.",
    "explanationDe": "Pilze nur trocken abbürsten; nasse Pilze braten nicht an, sondern dünsten zäh aus.",
    "qEn": "Why should Chanterelle mushrooms (Pfifferlinge) never be washed in a sink of water?",
    "qDe": "Warum sollte man frische Pfifferlinge niemals im Wasserbad waschen?",
    "optEn": [
      "Spongy gills soak up water like a sponge, turning rubbery and boiling in their own juice in the pan",
      "Water makes them poisonous",
      "Caps dissolve in water",
      "Color washes off completely"
    ],
    "optDe": [
      "Das poröse Schwammgewebe saugt Wasser auf; in der Pfanne kochen sie im Saft und werden zäh",
      "Wasser macht sie giftig",
      "Die Hüte lösen sich auf",
      "Die gelbe Farbe wäscht sich ab"
    ],
    "correct": 0,
    "expEn": "Dry brush or trim chanterelles; wet mushrooms cannot sear properly at high frying heat.",
    "expDe": "Pilze nur trocken abbürsten; nasse Pilze braten nicht an, sondern dünsten zäh aus."
  },
  {
    "id": "q_veg_03",
    "category": "vegetables",
    "questionEn": "What is the secret of French Caramelized Onions (Oignons caramélisés)?",
    "questionDe": "Was ist das Geheimnis für echte französische karamellisierte Zwiebeln?",
    "optionsEn": [
      "Boiling in vinegar",
      "Adding two cups of white sugar",
      "Frying at 250°C for 2 minutes",
      "Slow cooking for 45-60 minutes, allowing cell walls to break down and sugars to caramelize slowly via Maillard reactions"
    ],
    "optionsDe": [
      "Kochen in Essig",
      "Zugabe von Kristallzucker",
      "Frittieren bei 250°C",
      "Langsames Dünsten über 45–60 Minuten; zelleigene Zucker karamellisieren durch Maillard-Reaktion"
    ],
    "correctIndex": 3,
    "explanationEn": "Gentle heat concentrates natural fructose without scorching bitter sulfur compounds.",
    "explanationDe": "Langsames Rösten wandelt scharfe schweflige Zwiebelstoffe in tiefsüßes Umami um.",
    "qEn": "What is the secret of French Caramelized Onions (Oignons caramélisés)?",
    "qDe": "Was ist das Geheimnis für echte französische karamellisierte Zwiebeln?",
    "optEn": [
      "Boiling in vinegar",
      "Adding two cups of white sugar",
      "Frying at 250°C for 2 minutes",
      "Slow cooking for 45-60 minutes, allowing cell walls to break down and sugars to caramelize slowly via Maillard reactions"
    ],
    "optDe": [
      "Kochen in Essig",
      "Zugabe von Kristallzucker",
      "Frittieren bei 250°C",
      "Langsames Dünsten über 45–60 Minuten; zelleigene Zucker karamellisieren durch Maillard-Reaktion"
    ],
    "correct": 3,
    "expEn": "Gentle heat concentrates natural fructose without scorching bitter sulfur compounds.",
    "expDe": "Langsames Rösten wandelt scharfe schweflige Zwiebelstoffe in tiefsüßes Umami um."
  },
  {
    "id": "q_veg_04",
    "category": "vegetables",
    "questionEn": "Why is white asparagus (Spargel) grown buried under dark earthen mounds?",
    "questionDe": "Warum wächst weißer Stangenspargel unter aufgeschütteten Erddämmen?",
    "optionsEn": [
      "To grow faster",
      "To protect from wind",
      "Lack of sunlight prevents photosynthesis and chlorophyll formation, keeping stalks snowy white and tender",
      "To absorb fertilizer better"
    ],
    "optionsDe": [
      "Damit er schneller wächst",
      "Schutz vor Wind",
      "Lichtentzug verhindert Photosynthese und Chlorophyllbildung; die Stangen bleiben weiß und zart",
      "Um Dünger aufzunehmen"
    ],
    "correctIndex": 2,
    "explanationEn": "Exposure to daylight turns the tips violet or green, triggering bitter compound synthesis.",
    "explanationDe": "Sobald Spargelspitzen die Erde durchbrechen, färben sie sich durch Sonnenlicht violett.",
    "qEn": "Why is white asparagus (Spargel) grown buried under dark earthen mounds?",
    "qDe": "Warum wächst weißer Stangenspargel unter aufgeschütteten Erddämmen?",
    "optEn": [
      "To grow faster",
      "To protect from wind",
      "Lack of sunlight prevents photosynthesis and chlorophyll formation, keeping stalks snowy white and tender",
      "To absorb fertilizer better"
    ],
    "optDe": [
      "Damit er schneller wächst",
      "Schutz vor Wind",
      "Lichtentzug verhindert Photosynthese und Chlorophyllbildung; die Stangen bleiben weiß und zart",
      "Um Dünger aufzunehmen"
    ],
    "correct": 2,
    "expEn": "Exposure to daylight turns the tips violet or green, triggering bitter compound synthesis.",
    "expDe": "Sobald Spargelspitzen die Erde durchbrechen, färben sie sich durch Sonnenlicht violett."
  },
  {
    "id": "q_veg_05",
    "category": "vegetables",
    "questionEn": "What gives Porcini mushrooms (Steinpilze / Boletus edulis) their celebrated savory umami?",
    "questionDe": "Was verleiht getrockneten Steinpilzen (Boletus edulis) ihr intensives Umami-Aroma?",
    "optionsEn": [
      "Added MSG powder",
      "High natural concentrations of free glutamic acid and ribonucleotide guanylate",
      "Wood ash",
      "Sugar crystals"
    ],
    "optionsDe": [
      "Zugesetztes Glutamat",
      "Extrem hohe Konzentration an natürlicher freier Glutaminsäure und Guanylat",
      "Holzasche",
      "Zuckerkristalle"
    ],
    "correctIndex": 1,
    "explanationEn": "Drying concentrates glutamates exponentially, making porcini soaking water liquid gold for sauces.",
    "explanationDe": "Beim Trocknen potenziert sich die Glutaminsäure; Steinpilzwasser ist die beste Naturbouillon.",
    "qEn": "What gives Porcini mushrooms (Steinpilze / Boletus edulis) their celebrated savory umami?",
    "qDe": "Was verleiht getrockneten Steinpilzen (Boletus edulis) ihr intensives Umami-Aroma?",
    "optEn": [
      "Added MSG powder",
      "High natural concentrations of free glutamic acid and ribonucleotide guanylate",
      "Wood ash",
      "Sugar crystals"
    ],
    "optDe": [
      "Zugesetztes Glutamat",
      "Extrem hohe Konzentration an natürlicher freier Glutaminsäure und Guanylat",
      "Holzasche",
      "Zuckerkristalle"
    ],
    "correct": 1,
    "expEn": "Drying concentrates glutamates exponentially, making porcini soaking water liquid gold for sauces.",
    "expDe": "Beim Trocknen potenziert sich die Glutaminsäure; Steinpilzwasser ist die beste Naturbouillon."
  },
  {
    "id": "q_veg_06",
    "category": "vegetables",
    "questionEn": "What enzyme reaction turns garlic pungent only after crushing or slicing?",
    "questionDe": "Welche enzymatische Reaktion erzeugt die typische Knoblauchschärfe erst beim Schneiden?",
    "optionsEn": [
      "Alliin is cleaved by alliinase enzyme when plant cells rupture, generating pungent allicin",
      "Garlic absorbs air oxygen",
      "Garlic heats up from knife friction",
      "Garlic releases vinegar"
    ],
    "optionsDe": [
      "Alliin wird beim Zerstören der Zellen durch Alliinase enzymatisch in scharfes Allicin gespalten",
      "Knoblauch bindet Luftsauerstoff",
      "Messerreibung erhitzt den Knoblauch",
      "Knoblauch scheidet Essig aus"
    ],
    "correctIndex": 0,
    "explanationEn": "Intact garlic cloves are mild; cell damage triggers the defensive allicin cascade.",
    "explanationDe": "Ganze Zehen riechen kaum; erst durch Quetschen oder Schneiden entsteht stechendes Allicin.",
    "qEn": "What enzyme reaction turns garlic pungent only after crushing or slicing?",
    "qDe": "Welche enzymatische Reaktion erzeugt die typische Knoblauchschärfe erst beim Schneiden?",
    "optEn": [
      "Alliin is cleaved by alliinase enzyme when plant cells rupture, generating pungent allicin",
      "Garlic absorbs air oxygen",
      "Garlic heats up from knife friction",
      "Garlic releases vinegar"
    ],
    "optDe": [
      "Alliin wird beim Zerstören der Zellen durch Alliinase enzymatisch in scharfes Allicin gespalten",
      "Knoblauch bindet Luftsauerstoff",
      "Messerreibung erhitzt den Knoblauch",
      "Knoblauch scheidet Essig aus"
    ],
    "correct": 0,
    "expEn": "Intact garlic cloves are mild; cell damage triggers the defensive allicin cascade.",
    "expDe": "Ganze Zehen riechen kaum; erst durch Quetschen oder Schneiden entsteht stechendes Allicin."
  },
  {
    "id": "q_veg_07",
    "category": "vegetables",
    "questionEn": "Why should tomatoes never be stored below 10°C in the refrigerator?",
    "questionDe": "Warum sollten aromatische Tomaten niemals im Kühlschrank unter 10°C gelagert werden?",
    "optionsEn": [
      "Seeds germinate inside",
      "Tomatoes turn poisonous",
      "Tomatoes freeze into ice",
      "Cold permanently shuts down volatile aroma-producing enzymes and breaks down cell walls into mealy texture"
    ],
    "optionsDe": [
      "Kerne keimen im Fruchtfleisch",
      "Tomaten werden giftig",
      "Tomaten gefrieren sofort",
      "Kälte deaktiviert die Enzyme für flüchtige Aromastoffe irreversibel und macht das Fleisch mehlig"
    ],
    "correctIndex": 3,
    "explanationEn": "Chilling suppresses linalool and geranial esters; store at room temperature for maximum bouquet.",
    "explanationDe": "Kälte zerstört das Aromagerüst; Raumtemperatur bewahrt Duft und saftige Festigkeit.",
    "qEn": "Why should tomatoes never be stored below 10°C in the refrigerator?",
    "qDe": "Warum sollten aromatische Tomaten niemals im Kühlschrank unter 10°C gelagert werden?",
    "optEn": [
      "Seeds germinate inside",
      "Tomatoes turn poisonous",
      "Tomatoes freeze into ice",
      "Cold permanently shuts down volatile aroma-producing enzymes and breaks down cell walls into mealy texture"
    ],
    "optDe": [
      "Kerne keimen im Fruchtfleisch",
      "Tomaten werden giftig",
      "Tomaten gefrieren sofort",
      "Kälte deaktiviert die Enzyme für flüchtige Aromastoffe irreversibel und macht das Fleisch mehlig"
    ],
    "correct": 3,
    "expEn": "Chilling suppresses linalool and geranial esters; store at room temperature for maximum bouquet.",
    "expDe": "Kälte zerstört das Aromagerüst; Raumtemperatur bewahrt Duft und saftige Festigkeit."
  },
  {
    "id": "q_veg_08",
    "category": "vegetables",
    "questionEn": "What is Romanesco botanically and aesthetically?",
    "questionDe": "Was ist Romanesco aus botanischer Sicht?",
    "optionsEn": [
      "A genetically modified fern",
      "A cross between carrot and potato",
      "A variant of Brassica oleracea with natural fractal logarithmic spiral florets",
      "An artificially carved cabbage"
    ],
    "optionsDe": [
      "Gentechnischer Farn",
      "Kreuzung aus Möhre und Kohl",
      "Eine Blumenkohlvariante (Brassica oleracea) mit fraktaler, mathematisch perfekter Spiralstruktur",
      "Künstlich geschnitzter Kohl"
    ],
    "correctIndex": 2,
    "explanationEn": "Each bud consists of a series of smaller identical spiral cones (Fibonacci sequence).",
    "explanationDe": "Romanesco schmeckt milder und nussiger als Blumenkohl und begeistert durch seine Fraktale.",
    "qEn": "What is Romanesco botanically and aesthetically?",
    "qDe": "Was ist Romanesco aus botanischer Sicht?",
    "optEn": [
      "A genetically modified fern",
      "A cross between carrot and potato",
      "A variant of Brassica oleracea with natural fractal logarithmic spiral florets",
      "An artificially carved cabbage"
    ],
    "optDe": [
      "Gentechnischer Farn",
      "Kreuzung aus Möhre und Kohl",
      "Eine Blumenkohlvariante (Brassica oleracea) mit fraktaler, mathematisch perfekter Spiralstruktur",
      "Künstlich geschnitzter Kohl"
    ],
    "correct": 2,
    "expEn": "Each bud consists of a series of smaller identical spiral cones (Fibonacci sequence).",
    "expDe": "Romanesco schmeckt milder und nussiger als Blumenkohl und begeistert durch seine Fraktale."
  },
  {
    "id": "q_veg_09",
    "category": "vegetables",
    "questionEn": "What causes the tears when cutting raw yellow onions?",
    "questionDe": "Warum weint man beim Schneiden von Küchenzwiebeln?",
    "optionsEn": [
      "Onion dust particles",
      "Syn-propanethial-S-oxide, a volatile sulfur gas that contacts eye moisture to form mild sulfuric acid",
      "Cold vapor",
      "Acidic juice squirts"
    ],
    "optionsDe": [
      "Zwiebelstaub",
      "Syn-Propanthial-S-oxid, ein flüchtiges Gas, das mit Tränenflüssigkeit zu verdünnter Schwefelsäure reagiert",
      "Kalter Dampf",
      "Saurer Spritzsaft"
    ],
    "correctIndex": 1,
    "explanationEn": "Lachrymatory factor synthase releases volatile sulfenic acids that irritate corneal nerves.",
    "explanationDe": "Das freigesetzte Gas reizt die Nerven der Hornhaut, die reflexartig Tränenfluss anregen.",
    "qEn": "What causes the tears when cutting raw yellow onions?",
    "qDe": "Warum weint man beim Schneiden von Küchenzwiebeln?",
    "optEn": [
      "Onion dust particles",
      "Syn-propanethial-S-oxide, a volatile sulfur gas that contacts eye moisture to form mild sulfuric acid",
      "Cold vapor",
      "Acidic juice squirts"
    ],
    "optDe": [
      "Zwiebelstaub",
      "Syn-Propanthial-S-oxid, ein flüchtiges Gas, das mit Tränenflüssigkeit zu verdünnter Schwefelsäure reagiert",
      "Kalter Dampf",
      "Saurer Spritzsaft"
    ],
    "correct": 1,
    "expEn": "Lachrymatory factor synthase releases volatile sulfenic acids that irritate corneal nerves.",
    "expDe": "Das freigesetzte Gas reizt die Nerven der Hornhaut, die reflexartig Tränenfluss anregen."
  },
  {
    "id": "q_veg_10",
    "category": "vegetables",
    "questionEn": "Why is blanching green vegetables in boiling salted water and ice-shocking essential?",
    "questionDe": "Warum ist Blanchieren in Salzwasser mit anschließendem Eiswasser-Schockieren so wichtig?",
    "optionsEn": [
      "Halts heat quickly, preserving bright chlorophyll and retaining crisp cellular crunch",
      "Kills root hairs",
      "Removes all vitamins",
      "Melts the skin"
    ],
    "optionsDe": [
      "Stoppt den Garprozess sofort, fixiert leuchtendes Blattchlorophyll und bewahrt Bissfestigkeit",
      "Tötet Wurzeln",
      "Schwemmt Vitamine aus",
      "Löst die Schale auf"
    ],
    "correctIndex": 0,
    "explanationEn": "Heat denatures chlorophyllase enzymes; ice water prevents residual cooking from turning greens dull brown.",
    "explanationDe": "Der Kälteschock verhindert das Nachgaren und bewahrt die strahlend grüne Farbe von Bohnen und Erbsen.",
    "qEn": "Why is blanching green vegetables in boiling salted water and ice-shocking essential?",
    "qDe": "Warum ist Blanchieren in Salzwasser mit anschließendem Eiswasser-Schockieren so wichtig?",
    "optEn": [
      "Halts heat quickly, preserving bright chlorophyll and retaining crisp cellular crunch",
      "Kills root hairs",
      "Removes all vitamins",
      "Melts the skin"
    ],
    "optDe": [
      "Stoppt den Garprozess sofort, fixiert leuchtendes Blattchlorophyll und bewahrt Bissfestigkeit",
      "Tötet Wurzeln",
      "Schwemmt Vitamine aus",
      "Löst die Schale auf"
    ],
    "correct": 0,
    "expEn": "Heat denatures chlorophyllase enzymes; ice water prevents residual cooking from turning greens dull brown.",
    "expDe": "Der Kälteschock verhindert das Nachgaren und bewahrt die strahlend grüne Farbe von Bohnen und Erbsen."
  },
  {
    "id": "q_veg_11",
    "category": "vegetables",
    "questionEn": "What is Belgian Endive (Chicorée) forced to grow in dark cellars for?",
    "questionDe": "Warum wird Chicorée in lichtdichten Dunkelräumen gezogen?",
    "optionsEn": [
      "To stay warm",
      "To prevent leaf insects",
      "To grow faster than weeds",
      "Darkness prevents chlorophyll formation, keeping leaves pale yellow and mildly bitter rather than unpalatably harsh"
    ],
    "optionsDe": [
      "Bleibt wärmer",
      "Schutz vor Insekten",
      "Wächst schneller",
      "Lichtentzug verhindert die Bildung von Chlorophyll und extremer Bitterkeit (Lactucin)"
    ],
    "correctIndex": 3,
    "explanationEn": "Light exposure produces intense bitter sesquiterpene lactones and dark green coloring.",
    "explanationDe": "Unter Licht bildet Chicorée Bitterstoffe aus; im Dunkeln bleibt er mild und knackig.",
    "qEn": "What is Belgian Endive (Chicorée) forced to grow in dark cellars for?",
    "qDe": "Warum wird Chicorée in lichtdichten Dunkelräumen gezogen?",
    "optEn": [
      "To stay warm",
      "To prevent leaf insects",
      "To grow faster than weeds",
      "Darkness prevents chlorophyll formation, keeping leaves pale yellow and mildly bitter rather than unpalatably harsh"
    ],
    "optDe": [
      "Bleibt wärmer",
      "Schutz vor Insekten",
      "Wächst schneller",
      "Lichtentzug verhindert die Bildung von Chlorophyll und extremer Bitterkeit (Lactucin)"
    ],
    "correct": 3,
    "expEn": "Light exposure produces intense bitter sesquiterpene lactones and dark green coloring.",
    "expDe": "Unter Licht bildet Chicorée Bitterstoffe aus; im Dunkeln bleibt er mild und knackig."
  },
  {
    "id": "q_veg_12",
    "category": "vegetables",
    "questionEn": "What is the defining aroma compound in truffles that trained pigs and dogs detect?",
    "questionDe": "Welcher Duftstoff im Trüffel wird von Trüffelschweinen und Hunden gewittert?",
    "optionsEn": [
      "Caffeine",
      "Capsaicin",
      "Dimethyl sulfide and androstenol (sex pheromone mimic)",
      "Vanillin"
    ],
    "optionsDe": [
      "Koffein",
      "Capsaicin",
      "Dimethylsulfid und Androstenol (Pheromon-Äquivalent)",
      "Vanillin"
    ],
    "correctIndex": 2,
    "explanationEn": "Androstenol is chemically identical to male boar sex pheromone, driving wild pigs wild.",
    "explanationDe": "Dieser Duftstoff ähnelt dem Pheromon des Ebers, weshalb Säue instinktiv danach graben.",
    "qEn": "What is the defining aroma compound in truffles that trained pigs and dogs detect?",
    "qDe": "Welcher Duftstoff im Trüffel wird von Trüffelschweinen und Hunden gewittert?",
    "optEn": [
      "Caffeine",
      "Capsaicin",
      "Dimethyl sulfide and androstenol (sex pheromone mimic)",
      "Vanillin"
    ],
    "optDe": [
      "Koffein",
      "Capsaicin",
      "Dimethylsulfid und Androstenol (Pheromon-Äquivalent)",
      "Vanillin"
    ],
    "correct": 2,
    "expEn": "Androstenol is chemically identical to male boar sex pheromone, driving wild pigs wild.",
    "expDe": "Dieser Duftstoff ähnelt dem Pheromon des Ebers, weshalb Säue instinktiv danach graben."
  },
  {
    "id": "q_veg_13",
    "category": "vegetables",
    "questionEn": "What culinary advantage do Charlotte or Nicola waxy potatoes (festkochend) offer?",
    "questionDe": "Welchen Vorteil bieten festkochende Kartoffelsorten (z.B. Sieglinde, Nicola) in der Küche?",
    "optionsEn": [
      "Cooks in 2 minutes",
      "Higher moisture and lower amylose starch keep slices firm and uncrumbled in potato salads or gratins",
      "Turns instantly into puree",
      "Contains zero calories"
    ],
    "optionsDe": [
      "Gart in 2 Minuten",
      "Hoher Feuchtigkeits- und geringer Stärkegehalt halten Scheiben beim Kochen fest in Form",
      "Zerfällt sofort zu Brei",
      "Hat keine Kalorien"
    ],
    "correctIndex": 1,
    "explanationEn": "Waxy potatoes hold their geometry cleanly when tossed with warm vinaigrette or baked in dauphinoise.",
    "explanationDe": "Festkochende Sorten zerfallen nicht und nehmen Dressings für Kartoffelsalat perfekt auf.",
    "qEn": "What culinary advantage do Charlotte or Nicola waxy potatoes (festkochend) offer?",
    "qDe": "Welchen Vorteil bieten festkochende Kartoffelsorten (z.B. Sieglinde, Nicola) in der Küche?",
    "optEn": [
      "Cooks in 2 minutes",
      "Higher moisture and lower amylose starch keep slices firm and uncrumbled in potato salads or gratins",
      "Turns instantly into puree",
      "Contains zero calories"
    ],
    "optDe": [
      "Gart in 2 Minuten",
      "Hoher Feuchtigkeits- und geringer Stärkegehalt halten Scheiben beim Kochen fest in Form",
      "Zerfällt sofort zu Brei",
      "Hat keine Kalorien"
    ],
    "correct": 1,
    "expEn": "Waxy potatoes hold their geometry cleanly when tossed with warm vinaigrette or baked in dauphinoise.",
    "expDe": "Festkochende Sorten zerfallen nicht und nehmen Dressings für Kartoffelsalat perfekt auf."
  },
  {
    "id": "q_veg_14",
    "category": "vegetables",
    "questionEn": "Why is raw aubergine (eggplant) salted before frying?",
    "questionDe": "Warum salzt man geschnittene Auberginen traditionell vor dem Braten?",
    "optionsEn": [
      "Draws out bitter juices through osmosis and collapses spongy air pockets so it absorbs less frying oil",
      "To preserve for months",
      "To cook it raw",
      "To turn it yellow"
    ],
    "optionsDe": [
      "Zieht bitteren Saft osmotisch heraus und verdichtet das Schwammgewebe, sodass weniger Fett aufgesaugt wird",
      "Konserviert monatelang",
      "Macht sie roh essbar",
      "Färbt sie gelb"
    ],
    "correctIndex": 0,
    "explanationEn": "Collapsing intercellular air spaces prevents the vegetable from behaving like an oil sponge.",
    "explanationDe": "Salzen entzieht Wasser und verdichtet die Poren; die Aubergine brät knusprig statt fettig.",
    "qEn": "Why is raw aubergine (eggplant) salted before frying?",
    "qDe": "Warum salzt man geschnittene Auberginen traditionell vor dem Braten?",
    "optEn": [
      "Draws out bitter juices through osmosis and collapses spongy air pockets so it absorbs less frying oil",
      "To preserve for months",
      "To cook it raw",
      "To turn it yellow"
    ],
    "optDe": [
      "Zieht bitteren Saft osmotisch heraus und verdichtet das Schwammgewebe, sodass weniger Fett aufgesaugt wird",
      "Konserviert monatelang",
      "Macht sie roh essbar",
      "Färbt sie gelb"
    ],
    "correct": 0,
    "expEn": "Collapsing intercellular air spaces prevents the vegetable from behaving like an oil sponge.",
    "expDe": "Salzen entzieht Wasser und verdichtet die Poren; die Aubergine brät knusprig statt fettig."
  },
  {
    "id": "q_veg_15",
    "category": "vegetables",
    "questionEn": "What makes Morel mushrooms (Morcheln) toxic if eaten raw?",
    "questionDe": "Warum sind Speisemorcheln roh giftig und müssen gründlich erhitzt oder getrocknet werden?",
    "optionsEn": [
      "Contain heavy mercury",
      "Contain nerve venom",
      "Contain cyanide",
      "Contain hydrazine toxins (like gyromitrin) and hemolysins that destroy red blood cells, destroyed only by heat (>70°C)"
    ],
    "optionsDe": [
      "Enthalten Quecksilber",
      "Enthalten Nervengift",
      "Enthalten Blausäure",
      "Enthalten hitzelabile Gifte (Hämolysine), die rote Blutkörperchen zersetzen und erst ab 70°C zerfallen"
    ],
    "correctIndex": 3,
    "explanationEn": "Always cook morels for at least 15-20 minutes; drying and heat neutralize hemolysin toxins completely.",
    "explanationDe": "Morcheln niemals roh verzehren; erst durch ausreichendes Garen oder Trocknen werden sie bekömmlich.",
    "qEn": "What makes Morel mushrooms (Morcheln) toxic if eaten raw?",
    "qDe": "Warum sind Speisemorcheln roh giftig und müssen gründlich erhitzt oder getrocknet werden?",
    "optEn": [
      "Contain heavy mercury",
      "Contain nerve venom",
      "Contain cyanide",
      "Contain hydrazine toxins (like gyromitrin) and hemolysins that destroy red blood cells, destroyed only by heat (>70°C)"
    ],
    "optDe": [
      "Enthalten Quecksilber",
      "Enthalten Nervengift",
      "Enthalten Blausäure",
      "Enthalten hitzelabile Gifte (Hämolysine), die rote Blutkörperchen zersetzen und erst ab 70°C zerfallen"
    ],
    "correct": 3,
    "expEn": "Always cook morels for at least 15-20 minutes; drying and heat neutralize hemolysin toxins completely.",
    "expDe": "Morcheln niemals roh verzehren; erst durch ausreichendes Garen oder Trocknen werden sie bekömmlich."
  },
  {
    "id": "q_veg_16",
    "category": "vegetables",
    "questionEn": "What is Mirepoix in classical French stock making?",
    "questionDe": "Was ist ein klassisches französisches Mirepoix?",
    "optionsEn": [
      "Mushrooms, tomatoes, and leek",
      "Garlic, ginger, and chili",
      "A diced aromatic vegetable base of 2 parts onion, 1 part carrot, and 1 part celery",
      "Potatoes and peas"
    ],
    "optionsDe": [
      "Pilze, Tomaten und Lauch",
      "Knoblauch, Ingwer und Chili",
      "Röstgemüse-Basis aus 2 Teilen Zwiebeln, 1 Teil Möhren und 1 Teil Knollensellerie",
      "Kartoffeln und Erbsen"
    ],
    "correctIndex": 2,
    "explanationEn": "Gently sweated in fat, Mirepoix provides the foundational savory backbone for stocks and braises.",
    "explanationDe": "Mirepoix bildet das aromatische Fundament für Fonds, Schmorgerichte und Saucen.",
    "qEn": "What is Mirepoix in classical French stock making?",
    "qDe": "Was ist ein klassisches französisches Mirepoix?",
    "optEn": [
      "Mushrooms, tomatoes, and leek",
      "Garlic, ginger, and chili",
      "A diced aromatic vegetable base of 2 parts onion, 1 part carrot, and 1 part celery",
      "Potatoes and peas"
    ],
    "optDe": [
      "Pilze, Tomaten und Lauch",
      "Knoblauch, Ingwer und Chili",
      "Röstgemüse-Basis aus 2 Teilen Zwiebeln, 1 Teil Möhren und 1 Teil Knollensellerie",
      "Kartoffeln und Erbsen"
    ],
    "correct": 2,
    "expEn": "Gently sweated in fat, Mirepoix provides the foundational savory backbone for stocks and braises.",
    "expDe": "Mirepoix bildet das aromatische Fundament für Fonds, Schmorgerichte und Saucen."
  },
  {
    "id": "q_veg_17",
    "category": "vegetables",
    "questionEn": "Why are Jerusalem Artichokes (Topinambur) sweet yet cause digestive gas in some people?",
    "questionDe": "Warum schmecken Topinambur-Knollen süßlich, können aber Blähungen verursachen?",
    "optionsEn": [
      "Contain table sugar",
      "Rich in inulin, a prebiotic fructose polymer indigestible by human enzymes but fermented by gut bacteria",
      "Contain sulfur crystals",
      "Contain alcohol"
    ],
    "optionsDe": [
      "Enthalten Haushaltszucker",
      "Enthalten Inulin, ein Fruktose-Polysaccharid, das erst im Dickdarm von Bakterien vergoren wird",
      "Bestehen aus Schwefel",
      "Enthalten Gärungsalkohol"
    ],
    "correctIndex": 1,
    "explanationEn": "Inulin is non-glycemic and diabetic-friendly, but intestinal fermentation produces carbon dioxide gas.",
    "explanationDe": "Inulin lässt den Blutzucker nicht ansteigen, fordert aber die Darmflora durch Fermentation heraus.",
    "qEn": "Why are Jerusalem Artichokes (Topinambur) sweet yet cause digestive gas in some people?",
    "qDe": "Warum schmecken Topinambur-Knollen süßlich, können aber Blähungen verursachen?",
    "optEn": [
      "Contain table sugar",
      "Rich in inulin, a prebiotic fructose polymer indigestible by human enzymes but fermented by gut bacteria",
      "Contain sulfur crystals",
      "Contain alcohol"
    ],
    "optDe": [
      "Enthalten Haushaltszucker",
      "Enthalten Inulin, ein Fruktose-Polysaccharid, das erst im Dickdarm von Bakterien vergoren wird",
      "Bestehen aus Schwefel",
      "Enthalten Gärungsalkohol"
    ],
    "correct": 1,
    "expEn": "Inulin is non-glycemic and diabetic-friendly, but intestinal fermentation produces carbon dioxide gas.",
    "expDe": "Inulin lässt den Blutzucker nicht ansteigen, fordert aber die Darmflora durch Fermentation heraus."
  },
  {
    "id": "q_veg_18",
    "category": "vegetables",
    "questionEn": "What gives red cabbage (Rotkohl) its changing color from blue to ruby red?",
    "questionDe": "Was steuert die Farbe von Rotkohl zwischen violettblau und rubinrot?",
    "optionsEn": [
      "Anthocyanin pigments act as natural pH indicators: turning red with acid (vinegar/apple) and blue in alkaline water",
      "Iron content in pot",
      "Amount of salt",
      "Cooking time in oven"
    ],
    "optionsDe": [
      "Anthocyane wirken als natürlicher pH-Indikator: sauer (Essig/Äpfel) = rubinrot; basisch = blauviolett",
      "Eisengehalt im Kochtopf",
      "Salzmenge",
      "Garzeit im Ofen"
    ],
    "correctIndex": 0,
    "explanationEn": "Adding vinegar or tart apples shifts anthocyanins into their protonated vibrant scarlet-red state.",
    "explanationDe": "Säurezugabe zaubert das leuchtende Rot; ohne Säure kocht der Kohl stumpf blauviolett.",
    "qEn": "What gives red cabbage (Rotkohl) its changing color from blue to ruby red?",
    "qDe": "Was steuert die Farbe von Rotkohl zwischen violettblau und rubinrot?",
    "optEn": [
      "Anthocyanin pigments act as natural pH indicators: turning red with acid (vinegar/apple) and blue in alkaline water",
      "Iron content in pot",
      "Amount of salt",
      "Cooking time in oven"
    ],
    "optDe": [
      "Anthocyane wirken als natürlicher pH-Indikator: sauer (Essig/Äpfel) = rubinrot; basisch = blauviolett",
      "Eisengehalt im Kochtopf",
      "Salzmenge",
      "Garzeit im Ofen"
    ],
    "correct": 0,
    "expEn": "Adding vinegar or tart apples shifts anthocyanins into their protonated vibrant scarlet-red state.",
    "expDe": "Säurezugabe zaubert das leuchtende Rot; ohne Säure kocht der Kohl stumpf blauviolett."
  },
  {
    "id": "q_fru_01",
    "category": "fruits",
    "questionEn": "What causes a green banana or avocado to ripen rapidly in a brown paper bag with an apple?",
    "questionDe": "Warum reifen Avocados oder Bananen in einer Papiertüte zusammen mit einem Apfel schneller nach?",
    "optionsEn": [
      "Apples release carbon monoxide",
      "Paper bags heat up to 40°C",
      "Apples absorb all moisture",
      "Apples release ethylene gas (C2H4), a natural plant hormone that triggers ripening enzymes"
    ],
    "optionsDe": [
      "Äpfel strömen Kohlenmonoxid aus",
      "Papiertüten heizen sich auf 40°C auf",
      "Äpfel entziehen Feuchtigkeit",
      "Äpfel strömen Ethylen aus, ein natürliches Phytohormon, das Fruchtreife-Enzyme stimuliert"
    ],
    "correctIndex": 3,
    "explanationEn": "Climacteric fruits respond to gaseous ethylene, converting starches into sweet sugars rapidly.",
    "explanationDe": "Klimakterische Früchte reagieren auf Ethylengas und bauen Stärke in aromatischen Fruchtzucker um.",
    "qEn": "What causes a green banana or avocado to ripen rapidly in a brown paper bag with an apple?",
    "qDe": "Warum reifen Avocados oder Bananen in einer Papiertüte zusammen mit einem Apfel schneller nach?",
    "optEn": [
      "Apples release carbon monoxide",
      "Paper bags heat up to 40°C",
      "Apples absorb all moisture",
      "Apples release ethylene gas (C2H4), a natural plant hormone that triggers ripening enzymes"
    ],
    "optDe": [
      "Äpfel strömen Kohlenmonoxid aus",
      "Papiertüten heizen sich auf 40°C auf",
      "Äpfel entziehen Feuchtigkeit",
      "Äpfel strömen Ethylen aus, ein natürliches Phytohormon, das Fruchtreife-Enzyme stimuliert"
    ],
    "correct": 3,
    "expEn": "Climacteric fruits respond to gaseous ethylene, converting starches into sweet sugars rapidly.",
    "expDe": "Klimakterische Früchte reagieren auf Ethylengas und bauen Stärke in aromatischen Fruchtzucker um."
  },
  {
    "id": "q_fru_02",
    "category": "fruits",
    "questionEn": "Why does freshly squeezed lemon juice prevent sliced apples and pears from browning?",
    "questionDe": "Warum verhindert Zitronensaft das Braunwerden von geschnittenen Äpfeln?",
    "optionsEn": [
      "Sugar in lemon covers fruit",
      "Lemon juice freezes fruit cells",
      "Ascorbic acid (Vitamin C) acts as an antioxidant and citric acid lowers pH, inactivating polyphenol oxidase",
      "Lemon kills yeast"
    ],
    "optionsDe": [
      "Zucker bildet eine Schutzschicht",
      "Zitronensaft gefriert Fruchtzellen",
      "Ascorbinsäure (Vitamin C) wirkt als Antioxidans und der niedrige pH hemmt Polyphenoloxidase",
      "Zitrone tötet Hefen ab"
    ],
    "correctIndex": 2,
    "explanationEn": "Low pH below 4 and antioxidant vitamin C block enzymatic oxidation of phenolic compounds into brown melanins.",
    "explanationDe": "Zitronensäure und Vitamin C unterbinden die enzymatische Bräunung des Fruchtfleisches an der Luft.",
    "qEn": "Why does freshly squeezed lemon juice prevent sliced apples and pears from browning?",
    "qDe": "Warum verhindert Zitronensaft das Braunwerden von geschnittenen Äpfeln?",
    "optEn": [
      "Sugar in lemon covers fruit",
      "Lemon juice freezes fruit cells",
      "Ascorbic acid (Vitamin C) acts as an antioxidant and citric acid lowers pH, inactivating polyphenol oxidase",
      "Lemon kills yeast"
    ],
    "optDe": [
      "Zucker bildet eine Schutzschicht",
      "Zitronensaft gefriert Fruchtzellen",
      "Ascorbinsäure (Vitamin C) wirkt als Antioxidans und der niedrige pH hemmt Polyphenoloxidase",
      "Zitrone tötet Hefen ab"
    ],
    "correct": 2,
    "expEn": "Low pH below 4 and antioxidant vitamin C block enzymatic oxidation of phenolic compounds into brown melanins.",
    "expDe": "Zitronensäure und Vitamin C unterbinden die enzymatische Bräunung des Fruchtfleisches an der Luft."
  },
  {
    "id": "q_fru_03",
    "category": "fruits",
    "questionEn": "What enzyme in raw pineapple and kiwi prevents gelatin from setting?",
    "questionDe": "Welches Enzym in frischer Ananas und Kiwi verhindert das Gelieren von Gelatinespeisen?",
    "optionsEn": [
      "Amylase",
      "Bromelain (in pineapple) and actinidin (in kiwi) proteases, which digest gelatin collagen into liquid peptides",
      "Lipase",
      "Lactase"
    ],
    "optionsDe": [
      "Amylase",
      "Proteasen (Bromelain in Ananas, Actinidin in Kiwi) spalten die Gelatine-Kollagene enzymatisch",
      "Lipase",
      "Laktase"
    ],
    "correctIndex": 1,
    "explanationEn": "Raw bromelain chops collagen protein chains; brief boiling denatures the enzyme, allowing gelatin to set.",
    "explanationDe": "Frische Ananas zersetzt Gelatine; erst kurzes Einkochen inaktiviert das eiweißspaltende Enzym.",
    "qEn": "What enzyme in raw pineapple and kiwi prevents gelatin from setting?",
    "qDe": "Welches Enzym in frischer Ananas und Kiwi verhindert das Gelieren von Gelatinespeisen?",
    "optEn": [
      "Amylase",
      "Bromelain (in pineapple) and actinidin (in kiwi) proteases, which digest gelatin collagen into liquid peptides",
      "Lipase",
      "Lactase"
    ],
    "optDe": [
      "Amylase",
      "Proteasen (Bromelain in Ananas, Actinidin in Kiwi) spalten die Gelatine-Kollagene enzymatisch",
      "Lipase",
      "Laktase"
    ],
    "correct": 1,
    "expEn": "Raw bromelain chops collagen protein chains; brief boiling denatures the enzyme, allowing gelatin to set.",
    "expDe": "Frische Ananas zersetzt Gelatine; erst kurzes Einkochen inaktiviert das eiweißspaltende Enzym."
  },
  {
    "id": "q_fru_04",
    "category": "fruits",
    "questionEn": "What defines an authentic Sicilian Blood Orange (Arancia Rossa di Sicilia IGP)?",
    "questionDe": "Was zeichnet sizilianische Blutorangen (Arancia Rossa IGP) aus?",
    "optionsEn": [
      "Volcanic Etna terroir and extreme diurnal temperature swings trigger deep anthocyanin red pigmentation",
      "Injected with pomegranate juice",
      "Grown in dark greenhouses",
      "Dyed with beet syrup"
    ],
    "optionsDe": [
      "Temperaturwechsel am Ätna stimulieren die Synthese von rubinroten Anthocyan-Antioxidantien",
      "Mit Granatapfelsaft geimpft",
      "Im Dunkeln gezogen",
      "Mit Rote-Bete-Sirup gefärbt"
    ],
    "correctIndex": 0,
    "explanationEn": "Cold night temperatures (under 5°C) contrast with warm Sicilian days, synthesizing antioxidant anthocyanins.",
    "explanationDe": "Kalte Nächte am Fuße des Ätna aktivieren die Bildung der rubinroten, beerenartigen Pflanzenfarbstoffe.",
    "qEn": "What defines an authentic Sicilian Blood Orange (Arancia Rossa di Sicilia IGP)?",
    "qDe": "Was zeichnet sizilianische Blutorangen (Arancia Rossa IGP) aus?",
    "optEn": [
      "Volcanic Etna terroir and extreme diurnal temperature swings trigger deep anthocyanin red pigmentation",
      "Injected with pomegranate juice",
      "Grown in dark greenhouses",
      "Dyed with beet syrup"
    ],
    "optDe": [
      "Temperaturwechsel am Ätna stimulieren die Synthese von rubinroten Anthocyan-Antioxidantien",
      "Mit Granatapfelsaft geimpft",
      "Im Dunkeln gezogen",
      "Mit Rote-Bete-Sirup gefärbt"
    ],
    "correct": 0,
    "expEn": "Cold night temperatures (under 5°C) contrast with warm Sicilian days, synthesizing antioxidant anthocyanins.",
    "expDe": "Kalte Nächte am Fuße des Ätna aktivieren die Bildung der rubinroten, beerenartigen Pflanzenfarbstoffe."
  },
  {
    "id": "q_fru_05",
    "category": "fruits",
    "questionEn": "What is the difference between a Meyer Lemon and a standard Eureka lemon?",
    "questionDe": "Was unterscheidet eine Meyer-Zitrone von einer herkömmlichen Zitrone?",
    "optionsEn": [
      "Meyer lemon is spicy like pepper",
      "Meyer lemon has green pulp",
      "Meyer lemon has zero juice",
      "Meyer lemon is a natural hybrid of lemon and sweet orange/mandarin, featuring thin skin, lower acid, and floral sweetness"
    ],
    "optionsDe": [
      "Ist scharf wie Pfeffer",
      "Hat grünes Fruchtfleisch",
      "Besitzt keinen Saft",
      "Meyer-Zitrone ist eine Naturkreuzung aus Zitrone und Mandarine/Orange mit dünner Schale und floraler Milde"
    ],
    "correctIndex": 3,
    "explanationEn": "Lower acidity and fragrant bergamot-like peel make Meyer lemons beloved in fine desserts.",
    "explanationDe": "Die feine Süße und dünne Schale machen sie zum Liebling der gehobenen Patisserie.",
    "qEn": "What is the difference between a Meyer Lemon and a standard Eureka lemon?",
    "qDe": "Was unterscheidet eine Meyer-Zitrone von einer herkömmlichen Zitrone?",
    "optEn": [
      "Meyer lemon is spicy like pepper",
      "Meyer lemon has green pulp",
      "Meyer lemon has zero juice",
      "Meyer lemon is a natural hybrid of lemon and sweet orange/mandarin, featuring thin skin, lower acid, and floral sweetness"
    ],
    "optDe": [
      "Ist scharf wie Pfeffer",
      "Hat grünes Fruchtfleisch",
      "Besitzt keinen Saft",
      "Meyer-Zitrone ist eine Naturkreuzung aus Zitrone und Mandarine/Orange mit dünner Schale und floraler Milde"
    ],
    "correct": 3,
    "expEn": "Lower acidity and fragrant bergamot-like peel make Meyer lemons beloved in fine desserts.",
    "expDe": "Die feine Süße und dünne Schale machen sie zum Liebling der gehobenen Patisserie."
  },
  {
    "id": "q_fru_06",
    "category": "fruits",
    "questionEn": "What gives fresh raspberries and strawberries their mouthwatering aroma?",
    "questionDe": "Welcher Aromastoff prägt das intensive Bouquet von Wald-Himbeeren?",
    "optionsEn": [
      "Acetic acid",
      "Pure vanillin",
      "Raspberry ketone (4-(4-hydroxyphenyl)butan-2-one) and volatile esters",
      "Menthol"
    ],
    "optionsDe": [
      "Essigsäure",
      "Reines Vanillin",
      "Himbeerketon (4-(4-Hydroxyphenyl)butan-2-on) und fruchtige Ester",
      "Menthol"
    ],
    "correctIndex": 2,
    "explanationEn": "Raspberry ketone delivers signature ripe berry perfume detectable in parts-per-billion.",
    "explanationDe": "Himbeerketon und Fruchtester sorgen für das berauschende, feine Sommerbeeren-Aroma.",
    "qEn": "What gives fresh raspberries and strawberries their mouthwatering aroma?",
    "qDe": "Welcher Aromastoff prägt das intensive Bouquet von Wald-Himbeeren?",
    "optEn": [
      "Acetic acid",
      "Pure vanillin",
      "Raspberry ketone (4-(4-hydroxyphenyl)butan-2-one) and volatile esters",
      "Menthol"
    ],
    "optDe": [
      "Essigsäure",
      "Reines Vanillin",
      "Himbeerketon (4-(4-Hydroxyphenyl)butan-2-on) und fruchtige Ester",
      "Menthol"
    ],
    "correct": 2,
    "expEn": "Raspberry ketone delivers signature ripe berry perfume detectable in parts-per-billion.",
    "expDe": "Himbeerketon und Fruchtester sorgen für das berauschende, feine Sommerbeeren-Aroma."
  },
  {
    "id": "q_fru_07",
    "category": "fruits",
    "questionEn": "Why are Quinces (Quitten) almost never eaten raw in European gastronomy?",
    "questionDe": "Warum werden Quitten in der europäischen Küche fast nie roh verzehrt?",
    "optionsEn": [
      "Raw quinces are toxic",
      "Rock-hard woody stone cells, high astringent tannins, and raw bitterness soften into fragrant pink jelly only when cooked",
      "Skin is covered in poison",
      "Raw quinces taste salty"
    ],
    "optionsDe": [
      "Rohe Quitten sind giftig",
      "Steinzellen und herbe Gerbstoffe werden erst durch Kochen weich, rosarot und betörend duftend",
      "Die Schale ist giftig",
      "Rohe Quitten sind salzig"
    ],
    "correctIndex": 1,
    "explanationEn": "Gentle poaching breaks down insoluble pectins and converts leucoanthocyanins into ruby-colored jewel jelly.",
    "explanationDe": "Langes Kochen spaltet die harten Pektine und färbt das Fruchtfleisch appetitlich rubinrosa.",
    "qEn": "Why are Quinces (Quitten) almost never eaten raw in European gastronomy?",
    "qDe": "Warum werden Quitten in der europäischen Küche fast nie roh verzehrt?",
    "optEn": [
      "Raw quinces are toxic",
      "Rock-hard woody stone cells, high astringent tannins, and raw bitterness soften into fragrant pink jelly only when cooked",
      "Skin is covered in poison",
      "Raw quinces taste salty"
    ],
    "optDe": [
      "Rohe Quitten sind giftig",
      "Steinzellen und herbe Gerbstoffe werden erst durch Kochen weich, rosarot und betörend duftend",
      "Die Schale ist giftig",
      "Rohe Quitten sind salzig"
    ],
    "correct": 1,
    "expEn": "Gentle poaching breaks down insoluble pectins and converts leucoanthocyanins into ruby-colored jewel jelly.",
    "expDe": "Langes Kochen spaltet die harten Pektine und färbt das Fruchtfleisch appetitlich rubinrosa."
  },
  {
    "id": "q_fru_08",
    "category": "fruits",
    "questionEn": "What is Pectin and where is it concentrated in fruits like apples and citrus?",
    "questionDe": "Was ist Pektin und wo ist es bei Zitrusfrüchten und Äpfeln am stärksten konzentriert?",
    "optionsEn": [
      "A structural plant polysaccharide concentrated in peels, cores, and white pith (albedo), forming fruit jam gels with sugar and acid",
      "A protein found in seeds",
      "Fruit fat",
      "A type of yeast"
    ],
    "optionsDe": [
      "Ein pflanzliches Polysaccharid in Schalen, Kerngehäusen und weißem Albedo, das Gelees festigt",
      "Ein Eiweiß in Kernen",
      "Fruchteigenes Fett",
      "Ein Hefepilz"
    ],
    "correctIndex": 0,
    "explanationEn": "Pectin forms a three-dimensional gel network in the presence of 60% sugar and acid (pH ~3.2).",
    "explanationDe": "Pektin geliert Marmeladen; es sitzt vor allem im weißen Schalengewebe und Kernhaus.",
    "qEn": "What is Pectin and where is it concentrated in fruits like apples and citrus?",
    "qDe": "Was ist Pektin und wo ist es bei Zitrusfrüchten und Äpfeln am stärksten konzentriert?",
    "optEn": [
      "A structural plant polysaccharide concentrated in peels, cores, and white pith (albedo), forming fruit jam gels with sugar and acid",
      "A protein found in seeds",
      "Fruit fat",
      "A type of yeast"
    ],
    "optDe": [
      "Ein pflanzliches Polysaccharid in Schalen, Kerngehäusen und weißem Albedo, das Gelees festigt",
      "Ein Eiweiß in Kernen",
      "Fruchteigenes Fett",
      "Ein Hefepilz"
    ],
    "correct": 0,
    "expEn": "Pectin forms a three-dimensional gel network in the presence of 60% sugar and acid (pH ~3.2).",
    "expDe": "Pektin geliert Marmeladen; es sitzt vor allem im weißen Schalengewebe und Kernhaus."
  },
  {
    "id": "q_fru_09",
    "category": "fruits",
    "questionEn": "What gives Japanese Yuzu citrus fruit its culinary fame?",
    "questionDe": "Was macht die japanische Yuzu-Zitrusfrucht in der Spitzengastronomie so begehrt?",
    "optionsEn": [
      "Has purple skin",
      "It is sweet like ripe mango",
      "Contains zero seeds",
      "Complex aroma blending green mandarin, grapefruit, and floral lime with tart high-acid juice"
    ],
    "optionsDe": [
      "Ist violett",
      "Schmeckt süß wie Mango",
      "Hat keine Kerne",
      "Komplexes Bouquet aus Mandarine, Grapefruit und Bergamotte mit intensiv-aromatischer Säure"
    ],
    "correctIndex": 3,
    "explanationEn": "Yuzu rind contains rare terpene oils that elevate sashimi dressings, ponzu, and sorbets.",
    "explanationDe": "Yuzu besitzt ätherische Öle, die selbst bei sparsamster Dosierung betörend frisch duften.",
    "qEn": "What gives Japanese Yuzu citrus fruit its culinary fame?",
    "qDe": "Was macht die japanische Yuzu-Zitrusfrucht in der Spitzengastronomie so begehrt?",
    "optEn": [
      "Has purple skin",
      "It is sweet like ripe mango",
      "Contains zero seeds",
      "Complex aroma blending green mandarin, grapefruit, and floral lime with tart high-acid juice"
    ],
    "optDe": [
      "Ist violett",
      "Schmeckt süß wie Mango",
      "Hat keine Kerne",
      "Komplexes Bouquet aus Mandarine, Grapefruit und Bergamotte mit intensiv-aromatischer Säure"
    ],
    "correct": 3,
    "expEn": "Yuzu rind contains rare terpene oils that elevate sashimi dressings, ponzu, and sorbets.",
    "expDe": "Yuzu besitzt ätherische Öle, die selbst bei sparsamster Dosierung betörend frisch duften."
  },
  {
    "id": "q_fru_10",
    "category": "fruits",
    "questionEn": "What defines authentic French Marrons Glacés?",
    "questionDe": "Was sind echte französische Marrons Glacés?",
    "optionsEn": [
      "Chestnut ice cream",
      "Roasted chestnuts in butter",
      "Candied sweet chestnuts slowly poached over days in vanilla sugar syrup and glazed",
      "Chestnut puree with salt"
    ],
    "optionsDe": [
      "Kastanieneis",
      "In Butter geröstete Maroni",
      "Über Tage hinweg schonend mit Bourbon-Vanillesirup kandierte und glasierte Edelkastanien",
      "Salziges Kastanienmus"
    ],
    "correctIndex": 2,
    "explanationEn": "Days of osmotic syrup bathing replace internal water with sugar crystal velvet.",
    "explanationDe": "Das tagelange, behutsame Kandieren verleiht den Edelkastanien ihre zart schmelzende Textur.",
    "qEn": "What defines authentic French Marrons Glacés?",
    "qDe": "Was sind echte französische Marrons Glacés?",
    "optEn": [
      "Chestnut ice cream",
      "Roasted chestnuts in butter",
      "Candied sweet chestnuts slowly poached over days in vanilla sugar syrup and glazed",
      "Chestnut puree with salt"
    ],
    "optDe": [
      "Kastanieneis",
      "In Butter geröstete Maroni",
      "Über Tage hinweg schonend mit Bourbon-Vanillesirup kandierte und glasierte Edelkastanien",
      "Salziges Kastanienmus"
    ],
    "correct": 2,
    "expEn": "Days of osmotic syrup bathing replace internal water with sugar crystal velvet.",
    "expDe": "Das tagelange, behutsame Kandieren verleiht den Edelkastanien ihre zart schmelzende Textur."
  },
  {
    "id": "q_fru_11",
    "category": "fruits",
    "questionEn": "Why are Figs (Feigen) technically not single fruits botanically?",
    "questionDe": "Warum sind Feigen aus botanischer Sicht keine einfachen Einzelfrüchte?",
    "optionsEn": [
      "They are underground mushrooms",
      "They are an inverted flower inflorescence ('Syconium') containing hundreds of tiny internal fruits",
      "They are tree roots",
      "They are sea algae"
    ],
    "optionsDe": [
      "Sie sind Baumpilze",
      "Sie sind ein nach innen gestülpter Blütenstand (Syconium) mit hunderten winzigen Steinfrüchten",
      "Sie sind Wurzelknollen",
      "Sie sind Algen"
    ],
    "correctIndex": 1,
    "explanationEn": "Fig wasps pollinate internal flowers through the eye opening; each crunch is a microscopic seed fruit.",
    "explanationDe": "Die Feige ist eine Scheinblüte, in deren Innerem hunderte Miniatur-Steinfrüchte heranreifen.",
    "qEn": "Why are Figs (Feigen) technically not single fruits botanically?",
    "qDe": "Warum sind Feigen aus botanischer Sicht keine einfachen Einzelfrüchte?",
    "optEn": [
      "They are underground mushrooms",
      "They are an inverted flower inflorescence ('Syconium') containing hundreds of tiny internal fruits",
      "They are tree roots",
      "They are sea algae"
    ],
    "optDe": [
      "Sie sind Baumpilze",
      "Sie sind ein nach innen gestülpter Blütenstand (Syconium) mit hunderten winzigen Steinfrüchten",
      "Sie sind Wurzelknollen",
      "Sie sind Algen"
    ],
    "correct": 1,
    "expEn": "Fig wasps pollinate internal flowers through the eye opening; each crunch is a microscopic seed fruit.",
    "expDe": "Die Feige ist eine Scheinblüte, in deren Innerem hunderte Miniatur-Steinfrüchte heranreifen."
  },
  {
    "id": "q_fru_12",
    "category": "fruits",
    "questionEn": "What is Passion Fruit (Maracuja) praised for in confectionery?",
    "questionDe": "Was zeichnet Passionsfrucht (Maracuja) in Desserts und Sorbets aus?",
    "optionsEn": [
      "Electrifying tropical acidity and volatile sulfur-ester aromatics that cut through heavy chocolates and creams",
      "Extremely mild bland sweetness",
      "High fat content",
      "Vanilla flavor"
    ],
    "optionsDe": [
      "Elektrisierende tropische Säure und exotische Schwefelfruchtester, die schwere Cremes beleben",
      "Milde neutrale Süße",
      "Hoher Fettgehalt",
      "Vanillegeschmack"
    ],
    "correctIndex": 0,
    "explanationEn": "Maracuja provides razor-sharp citric acid and exotic aromatics to balance chocolate and caramel.",
    "explanationDe": "Die knackige Fruchtsäure der Maracuja ist der perfekte Kontrapunkt zu süßer Schokolade.",
    "qEn": "What is Passion Fruit (Maracuja) praised for in confectionery?",
    "qDe": "Was zeichnet Passionsfrucht (Maracuja) in Desserts und Sorbets aus?",
    "optEn": [
      "Electrifying tropical acidity and volatile sulfur-ester aromatics that cut through heavy chocolates and creams",
      "Extremely mild bland sweetness",
      "High fat content",
      "Vanilla flavor"
    ],
    "optDe": [
      "Elektrisierende tropische Säure und exotische Schwefelfruchtester, die schwere Cremes beleben",
      "Milde neutrale Süße",
      "Hoher Fettgehalt",
      "Vanillegeschmack"
    ],
    "correct": 0,
    "expEn": "Maracuja provides razor-sharp citric acid and exotic aromatics to balance chocolate and caramel.",
    "expDe": "Die knackige Fruchtsäure der Maracuja ist der perfekte Kontrapunkt zu süßer Schokolade."
  },
  {
    "id": "q_fru_13",
    "category": "fruits",
    "questionEn": "What distinguishes sweet cherries from sour cherries (Sauerkirschen / Morellen)?",
    "questionDe": "Was unterscheidet Sauerkirschen (Schattenmorellen) von Süßkirschen in der Küche?",
    "optionsEn": [
      "Sour cherries cannot be cooked",
      "Sour cherries have no stone",
      "Sweet cherries are yellow only",
      "Higher malic acid, lower sugar, and intense tart anthocyanin pigment, holding shape brilliantly when baked"
    ],
    "optionsDe": [
      "Sauerkirschen zerkochen sofort",
      "Sauerkirschen haben keine Steine",
      "Süßkirschen sind gelb",
      "Höherer Äpfelsäuregehalt, herbere Tannine und intensive Farbe; ideal für Kuchen und Kompott"
    ],
    "correctIndex": 3,
    "explanationEn": "Sour cherries retain fruit sharpness and deep crimson color in Black Forest Gateau (Schwarzwälder Kirschtorte).",
    "explanationDe": "Schattenmorellen behalten beim Backen Biss und belebende Säure gegen schwere Schlagsahne.",
    "qEn": "What distinguishes sweet cherries from sour cherries (Sauerkirschen / Morellen)?",
    "qDe": "Was unterscheidet Sauerkirschen (Schattenmorellen) von Süßkirschen in der Küche?",
    "optEn": [
      "Sour cherries cannot be cooked",
      "Sour cherries have no stone",
      "Sweet cherries are yellow only",
      "Higher malic acid, lower sugar, and intense tart anthocyanin pigment, holding shape brilliantly when baked"
    ],
    "optDe": [
      "Sauerkirschen zerkochen sofort",
      "Sauerkirschen haben keine Steine",
      "Süßkirschen sind gelb",
      "Höherer Äpfelsäuregehalt, herbere Tannine und intensive Farbe; ideal für Kuchen und Kompott"
    ],
    "correct": 3,
    "expEn": "Sour cherries retain fruit sharpness and deep crimson color in Black Forest Gateau (Schwarzwälder Kirschtorte).",
    "expDe": "Schattenmorellen behalten beim Backen Biss und belebende Säure gegen schwere Schlagsahne."
  },
  {
    "id": "q_fru_14",
    "category": "fruits",
    "questionEn": "What makes Mango 'Alphonso' from Ratnagiri, India the queen of mangoes?",
    "questionDe": "Warum gilt die indische Alphonso-Mango als Königin aller Mangos?",
    "optionsEn": [
      "Has five stones inside",
      "It stays green and crunchy",
      "Saffron-golden fiberless pulp with intense floral aroma, honey sweetness, and velvety texture",
      "Has bitter grapefruit flavor"
    ],
    "optionsDe": [
      "Enthält 5 Kerne",
      "Bleibt grün und hart",
      "Faserfreies, safrangelbes Fruchtfleisch mit intensivem floralem Bukett und zartem Schmelz",
      "Schmeckt bitter"
    ],
    "correctIndex": 2,
    "explanationEn": "Volatile monoterpenes and absence of stringy fibers make Alphonso the gold standard for purees and lassis.",
    "explanationDe": "Das cremig-faserfreie Fleisch und die Aromafülle sind weltweit unerreicht für Mango Lassi.",
    "qEn": "What makes Mango 'Alphonso' from Ratnagiri, India the queen of mangoes?",
    "qDe": "Warum gilt die indische Alphonso-Mango als Königin aller Mangos?",
    "optEn": [
      "Has five stones inside",
      "It stays green and crunchy",
      "Saffron-golden fiberless pulp with intense floral aroma, honey sweetness, and velvety texture",
      "Has bitter grapefruit flavor"
    ],
    "optDe": [
      "Enthält 5 Kerne",
      "Bleibt grün und hart",
      "Faserfreies, safrangelbes Fruchtfleisch mit intensivem floralem Bukett und zartem Schmelz",
      "Schmeckt bitter"
    ],
    "correct": 2,
    "expEn": "Volatile monoterpenes and absence of stringy fibers make Alphonso the gold standard for purees and lassis.",
    "expDe": "Das cremig-faserfreie Fleisch und die Aromafülle sind weltweit unerreicht für Mango Lassi."
  },
  {
    "id": "q_fru_15",
    "category": "fruits",
    "questionEn": "What compound gives Rhubarb (Rhabarber) its teeth-coating astringency?",
    "questionDe": "Welche Säure erzeugt das pelzige Gefühl auf den Zähnen beim Essen von Rhabarber?",
    "optionsEn": [
      "Citric acid only",
      "Oxalic acid, which precipitates calcium from saliva onto tooth enamel",
      "Acetic acid",
      "Lactic acid"
    ],
    "optionsDe": [
      "Reine Zitronensäure",
      "Oxalsäure, die mit Speichel-Calcium zu unlöslichem Calciumoxalat auf dem Zahnschmelz reagiert",
      "Essigsäure",
      "Milchsäure"
    ],
    "correctIndex": 1,
    "explanationEn": "Oxalic acid forms microscopic calcium oxalate crystals; peeling and cooking with dairy buffers the sensation.",
    "explanationDe": "Oxalsäure bindet Calcium; Milchprodukte oder Schälen puffern den adstringierenden Belag ab.",
    "qEn": "What compound gives Rhubarb (Rhabarber) its teeth-coating astringency?",
    "qDe": "Welche Säure erzeugt das pelzige Gefühl auf den Zähnen beim Essen von Rhabarber?",
    "optEn": [
      "Citric acid only",
      "Oxalic acid, which precipitates calcium from saliva onto tooth enamel",
      "Acetic acid",
      "Lactic acid"
    ],
    "optDe": [
      "Reine Zitronensäure",
      "Oxalsäure, die mit Speichel-Calcium zu unlöslichem Calciumoxalat auf dem Zahnschmelz reagiert",
      "Essigsäure",
      "Milchsäure"
    ],
    "correct": 1,
    "expEn": "Oxalic acid forms microscopic calcium oxalate crystals; peeling and cooking with dairy buffers the sensation.",
    "expDe": "Oxalsäure bindet Calcium; Milchprodukte oder Schälen puffern den adstringierenden Belag ab."
  },
  {
    "id": "q_fru_16",
    "category": "fruits",
    "questionEn": "What is Bergamot orange (Citrus bergamia) primarily cultivated for?",
    "questionDe": "Wofür wird die kalabrische Bergamotte (Citrus bergamia) fast ausschließlich angebaut?",
    "optionsEn": [
      "Cold-pressed aromatic peel oil for Earl Grey tea, perfumery, and liqueurs (juice is too intensely bitter/sour)",
      "Fresh fruit consumption like clementines",
      "Feeding livestock",
      "Producing sweet table wine"
    ],
    "optionsDe": [
      "Kaltgepresstes ätherisches Schalenöl für Earl Grey, Parfums und Liköre (Fruchtfleisch zu sauer-bitter)",
      "Als Tafelfrucht zum Schälen",
      "Als Tierfutter",
      "Zur Weinkelterung"
    ],
    "correctIndex": 0,
    "explanationEn": "90% of global Bergamot comes from Calabria; its peel is packed with linalyl acetate and linalool.",
    "explanationDe": "Das edle Öl aus der Schale kalabrischer Bergamotten ist weltberühmt für Earl Grey und Eau de Cologne.",
    "qEn": "What is Bergamot orange (Citrus bergamia) primarily cultivated for?",
    "qDe": "Wofür wird die kalabrische Bergamotte (Citrus bergamia) fast ausschließlich angebaut?",
    "optEn": [
      "Cold-pressed aromatic peel oil for Earl Grey tea, perfumery, and liqueurs (juice is too intensely bitter/sour)",
      "Fresh fruit consumption like clementines",
      "Feeding livestock",
      "Producing sweet table wine"
    ],
    "optDe": [
      "Kaltgepresstes ätherisches Schalenöl für Earl Grey, Parfums und Liköre (Fruchtfleisch zu sauer-bitter)",
      "Als Tafelfrucht zum Schälen",
      "Als Tierfutter",
      "Zur Weinkelterung"
    ],
    "correct": 0,
    "expEn": "90% of global Bergamot comes from Calabria; its peel is packed with linalyl acetate and linalool.",
    "expDe": "Das edle Öl aus der Schale kalabrischer Bergamotten ist weltberühmt für Earl Grey und Eau de Cologne."
  },
  {
    "id": "q_fru_17",
    "category": "fruits",
    "questionEn": "Why do Pomegranates (Granatäpfel) contain hundreds of juicy arils?",
    "questionDe": "Was isst man bei einem Granatapfel aus botanischer Sicht?",
    "optionsEn": [
      "The flower petals",
      "The bitter white spongy pith",
      "The outer woody rind",
      "The jewel-like fleshy edible seed coats (Arils), bursting with sweet-tart ruby juice"
    ],
    "optionsDe": [
      "Die Blütenblätter",
      "Das bittere weiße Schwammgewebe",
      "Die ledrige Außenschale",
      "Die saftigen Samenmäntel (Arillen), die die Kerne mit rubinrotem Fruchtsaft umhüllen"
    ],
    "correctIndex": 3,
    "explanationEn": "Pomegranate juice is rich in punicalagins, providing deep berry tartness and tannic complexity.",
    "explanationDe": "Die roten Arillen liefern knackigen Saftbissen mit feinen Gerbstoffen für Salate und Fleischglasuren.",
    "qEn": "Why do Pomegranates (Granatäpfel) contain hundreds of juicy arils?",
    "qDe": "Was isst man bei einem Granatapfel aus botanischer Sicht?",
    "optEn": [
      "The flower petals",
      "The bitter white spongy pith",
      "The outer woody rind",
      "The jewel-like fleshy edible seed coats (Arils), bursting with sweet-tart ruby juice"
    ],
    "optDe": [
      "Die Blütenblätter",
      "Das bittere weiße Schwammgewebe",
      "Die ledrige Außenschale",
      "Die saftigen Samenmäntel (Arillen), die die Kerne mit rubinrotem Fruchtsaft umhüllen"
    ],
    "correct": 3,
    "expEn": "Pomegranate juice is rich in punicalagins, providing deep berry tartness and tannic complexity.",
    "expDe": "Die roten Arillen liefern knackigen Saftbissen mit feinen Gerbstoffen für Salate und Fleischglasuren."
  },
  {
    "id": "q_fru_18",
    "category": "fruits",
    "questionEn": "What is the botanical difference between wild blueberries (Waldheidelbeeren) and cultivated blueberries (Kulturheidelbeeren)?",
    "questionDe": "Was unterscheidet echte Waldheidelbeeren von Kulturheidelbeeren?",
    "optionsEn": [
      "Wild berries grow on palm trees",
      "Cultivated berries are bitter",
      "Wild berries are dark purple through and through with red staining juice; cultivated berries have pale translucent white flesh",
      "Cultivated berries have thorns"
    ],
    "optionsDe": [
      "Waldbeeren wachsen auf Palmen",
      "Kulturheidelbeeren sind bitter",
      "Waldheidelbeeren sind durchgefärbt blau mit färbendem Saft; Kulturheidelbeeren haben weißes Fruchtfleisch",
      "Kulturbeeren haben Dornen"
    ],
    "correctIndex": 2,
    "explanationEn": "Wild Vaccinium myrtillus contains anthocyanins in the flesh; cultivated Vaccinium corymbosum only in the skin.",
    "explanationDe": "Echte Waldheidelbeeren färben Zunge und Zähne tiefblau, Kulturheidelbeeren sind innen hell.",
    "qEn": "What is the botanical difference between wild blueberries (Waldheidelbeeren) and cultivated blueberries (Kulturheidelbeeren)?",
    "qDe": "Was unterscheidet echte Waldheidelbeeren von Kulturheidelbeeren?",
    "optEn": [
      "Wild berries grow on palm trees",
      "Cultivated berries are bitter",
      "Wild berries are dark purple through and through with red staining juice; cultivated berries have pale translucent white flesh",
      "Cultivated berries have thorns"
    ],
    "optDe": [
      "Waldbeeren wachsen auf Palmen",
      "Kulturheidelbeeren sind bitter",
      "Waldheidelbeeren sind durchgefärbt blau mit färbendem Saft; Kulturheidelbeeren haben weißes Fruchtfleisch",
      "Kulturbeeren haben Dornen"
    ],
    "correct": 2,
    "expEn": "Wild Vaccinium myrtillus contains anthocyanins in the flesh; cultivated Vaccinium corymbosum only in the skin.",
    "expDe": "Echte Waldheidelbeeren färben Zunge und Zähne tiefblau, Kulturheidelbeeren sind innen hell."
  },
  {
    "id": "q_nut_01",
    "category": "nuts",
    "questionEn": "What makes Pistacchio Verde di Bronte DOP from Sicily world-renowned?",
    "questionDe": "Was macht die grüne Pistazie aus Bronte DOP (Sizilien) weltberühmt?",
    "optionsEn": [
      "Dyed with spinach",
      "Grown on volcanic lava slopes of Mount Etna, hand-harvested biennially, with emerald green color and intense sweet resinous aroma",
      "Grown under water",
      "Naturally salted on tree"
    ],
    "optionsDe": [
      "Wird mit Spinat gefärbt",
      "Wächst auf erkalteter Ätna-Lava, wird nur alle 2 Jahre geerntet und besitzt smaragdgrünes, harzig-süßes Aroma",
      "Wächst unter Wasser",
      "Ist von Natur aus gesalzen"
    ],
    "correctIndex": 1,
    "explanationEn": "Volcanic minerals and biennial harvesting concentrate aroma and chlorophyll into vibrant green gems.",
    "explanationDe": "Die sizilianische Vulkanerde schenkt der Pistazie ihre unvergleichliche Farbe und aromatische Tiefe.",
    "qEn": "What makes Pistacchio Verde di Bronte DOP from Sicily world-renowned?",
    "qDe": "Was macht die grüne Pistazie aus Bronte DOP (Sizilien) weltberühmt?",
    "optEn": [
      "Dyed with spinach",
      "Grown on volcanic lava slopes of Mount Etna, hand-harvested biennially, with emerald green color and intense sweet resinous aroma",
      "Grown under water",
      "Naturally salted on tree"
    ],
    "optDe": [
      "Wird mit Spinat gefärbt",
      "Wächst auf erkalteter Ätna-Lava, wird nur alle 2 Jahre geerntet und besitzt smaragdgrünes, harzig-süßes Aroma",
      "Wächst unter Wasser",
      "Ist von Natur aus gesalzen"
    ],
    "correct": 1,
    "expEn": "Volcanic minerals and biennial harvesting concentrate aroma and chlorophyll into vibrant green gems.",
    "expDe": "Die sizilianische Vulkanerde schenkt der Pistazie ihre unvergleichliche Farbe und aromatische Tiefe."
  },
  {
    "id": "q_nut_02",
    "category": "nuts",
    "questionEn": "Why must Piedmontese Hazelnuts (Nocciola del Piemonte IGP) be gently roasted?",
    "questionDe": "Warum werden Piemonteser Haselnüsse (Nocciola del Piemonte IGP) schonend geröstet?",
    "optionsEn": [
      "Roasting peels papery bitter skins and triggers Maillard reactions, releasing hazelnut pyrazines for gianduja chocolate",
      "Kills poison",
      "Makes them soft as butter",
      "Bleaches them white"
    ],
    "optionsDe": [
      "Entfernt die herbe Fruchthaut und bildet Röstpyrazine für feinstes Nougat- und Gianduja-Aroma",
      "Tötet Gift ab",
      "Macht sie weich wie Butter",
      "Färbt sie weiß"
    ],
    "correctIndex": 0,
    "explanationEn": "The spherical Tonda Gentile Trilobata hazelnut is the undisputed pinnacle for chocolate confectionery.",
    "explanationDe": "Die Tonda Gentile besitzt nach dem Rösten den vollkommensten Schmelz für Nusscremes und Pralinen.",
    "qEn": "Why must Piedmontese Hazelnuts (Nocciola del Piemonte IGP) be gently roasted?",
    "qDe": "Warum werden Piemonteser Haselnüsse (Nocciola del Piemonte IGP) schonend geröstet?",
    "optEn": [
      "Roasting peels papery bitter skins and triggers Maillard reactions, releasing hazelnut pyrazines for gianduja chocolate",
      "Kills poison",
      "Makes them soft as butter",
      "Bleaches them white"
    ],
    "optDe": [
      "Entfernt die herbe Fruchthaut und bildet Röstpyrazine für feinstes Nougat- und Gianduja-Aroma",
      "Tötet Gift ab",
      "Macht sie weich wie Butter",
      "Färbt sie weiß"
    ],
    "correct": 0,
    "expEn": "The spherical Tonda Gentile Trilobata hazelnut is the undisputed pinnacle for chocolate confectionery.",
    "expDe": "Die Tonda Gentile besitzt nach dem Rösten den vollkommensten Schmelz für Nusscremes und Pralinen."
  },
  {
    "id": "q_nut_03",
    "category": "nuts",
    "questionEn": "What is the toxic compound in raw Bitter Almonds that is absent in sweet almonds?",
    "questionDe": "Welcher Giftstoff steckt in rohen Bittermandeln im Gegensatz zu süßen Mandeln?",
    "optionsEn": [
      "Strychnine",
      "Arsenic",
      "Mercury",
      "Amygdalin, which breaks down into deadly hydrogen cyanide (HCN) and benzaldehyde when crushed"
    ],
    "optionsDe": [
      "Strychnin",
      "Arsen",
      "Quecksilber",
      "Amygdalin, das bei Kontakt mit Speichel hochgiftige Blausäure (HCN) freisetzt"
    ],
    "correctIndex": 3,
    "explanationEn": "As few as 5-10 raw bitter almonds can be fatal to children; heat or distillation safely strips toxicity.",
    "explanationDe": "Bittermandeln dürfen nur entgiftet verwendet werden; das Spaltprodukt Benzaldehyd liefert Marzipanduft.",
    "qEn": "What is the toxic compound in raw Bitter Almonds that is absent in sweet almonds?",
    "qDe": "Welcher Giftstoff steckt in rohen Bittermandeln im Gegensatz zu süßen Mandeln?",
    "optEn": [
      "Strychnine",
      "Arsenic",
      "Mercury",
      "Amygdalin, which breaks down into deadly hydrogen cyanide (HCN) and benzaldehyde when crushed"
    ],
    "optDe": [
      "Strychnin",
      "Arsen",
      "Quecksilber",
      "Amygdalin, das bei Kontakt mit Speichel hochgiftige Blausäure (HCN) freisetzt"
    ],
    "correct": 3,
    "expEn": "As few as 5-10 raw bitter almonds can be fatal to children; heat or distillation safely strips toxicity.",
    "expDe": "Bittermandeln dürfen nur entgiftet verwendet werden; das Spaltprodukt Benzaldehyd liefert Marzipanduft."
  },
  {
    "id": "q_nut_04",
    "category": "nuts",
    "questionEn": "What is Tahini in Middle Eastern culinary science?",
    "questionDe": "Woraus besteht echtes orientalisches Tahini (Tahin)?",
    "optionsEn": [
      "Chickpea flour paste",
      "Peanut butter with lemon",
      "100% smooth ground toasted hulled sesame seeds (rich in sesamin and healthy fats)",
      "Sunflower oil paste"
    ],
    "optionsDe": [
      "Kichererbsenmehlpaste",
      "Erdnussbutter mit Zitrone",
      "Feinst vermahlene Paste aus gerösteten Sesamsamen ohne Zusätze",
      "Sonnenblumenkernpaste"
    ],
    "correctIndex": 2,
    "explanationEn": "Tahini is rich in calcium and natural emulsifiers, essential for creamy Hummus and Baba Ghanoush.",
    "explanationDe": "Sesampaste schenkt Hummus seine nussige Bindung und samtige Cremigkeit.",
    "qEn": "What is Tahini in Middle Eastern culinary science?",
    "qDe": "Woraus besteht echtes orientalisches Tahini (Tahin)?",
    "optEn": [
      "Chickpea flour paste",
      "Peanut butter with lemon",
      "100% smooth ground toasted hulled sesame seeds (rich in sesamin and healthy fats)",
      "Sunflower oil paste"
    ],
    "optDe": [
      "Kichererbsenmehlpaste",
      "Erdnussbutter mit Zitrone",
      "Feinst vermahlene Paste aus gerösteten Sesamsamen ohne Zusätze",
      "Sonnenblumenkernpaste"
    ],
    "correct": 2,
    "expEn": "Tahini is rich in calcium and natural emulsifiers, essential for creamy Hummus and Baba Ghanoush.",
    "expDe": "Sesampaste schenkt Hummus seine nussige Bindung und samtige Cremigkeit."
  },
  {
    "id": "q_nut_05",
    "category": "nuts",
    "questionEn": "Why are Walnuts (Walnüsse) prone to turning rancid quickly if stored warm?",
    "questionDe": "Warum werden Walnüsse bei warmer Lagerung so schnell ranzig?",
    "optionsEn": [
      "They have high sugar",
      "Exceptionally high in delicate polyunsaturated omega-3 alpha-linolenic fatty acids that oxidize rapidly in air",
      "Moisture dissolves nuts",
      "Salt attracts oxygen"
    ],
    "optionsDe": [
      "Haben zu viel Zucker",
      "Sehr hoher Gehalt an empfindlichen mehrfach ungesättigten Omega-3-Fettsäuren, die an der Luft oxidieren",
      "Feuchtigkeit löst sie auf",
      "Salz zieht Sauerstoff an"
    ],
    "correctIndex": 1,
    "explanationEn": "Store shelled walnuts in airtight jars in the refrigerator or freezer to prevent lipid peroxidation.",
    "explanationDe": "Das wertvolle Walnussöl oxidiert bei Wärme rasch; Lagerung im Kühlschrank schützt den nussigen Geschmack.",
    "qEn": "Why are Walnuts (Walnüsse) prone to turning rancid quickly if stored warm?",
    "qDe": "Warum werden Walnüsse bei warmer Lagerung so schnell ranzig?",
    "optEn": [
      "They have high sugar",
      "Exceptionally high in delicate polyunsaturated omega-3 alpha-linolenic fatty acids that oxidize rapidly in air",
      "Moisture dissolves nuts",
      "Salt attracts oxygen"
    ],
    "optDe": [
      "Haben zu viel Zucker",
      "Sehr hoher Gehalt an empfindlichen mehrfach ungesättigten Omega-3-Fettsäuren, die an der Luft oxidieren",
      "Feuchtigkeit löst sie auf",
      "Salz zieht Sauerstoff an"
    ],
    "correct": 1,
    "expEn": "Store shelled walnuts in airtight jars in the refrigerator or freezer to prevent lipid peroxidation.",
    "expDe": "Das wertvolle Walnussöl oxidiert bei Wärme rasch; Lagerung im Kühlschrank schützt den nussigen Geschmack."
  },
  {
    "id": "q_nut_06",
    "category": "nuts",
    "questionEn": "What is the Cashew nut botanically and why is it never sold in its raw shell?",
    "questionDe": "Was ist die Cashewnuss botanisch und warum wird sie nie in der Rohschale verkauft?",
    "optionsEn": [
      "The seed of the Cashew Apple; the shell contains caustic urushiol resin (poison ivy toxin) destroyed only by roasting",
      "A root tuber",
      "A cereal grain",
      "A sea shell"
    ],
    "optionsDe": [
      "Der Samen des Cashew-Apfels; die Schale enthält ätzendes Urushiol-Öl, das erst durch Rösten verbrennt",
      "Eine Wurzelknolle",
      "Ein Getreidekorn",
      "Eine Muschel"
    ],
    "correctIndex": 0,
    "explanationEn": "Urushiol causes severe skin chemical burns; cashews are steamed and shelled under strict safety standards.",
    "explanationDe": "Das Schalenöl ist hochgradig ätzend; erst Dämpfen und Rösten machen den milden Cashewkern genießbar.",
    "qEn": "What is the Cashew nut botanically and why is it never sold in its raw shell?",
    "qDe": "Was ist die Cashewnuss botanisch und warum wird sie nie in der Rohschale verkauft?",
    "optEn": [
      "The seed of the Cashew Apple; the shell contains caustic urushiol resin (poison ivy toxin) destroyed only by roasting",
      "A root tuber",
      "A cereal grain",
      "A sea shell"
    ],
    "optDe": [
      "Der Samen des Cashew-Apfels; die Schale enthält ätzendes Urushiol-Öl, das erst durch Rösten verbrennt",
      "Eine Wurzelknolle",
      "Ein Getreidekorn",
      "Eine Muschel"
    ],
    "correct": 0,
    "expEn": "Urushiol causes severe skin chemical burns; cashews are steamed and shelled under strict safety standards.",
    "expDe": "Das Schalenöl ist hochgradig ätzend; erst Dämpfen und Rösten machen den milden Cashewkern genießbar."
  },
  {
    "id": "q_nut_07",
    "category": "nuts",
    "questionEn": "What makes Mediterranean Pine Nuts (Pinoli) so prized compared to Siberian cedar nuts?",
    "questionDe": "Was unterscheidet echte Mittelmeer-Pinienkerne (Pinus pinea) von asiatischen Zedernüssen?",
    "optionsEn": [
      "They are dyed green",
      "They are crunchy like rocks",
      "They taste like sweet sugar",
      "Slender ivory shape, delicate creamy-resinous aroma, and absence of the metallic 'pine mouth' taste defect"
    ],
    "optionsDe": [
      "Sind grün gefärbt",
      "Sind steinhart",
      "Schmecken wie Zucker",
      "Schlanke Elfenbeinform, cremig-harziger Schmelz und kein Risiko des metallischen 'Pinienmund'-Syndroms"
    ],
    "correctIndex": 3,
    "explanationEn": "True Italian pinoli from stone pines are the heart of Pesto Genovese; cheaper cedar nuts can cause dysgeusia.",
    "explanationDe": "Pinus pinea liefert den unverfälschten Buttergeschmack für Pesto ohne metallischen Nachgeschmack.",
    "qEn": "What makes Mediterranean Pine Nuts (Pinoli) so prized compared to Siberian cedar nuts?",
    "qDe": "Was unterscheidet echte Mittelmeer-Pinienkerne (Pinus pinea) von asiatischen Zedernüssen?",
    "optEn": [
      "They are dyed green",
      "They are crunchy like rocks",
      "They taste like sweet sugar",
      "Slender ivory shape, delicate creamy-resinous aroma, and absence of the metallic 'pine mouth' taste defect"
    ],
    "optDe": [
      "Sind grün gefärbt",
      "Sind steinhart",
      "Schmecken wie Zucker",
      "Schlanke Elfenbeinform, cremig-harziger Schmelz und kein Risiko des metallischen 'Pinienmund'-Syndroms"
    ],
    "correct": 3,
    "expEn": "True Italian pinoli from stone pines are the heart of Pesto Genovese; cheaper cedar nuts can cause dysgeusia.",
    "expDe": "Pinus pinea liefert den unverfälschten Buttergeschmack für Pesto ohne metallischen Nachgeschmack."
  },
  {
    "id": "q_nut_08",
    "category": "nuts",
    "questionEn": "Why are Peanuts botanically classified as legumes rather than true tree nuts?",
    "questionDe": "Warum sind Erdnüsse botanisch Hülsenfrüchte und keine echten Nüsse?",
    "optionsEn": [
      "They are cereal seeds",
      "They grow on palm trees",
      "They grow in pods underground (Arachis hypogaea) like beans and peas, with nitrogen-fixing roots",
      "They are mushrooms"
    ],
    "optionsDe": [
      "Sie sind Getreidekörner",
      "Sie wachsen auf Palmen",
      "Sie reifen als unterirdische Hülsenfrüchte an den Wurzeln wie Erbsen und Bohnen",
      "Sie sind Pilze"
    ],
    "correctIndex": 2,
    "explanationEn": "After flowering above ground, flower stalks bend down and bury themselves to mature pods in the soil.",
    "explanationDe": "Nach der Blüte senkt sich der Trieb in die Erde, wo die Erdnuss wie eine Bohne heranreift.",
    "qEn": "Why are Peanuts botanically classified as legumes rather than true tree nuts?",
    "qDe": "Warum sind Erdnüsse botanisch Hülsenfrüchte und keine echten Nüsse?",
    "optEn": [
      "They are cereal seeds",
      "They grow on palm trees",
      "They grow in pods underground (Arachis hypogaea) like beans and peas, with nitrogen-fixing roots",
      "They are mushrooms"
    ],
    "optDe": [
      "Sie sind Getreidekörner",
      "Sie wachsen auf Palmen",
      "Sie reifen als unterirdische Hülsenfrüchte an den Wurzeln wie Erbsen und Bohnen",
      "Sie sind Pilze"
    ],
    "correct": 2,
    "expEn": "After flowering above ground, flower stalks bend down and bury themselves to mature pods in the soil.",
    "expDe": "Nach der Blüte senkt sich der Trieb in die Erde, wo die Erdnuss wie eine Bohne heranreift."
  },
  {
    "id": "q_nut_09",
    "category": "nuts",
    "questionEn": "What gives Marzipan its legally defined quality grades in Germany?",
    "questionDe": "Was bestimmt die Qualitätsstufen von echtem Lübecker Marzipan?",
    "optionsEn": [
      "Amount of flour added",
      "The ratio of pure almond paste (Marzipanrohmasse) to added sugar (max 10% sugar added for Edelmarzipan)",
      "Amount of butter added",
      "Egg white content"
    ],
    "optionsDe": [
      "Mehlzusatz",
      "Das Verhältnis von Marzipanrohmasse zu zugesetztem Zucker (Edelmarzipan: max. 30% Zuckerzusatz)",
      "Buttergehalt",
      "Eiweißanteil"
    ],
    "correctIndex": 1,
    "explanationEn": "Lübecker Marzipan has PGI protection; high almond content ensures rich, unctuous mouthfeel.",
    "explanationDe": "Viel Mandeln und wenig Zucker garantieren das edle, feuchte Marzipanerlebnis aus Lübeck.",
    "qEn": "What gives Marzipan its legally defined quality grades in Germany?",
    "qDe": "Was bestimmt die Qualitätsstufen von echtem Lübecker Marzipan?",
    "optEn": [
      "Amount of flour added",
      "The ratio of pure almond paste (Marzipanrohmasse) to added sugar (max 10% sugar added for Edelmarzipan)",
      "Amount of butter added",
      "Egg white content"
    ],
    "optDe": [
      "Mehlzusatz",
      "Das Verhältnis von Marzipanrohmasse zu zugesetztem Zucker (Edelmarzipan: max. 30% Zuckerzusatz)",
      "Buttergehalt",
      "Eiweißanteil"
    ],
    "correct": 1,
    "expEn": "Lübecker Marzipan has PGI protection; high almond content ensures rich, unctuous mouthfeel.",
    "expDe": "Viel Mandeln und wenig Zucker garantieren das edle, feuchte Marzipanerlebnis aus Lübeck."
  },
  {
    "id": "q_nut_09b",
    "category": "nuts",
    "questionEn": "What are Chia seeds valued for in culinary suspensions and puddings?",
    "questionDe": "Warum quellen Chiasamen in Flüssigkeiten zu einem geleeartigen Pudding auf?",
    "optionsEn": [
      "High soluble mucilage fiber in seed coats forms a thick hydrophilic hydrogel absorbing 10x its weight in water",
      "Starch boils instantly",
      "Gluten binds water",
      "Yeast ferments water"
    ],
    "optionsDe": [
      "Lösliche Schleimstoffe in der Samenschale bilden ein Hydrogel, das das Zehnfache an Wasser bindet",
      "Stärke quillt auf",
      "Gluten geliert",
      "Hefe fermentiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Chia gel mimics egg or fat emulsions in vegan baking and creates soothing breakfast puddings.",
    "explanationDe": "Die pflanzlichen Quellstoffe binden Flüssigkeit ohne Kochen zu samtiger Geltextur.",
    "qEn": "What are Chia seeds valued for in culinary suspensions and puddings?",
    "qDe": "Warum quellen Chiasamen in Flüssigkeiten zu einem geleeartigen Pudding auf?",
    "optEn": [
      "High soluble mucilage fiber in seed coats forms a thick hydrophilic hydrogel absorbing 10x its weight in water",
      "Starch boils instantly",
      "Gluten binds water",
      "Yeast ferments water"
    ],
    "optDe": [
      "Lösliche Schleimstoffe in der Samenschale bilden ein Hydrogel, das das Zehnfache an Wasser bindet",
      "Stärke quillt auf",
      "Gluten geliert",
      "Hefe fermentiert"
    ],
    "correct": 0,
    "expEn": "Chia gel mimics egg or fat emulsions in vegan baking and creates soothing breakfast puddings.",
    "expDe": "Die pflanzlichen Quellstoffe binden Flüssigkeit ohne Kochen zu samtiger Geltextur."
  },
  {
    "id": "q_nut_11",
    "category": "nuts",
    "questionEn": "Where does the Macadamia nut originate and why is its shell notoriously difficult to crack?",
    "questionDe": "Wo stammt die Macadamianuss her und warum ist ihre Schale so steinhart?",
    "optionsEn": [
      "Originated in Egypt",
      "Originated in Germany",
      "Originated in Alaska",
      "Indigenous to rainforests of eastern Australia; spherical dense lignified shell withstands 300 psi of pressure"
    ],
    "optionsDe": [
      "Aus Ägypten",
      "Aus Deutschland",
      "Aus Alaska",
      "Aus den Regenwäldern Ostaustraliens; die verholzte Steinschale hält über 20 bar Druck stand"
    ],
    "correctIndex": 3,
    "explanationEn": "Known as the Queen of Nuts; requires specialized tungsten steel notched crackers to release buttery kernel.",
    "explanationDe": "Die extrem harte Schale schützt die fettreichste und cremigste Nuss der Welt.",
    "qEn": "Where does the Macadamia nut originate and why is its shell notoriously difficult to crack?",
    "qDe": "Wo stammt die Macadamianuss her und warum ist ihre Schale so steinhart?",
    "optEn": [
      "Originated in Egypt",
      "Originated in Germany",
      "Originated in Alaska",
      "Indigenous to rainforests of eastern Australia; spherical dense lignified shell withstands 300 psi of pressure"
    ],
    "optDe": [
      "Aus Ägypten",
      "Aus Deutschland",
      "Aus Alaska",
      "Aus den Regenwäldern Ostaustraliens; die verholzte Steinschale hält über 20 bar Druck stand"
    ],
    "correct": 3,
    "expEn": "Known as the Queen of Nuts; requires specialized tungsten steel notched crackers to release buttery kernel.",
    "expDe": "Die extrem harte Schale schützt die fettreichste und cremigste Nuss der Welt."
  },
  {
    "id": "q_nut_12",
    "category": "nuts",
    "questionEn": "What is Gomasio in Japanese macrobiotic seasoning?",
    "questionDe": "Was ist japanisches Gomasio?",
    "optionsEn": [
      "Wasabi salt",
      "Soy sauce powder",
      "Toasted whole sesame seeds crushed with sea salt in a Suribachi mortar (approx. 10:1 ratio)",
      "Dried fish flakes"
    ],
    "optionsDe": [
      "Wasabisalz",
      "Sojasaucenpulver",
      "Im Mörser zerstoßener gerösteter Sesam vermengt mit feinem Meersalz (ca. 10:1)",
      "Fischflocken"
    ],
    "correctIndex": 2,
    "explanationEn": "Sesame oil coats salt grains, reducing required sodium while imparting deep roasty umami to rice.",
    "explanationDe": "Das Sesamöl umhüllt die Salzkörner; man salzt sparsamer und genießt nussige Röstaromen.",
    "qEn": "What is Gomasio in Japanese macrobiotic seasoning?",
    "qDe": "Was ist japanisches Gomasio?",
    "optEn": [
      "Wasabi salt",
      "Soy sauce powder",
      "Toasted whole sesame seeds crushed with sea salt in a Suribachi mortar (approx. 10:1 ratio)",
      "Dried fish flakes"
    ],
    "optDe": [
      "Wasabisalz",
      "Sojasaucenpulver",
      "Im Mörser zerstoßener gerösteter Sesam vermengt mit feinem Meersalz (ca. 10:1)",
      "Fischflocken"
    ],
    "correct": 2,
    "expEn": "Sesame oil coats salt grains, reducing required sodium while imparting deep roasty umami to rice.",
    "expDe": "Das Sesamöl umhüllt die Salzkörner; man salzt sparsamer und genießt nussige Röstaromen."
  },
  {
    "id": "q_nut_13",
    "category": "nuts",
    "questionEn": "Why are Pecans favored over walnuts in American Southern pies?",
    "questionDe": "Warum werden Pekannüsse für klassischen Pecan Pie gegenüber Walnüssen bevorzugt?",
    "optionsEn": [
      "Pecans never burn",
      "Higher fat, lower astringent tannins, and rich maple-butter sweetness that caramelizes with corn syrup/molasses",
      "Pecans have zero calories",
      "Pecans are salty"
    ],
    "optionsDe": [
      "Brennen nie an",
      "Höherer Fettgehalt, kaum herbe Gerbstoffe und süßliches Ahornaroma, das wunderbar karamellisiert",
      "Haben keine Kalorien",
      "Sind salzig"
    ],
    "correctIndex": 1,
    "explanationEn": "Thin, smooth shells and sweet lipids lack the bitter tannic skin bite of walnuts.",
    "explanationDe": "Pekannüsse schmecken süß-buttrig ohne herben Beigeschmack und karamellisieren grandios.",
    "qEn": "Why are Pecans favored over walnuts in American Southern pies?",
    "qDe": "Warum werden Pekannüsse für klassischen Pecan Pie gegenüber Walnüssen bevorzugt?",
    "optEn": [
      "Pecans never burn",
      "Higher fat, lower astringent tannins, and rich maple-butter sweetness that caramelizes with corn syrup/molasses",
      "Pecans have zero calories",
      "Pecans are salty"
    ],
    "optDe": [
      "Brennen nie an",
      "Höherer Fettgehalt, kaum herbe Gerbstoffe und süßliches Ahornaroma, das wunderbar karamellisiert",
      "Haben keine Kalorien",
      "Sind salzig"
    ],
    "correct": 1,
    "expEn": "Thin, smooth shells and sweet lipids lack the bitter tannic skin bite of walnuts.",
    "expDe": "Pekannüsse schmecken süß-buttrig ohne herben Beigeschmack und karamellisieren grandios."
  },
  {
    "id": "q_nut_14",
    "category": "nuts",
    "questionEn": "What are Pumpkin Seeds (Steirische Kürbiskerne g.g.A.) known for?",
    "questionDe": "Was zeichnet Steirische Kürbiskerne g.g.A. botanisch aus?",
    "optionsEn": [
      "Mutation yielding hull-less soft dark green seeds packed with chlorophyll, nutty fats, and zinc",
      "Thick white shells",
      "Red color",
      "Sweet fruit pulp"
    ],
    "optionsDe": [
      "Schalenlose weiche, dunkelgrüne Kerne mit hohem Chlorophyll- und nussigem Ölgehalt",
      "Dicke weiße Schale",
      "Rote Farbe",
      "Süßes Fruchtfleisch"
    ],
    "correctIndex": 0,
    "explanationEn": "Mutated Cucurbita pepo var. styriaca grows seed without woody husks, pressed into emerald pumpkin seed oil.",
    "explanationDe": "Die schalenlos gewachsenen Kerne werden direkt zu dunklem, nussigem Steirischem Kürbiskernöl geröstet.",
    "qEn": "What are Pumpkin Seeds (Steirische Kürbiskerne g.g.A.) known for?",
    "qDe": "Was zeichnet Steirische Kürbiskerne g.g.A. botanisch aus?",
    "optEn": [
      "Mutation yielding hull-less soft dark green seeds packed with chlorophyll, nutty fats, and zinc",
      "Thick white shells",
      "Red color",
      "Sweet fruit pulp"
    ],
    "optDe": [
      "Schalenlose weiche, dunkelgrüne Kerne mit hohem Chlorophyll- und nussigem Ölgehalt",
      "Dicke weiße Schale",
      "Rote Farbe",
      "Süßes Fruchtfleisch"
    ],
    "correct": 0,
    "expEn": "Mutated Cucurbita pepo var. styriaca grows seed without woody husks, pressed into emerald pumpkin seed oil.",
    "expDe": "Die schalenlos gewachsenen Kerne werden direkt zu dunklem, nussigem Steirischem Kürbiskernöl geröstet."
  },
  {
    "id": "q_nut_15",
    "category": "nuts",
    "questionEn": "What culinary seed provides the base for French Dijon mustard and curry powders?",
    "questionDe": "Welcher Samen bildet das Fundament für Senf und viele Currymischungen?",
    "optionsEn": [
      "Coriander seeds",
      "Cumin seeds",
      "Fennel seeds",
      "Mustard seeds (Sinapis alba, Brassica juncea, and Brassica nigra)"
    ],
    "optionsDe": [
      "Koriandersamen",
      "Kreuzkümmelsamen",
      "Fenchelsamen",
      "Senfsaat (Gelber, Brauner und Schwarzer Senf)"
    ],
    "correctIndex": 3,
    "explanationEn": "Cruciferous mustard seeds contain sinigrin and sinalbin, unlocking fiery pungency upon contact with liquid.",
    "explanationDe": "Senfkörner enthalten Glukosinolate, die erst durch Wasser Schärfe freisetzen.",
    "qEn": "What culinary seed provides the base for French Dijon mustard and curry powders?",
    "qDe": "Welcher Samen bildet das Fundament für Senf und viele Currymischungen?",
    "optEn": [
      "Coriander seeds",
      "Cumin seeds",
      "Fennel seeds",
      "Mustard seeds (Sinapis alba, Brassica juncea, and Brassica nigra)"
    ],
    "optDe": [
      "Koriandersamen",
      "Kreuzkümmelsamen",
      "Fenchelsamen",
      "Senfsaat (Gelber, Brauner und Schwarzer Senf)"
    ],
    "correct": 3,
    "expEn": "Cruciferous mustard seeds contain sinigrin and sinalbin, unlocking fiery pungency upon contact with liquid.",
    "expDe": "Senfkörner enthalten Glukosinolate, die erst durch Wasser Schärfe freisetzen."
  },
  {
    "id": "q_nut_16",
    "category": "nuts",
    "questionEn": "Why are Brazil Nuts (Paranüsse) prized for thyroid health?",
    "questionDe": "Warum gelten Paranüsse als die reichste natürliche Quelle für Selen?",
    "optionsEn": [
      "They contain synthetic tablets",
      "They contain iodine",
      "Trees in deep Amazonian soils accumulate massive concentrations of trace mineral Selenium",
      "They have thyroid hormones"
    ],
    "optionsDe": [
      "Enthalten synthetische Stoffe",
      "Enthalten Jod",
      "Tiefwurzelnde Urwaldriesen im Amazonas reichern das Spurenelement Selen extrem an",
      "Enthalten Schilddrüsenhormone"
    ],
    "correctIndex": 2,
    "explanationEn": "Just 1 to 2 Brazil nuts per day cover 100% of the adult human selenium requirement.",
    "explanationDe": "Bereits ein bis zwei Paranüsse täglich decken den menschlichen Selenbedarf vollständig.",
    "qEn": "Why are Brazil Nuts (Paranüsse) prized for thyroid health?",
    "qDe": "Warum gelten Paranüsse als die reichste natürliche Quelle für Selen?",
    "optEn": [
      "They contain synthetic tablets",
      "They contain iodine",
      "Trees in deep Amazonian soils accumulate massive concentrations of trace mineral Selenium",
      "They have thyroid hormones"
    ],
    "optDe": [
      "Enthalten synthetische Stoffe",
      "Enthalten Jod",
      "Tiefwurzelnde Urwaldriesen im Amazonas reichern das Spurenelement Selen extrem an",
      "Enthalten Schilddrüsenhormone"
    ],
    "correct": 2,
    "expEn": "Just 1 to 2 Brazil nuts per day cover 100% of the adult human selenium requirement.",
    "expDe": "Bereits ein bis zwei Paranüsse täglich decken den menschlichen Selenbedarf vollständig."
  },
  {
    "id": "q_nut_17",
    "category": "nuts",
    "questionEn": "What is Poppy Seed filling (Mohnback) in Central European strudels and cakes?",
    "questionDe": "Wie wird Mohnsaat für Mohnstrudel verarbeitet, damit sie ihr Aroma entfaltet?",
    "optionsEn": [
      "Soaked in vinegar",
      "Seeds must be crushed or ground in a poppy mill to crack hard seed coats and release fragrant milk oils",
      "Fried in beef fat",
      "Eaten whole unground"
    ],
    "optionsDe": [
      "In Essig eingelegt",
      "Blaumohn muss gequetscht oder gemahlen werden, um die harten Schalen zu brechen und Aromaöle freizusetzen",
      "In Rinderfett gebraten",
      "Unzerkleinert gegessen"
    ],
    "correctIndex": 1,
    "explanationEn": "Whole poppy seeds pass through undigested; grinding releases rich, nutty, blue-black oil paste.",
    "explanationDe": "Erst gemahlen entfaltet Blaumohn seinen samtigen, nussig-herben Geschmack in Strudel und Kuchen.",
    "qEn": "What is Poppy Seed filling (Mohnback) in Central European strudels and cakes?",
    "qDe": "Wie wird Mohnsaat für Mohnstrudel verarbeitet, damit sie ihr Aroma entfaltet?",
    "optEn": [
      "Soaked in vinegar",
      "Seeds must be crushed or ground in a poppy mill to crack hard seed coats and release fragrant milk oils",
      "Fried in beef fat",
      "Eaten whole unground"
    ],
    "optDe": [
      "In Essig eingelegt",
      "Blaumohn muss gequetscht oder gemahlen werden, um die harten Schalen zu brechen und Aromaöle freizusetzen",
      "In Rinderfett gebraten",
      "Unzerkleinert gegessen"
    ],
    "correct": 1,
    "expEn": "Whole poppy seeds pass through undigested; grinding releases rich, nutty, blue-black oil paste.",
    "expDe": "Erst gemahlen entfaltet Blaumohn seinen samtigen, nussig-herben Geschmack in Strudel und Kuchen."
  },
  {
    "id": "q_nut_18",
    "category": "nuts",
    "questionEn": "What makes Pine Nut mouth (Pine Mouth syndrome) occur from inferior imports?",
    "questionDe": "Was löst das gefürchtete 'Pinienmund-Syndrom' bei minderwertigen Importen aus?",
    "optionsEn": [
      "Consuming non-culinary wild pine species (Pinus armandii) causing intense metallic bitter taste lasting 2 weeks",
      "Allergic shock",
      "Tooth decay",
      "Food poisoning from salmonella"
    ],
    "optionsDe": [
      "Verzehr ungeeigneter Wildkiefern (Pinus armandii); erzeugt tagelang anhaltenden metallischen Bittergeschmack",
      "Allergischer Schock",
      "Karies",
      "Salmonellen"
    ],
    "correctIndex": 0,
    "explanationEn": "Armand's pine nuts induce reversible trigeminal taste distortion; always purchase authentic Pinus pinea.",
    "explanationDe": "Minderwertige chinesische Kiefernnüsse können für Wochen jeden Bissen metallisch-bitter schmecken lassen.",
    "qEn": "What makes Pine Nut mouth (Pine Mouth syndrome) occur from inferior imports?",
    "qDe": "Was löst das gefürchtete 'Pinienmund-Syndrom' bei minderwertigen Importen aus?",
    "optEn": [
      "Consuming non-culinary wild pine species (Pinus armandii) causing intense metallic bitter taste lasting 2 weeks",
      "Allergic shock",
      "Tooth decay",
      "Food poisoning from salmonella"
    ],
    "optDe": [
      "Verzehr ungeeigneter Wildkiefern (Pinus armandii); erzeugt tagelang anhaltenden metallischen Bittergeschmack",
      "Allergischer Schock",
      "Karies",
      "Salmonellen"
    ],
    "correct": 0,
    "expEn": "Armand's pine nuts induce reversible trigeminal taste distortion; always purchase authentic Pinus pinea.",
    "expDe": "Minderwertige chinesische Kiefernnüsse können für Wochen jeden Bissen metallisch-bitter schmecken lassen."
  },
  {
    "id": "q_spi_01",
    "category": "spices_herbs",
    "questionEn": "Why is authentic Saffron (Crocus sativus) the most expensive spice in the world?",
    "questionDe": "Warum ist echter Safran das teuerste Gewürz der Welt?",
    "optionsEn": [
      "It is aged 100 years",
      "It grows on mountain peaks",
      "It is made of gold dust",
      "Each flower yields only three delicate red stigmas, hand-picked requiring 150,000 flowers per kilogram"
    ],
    "optionsDe": [
      "Muss 100 Jahre lagern",
      "Wächst nur auf Berggipfeln",
      "Besteht aus Blattgold",
      "Jede Blüte trägt nur 3 zarte Narbenschenkel; für 1 kg werden rund 150.000 Blüten von Hand gepflückt"
    ],
    "correctIndex": 3,
    "explanationEn": "Crocin provides intense yellow color; safranal imparts bitter honey aroma; picrocrocin adds hay-like piquancy.",
    "explanationDe": "Handarbeit im Morgengrauen: Crocin färbt intensiv goldgelb, Safranal schenkt den erdigen Duft.",
    "qEn": "Why is authentic Saffron (Crocus sativus) the most expensive spice in the world?",
    "qDe": "Warum ist echter Safran das teuerste Gewürz der Welt?",
    "optEn": [
      "It is aged 100 years",
      "It grows on mountain peaks",
      "It is made of gold dust",
      "Each flower yields only three delicate red stigmas, hand-picked requiring 150,000 flowers per kilogram"
    ],
    "optDe": [
      "Muss 100 Jahre lagern",
      "Wächst nur auf Berggipfeln",
      "Besteht aus Blattgold",
      "Jede Blüte trägt nur 3 zarte Narbenschenkel; für 1 kg werden rund 150.000 Blüten von Hand gepflückt"
    ],
    "correct": 3,
    "expEn": "Crocin provides intense yellow color; safranal imparts bitter honey aroma; picrocrocin adds hay-like piquancy.",
    "expDe": "Handarbeit im Morgengrauen: Crocin färbt intensiv goldgelb, Safranal schenkt den erdigen Duft."
  },
  {
    "id": "q_spi_02",
    "category": "spices_herbs",
    "questionEn": "What is the botanical difference between true Ceylon Cinnamon and Cassia Cinnamon?",
    "questionDe": "Was unterscheidet echten Ceylon-Zimt von billigem Cassia-Zimt?",
    "optionsEn": [
      "Cassia has no aroma",
      "Ceylon is toxic",
      "Ceylon has delicate paper-thin rolled layers and minimal coumarin; Cassia is a thick single hard bark roll high in coumarin",
      "Ceylon is red"
    ],
    "optionsDe": [
      "Cassia hat kein Aroma",
      "Ceylon ist giftig",
      "Ceylon-Zimt besteht aus hauchdünnen gerollten Schichten mit kaum Cumarin; Cassia ist eine dicke, harte Rinde mit viel Cumarin",
      "Ceylon ist knallrot"
    ],
    "correctIndex": 2,
    "explanationEn": "Cassia cinnamon contains liver-toxic coumarin; delicate Ceylon cinnamon (Cinnamomum verum) is refined and safe.",
    "explanationDe": "Echter Ceylon-Zimt schmeckt edel-süßlich; Cassia ist holzig-scharf und enthält leberbelastendes Cumarin.",
    "qEn": "What is the botanical difference between true Ceylon Cinnamon and Cassia Cinnamon?",
    "qDe": "Was unterscheidet echten Ceylon-Zimt von billigem Cassia-Zimt?",
    "optEn": [
      "Cassia has no aroma",
      "Ceylon is toxic",
      "Ceylon has delicate paper-thin rolled layers and minimal coumarin; Cassia is a thick single hard bark roll high in coumarin",
      "Ceylon is red"
    ],
    "optDe": [
      "Cassia hat kein Aroma",
      "Ceylon ist giftig",
      "Ceylon-Zimt besteht aus hauchdünnen gerollten Schichten mit kaum Cumarin; Cassia ist eine dicke, harte Rinde mit viel Cumarin",
      "Ceylon ist knallrot"
    ],
    "correct": 2,
    "expEn": "Cassia cinnamon contains liver-toxic coumarin; delicate Ceylon cinnamon (Cinnamomum verum) is refined and safe.",
    "expDe": "Echter Ceylon-Zimt schmeckt edel-süßlich; Cassia ist holzig-scharf und enthält leberbelastendes Cumarin."
  },
  {
    "id": "q_spi_03",
    "category": "spices_herbs",
    "questionEn": "What gives Tellicherry Garbled Extra Bold black pepper its reputation?",
    "questionDe": "Was zeichnet Tellicherry Black Pepper (TGSEB) von der Malabarküste aus?",
    "optionsEn": [
      "It is dried in ovens",
      "Berries are left to ripen fully on the vine until orange-red, yielding maximum piperine heat and floral citrus oils",
      "It is soaked in lime",
      "It has zero pungency"
    ],
    "optionsDe": [
      "Wird im Ofen gedörrt",
      "Vollreif geerntete dicke Beeren von der Malabarküste mit intensivem Piperin und warm-fruchtigen Terpenen",
      "In Kalk gebadet",
      "Hat keine Schärfe"
    ],
    "correctIndex": 1,
    "explanationEn": "Extra bold berries have a large surface-to-heat ratio, packed with pinene and limonene aromatics.",
    "explanationDe": "Spät geerntete Beeren entwickeln neben edler Pfefferschärfe tiefe Noten von Waldbeeren und Holz.",
    "qEn": "What gives Tellicherry Garbled Extra Bold black pepper its reputation?",
    "qDe": "Was zeichnet Tellicherry Black Pepper (TGSEB) von der Malabarküste aus?",
    "optEn": [
      "It is dried in ovens",
      "Berries are left to ripen fully on the vine until orange-red, yielding maximum piperine heat and floral citrus oils",
      "It is soaked in lime",
      "It has zero pungency"
    ],
    "optDe": [
      "Wird im Ofen gedörrt",
      "Vollreif geerntete dicke Beeren von der Malabarküste mit intensivem Piperin und warm-fruchtigen Terpenen",
      "In Kalk gebadet",
      "Hat keine Schärfe"
    ],
    "correct": 1,
    "expEn": "Extra bold berries have a large surface-to-heat ratio, packed with pinene and limonene aromatics.",
    "expDe": "Spät geerntete Beeren entwickeln neben edler Pfefferschärfe tiefe Noten von Waldbeeren und Holz."
  },
  {
    "id": "q_spi_04",
    "category": "spices_herbs",
    "questionEn": "What active compound gives fresh Chili peppers their fiery heat on the Scoville scale?",
    "questionDe": "Welcher Inhaltsstoff erzeugt die brennende Schärfe in Chilis auf der Scoville-Skala?",
    "optionsEn": [
      "Capsaicin, which binds to heat and pain receptors (TRPV1) on the tongue",
      "Piperine",
      "Gingerol",
      "Sinigrin"
    ],
    "optionsDe": [
      "Capsaicin, das die Hitzerezeptoren (TRPV1) auf der Zunge stimuliert",
      "Piperin",
      "Gingerol",
      "Sinigrin"
    ],
    "correctIndex": 0,
    "explanationEn": "Capsaicin tricks nerve endings into perceiving burning heat (>43°C); dairy casein dissolves it best.",
    "explanationDe": "Capsaicin täuscht dem Gehirn Verbrennungshitze vor; Milchfett und Kasein lindern das Brennen.",
    "qEn": "What active compound gives fresh Chili peppers their fiery heat on the Scoville scale?",
    "qDe": "Welcher Inhaltsstoff erzeugt die brennende Schärfe in Chilis auf der Scoville-Skala?",
    "optEn": [
      "Capsaicin, which binds to heat and pain receptors (TRPV1) on the tongue",
      "Piperine",
      "Gingerol",
      "Sinigrin"
    ],
    "optDe": [
      "Capsaicin, das die Hitzerezeptoren (TRPV1) auf der Zunge stimuliert",
      "Piperin",
      "Gingerol",
      "Sinigrin"
    ],
    "correct": 0,
    "expEn": "Capsaicin tricks nerve endings into perceiving burning heat (>43°C); dairy casein dissolves it best.",
    "expDe": "Capsaicin täuscht dem Gehirn Verbrennungshitze vor; Milchfett und Kasein lindern das Brennen."
  },
  {
    "id": "q_spi_05",
    "category": "spices_herbs",
    "questionEn": "Why should whole spices (cumin, coriander, cardamom) be dry-toasted in a pan before grinding?",
    "questionDe": "Warum sollten ganze Gewürze (Kreuzkümmel, Koriander) vor dem Mahlen trocken angeröstet werden?",
    "optionsEn": [
      "To turn them black",
      "To burn off germs",
      "To dry out mold",
      "Dry heat volatilizes essential oils and generates pyrazines, intensifying aroma depth dramatically"
    ],
    "optionsDe": [
      "Damit sie schwarz werden",
      "Um Keime zu verbrennen",
      "Gegen Schimmel",
      "Hitze setzt ätherische Öle frei und bildet durch Maillard-Reaktion intensive Röst-Pyrazine"
    ],
    "correctIndex": 3,
    "explanationEn": "Roasting cracks outer cell walls and activates dormant aroma compounds before crushing.",
    "explanationDe": "Kurzes Rösten ohne Fett weckt schlafende Aromen und vertieft die Würzkraft um ein Vielfaches.",
    "qEn": "Why should whole spices (cumin, coriander, cardamom) be dry-toasted in a pan before grinding?",
    "qDe": "Warum sollten ganze Gewürze (Kreuzkümmel, Koriander) vor dem Mahlen trocken angeröstet werden?",
    "optEn": [
      "To turn them black",
      "To burn off germs",
      "To dry out mold",
      "Dry heat volatilizes essential oils and generates pyrazines, intensifying aroma depth dramatically"
    ],
    "optDe": [
      "Damit sie schwarz werden",
      "Um Keime zu verbrennen",
      "Gegen Schimmel",
      "Hitze setzt ätherische Öle frei und bildet durch Maillard-Reaktion intensive Röst-Pyrazine"
    ],
    "correct": 3,
    "expEn": "Roasting cracks outer cell walls and activates dormant aroma compounds before crushing.",
    "expDe": "Kurzes Rösten ohne Fett weckt schlafende Aromen und vertieft die Würzkraft um ein Vielfaches."
  },
  {
    "id": "q_spi_06",
    "category": "spices_herbs",
    "questionEn": "What is the difference between Green Cardamom and Black Cardamom?",
    "questionDe": "Wie unterscheidet sich Grüner Kardamom von Schwarzem Kardamom?",
    "optionsEn": [
      "Green cardamom is spicy like chili",
      "Black cardamom is dyed",
      "Green cardamom is sweet, floral, and herbal; Black cardamom is dried over open wood fires, yielding deep smoky camphor notes",
      "Black cardamom is sweet vanilla"
    ],
    "optionsDe": [
      "Grün ist scharf wie Chili",
      "Schwarzer Kardamom ist gefärbt",
      "Grüner Kardamom schmeckt blumig-eukalyptisch; Schwarzer Kardamom wird über Holzfeuer getrocknet und schmeckt rauchig-harzig",
      "Schwarz schmeckt nach Vanille"
    ],
    "correctIndex": 2,
    "explanationEn": "Black cardamom (Amomum subulatum) is essential for rustic North Indian curries and Vietnamese Pho broth.",
    "explanationDe": "Schwarzer Kardamom bringt Rauch und Harz in Schmorgerichte; grüner Kardamom verfeinert Süßspeisen.",
    "qEn": "What is the difference between Green Cardamom and Black Cardamom?",
    "qDe": "Wie unterscheidet sich Grüner Kardamom von Schwarzem Kardamom?",
    "optEn": [
      "Green cardamom is spicy like chili",
      "Black cardamom is dyed",
      "Green cardamom is sweet, floral, and herbal; Black cardamom is dried over open wood fires, yielding deep smoky camphor notes",
      "Black cardamom is sweet vanilla"
    ],
    "optDe": [
      "Grün ist scharf wie Chili",
      "Schwarzer Kardamom ist gefärbt",
      "Grüner Kardamom schmeckt blumig-eukalyptisch; Schwarzer Kardamom wird über Holzfeuer getrocknet und schmeckt rauchig-harzig",
      "Schwarz schmeckt nach Vanille"
    ],
    "correct": 2,
    "expEn": "Black cardamom (Amomum subulatum) is essential for rustic North Indian curries and Vietnamese Pho broth.",
    "expDe": "Schwarzer Kardamom bringt Rauch und Harz in Schmorgerichte; grüner Kardamom verfeinert Süßspeisen."
  },
  {
    "id": "q_spi_07",
    "category": "spices_herbs",
    "questionEn": "What gives freshly grated Nutmeg (Muskatnuss) its warm aroma and why should it be used sparingly?",
    "questionDe": "Welcher Stoff prägt das Aroma der Muskatnuss und warum sollte man sie sparsam dosieren?",
    "optionsEn": [
      "Arsenic",
      "Myristicin and elemicin provide warm sweet depth, but in large doses (5g+) act as a toxic psychoactive hallucinogen",
      "Caffeine",
      "Cyanide"
    ],
    "optionsDe": [
      "Arsen",
      "Myristicin verleiht den warmen Duft, wirkt aber in hohen Dosen (ab 5g) toxisch und halluzinogen",
      "Koffein",
      "Blausäure"
    ],
    "correctIndex": 1,
    "explanationEn": "A pinch enhances mashed potatoes and béchamel; excess causes nausea and toxicity.",
    "explanationDe": "Eine feine Prise adelt Kartoffelpüree; löffelweise verzehrt wirkt Muskat als Rauschgift.",
    "qEn": "What gives freshly grated Nutmeg (Muskatnuss) its warm aroma and why should it be used sparingly?",
    "qDe": "Welcher Stoff prägt das Aroma der Muskatnuss und warum sollte man sie sparsam dosieren?",
    "optEn": [
      "Arsenic",
      "Myristicin and elemicin provide warm sweet depth, but in large doses (5g+) act as a toxic psychoactive hallucinogen",
      "Caffeine",
      "Cyanide"
    ],
    "optDe": [
      "Arsen",
      "Myristicin verleiht den warmen Duft, wirkt aber in hohen Dosen (ab 5g) toxisch und halluzinogen",
      "Koffein",
      "Blausäure"
    ],
    "correct": 1,
    "expEn": "A pinch enhances mashed potatoes and béchamel; excess causes nausea and toxicity.",
    "expDe": "Eine feine Prise adelt Kartoffelpüree; löffelweise verzehrt wirkt Muskat als Rauschgift."
  },
  {
    "id": "q_spi_08",
    "category": "spices_herbs",
    "questionEn": "What is Star Anise (Sternanis) and which Asian classic spice blend features it?",
    "questionDe": "Was ist Sternanis und in welcher klassischen asiatischen Gewürzmischung ist er unverzichtbar?",
    "optionsEn": [
      "The dried star fruit of Illicium verum, providing anethole sweetness in Chinese Five-Spice and Vietnamese Pho",
      "A root related to ginger",
      "Caraway seeds pressed into stars",
      "Anise seeds mixed with sugar"
    ],
    "optionsDe": [
      "Die sternförmige Frucht von Illicium verum; Hauptbestandteil des chinesischen Fünf-Gewürze-Pulvers und von Pho",
      "Eine Ingwerwurzel",
      "Aus Kümmel gepresst",
      "Anissamen mit Zucker"
    ],
    "correctIndex": 0,
    "explanationEn": "Contains high levels of sweet anethole, imparting liquorice notes to braised pork belly and broths.",
    "explanationDe": "Sternanis duftet intensiv nach Lakritz und verleiht geschmortem Schweinebauch seinen Glanz.",
    "qEn": "What is Star Anise (Sternanis) and which Asian classic spice blend features it?",
    "qDe": "Was ist Sternanis und in welcher klassischen asiatischen Gewürzmischung ist er unverzichtbar?",
    "optEn": [
      "The dried star fruit of Illicium verum, providing anethole sweetness in Chinese Five-Spice and Vietnamese Pho",
      "A root related to ginger",
      "Caraway seeds pressed into stars",
      "Anise seeds mixed with sugar"
    ],
    "optDe": [
      "Die sternförmige Frucht von Illicium verum; Hauptbestandteil des chinesischen Fünf-Gewürze-Pulvers und von Pho",
      "Eine Ingwerwurzel",
      "Aus Kümmel gepresst",
      "Anissamen mit Zucker"
    ],
    "correct": 0,
    "expEn": "Contains high levels of sweet anethole, imparting liquorice notes to braised pork belly and broths.",
    "expDe": "Sternanis duftet intensiv nach Lakritz und verleiht geschmortem Schweinebauch seinen Glanz."
  },
  {
    "id": "q_spi_09",
    "category": "spices_herbs",
    "questionEn": "What active ginger compound transforms from fresh gingerol into sweeter shogaol when dried or cooked?",
    "questionDe": "Welcher Schärfestoff in frischem Ingwer wandelt sich beim Kochen und Trocknen in würziges Shogaol um?",
    "optionsEn": [
      "Menthol",
      "Capsaicin",
      "Curcumin",
      "Gingerol"
    ],
    "optionsDe": [
      "Menthol",
      "Capsaicin",
      "Curcumin",
      "Gingerol"
    ],
    "correctIndex": 3,
    "explanationEn": "Cooking or dehydration converts gingerol into shogaol, which is twice as pungent and deeply warming.",
    "explanationDe": "Frischer Ingwer schmeckt spritzig-scharf (Gingerol); getrockneter Ingwer heizt tiefer ein (Shogaol).",
    "qEn": "What active ginger compound transforms from fresh gingerol into sweeter shogaol when dried or cooked?",
    "qDe": "Welcher Schärfestoff in frischem Ingwer wandelt sich beim Kochen und Trocknen in würziges Shogaol um?",
    "optEn": [
      "Menthol",
      "Capsaicin",
      "Curcumin",
      "Gingerol"
    ],
    "optDe": [
      "Menthol",
      "Capsaicin",
      "Curcumin",
      "Gingerol"
    ],
    "correct": 3,
    "expEn": "Cooking or dehydration converts gingerol into shogaol, which is twice as pungent and deeply warming.",
    "expDe": "Frischer Ingwer schmeckt spritzig-scharf (Gingerol); getrockneter Ingwer heizt tiefer ein (Shogaol)."
  },
  {
    "id": "q_spi_10",
    "category": "spices_herbs",
    "questionEn": "What gives pure Vanilla beans (Vanilla planifolia) their legendary aroma?",
    "questionDe": "Welcher Stoff prägt das Bouquet echter Bourbon-Vanilleschoten?",
    "optionsEn": [
      "Clove oil",
      "Caramel sugar",
      "Vanillin and over 250 volatile aromatic esters developed during slow sweat curing of orchid seed pods",
      "Nutmeg essence"
    ],
    "optionsDe": [
      "Nelkenöl",
      "Karamellzucker",
      "Vanillin und über 250 Begleit-Aromen, gebildet beim monatelangen Fermentieren der Orchideenkapseln",
      "Muskatessenz"
    ],
    "correctIndex": 2,
    "explanationEn": "Synthetic vanillin lacks the smoky, prune, floral, and woody complexity of whole fermented beans.",
    "explanationDe": "Echte Orchideenschoten reifen monatelang in der Sonne, bis sich weiße Vanillinkristalle bilden.",
    "qEn": "What gives pure Vanilla beans (Vanilla planifolia) their legendary aroma?",
    "qDe": "Welcher Stoff prägt das Bouquet echter Bourbon-Vanilleschoten?",
    "optEn": [
      "Clove oil",
      "Caramel sugar",
      "Vanillin and over 250 volatile aromatic esters developed during slow sweat curing of orchid seed pods",
      "Nutmeg essence"
    ],
    "optDe": [
      "Nelkenöl",
      "Karamellzucker",
      "Vanillin und über 250 Begleit-Aromen, gebildet beim monatelangen Fermentieren der Orchideenkapseln",
      "Muskatessenz"
    ],
    "correct": 2,
    "expEn": "Synthetic vanillin lacks the smoky, prune, floral, and woody complexity of whole fermented beans.",
    "expDe": "Echte Orchideenschoten reifen monatelang in der Sonne, bis sich weiße Vanillinkristalle bilden."
  },
  {
    "id": "q_spi_11",
    "category": "spices_herbs",
    "questionEn": "What is Sumac in Middle Eastern and Levantine cooking?",
    "questionDe": "Was ist Sumach in der levantinischen Küche?",
    "optionsEn": [
      "Hot red chili powder",
      "Coarsely ground dried red berries of Rhus coriaria, offering a fruity, tangy citrus acid kick without liquid",
      "Ground pomegranate seeds",
      "Red salt"
    ],
    "optionsDe": [
      "Scharfes Chilipulver",
      "Gerebelte getrocknete Steinfrüchte des Färberbaums mit fruchtig-zitroniger Säure ohne Flüssigkeitseintrag",
      "Granatapfelkerne",
      "Rotes Wüstensalz"
    ],
    "correctIndex": 1,
    "explanationEn": "Sumac contains malic and citric acids, dusted over grilled meats, hummus, and fattoush salads.",
    "explanationDe": "Sumach ersetzt Zitronensaft auf gegrilltem Lamm, Zwiebelsalat und Dips ohne das Gericht zu wässern.",
    "qEn": "What is Sumac in Middle Eastern and Levantine cooking?",
    "qDe": "Was ist Sumach in der levantinischen Küche?",
    "optEn": [
      "Hot red chili powder",
      "Coarsely ground dried red berries of Rhus coriaria, offering a fruity, tangy citrus acid kick without liquid",
      "Ground pomegranate seeds",
      "Red salt"
    ],
    "optDe": [
      "Scharfes Chilipulver",
      "Gerebelte getrocknete Steinfrüchte des Färberbaums mit fruchtig-zitroniger Säure ohne Flüssigkeitseintrag",
      "Granatapfelkerne",
      "Rotes Wüstensalz"
    ],
    "correct": 1,
    "expEn": "Sumac contains malic and citric acids, dusted over grilled meats, hummus, and fattoush salads.",
    "expDe": "Sumach ersetzt Zitronensaft auf gegrilltem Lamm, Zwiebelsalat und Dips ohne das Gericht zu wässern."
  },
  {
    "id": "q_spi_12",
    "category": "spices_herbs",
    "questionEn": "What is the defining fresh herb in authentic Greek cuisine and Italian tomato sauces?",
    "questionDe": "Welches sonnige Kraut bildet das Herz der mediterranen Tomatengerichte und Pizza?",
    "optionsEn": [
      "Oregano (Origanum vulgare / Origanum dictamnus)",
      "Dill",
      "Tarragon",
      "Mint"
    ],
    "optionsDe": [
      "Oregano (Origanum vulgare / Echter Dost)",
      "Dill",
      "Estragon",
      "Pfefferminze"
    ],
    "correctIndex": 0,
    "explanationEn": "Carvacrol and thymol terpenes intensify when dried, blooming powerfully in hot olive oil.",
    "explanationDe": "Oregano ist eines der wenigen Kräuter, das getrocknet noch intensiver und feuriger schmeckt.",
    "qEn": "What is the defining fresh herb in authentic Greek cuisine and Italian tomato sauces?",
    "qDe": "Welches sonnige Kraut bildet das Herz der mediterranen Tomatengerichte und Pizza?",
    "optEn": [
      "Oregano (Origanum vulgare / Origanum dictamnus)",
      "Dill",
      "Tarragon",
      "Mint"
    ],
    "optDe": [
      "Oregano (Origanum vulgare / Echter Dost)",
      "Dill",
      "Estragon",
      "Pfefferminze"
    ],
    "correct": 0,
    "expEn": "Carvacrol and thymol terpenes intensify when dried, blooming powerfully in hot olive oil.",
    "expDe": "Oregano ist eines der wenigen Kräuter, das getrocknet noch intensiver und feuriger schmeckt."
  },
  {
    "id": "q_spi_13",
    "category": "spices_herbs",
    "questionEn": "What gives Rosemary (Rosmarin) its needle-like resilience and piney balsam aroma?",
    "questionDe": "Was verleiht Rosmarin seine nadelartige Robustheit und sein waldig-harziges Aroma?",
    "optionsEn": [
      "Vinegar sap",
      "High sugar sap",
      "Salt crystals",
      "High concentration of camphor, cineole, and pinene essential oils in leathery drought-adapted leaves"
    ],
    "optionsDe": [
      "Essigsäure",
      "Süßer Pflanzensaft",
      "Salzkristalle",
      "Hohe Konzentration an Campher, Cineol und Pinen in den lederartigen Schutzblättern"
    ],
    "correctIndex": 3,
    "explanationEn": "Rosemary infuses roasted potatoes and lamb without wilting; carnosic acid acts as a natural antioxidant.",
    "explanationDe": "Die ätherischen Öle halten selbst langen Ofengarzeiten stand und schützen Bratfette vor Oxidation.",
    "qEn": "What gives Rosemary (Rosmarin) its needle-like resilience and piney balsam aroma?",
    "qDe": "Was verleiht Rosmarin seine nadelartige Robustheit und sein waldig-harziges Aroma?",
    "optEn": [
      "Vinegar sap",
      "High sugar sap",
      "Salt crystals",
      "High concentration of camphor, cineole, and pinene essential oils in leathery drought-adapted leaves"
    ],
    "optDe": [
      "Essigsäure",
      "Süßer Pflanzensaft",
      "Salzkristalle",
      "Hohe Konzentration an Campher, Cineol und Pinen in den lederartigen Schutzblättern"
    ],
    "correct": 3,
    "expEn": "Rosemary infuses roasted potatoes and lamb without wilting; carnosic acid acts as a natural antioxidant.",
    "expDe": "Die ätherischen Öle halten selbst langen Ofengarzeiten stand und schützen Bratfette vor Oxidation."
  },
  {
    "id": "q_spi_14",
    "category": "spices_herbs",
    "questionEn": "What is Za'atar spice blend in the Levant?",
    "questionDe": "Woraus besteht die traditionelle orientalische Gewürzmischung Za'atar?",
    "optionsEn": [
      "Curry, turmeric, and ginger",
      "Chili, garlic, and cumin",
      "Wild thyme/oregano, toasted sesame seeds, ground tart sumac, and sea salt",
      "Cinnamon, cardamom, and clove"
    ],
    "optionsDe": [
      "Curry, Kurkuma und Ingwer",
      "Chili, Knoblauch und Kreuzkümmel",
      "Wilder Thymian/Bibernelle, geröstete Sesamsamen, fruchtiger Sumach und Meersalz",
      "Zimt, Kardamom und Nelken"
    ],
    "correctIndex": 2,
    "explanationEn": "Dipper with fresh pita bread in extra virgin olive oil for breakfast throughout the Middle East.",
    "explanationDe": "In Olivenöl getunkt und mit warmem Fladenbrot genossen: der Duft der Levante.",
    "qEn": "What is Za'atar spice blend in the Levant?",
    "qDe": "Woraus besteht die traditionelle orientalische Gewürzmischung Za'atar?",
    "optEn": [
      "Curry, turmeric, and ginger",
      "Chili, garlic, and cumin",
      "Wild thyme/oregano, toasted sesame seeds, ground tart sumac, and sea salt",
      "Cinnamon, cardamom, and clove"
    ],
    "optDe": [
      "Curry, Kurkuma und Ingwer",
      "Chili, Knoblauch und Kreuzkümmel",
      "Wilder Thymian/Bibernelle, geröstete Sesamsamen, fruchtiger Sumach und Meersalz",
      "Zimt, Kardamom und Nelken"
    ],
    "correct": 2,
    "expEn": "Dipper with fresh pita bread in extra virgin olive oil for breakfast throughout the Middle East.",
    "expDe": "In Olivenöl getunkt und mit warmem Fladenbrot genossen: der Duft der Levante."
  },
  {
    "id": "q_spi_15",
    "category": "spices_herbs",
    "questionEn": "Why must delicate herbs (basil, chervil, cilantro) be added at the very end of cooking?",
    "questionDe": "Warum sollten zarte Kräuter (Basilikum, Kerbel, Koriander) erst kurz vor dem Servieren zugegeben werden?",
    "optionsEn": [
      "They turn poisonous when boiled",
      "Their delicate volatile essential oils (linalool, estragole) evaporate quickly and heat turns leaves bitter and brown",
      "They dissolve water into steam",
      "They absorb all salt"
    ],
    "optionsDe": [
      "Sie werden beim Kochen giftig",
      "Ihre flüchtigen ätherischen Öle verdampfen bei Hitze rasch und die Blätter werden braun und bitter",
      "Sie lösen Wasser auf",
      "Sie schlucken das Salz"
    ],
    "correctIndex": 1,
    "explanationEn": "Heat destroys fresh green top notes; stir in off the flame to preserve garden vibrancy.",
    "explanationDe": "Hitze zerstört die feinen Aromen; zarte Kräuter immer erst beim Anrichten über das Gericht streuen.",
    "qEn": "Why must delicate herbs (basil, chervil, cilantro) be added at the very end of cooking?",
    "qDe": "Warum sollten zarte Kräuter (Basilikum, Kerbel, Koriander) erst kurz vor dem Servieren zugegeben werden?",
    "optEn": [
      "They turn poisonous when boiled",
      "Their delicate volatile essential oils (linalool, estragole) evaporate quickly and heat turns leaves bitter and brown",
      "They dissolve water into steam",
      "They absorb all salt"
    ],
    "optDe": [
      "Sie werden beim Kochen giftig",
      "Ihre flüchtigen ätherischen Öle verdampfen bei Hitze rasch und die Blätter werden braun und bitter",
      "Sie lösen Wasser auf",
      "Sie schlucken das Salz"
    ],
    "correct": 1,
    "expEn": "Heat destroys fresh green top notes; stir in off the flame to preserve garden vibrancy.",
    "expDe": "Hitze zerstört die feinen Aromen; zarte Kräuter immer erst beim Anrichten über das Gericht streuen."
  },
  {
    "id": "q_spi_16",
    "category": "spices_herbs",
    "questionEn": "What active compound gives Cloves (Gewürznelken) their intense numbing antiseptic flavor?",
    "questionDe": "Welcher Aromastoff dominiert in getrockneten Gewürznelken (Syzygium aromaticum)?",
    "optionsEn": [
      "Eugenol (making up 70-90% of clove essential oil)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "optionsDe": [
      "Eugenol (macht bis zu 90% des ätherischen Nelkenöls aus)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "correctIndex": 0,
    "explanationEn": "Eugenol has natural local anesthetic and antimicrobial properties, starring in glühwein and braised meats.",
    "explanationDe": "Eugenol betäubt sanft die Zunge und wärmt klassisch in Rotkohl, Lebkuchen und Glühwein.",
    "qEn": "What active compound gives Cloves (Gewürznelken) their intense numbing antiseptic flavor?",
    "qDe": "Welcher Aromastoff dominiert in getrockneten Gewürznelken (Syzygium aromaticum)?",
    "optEn": [
      "Eugenol (making up 70-90% of clove essential oil)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "optDe": [
      "Eugenol (macht bis zu 90% des ätherischen Nelkenöls aus)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "correct": 0,
    "expEn": "Eugenol has natural local anesthetic and antimicrobial properties, starring in glühwein and braised meats.",
    "expDe": "Eugenol betäubt sanft die Zunge und wärmt klassisch in Rotkohl, Lebkuchen und Glühwein."
  },
  {
    "id": "q_spi_17",
    "category": "spices_herbs",
    "questionEn": "Why does freshly grated Horseradish (Meerrettich / Kren) produce a stinging nasal sensation?",
    "questionDe": "Was erzeugt das typische Stechen in der Nase bei frisch geriebenem Kren (Meerrettich)?",
    "optionsEn": [
      "Acetic acid",
      "Capsaicin gas",
      "Black pepper fumes",
      "Glucosinolate sinigrin is cleaved into volatile allyl isothiocyanate, identical to wasabi"
    ],
    "optionsDe": [
      "Essigdampf",
      "Capsaicingas",
      "Pfefferstaub",
      "Das Senfölglykosid Sinigrin wird beim Reiben enzymatisch in flüchtiges Allylisothiocyanat gespalten"
    ],
    "correctIndex": 3,
    "explanationEn": "Isothiocyanates evaporate and rise into the olfactory nasopharynx, clearing sinuses instantly.",
    "explanationDe": "Das flüchtige Senföl reizt die Nasenschleimhaut, verbrennt aber im Gegensatz zu Chili nicht die Zunge.",
    "qEn": "Why does freshly grated Horseradish (Meerrettich / Kren) produce a stinging nasal sensation?",
    "qDe": "Was erzeugt das typische Stechen in der Nase bei frisch geriebenem Kren (Meerrettich)?",
    "optEn": [
      "Acetic acid",
      "Capsaicin gas",
      "Black pepper fumes",
      "Glucosinolate sinigrin is cleaved into volatile allyl isothiocyanate, identical to wasabi"
    ],
    "optDe": [
      "Essigdampf",
      "Capsaicingas",
      "Pfefferstaub",
      "Das Senfölglykosid Sinigrin wird beim Reiben enzymatisch in flüchtiges Allylisothiocyanat gespalten"
    ],
    "correct": 3,
    "expEn": "Isothiocyanates evaporate and rise into the olfactory nasopharynx, clearing sinuses instantly.",
    "expDe": "Das flüchtige Senföl reizt die Nasenschleimhaut, verbrennt aber im Gegensatz zu Chili nicht die Zunge."
  },
  {
    "id": "q_spi_18",
    "category": "spices_herbs",
    "questionEn": "What is Juniper berry (Wacholderbeere) botanically and culinarily?",
    "questionDe": "Was ist die Wacholderbeere botanisch und gastronomisch?",
    "optionsEn": [
      "A citrus berry",
      "A true stone fruit",
      "The female seed cone of Juniperus communis with fleshy merged scales, packed with pinene for game and sauerkraut",
      "A dried mushroom"
    ],
    "optionsDe": [
      "Eine Zitrusfrucht",
      "Eine echte Steinbeere",
      "Der fleischig verwachsene weibliche Zapfen von Juniperus communis; reich an waldigen Pinenen",
      "Ein getrockneter Pilz"
    ],
    "correctIndex": 2,
    "explanationEn": "Juniper cuts through rich game fats (venison, wild boar) and gives London Dry Gin its defining identity.",
    "explanationDe": "Wacholder bändigt fettes Wildbret und verleiht Sauerkraut sowie Gin den typischen Nadelwald-Charakter.",
    "qEn": "What is Juniper berry (Wacholderbeere) botanically and culinarily?",
    "qDe": "Was ist die Wacholderbeere botanisch und gastronomisch?",
    "optEn": [
      "A citrus berry",
      "A true stone fruit",
      "The female seed cone of Juniperus communis with fleshy merged scales, packed with pinene for game and sauerkraut",
      "A dried mushroom"
    ],
    "optDe": [
      "Eine Zitrusfrucht",
      "Eine echte Steinbeere",
      "Der fleischig verwachsene weibliche Zapfen von Juniperus communis; reich an waldigen Pinenen",
      "Ein getrockneter Pilz"
    ],
    "correct": 2,
    "expEn": "Juniper cuts through rich game fats (venison, wild boar) and gives London Dry Gin its defining identity.",
    "expDe": "Wacholder bändigt fettes Wildbret und verleiht Sauerkraut sowie Gin den typischen Nadelwald-Charakter."
  },
  {
    "id": "q_oli_01",
    "category": "olives",
    "questionEn": "Why can fresh olives never be eaten straight from the olive tree?",
    "questionDe": "Warum kann man frisch geerntete Oliven niemals direkt vom Baum essen?",
    "optionsEn": [
      "They are rock-hard wood",
      "They contain extremely bitter phenolic glycoside Oleuropein, which must be cured or brined out to become palatable",
      "They contain snake venom",
      "They are sour like vinegar"
    ],
    "optionsDe": [
      "Sie sind hart wie Stein",
      "Sie enthalten das extrem bittere Phenolglykosid Oleuropein, das erst durch Wässern oder Salzen entbittert werden muss",
      "Sie enthalten Schlangengift",
      "Sie schmecken sauer wie Essig"
    ],
    "correctIndex": 1,
    "explanationEn": "Oleuropein protects olives from pests; water, brine, or lye curing leaches it out over weeks.",
    "explanationDe": "Frische Oliven schmecken unerträglich gallenbitter; traditionelles Einlegen baut das Oleuropein ab.",
    "qEn": "Why can fresh olives never be eaten straight from the olive tree?",
    "qDe": "Warum kann man frisch geerntete Oliven niemals direkt vom Baum essen?",
    "optEn": [
      "They are rock-hard wood",
      "They contain extremely bitter phenolic glycoside Oleuropein, which must be cured or brined out to become palatable",
      "They contain snake venom",
      "They are sour like vinegar"
    ],
    "optDe": [
      "Sie sind hart wie Stein",
      "Sie enthalten das extrem bittere Phenolglykosid Oleuropein, das erst durch Wässern oder Salzen entbittert werden muss",
      "Sie enthalten Schlangengift",
      "Sie schmecken sauer wie Essig"
    ],
    "correct": 1,
    "expEn": "Oleuropein protects olives from pests; water, brine, or lye curing leaches it out over weeks.",
    "expDe": "Frische Oliven schmecken unerträglich gallenbitter; traditionelles Einlegen baut das Oleuropein ab."
  },
  {
    "id": "q_oli_02",
    "category": "olives",
    "questionEn": "What distinguishes Kalamata Olives PDO from Greece?",
    "questionDe": "Was zeichnet echte griechische Kalamata-Oliven g.U. aus?",
    "optionsEn": [
      "Almond-shaped, deep aubergine/purple color, cured in red wine vinegar and olive oil brine, with fruity wine tang",
      "Artificially dyed black",
      "Stuffed with cheese on the tree",
      "Small green round shape"
    ],
    "optionsDe": [
      "Mandelförmig, tiefviolett gereift, in Rotweinessig und Salzlake entbittert, fruchtig-fleischig mit Weinnote",
      "Mit Eisensalz schwarz gefärbt",
      "Am Baum mit Käse gefüllt",
      "Winzig klein und rund"
    ],
    "correctIndex": 0,
    "explanationEn": "Harvested fully ripe by hand in Messinia; red wine vinegar curing creates signature savory acidity.",
    "explanationDe": "Vollreif geerntet und mit Weinessig veredelt: die Königin der griechischen Tafeloliven.",
    "qEn": "What distinguishes Kalamata Olives PDO from Greece?",
    "qDe": "Was zeichnet echte griechische Kalamata-Oliven g.U. aus?",
    "optEn": [
      "Almond-shaped, deep aubergine/purple color, cured in red wine vinegar and olive oil brine, with fruity wine tang",
      "Artificially dyed black",
      "Stuffed with cheese on the tree",
      "Small green round shape"
    ],
    "optDe": [
      "Mandelförmig, tiefviolett gereift, in Rotweinessig und Salzlake entbittert, fruchtig-fleischig mit Weinnote",
      "Mit Eisensalz schwarz gefärbt",
      "Am Baum mit Käse gefüllt",
      "Winzig klein und rund"
    ],
    "correct": 0,
    "expEn": "Harvested fully ripe by hand in Messinia; red wine vinegar curing creates signature savory acidity.",
    "expDe": "Vollreif geerntet und mit Weinessig veredelt: die Königin der griechischen Tafeloliven."
  },
  {
    "id": "q_oli_03",
    "category": "olives",
    "questionEn": "What is the green Castelvetrano (Nocellara del Belice) olive from Sicily celebrated for?",
    "questionDe": "Wofür ist die leuchtend grüne Nocellara del Belice (Castelvetrano) aus Sizilien berühmt?",
    "optionsEn": [
      "Cooked in tomato sauce",
      "Extremely sour taste",
      "Hard wooden core",
      "Vibrant emerald green color, crisp buttery crunch, and sweet mild nutty taste cured using the gentle Castelvetrano lye method"
    ],
    "optionsDe": [
      "In Tomatensauce gekocht",
      "Extrem sauer",
      "Harter Kern",
      "Smaragdgrüne Farbe, knackig-buttriger Biss und süßlich-milder Geschmack durch milde Laugenentbitterung"
    ],
    "correctIndex": 3,
    "explanationEn": "Gentle sodium hydroxide wash followed by rapid cold rinsing preserves raw bright green crunch.",
    "explanationDe": "Die milde Entbitterung bewahrt das saftige, buttrige Fruchtfleisch ohne beißende Salzigkeit.",
    "qEn": "What is the green Castelvetrano (Nocellara del Belice) olive from Sicily celebrated for?",
    "qDe": "Wofür ist die leuchtend grüne Nocellara del Belice (Castelvetrano) aus Sizilien berühmt?",
    "optEn": [
      "Cooked in tomato sauce",
      "Extremely sour taste",
      "Hard wooden core",
      "Vibrant emerald green color, crisp buttery crunch, and sweet mild nutty taste cured using the gentle Castelvetrano lye method"
    ],
    "optDe": [
      "In Tomatensauce gekocht",
      "Extrem sauer",
      "Harter Kern",
      "Smaragdgrüne Farbe, knackig-buttriger Biss und süßlich-milder Geschmack durch milde Laugenentbitterung"
    ],
    "correct": 3,
    "expEn": "Gentle sodium hydroxide wash followed by rapid cold rinsing preserves raw bright green crunch.",
    "expDe": "Die milde Entbitterung bewahrt das saftige, buttrige Fruchtfleisch ohne beißende Salzigkeit."
  },
  {
    "id": "q_oli_04",
    "category": "olives",
    "questionEn": "How can one tell naturally tree-ripened black olives from artificially blackened olives?",
    "questionDe": "Woran erkennt man naturreife schwarze Oliven im Vergleich zu chemisch geschwärzten Oliven?",
    "optionsEn": [
      "Blackened olives have no stones",
      "Natural black olives are square",
      "Artificially blackened olives are jet-black green olives oxidized with air and fixed with Ferrous gluconate (E579)",
      "Natural black olives are green inside"
    ],
    "optionsDe": [
      "Geschwärzte haben keine Kerne",
      "Echte schwarze Oliven sind viereckig",
      "Geschwärzte Oliven sind pechschwarz mit glatter Haut und enthalten Stabilisator Eisengluconat (E579)",
      "Naturreife sind innen weiß"
    ],
    "correctIndex": 2,
    "explanationEn": "Naturally ripe black olives have shriveled, matte skin and shades of purple, brown, and violet.",
    "explanationDe": "Naturreife Oliven schimmern violett-bräunlich; industriell geschwärzte sind kohlrabenschwarz und fest.",
    "qEn": "How can one tell naturally tree-ripened black olives from artificially blackened olives?",
    "qDe": "Woran erkennt man naturreife schwarze Oliven im Vergleich zu chemisch geschwärzten Oliven?",
    "optEn": [
      "Blackened olives have no stones",
      "Natural black olives are square",
      "Artificially blackened olives are jet-black green olives oxidized with air and fixed with Ferrous gluconate (E579)",
      "Natural black olives are green inside"
    ],
    "optDe": [
      "Geschwärzte haben keine Kerne",
      "Echte schwarze Oliven sind viereckig",
      "Geschwärzte Oliven sind pechschwarz mit glatter Haut und enthalten Stabilisator Eisengluconat (E579)",
      "Naturreife sind innen weiß"
    ],
    "correct": 2,
    "expEn": "Naturally ripe black olives have shriveled, matte skin and shades of purple, brown, and violet.",
    "expDe": "Naturreife Oliven schimmern violett-bräunlich; industriell geschwärzte sind kohlrabenschwarz und fest."
  },
  {
    "id": "q_oli_05",
    "category": "olives",
    "questionEn": "What defines French Niçoise (Cailletier) olives?",
    "questionDe": "Was zeichnet französische Niçoise-Oliven (Sorte Cailletier) aus?",
    "optionsEn": [
      "Giant green pitted olives",
      "Tiny dark brown-purple olives cured in herb brine, offering nutty, smoky licorice complexity for Salade Niçoise",
      "Stuffed with pimiento",
      "Sweet dessert olives"
    ],
    "optionsDe": [
      "Riesige grüne Riesenoliven",
      "Kleine, braun-violette Oliven mit nussig-rauchigem Kräuteraroma, unverzichtbar für Salade Niçoise",
      "Mit Paprika gefüllt",
      "Süße Dessertholiven"
    ],
    "correctIndex": 1,
    "explanationEn": "Small fruit with high flesh-to-pit ratio and delicate savory depth, paired with tuna and anchovies.",
    "explanationDe": "Die feine Cailletier-Olive schenkt dem echten Salade Niçoise seine provenzalische Seele.",
    "qEn": "What defines French Niçoise (Cailletier) olives?",
    "qDe": "Was zeichnet französische Niçoise-Oliven (Sorte Cailletier) aus?",
    "optEn": [
      "Giant green pitted olives",
      "Tiny dark brown-purple olives cured in herb brine, offering nutty, smoky licorice complexity for Salade Niçoise",
      "Stuffed with pimiento",
      "Sweet dessert olives"
    ],
    "optDe": [
      "Riesige grüne Riesenoliven",
      "Kleine, braun-violette Oliven mit nussig-rauchigem Kräuteraroma, unverzichtbar für Salade Niçoise",
      "Mit Paprika gefüllt",
      "Süße Dessertholiven"
    ],
    "correct": 1,
    "expEn": "Small fruit with high flesh-to-pit ratio and delicate savory depth, paired with tuna and anchovies.",
    "expDe": "Die feine Cailletier-Olive schenkt dem echten Salade Niçoise seine provenzalische Seele."
  },
  {
    "id": "q_oli_06",
    "category": "olives",
    "questionEn": "What is Spanish Manzanilla olive known for in tapas culture?",
    "questionDe": "Wofür ist die spanische Manzanilla-Olive in der Tapas-Kultur berühmt?",
    "optionsEn": [
      "Apple-shaped firm green olive with crisp bite and nutty brine flavor, ideal for pitting and stuffing with anchovy or pimiento",
      "It is black and soft",
      "It is dried in ovens",
      "It has no pit"
    ],
    "optionsDe": [
      "Apfelförmige, feste grüne Olive mit feinem Schmelz, ideal zum Entsteinen und Füllen mit Sardelle oder Paprika",
      "Sie ist schwarz und weich",
      "Im Ofen getrocknet",
      "Hat keinen Stein"
    ],
    "correctIndex": 0,
    "explanationEn": "Manzanilla ('little apple') is Spain's quintessential green cocktail and martini olive.",
    "explanationDe": "Die feste Textur und milde Würze machen die Manzanilla zum spanischen Bar-Klassiker.",
    "qEn": "What is Spanish Manzanilla olive known for in tapas culture?",
    "qDe": "Wofür ist die spanische Manzanilla-Olive in der Tapas-Kultur berühmt?",
    "optEn": [
      "Apple-shaped firm green olive with crisp bite and nutty brine flavor, ideal for pitting and stuffing with anchovy or pimiento",
      "It is black and soft",
      "It is dried in ovens",
      "It has no pit"
    ],
    "optDe": [
      "Apfelförmige, feste grüne Olive mit feinem Schmelz, ideal zum Entsteinen und Füllen mit Sardelle oder Paprika",
      "Sie ist schwarz und weich",
      "Im Ofen getrocknet",
      "Hat keinen Stein"
    ],
    "correct": 0,
    "expEn": "Manzanilla ('little apple') is Spain's quintessential green cocktail and martini olive.",
    "expDe": "Die feste Textur und milde Würze machen die Manzanilla zum spanischen Bar-Klassiker."
  },
  {
    "id": "q_oli_07",
    "category": "olives",
    "questionEn": "What are Moroccan Beldi or Thassos dry-cured black olives?",
    "questionDe": "Was sind marokkanische Beldi-Oliven oder schrumpelige Thassos-Oliven?",
    "optionsEn": [
      "Sweet sugar olives",
      "Green olives soaked in milk",
      "Olives boiled in vinegar",
      "Ripe black olives dry-cured in coarse salt (without liquid brine), shriveling into intense, chewy, concentrated prune-like bites"
    ],
    "optionsDe": [
      "Gezuckerte Oliven",
      "In Milch eingelegte Oliven",
      "In Essig gekochte Oliven",
      "In trockenem Salz gereifte schwarze Oliven, die schrumpfen und ein konzentriertes, getrocknetes Aroma entwickeln"
    ],
    "correctIndex": 3,
    "explanationEn": "Dry salt draws out water and oleuropein through osmosis, yielding concentrated umami leather.",
    "explanationDe": "Salzentzug lässt die Oliven wie Rosinen einschrumpfen; das Aroma ist intensiv, salzig und fleischig.",
    "qEn": "What are Moroccan Beldi or Thassos dry-cured black olives?",
    "qDe": "Was sind marokkanische Beldi-Oliven oder schrumpelige Thassos-Oliven?",
    "optEn": [
      "Sweet sugar olives",
      "Green olives soaked in milk",
      "Olives boiled in vinegar",
      "Ripe black olives dry-cured in coarse salt (without liquid brine), shriveling into intense, chewy, concentrated prune-like bites"
    ],
    "optDe": [
      "Gezuckerte Oliven",
      "In Milch eingelegte Oliven",
      "In Essig gekochte Oliven",
      "In trockenem Salz gereifte schwarze Oliven, die schrumpfen und ein konzentriertes, getrocknetes Aroma entwickeln"
    ],
    "correct": 3,
    "expEn": "Dry salt draws out water and oleuropein through osmosis, yielding concentrated umami leather.",
    "expDe": "Salzentzug lässt die Oliven wie Rosinen einschrumpfen; das Aroma ist intensiv, salzig und fleischig."
  },
  {
    "id": "q_oli_08",
    "category": "olives",
    "questionEn": "What is Spanish Gordal olive nicknamed?",
    "questionDe": "Welchen Spitznamen trägt die spanische Gordal Sevillana-Olive?",
    "optionsEn": [
      "The Red Devil",
      "The Tiny Olive",
      "'The Fat One' (La Reina) due to its enormous jumbo size, meaty flesh, and juicy bite",
      "The Bitter Seed"
    ],
    "optionsDe": [
      "Der Rote Teufel",
      "Die Winzige",
      "'Die Dicke' (La Reina) wegen ihrer gigantischen Fruchtgröße und saftigen Fleischigkeit",
      "Der Bitterkern"
    ],
    "correctIndex": 2,
    "explanationEn": "Gordal means fat; its immense size makes it a dramatic showpiece on charcuterie boards.",
    "explanationDe": "Wegen ihres fleischigen Volumens wird die Gordal gerne mit Orangenstücken oder Knoblauch mariniert.",
    "qEn": "What is Spanish Gordal olive nicknamed?",
    "qDe": "Welchen Spitznamen trägt die spanische Gordal Sevillana-Olive?",
    "optEn": [
      "The Red Devil",
      "The Tiny Olive",
      "'The Fat One' (La Reina) due to its enormous jumbo size, meaty flesh, and juicy bite",
      "The Bitter Seed"
    ],
    "optDe": [
      "Der Rote Teufel",
      "Die Winzige",
      "'Die Dicke' (La Reina) wegen ihrer gigantischen Fruchtgröße und saftigen Fleischigkeit",
      "Der Bitterkern"
    ],
    "correct": 2,
    "expEn": "Gordal means fat; its immense size makes it a dramatic showpiece on charcuterie boards.",
    "expDe": "Wegen ihres fleischigen Volumens wird die Gordal gerne mit Orangenstücken oder Knoblauch mariniert."
  },
  {
    "id": "q_oli_09",
    "category": "olives",
    "questionEn": "What traditional dish utilizes chopped cured black olives, capers, anchovies, and olive oil?",
    "questionDe": "Welche provenzalische Paste besteht aus gehackten schwarzen Oliven, Kapern, Sardellen und Olivenöl?",
    "optionsEn": [
      "Guacamole",
      "Tapenade",
      "Hummus",
      "Aioli"
    ],
    "optionsDe": [
      "Guacamole",
      "Tapenade",
      "Hummus",
      "Aioli"
    ],
    "correctIndex": 1,
    "explanationEn": "Tapenade takes its name from tapeno (Provençal for caper), pounded into a rich rustic bread spread.",
    "explanationDe": "Tapenade ist die Königin der südfranzösischen Vorspeisen auf geröstetem Landbrot.",
    "qEn": "What traditional dish utilizes chopped cured black olives, capers, anchovies, and olive oil?",
    "qDe": "Welche provenzalische Paste besteht aus gehackten schwarzen Oliven, Kapern, Sardellen und Olivenöl?",
    "optEn": [
      "Guacamole",
      "Tapenade",
      "Hummus",
      "Aioli"
    ],
    "optDe": [
      "Guacamole",
      "Tapenade",
      "Hummus",
      "Aioli"
    ],
    "correct": 1,
    "expEn": "Tapenade takes its name from tapeno (Provençal for caper), pounded into a rich rustic bread spread.",
    "expDe": "Tapenade ist die Königin der südfranzösischen Vorspeisen auf geröstetem Landbrot."
  },
  {
    "id": "q_oli_09b",
    "category": "olives",
    "questionEn": "What role do natural polyphenols in table olives play in longevity diets?",
    "questionDe": "Welche gesundheitliche Rolle spielen die Polyphenole in naturbelassenen Oliven?",
    "optionsEn": [
      "Potent antioxidant and anti-inflammatory free-radical scavengers supporting heart and arterial health",
      "They add cholesterol",
      "They turn into sugar",
      "They destroy vitamins"
    ],
    "optionsDe": [
      "Starke Antioxidantien (Hydroxytyrosol), die Zellen schützen und Entzündungen hemmen",
      "Sie erhöhen Cholesterin",
      "Sie werden zu Zucker",
      "Sie zerstören Vitamine"
    ],
    "correctIndex": 0,
    "explanationEn": "Hydroxytyrosol in olives is among nature's most powerful cardiovascular antioxidants.",
    "explanationDe": "Polyphenole schützen das Olivenöl vor Oxidation und stärken die Gefäße des Menschen.",
    "qEn": "What role do natural polyphenols in table olives play in longevity diets?",
    "qDe": "Welche gesundheitliche Rolle spielen die Polyphenole in naturbelassenen Oliven?",
    "optEn": [
      "Potent antioxidant and anti-inflammatory free-radical scavengers supporting heart and arterial health",
      "They add cholesterol",
      "They turn into sugar",
      "They destroy vitamins"
    ],
    "optDe": [
      "Starke Antioxidantien (Hydroxytyrosol), die Zellen schützen und Entzündungen hemmen",
      "Sie erhöhen Cholesterin",
      "Sie werden zu Zucker",
      "Sie zerstören Vitamine"
    ],
    "correct": 0,
    "expEn": "Hydroxytyrosol in olives is among nature's most powerful cardiovascular antioxidants.",
    "expDe": "Polyphenole schützen das Olivenöl vor Oxidation und stärken die Gefäße des Menschen."
  },
  {
    "id": "q_oli_11",
    "category": "olives",
    "questionEn": "Why are cracked green olives (Alcaparras / Tsakistes) bruised with a mallet before brining?",
    "questionDe": "Warum werden grüne Oliven vor dem Einlegen oft mit einem Holzhammer angeklopft (Tsakistes)?",
    "optionsEn": [
      "To shape them flat",
      "To crack the stone inside",
      "To extract oil for frying",
      "Cracking the flesh allows brine and citrus marinades to penetrate deep into the pit, speeding debittering"
    ],
    "optionsDe": [
      "Damit sie flach werden",
      "Um den Stein zu zerschlagen",
      "Um Bratöl zu gewinnen",
      "Das Aufplatzen der Haut lässt Salzlake und Zitronenmarinade viel schneller zum Kern dringen"
    ],
    "correctIndex": 3,
    "explanationEn": "Cracked olives absorb garlic, coriander, and wild fennel seasonings in half the time.",
    "explanationDe": "Durch die Risse diffundiert das bittere Oleuropein rasch aus und Kräuteraromen ziehen tief ein.",
    "qEn": "Why are cracked green olives (Alcaparras / Tsakistes) bruised with a mallet before brining?",
    "qDe": "Warum werden grüne Oliven vor dem Einlegen oft mit einem Holzhammer angeklopft (Tsakistes)?",
    "optEn": [
      "To shape them flat",
      "To crack the stone inside",
      "To extract oil for frying",
      "Cracking the flesh allows brine and citrus marinades to penetrate deep into the pit, speeding debittering"
    ],
    "optDe": [
      "Damit sie flach werden",
      "Um den Stein zu zerschlagen",
      "Um Bratöl zu gewinnen",
      "Das Aufplatzen der Haut lässt Salzlake und Zitronenmarinade viel schneller zum Kern dringen"
    ],
    "correct": 3,
    "expEn": "Cracked olives absorb garlic, coriander, and wild fennel seasonings in half the time.",
    "expDe": "Durch die Risse diffundiert das bittere Oleuropein rasch aus und Kräuteraromen ziehen tief ein."
  },
  {
    "id": "q_oli_12",
    "category": "olives",
    "questionEn": "What gives Picholine olives from southern France their distinction?",
    "questionDe": "Was zeichnet französische Picholine-Oliven aus?",
    "optionsEn": [
      "Yellow sweet taste",
      "Squishy texture",
      "Firm elongated teardrop shape, pointed tip, crisp crunchy bite, and green herbal artichoke notes",
      "Smoky peat aroma"
    ],
    "optionsDe": [
      "Süßlicher Geschmack",
      "Matschige Textur",
      "Längliche spitze Tropfenform, fester knackiger Biss und frische Aromen von grüner Artischocke",
      "Raucharoma"
    ],
    "correctIndex": 2,
    "explanationEn": "Picholine yields crisp cocktail table olives and grassy peppery virgin olive oil.",
    "explanationDe": "Die feste Hülle und der nussig-grasige Geschmack machen die Picholine zum Liebling Südfrankreichs.",
    "qEn": "What gives Picholine olives from southern France their distinction?",
    "qDe": "Was zeichnet französische Picholine-Oliven aus?",
    "optEn": [
      "Yellow sweet taste",
      "Squishy texture",
      "Firm elongated teardrop shape, pointed tip, crisp crunchy bite, and green herbal artichoke notes",
      "Smoky peat aroma"
    ],
    "optDe": [
      "Süßlicher Geschmack",
      "Matschige Textur",
      "Längliche spitze Tropfenform, fester knackiger Biss und frische Aromen von grüner Artischocke",
      "Raucharoma"
    ],
    "correct": 2,
    "expEn": "Picholine yields crisp cocktail table olives and grassy peppery virgin olive oil.",
    "expDe": "Die feste Hülle und der nussig-grasige Geschmack machen die Picholine zum Liebling Südfrankreichs."
  },
  {
    "id": "q_oli_13",
    "category": "olives",
    "questionEn": "What is an olive pit (stone) botanically?",
    "questionDe": "Was ist der Olivenkern botanisch gesehen?",
    "optionsEn": [
      "A crystallized salt deposit",
      "The hard lignified endocarp protecting the inner reproductive seed",
      "A dried wooden twig",
      "A clump of starch"
    ],
    "optionsDe": [
      "Eine Salzkristallisation",
      "Das verholzte Endokarp (Stein), das den inneren Samen schützt",
      "Ein verholzter Zweig",
      "Ein Stärkeklumpen"
    ],
    "correctIndex": 1,
    "explanationEn": "Olives are drupes (stone fruits); the pericarp is flesh and the endocarp is the protective pit.",
    "explanationDe": "Wie Kirschen oder Pfirsiche sind Oliven Steinobst mit verholztem Kern im saftigen Fruchtfleisch.",
    "qEn": "What is an olive pit (stone) botanically?",
    "qDe": "Was ist der Olivenkern botanisch gesehen?",
    "optEn": [
      "A crystallized salt deposit",
      "The hard lignified endocarp protecting the inner reproductive seed",
      "A dried wooden twig",
      "A clump of starch"
    ],
    "optDe": [
      "Eine Salzkristallisation",
      "Das verholzte Endokarp (Stein), das den inneren Samen schützt",
      "Ein verholzter Zweig",
      "Ein Stärkeklumpen"
    ],
    "correct": 1,
    "expEn": "Olives are drupes (stone fruits); the pericarp is flesh and the endocarp is the protective pit.",
    "expDe": "Wie Kirschen oder Pfirsiche sind Oliven Steinobst mit verholztem Kern im saftigen Fruchtfleisch."
  },
  {
    "id": "q_oli_14",
    "category": "olives",
    "questionEn": "Why are stuffed cocktail olives traditionally paired with the Dry Martini?",
    "questionDe": "Warum harmonieren Oliven perfekt mit einem klassischen Dry Martini?",
    "optionsEn": [
      "The savory olive brine salinity and oily coating contrast and smooth the dry juniper ethanol punch of gin",
      "Olives cool the drink down",
      "Olives add sugar",
      "Olives turn gin blue"
    ],
    "optionsDe": [
      "Die feine Salzigkeit und das Olivenöl puffern die scharfe Wacholder-Trockenheit des Gins harmonisch ab",
      "Oliven kühlen den Drink",
      "Oliven süßen den Drink",
      "Oliven färben den Gin blau"
    ],
    "correctIndex": 0,
    "explanationEn": "Olive brine balances dry vermouth botanicals; a 'Dirty Martini' adds a barspoon of olive brine directly.",
    "explanationDe": "Das Salz und die Lipide runden den Alkohol ab und machen den Martini unnachahmlich pikant.",
    "qEn": "Why are stuffed cocktail olives traditionally paired with the Dry Martini?",
    "qDe": "Warum harmonieren Oliven perfekt mit einem klassischen Dry Martini?",
    "optEn": [
      "The savory olive brine salinity and oily coating contrast and smooth the dry juniper ethanol punch of gin",
      "Olives cool the drink down",
      "Olives add sugar",
      "Olives turn gin blue"
    ],
    "optDe": [
      "Die feine Salzigkeit und das Olivenöl puffern die scharfe Wacholder-Trockenheit des Gins harmonisch ab",
      "Oliven kühlen den Drink",
      "Oliven süßen den Drink",
      "Oliven färben den Gin blau"
    ],
    "correct": 0,
    "expEn": "Olive brine balances dry vermouth botanicals; a 'Dirty Martini' adds a barspoon of olive brine directly.",
    "expDe": "Das Salz und die Lipide runden den Alkohol ab und machen den Martini unnachahmlich pikant."
  },
  {
    "id": "q_oli_15",
    "category": "olives",
    "questionEn": "What is the Lucques olive from Languedoc famous for?",
    "questionDe": "Wofür ist die französische Lucques-Olive aus dem Languedoc berühmt?",
    "optionsEn": [
      "Bitter vinegar taste",
      "Black square shape",
      "Chili spice",
      "Distinctive curved crescent-moon shape, bright green skin, and sweet fresh avocado-almond flavor"
    ],
    "optionsDe": [
      "Essiggeschmack",
      "Schwarze Würfelform",
      "Chilischärfe",
      "Halbmondförmige, geschwungene Silhouette und sahnig-milder Geschmack nach Avocado und frischer Mandel"
    ],
    "correctIndex": 3,
    "explanationEn": "Known as the 'Green Diamond' of Languedoc, difficult to harvest but unmatched in creamy crunch.",
    "explanationDe": "Wegen ihrer geschwungenen Mondsichel-Form und Buttrigkeit gilt sie als Haute-Cuisine-Delikatesse.",
    "qEn": "What is the Lucques olive from Languedoc famous for?",
    "qDe": "Wofür ist die französische Lucques-Olive aus dem Languedoc berühmt?",
    "optEn": [
      "Bitter vinegar taste",
      "Black square shape",
      "Chili spice",
      "Distinctive curved crescent-moon shape, bright green skin, and sweet fresh avocado-almond flavor"
    ],
    "optDe": [
      "Essiggeschmack",
      "Schwarze Würfelform",
      "Chilischärfe",
      "Halbmondförmige, geschwungene Silhouette und sahnig-milder Geschmack nach Avocado und frischer Mandel"
    ],
    "correct": 3,
    "expEn": "Known as the 'Green Diamond' of Languedoc, difficult to harvest but unmatched in creamy crunch.",
    "expDe": "Wegen ihrer geschwungenen Mondsichel-Form und Buttrigkeit gilt sie als Haute-Cuisine-Delikatesse."
  },
  {
    "id": "q_oli_16",
    "category": "olives",
    "questionEn": "How does olive harvesting time affect olive oil character?",
    "questionDe": "Wie beeinflusst der Erntezeitpunkt den Charakter des Olivenöls?",
    "optionsEn": [
      "Late olives have no oil",
      "Early olives yield vinegar",
      "Early harvest green olives yield peppery, bitter, high-polyphenol grass oil; late black olives yield mild, golden, buttery oil",
      "Harvest time has zero effect"
    ],
    "optionsDe": [
      "Späte haben kein Öl",
      "Frühe Oliven ergeben Essig",
      "Früh geerntete grüne Oliven ergeben pfeffrig-herbes, polyphenolreiches Öl; späte reife Oliven mild-buttriges Öl",
      "Erntezeitpunkt ist egal"
    ],
    "correctIndex": 2,
    "explanationEn": "Early harvest ('Raccolto precoce') sacrifices yield for explosive grassy piquancy and high antioxidants.",
    "explanationDe": "Grün gepflückt duftet das Öl nach Artischocke und Tomatenblatt mit pfeffrigem Kratzen im Hals.",
    "qEn": "How does olive harvesting time affect olive oil character?",
    "qDe": "Wie beeinflusst der Erntezeitpunkt den Charakter des Olivenöls?",
    "optEn": [
      "Late olives have no oil",
      "Early olives yield vinegar",
      "Early harvest green olives yield peppery, bitter, high-polyphenol grass oil; late black olives yield mild, golden, buttery oil",
      "Harvest time has zero effect"
    ],
    "optDe": [
      "Späte haben kein Öl",
      "Frühe Oliven ergeben Essig",
      "Früh geerntete grüne Oliven ergeben pfeffrig-herbes, polyphenolreiches Öl; späte reife Oliven mild-buttriges Öl",
      "Erntezeitpunkt ist egal"
    ],
    "correct": 2,
    "expEn": "Early harvest ('Raccolto precoce') sacrifices yield for explosive grassy piquancy and high antioxidants.",
    "expDe": "Grün gepflückt duftet das Öl nach Artischocke und Tomatenblatt mit pfeffrigem Kratzen im Hals."
  },
  {
    "id": "q_oli_17",
    "category": "olives",
    "questionEn": "What gives Gaeta olives from Lazio their Italian fame?",
    "questionDe": "Was zeichnet Gaeta-Oliven aus dem italienischen Latium aus?",
    "optionsEn": [
      "Bright green spicy olives",
      "Purplish-black soft wrinkly olives cured in sea salt and water, starring in Pasta alla Puttanesca",
      "Stuffed with cheese",
      "Deep fried in dough"
    ],
    "optionsDe": [
      "Helltürkise Chiligemüse",
      "Violettschwarze, weiche Oliven mit feiner Würze, der Star in echter Pasta alla Puttanesca",
      "Mit Käse gefüllt",
      "Im Teigmantel frittiert"
    ],
    "correctIndex": 1,
    "explanationEn": "Gaeta olives deliver deep savory fruitiness that harmonizes with capers, garlic, and tomato sauce.",
    "explanationDe": "In der Puttanesca verschmilzt die weiche Gaeta-Olive mit Sardellen und Tomaten zu purer Harmonie.",
    "qEn": "What gives Gaeta olives from Lazio their Italian fame?",
    "qDe": "Was zeichnet Gaeta-Oliven aus dem italienischen Latium aus?",
    "optEn": [
      "Bright green spicy olives",
      "Purplish-black soft wrinkly olives cured in sea salt and water, starring in Pasta alla Puttanesca",
      "Stuffed with cheese",
      "Deep fried in dough"
    ],
    "optDe": [
      "Helltürkise Chiligemüse",
      "Violettschwarze, weiche Oliven mit feiner Würze, der Star in echter Pasta alla Puttanesca",
      "Mit Käse gefüllt",
      "Im Teigmantel frittiert"
    ],
    "correct": 1,
    "expEn": "Gaeta olives deliver deep savory fruitiness that harmonizes with capers, garlic, and tomato sauce.",
    "expDe": "In der Puttanesca verschmilzt die weiche Gaeta-Olive mit Sardellen und Tomaten zu purer Harmonie."
  },
  {
    "id": "q_oli_18",
    "category": "olives",
    "questionEn": "Why is brine-fermented table olive production considered a biological lactic fermentation?",
    "questionDe": "Warum ist die traditionelle Olivenentbitterung eine echte biologische Milchsäurefermentation?",
    "optionsEn": [
      "Natural airborne Lactobacillus and yeasts ferment fruit sugars into lactic acid in salt brine, preserving olives naturally",
      "Chemical bleach is added",
      "Alcoholic brewer yeast ferments beer",
      "Vinegar boils the olives"
    ],
    "optionsDe": [
      "Natürliche Milchsäurebakterien und Hefen vergären Fruchtzucker in der Salzlake zu konservierender Milchsäure",
      "Bleichmittel wird zugefügt",
      "Bierhefe gärt Alkohol",
      "Kochender Essig sterilisiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Lactic acid drops pH below 4.5, naturally preserving olives with complex savory depth without pasteurization.",
    "explanationDe": "Ähnlich wie bei Sauerkraut senkt die Milchsäure den pH-Wert und macht die Oliven haltbar und aromatisch.",
    "qEn": "Why is brine-fermented table olive production considered a biological lactic fermentation?",
    "qDe": "Warum ist die traditionelle Olivenentbitterung eine echte biologische Milchsäurefermentation?",
    "optEn": [
      "Natural airborne Lactobacillus and yeasts ferment fruit sugars into lactic acid in salt brine, preserving olives naturally",
      "Chemical bleach is added",
      "Alcoholic brewer yeast ferments beer",
      "Vinegar boils the olives"
    ],
    "optDe": [
      "Natürliche Milchsäurebakterien und Hefen vergären Fruchtzucker in der Salzlake zu konservierender Milchsäure",
      "Bleichmittel wird zugefügt",
      "Bierhefe gärt Alkohol",
      "Kochender Essig sterilisiert"
    ],
    "correct": 0,
    "expEn": "Lactic acid drops pH below 4.5, naturally preserving olives with complex savory depth without pasteurization.",
    "expDe": "Ähnlich wie bei Sauerkraut senkt die Milchsäure den pH-Wert und macht die Oliven haltbar und aromatisch."
  },
  {
    "id": "q_oil_01",
    "category": "oils_vinegars",
    "questionEn": "What is the legal maximum free acidity (as oleic acid) for Extra Virgin Olive Oil (EVOO)?",
    "questionDe": "Wie hoch darf der freie Säuregehalt (Ölsäure) bei 'Natives Olivenöl Extra' gesetzlich maximal sein?",
    "optionsEn": [
      "Zero tolerance 0.00%",
      "Max 3.3%",
      "Max 10%",
      "Max 0.8% (0.8g per 100g); premium artisanal oils achieve under 0.2-0.3%"
    ],
    "optionsDe": [
      "Exakt 0,00%",
      "Maximal 3,3%",
      "Maximal 10%",
      "Maximal 0,8% (Spitzenöle liegen meist unter 0,2–0,3%)"
    ],
    "correctIndex": 3,
    "explanationEn": "Low acidity proves pristine, undamaged olives milled immediately without fermentation.",
    "explanationDe": "Niedrige freie Fettsäuren beweisen makellose, gesunde Oliven, die ohne Verzögerung gepresst wurden.",
    "qEn": "What is the legal maximum free acidity (as oleic acid) for Extra Virgin Olive Oil (EVOO)?",
    "qDe": "Wie hoch darf der freie Säuregehalt (Ölsäure) bei 'Natives Olivenöl Extra' gesetzlich maximal sein?",
    "optEn": [
      "Zero tolerance 0.00%",
      "Max 3.3%",
      "Max 10%",
      "Max 0.8% (0.8g per 100g); premium artisanal oils achieve under 0.2-0.3%"
    ],
    "optDe": [
      "Exakt 0,00%",
      "Maximal 3,3%",
      "Maximal 10%",
      "Maximal 0,8% (Spitzenöle liegen meist unter 0,2–0,3%)"
    ],
    "correct": 3,
    "expEn": "Low acidity proves pristine, undamaged olives milled immediately without fermentation.",
    "expDe": "Niedrige freie Fettsäuren beweisen makellose, gesunde Oliven, die ohne Verzögerung gepresst wurden."
  },
  {
    "id": "q_oil_02",
    "category": "oils_vinegars",
    "questionEn": "What causes the peaty peppery burn at the back of the throat when tasting great fresh EVOO?",
    "questionDe": "Was erzeugt das typische pfeffrige Kratzen im Hals bei frischem Spitzen-Olivenöl?",
    "optionsEn": [
      "Rancid spoiled fats",
      "Added chili extract",
      "Oleocanthal, a natural phenolic compound with potent anti-inflammatory effects identical to ibuprofen",
      "High alcohol content"
    ],
    "optionsDe": [
      "Verdorbenes ranziges Fett",
      "Zusatz von Chili",
      "Oleocanthal, ein entzündungshemmendes Polyphenol mit ibuprofen-ähnlicher Wirkung",
      "Hoher Alkoholgehalt"
    ],
    "correctIndex": 2,
    "explanationEn": "Oleocanthal stimulates the exact same pharyngeal receptors as ibuprofen; it is a mark of top quality.",
    "explanationDe": "Das Hustenreizen im Rachen beweist einen hohen Gehalt an bioaktivem, gesundheitsförderndem Oleocanthal.",
    "qEn": "What causes the peaty peppery burn at the back of the throat when tasting great fresh EVOO?",
    "qDe": "Was erzeugt das typische pfeffrige Kratzen im Hals bei frischem Spitzen-Olivenöl?",
    "optEn": [
      "Rancid spoiled fats",
      "Added chili extract",
      "Oleocanthal, a natural phenolic compound with potent anti-inflammatory effects identical to ibuprofen",
      "High alcohol content"
    ],
    "optDe": [
      "Verdorbenes ranziges Fett",
      "Zusatz von Chili",
      "Oleocanthal, ein entzündungshemmendes Polyphenol mit ibuprofen-ähnlicher Wirkung",
      "Hoher Alkoholgehalt"
    ],
    "correct": 2,
    "expEn": "Oleocanthal stimulates the exact same pharyngeal receptors as ibuprofen; it is a mark of top quality.",
    "expDe": "Das Hustenreizen im Rachen beweist einen hohen Gehalt an bioaktivem, gesundheitsförderndem Oleocanthal."
  },
  {
    "id": "q_oil_03",
    "category": "oils_vinegars",
    "questionEn": "What does 'Cold Pressed / Cold Extracted' mean under EU olive oil law?",
    "questionDe": "Was bedeutet die Angabe 'Kaltextraktion' bei Olivenöl gesetzlich?",
    "optionsEn": [
      "Pressed with ice cubes",
      "Milling and centrifugation conducted strictly below 27°C (80.6°F) to preserve volatile aromatics and antioxidants",
      "Harvested in winter frost",
      "Stored in freezers"
    ],
    "optionsDe": [
      "Mit Eiswürfeln gepresst",
      "Verarbeitung und Zentrifugation bei maximal 27°C zur Schonung von Aromen und Vitaminen",
      "Bei Frost geerntet",
      "Im Gefrierfach gelagert"
    ],
    "correctIndex": 1,
    "explanationEn": "Temperatures above 27°C yield more oil volume but degrade delicate polyphenols and grassy esters.",
    "explanationDe": "Über 27°C steigt die Ausbeute, aber die feinen Fruchtaromen und hitzeempfindlichen Polyphenole verbrennen.",
    "qEn": "What does 'Cold Pressed / Cold Extracted' mean under EU olive oil law?",
    "qDe": "Was bedeutet die Angabe 'Kaltextraktion' bei Olivenöl gesetzlich?",
    "optEn": [
      "Pressed with ice cubes",
      "Milling and centrifugation conducted strictly below 27°C (80.6°F) to preserve volatile aromatics and antioxidants",
      "Harvested in winter frost",
      "Stored in freezers"
    ],
    "optDe": [
      "Mit Eiswürfeln gepresst",
      "Verarbeitung und Zentrifugation bei maximal 27°C zur Schonung von Aromen und Vitaminen",
      "Bei Frost geerntet",
      "Im Gefrierfach gelagert"
    ],
    "correct": 1,
    "expEn": "Temperatures above 27°C yield more oil volume but degrade delicate polyphenols and grassy esters.",
    "expDe": "Über 27°C steigt die Ausbeute, aber die feinen Fruchtaromen und hitzeempfindlichen Polyphenole verbrennen."
  },
  {
    "id": "q_oil_04",
    "category": "oils_vinegars",
    "questionEn": "How is authentic Aceto Balsamico Tradizionale di Modena DOP produced?",
    "questionDe": "Wie wird echter traditioneller Aceto Balsamico Tradizionale DOP hergestellt?",
    "optionsEn": [
      "Cooked Trebbiano/Lambrusco grape must aged for at least 12 to 25+ years in batteries of graduating wood barrels",
      "Wine vinegar dyed with caramel",
      "Boiled balsamic syrup",
      "Cider vinegar aged in steel"
    ],
    "optionsDe": [
      "Eingekochter Traubenmost reift mindestens 12 bis 25 Jahre kaskadierend in einer Holzfass-Batterie",
      "Weinessig mit Zuckerkulör",
      "Eingedickter Balsamicosirup",
      "Apfelessig im Stahltank"
    ],
    "correctIndex": 0,
    "explanationEn": "Transferred through oak, chestnut, cherry, ash, and mulberry casks; evaporation creates syrupy nectar.",
    "explanationDe": "Das jährliche Umfüllen in immer kleinere Fässer aus verschiedenen Hölzern schenkt unvergleichliche Dichte.",
    "qEn": "How is authentic Aceto Balsamico Tradizionale di Modena DOP produced?",
    "qDe": "Wie wird echter traditioneller Aceto Balsamico Tradizionale DOP hergestellt?",
    "optEn": [
      "Cooked Trebbiano/Lambrusco grape must aged for at least 12 to 25+ years in batteries of graduating wood barrels",
      "Wine vinegar dyed with caramel",
      "Boiled balsamic syrup",
      "Cider vinegar aged in steel"
    ],
    "optDe": [
      "Eingekochter Traubenmost reift mindestens 12 bis 25 Jahre kaskadierend in einer Holzfass-Batterie",
      "Weinessig mit Zuckerkulör",
      "Eingedickter Balsamicosirup",
      "Apfelessig im Stahltank"
    ],
    "correct": 0,
    "expEn": "Transferred through oak, chestnut, cherry, ash, and mulberry casks; evaporation creates syrupy nectar.",
    "expDe": "Das jährliche Umfüllen in immer kleinere Fässer aus verschiedenen Hölzern schenkt unvergleichliche Dichte."
  },
  {
    "id": "q_oil_05",
    "category": "oils_vinegars",
    "questionEn": "What distinguishes commercial 'Aceto Balsamico di Modena IGP' from traditional DOP?",
    "questionDe": "Was unterscheidet billigen Supermarkt-Balsamico IGP vom traditionellen DOP-Balsamico?",
    "optionsEn": [
      "IGP is 100 years old",
      "IGP contains olive oil",
      "IGP is made of apples",
      "IGP is a blend of wine vinegar and concentrated must aged only 60 days to 3 years; caramel color is permitted"
    ],
    "optionsDe": [
      "IGP ist 100 Jahre alt",
      "IGP enthält Olivenöl",
      "IGP besteht aus Äpfeln",
      "IGP ist ein Verschnitt aus Weinessig und Traubenmost, reift oft nur 60 Tage; Zuckerkulör ist erlaubt"
    ],
    "correctIndex": 3,
    "explanationEn": "Commercial IGP is fluid and tart for daily salads; thick syrupy DOP is savored drop by drop over Parmesan.",
    "explanationDe": "Industrieller IGP-Balsamico ist dünnflüssig; dickflüssiger DOP-Tradizionale wird tropfenweise genossen.",
    "qEn": "What distinguishes commercial 'Aceto Balsamico di Modena IGP' from traditional DOP?",
    "qDe": "Was unterscheidet billigen Supermarkt-Balsamico IGP vom traditionellen DOP-Balsamico?",
    "optEn": [
      "IGP is 100 years old",
      "IGP contains olive oil",
      "IGP is made of apples",
      "IGP is a blend of wine vinegar and concentrated must aged only 60 days to 3 years; caramel color is permitted"
    ],
    "optDe": [
      "IGP ist 100 Jahre alt",
      "IGP enthält Olivenöl",
      "IGP besteht aus Äpfeln",
      "IGP ist ein Verschnitt aus Weinessig und Traubenmost, reift oft nur 60 Tage; Zuckerkulör ist erlaubt"
    ],
    "correct": 3,
    "expEn": "Commercial IGP is fluid and tart for daily salads; thick syrupy DOP is savored drop by drop over Parmesan.",
    "expDe": "Industrieller IGP-Balsamico ist dünnflüssig; dickflüssiger DOP-Tradizionale wird tropfenweise genossen."
  },
  {
    "id": "q_oil_06",
    "category": "oils_vinegars",
    "questionEn": "Why does cold-pressed Pumpkin Seed Oil (Kürbiskernöl) appear dark green in a spoon but ruby red in bright light?",
    "questionDe": "Warum schimmert steirisches Kürbiskernöl im Löffel dunkelgrün, im Gegenlicht aber rubinrot?",
    "optionsEn": [
      "Bleeding oil defect",
      "Artificial food dye",
      "Dichromatism (dichromatic optical effect caused by chlorophyll and protochlorophyll absorption spectra)",
      "Chemical refraction error"
    ],
    "optionsDe": [
      "Ölfehler",
      "Künstlicher Farbstoff",
      "Dichromatismus: ein physikalisches Phänomen, bei dem die Farbwahrnehmung von der Schichtdicke abhängt",
      "Lichtbrechungsfehler"
    ],
    "correctIndex": 2,
    "explanationEn": "Thin films let red light wavelengths pass; thick layers absorb all light except deep forest green.",
    "explanationDe": "In dünner Schicht leuchtet es rot, in dicker Schicht tief smaragdgrün: ein Zeichen höchster Reinheit.",
    "qEn": "Why does cold-pressed Pumpkin Seed Oil (Kürbiskernöl) appear dark green in a spoon but ruby red in bright light?",
    "qDe": "Warum schimmert steirisches Kürbiskernöl im Löffel dunkelgrün, im Gegenlicht aber rubinrot?",
    "optEn": [
      "Bleeding oil defect",
      "Artificial food dye",
      "Dichromatism (dichromatic optical effect caused by chlorophyll and protochlorophyll absorption spectra)",
      "Chemical refraction error"
    ],
    "optDe": [
      "Ölfehler",
      "Künstlicher Farbstoff",
      "Dichromatismus: ein physikalisches Phänomen, bei dem die Farbwahrnehmung von der Schichtdicke abhängt",
      "Lichtbrechungsfehler"
    ],
    "correct": 2,
    "expEn": "Thin films let red light wavelengths pass; thick layers absorb all light except deep forest green.",
    "expDe": "In dünner Schicht leuchtet es rot, in dicker Schicht tief smaragdgrün: ein Zeichen höchster Reinheit."
  },
  {
    "id": "q_oil_07",
    "category": "oils_vinegars",
    "questionEn": "What is the culinary smoke point of refined peanut oil versus extra virgin olive oil?",
    "questionDe": "Wie unterscheidet sich der Rauchpunkt von raffiniertem Erdnussöl von unfiltriertem Olivenöl?",
    "optionsEn": [
      "Both smoke at 100°C",
      "Refined peanut oil has a high smoke point (~230°C / 450°F); unrefined EVOO smokes around 180-190°C",
      "Olive oil never smokes",
      "Peanut oil smokes at 60°C"
    ],
    "optionsDe": [
      "Beide rauchen ab 100°C",
      "Raffiniertes Erdnussöl hat einen hohen Rauchpunkt (~230°C); unfiltriertes Olivenöl raucht ab ca. 180–190°C",
      "Olivenöl raucht nie",
      "Erdnussöl raucht bei 60°C"
    ],
    "correctIndex": 1,
    "explanationEn": "Refining removes free fatty acids and solids, enabling high-heat stir-frying and deep-frying without burning.",
    "explanationDe": "Raffiniertes Öl ist hitzestabil für Wok und Fritteuse; Rohöle verbrennen bei starker Hitze.",
    "qEn": "What is the culinary smoke point of refined peanut oil versus extra virgin olive oil?",
    "qDe": "Wie unterscheidet sich der Rauchpunkt von raffiniertem Erdnussöl von unfiltriertem Olivenöl?",
    "optEn": [
      "Both smoke at 100°C",
      "Refined peanut oil has a high smoke point (~230°C / 450°F); unrefined EVOO smokes around 180-190°C",
      "Olive oil never smokes",
      "Peanut oil smokes at 60°C"
    ],
    "optDe": [
      "Beide rauchen ab 100°C",
      "Raffiniertes Erdnussöl hat einen hohen Rauchpunkt (~230°C); unfiltriertes Olivenöl raucht ab ca. 180–190°C",
      "Olivenöl raucht nie",
      "Erdnussöl raucht bei 60°C"
    ],
    "correct": 1,
    "expEn": "Refining removes free fatty acids and solids, enabling high-heat stir-frying and deep-frying without burning.",
    "expDe": "Raffiniertes Öl ist hitzestabil für Wok und Fritteuse; Rohöle verbrennen bei starker Hitze."
  },
  {
    "id": "q_oil_08",
    "category": "oils_vinegars",
    "questionEn": "What makes Toasted Sesame Oil indispensable in Asian finishing seasoning?",
    "questionDe": "Warum wird dunkles geröstetes Sesamöl in der asiatischen Küche erst am Schluss zugegeben?",
    "optionsEn": [
      "Deep nutty aroma compounds decompose and turn bitter if used for high-heat frying; it is a finishing aroma oil",
      "It is explosive at high heat",
      "It is a solid wax",
      "It evaporates instantly"
    ],
    "optionsDe": [
      "Die intensiven Röstaromen verbrennen bei hoher Brathitze; es dient als reines Würzöl zum Parfümieren",
      "Es explodiert bei Hitze",
      "Es ist fest wie Wachs",
      "Es verdampft sofort"
    ],
    "correctIndex": 0,
    "explanationEn": "Rich in sesamol antioxidants; a few drops off the heat infuse stir-fries, ramen, and marinades with toasted depth.",
    "explanationDe": "Ein paar Tropfen über die fertige Suppe oder das Wokgericht genügen für nussige Perfektion.",
    "qEn": "What makes Toasted Sesame Oil indispensable in Asian finishing seasoning?",
    "qDe": "Warum wird dunkles geröstetes Sesamöl in der asiatischen Küche erst am Schluss zugegeben?",
    "optEn": [
      "Deep nutty aroma compounds decompose and turn bitter if used for high-heat frying; it is a finishing aroma oil",
      "It is explosive at high heat",
      "It is a solid wax",
      "It evaporates instantly"
    ],
    "optDe": [
      "Die intensiven Röstaromen verbrennen bei hoher Brathitze; es dient als reines Würzöl zum Parfümieren",
      "Es explodiert bei Hitze",
      "Es ist fest wie Wachs",
      "Es verdampft sofort"
    ],
    "correct": 0,
    "expEn": "Rich in sesamol antioxidants; a few drops off the heat infuse stir-fries, ramen, and marinades with toasted depth.",
    "expDe": "Ein paar Tropfen über die fertige Suppe oder das Wokgericht genügen für nussige Perfektion."
  },
  {
    "id": "q_oil_09",
    "category": "oils_vinegars",
    "questionEn": "What is Sherry Vinegar (Vinagre de Jerez DOP) aged in?",
    "questionDe": "Worin reift echter spanischer Sherry-Essig (Vinagre de Jerez DOP)?",
    "optionsEn": [
      "Stainless steel silos",
      "Plastic tanks",
      "Glass demijohns in the sun",
      "American oak barrels using the traditional Criaderas and Solera system for up to 10-20+ years"
    ],
    "optionsDe": [
      "In Stahltanks",
      "In Plastikfässern",
      "In Glasballons an der Sonne",
      "In Fässern aus amerikanischer Eiche nach dem Solera-Verfahren für mindestens 2 bis über 20 Jahre"
    ],
    "correctIndex": 3,
    "explanationEn": "Solera aging concentrates acetic acid and wood vanillins, creating mahogany color and complex dry nutty finish.",
    "explanationDe": "Das Solera-Verfahren verleiht dem Sherry-Essig Holzaromen, Nuancen von Nüssen und samtige Säure.",
    "qEn": "What is Sherry Vinegar (Vinagre de Jerez DOP) aged in?",
    "qDe": "Worin reift echter spanischer Sherry-Essig (Vinagre de Jerez DOP)?",
    "optEn": [
      "Stainless steel silos",
      "Plastic tanks",
      "Glass demijohns in the sun",
      "American oak barrels using the traditional Criaderas and Solera system for up to 10-20+ years"
    ],
    "optDe": [
      "In Stahltanks",
      "In Plastikfässern",
      "In Glasballons an der Sonne",
      "In Fässern aus amerikanischer Eiche nach dem Solera-Verfahren für mindestens 2 bis über 20 Jahre"
    ],
    "correct": 3,
    "expEn": "Solera aging concentrates acetic acid and wood vanillins, creating mahogany color and complex dry nutty finish.",
    "expDe": "Das Solera-Verfahren verleiht dem Sherry-Essig Holzaromen, Nuancen von Nüssen und samtige Säure."
  },
  {
    "id": "q_oil_10",
    "category": "oils_vinegars",
    "questionEn": "Why is Walnut Oil (Walnussöl) never used for high-heat frying?",
    "questionDe": "Warum darf kaltgepresstes Walnussöl niemals zum Braten verwendet werden?",
    "optionsEn": [
      "It turns into sugar",
      "It explodes in pans",
      "Extremely high in polyunsaturated fatty acids with a low smoke point (160°C); heat destroys omega-3s and creates bitter toxins",
      "It evaporates like alcohol"
    ],
    "optionsDe": [
      "Es wird zu Zucker",
      "Es explodiert in der Pfanne",
      "Sehr empfindliche mehrfach ungesättigte Fettsäuren verbrennen ab 160°C und bilden Schadstoffe",
      "Es verdampft wie Alkohol"
    ],
    "correctIndex": 2,
    "explanationEn": "Precious walnut oil is an exquisite finishing oil for root vegetable salads, goat cheese, and pumpkin soup.",
    "explanationDe": "Walnussöl gehört als kaltes Veredelungsöl über Feldsalat, Ziegenkäse oder feines Wurzelgemüse.",
    "qEn": "Why is Walnut Oil (Walnussöl) never used for high-heat frying?",
    "qDe": "Warum darf kaltgepresstes Walnussöl niemals zum Braten verwendet werden?",
    "optEn": [
      "It turns into sugar",
      "It explodes in pans",
      "Extremely high in polyunsaturated fatty acids with a low smoke point (160°C); heat destroys omega-3s and creates bitter toxins",
      "It evaporates like alcohol"
    ],
    "optDe": [
      "Es wird zu Zucker",
      "Es explodiert in der Pfanne",
      "Sehr empfindliche mehrfach ungesättigte Fettsäuren verbrennen ab 160°C und bilden Schadstoffe",
      "Es verdampft wie Alkohol"
    ],
    "correct": 2,
    "expEn": "Precious walnut oil is an exquisite finishing oil for root vegetable salads, goat cheese, and pumpkin soup.",
    "expDe": "Walnussöl gehört als kaltes Veredelungsöl über Feldsalat, Ziegenkäse oder feines Wurzelgemüse."
  },
  {
    "id": "q_oil_11",
    "category": "oils_vinegars",
    "questionEn": "What gives Japanese Rice Vinegar (Komezu) its culinary gentleness?",
    "questionDe": "Was macht japanischen Reisessig (Komezu) so bemerkenswert mild?",
    "optionsEn": [
      "Contains no acid at all",
      "Lower acetic acid concentration (~4-4.5% acidity) compared to European vinegars (6-8%), with sweet amino acid finish",
      "Diluted with 90% water",
      "Sweetened with corn syrup"
    ],
    "optionsDe": [
      "Enthält gar keine Säure",
      "Geringerer Säuregehalt (~4–4,5%) im Vergleich zu europäischem Essig (6–8%) und feine Umami-Aminosäuren",
      "Besteht zu 90% aus Wasser",
      "Mit Maissirup gesüßt"
    ],
    "correctIndex": 1,
    "explanationEn": "Soft acidity prevents curdling and perfectly seasons delicate sushi rice without overwhelming raw fish.",
    "explanationDe": "Milder Reisessig unterstreicht die Frische von rohem Fisch und würzt Sushireis harmonisch.",
    "qEn": "What gives Japanese Rice Vinegar (Komezu) its culinary gentleness?",
    "qDe": "Was macht japanischen Reisessig (Komezu) so bemerkenswert mild?",
    "optEn": [
      "Contains no acid at all",
      "Lower acetic acid concentration (~4-4.5% acidity) compared to European vinegars (6-8%), with sweet amino acid finish",
      "Diluted with 90% water",
      "Sweetened with corn syrup"
    ],
    "optDe": [
      "Enthält gar keine Säure",
      "Geringerer Säuregehalt (~4–4,5%) im Vergleich zu europäischem Essig (6–8%) und feine Umami-Aminosäuren",
      "Besteht zu 90% aus Wasser",
      "Mit Maissirup gesüßt"
    ],
    "correct": 1,
    "expEn": "Soft acidity prevents curdling and perfectly seasons delicate sushi rice without overwhelming raw fish.",
    "expDe": "Milder Reisessig unterstreicht die Frische von rohem Fisch und würzt Sushireis harmonisch."
  },
  {
    "id": "q_oil_12",
    "category": "oils_vinegars",
    "questionEn": "What is the biological role of the 'Mother of Vinegar' (Essigmutter)?",
    "questionDe": "Was ist die 'Essigmutter' bei der traditionellen Essigbereitung?",
    "optionsEn": [
      "A cellulose biofilm mat of symbiotic acetic acid bacteria (Acetobacter) that oxidize ethanol into acetic acid",
      "A fungal spore tablet",
      "A piece of yeast bread",
      "Mother plant roots"
    ],
    "optionsDe": [
      "Eine gallertartige Schicht aus Essigsäurebakterien (Acetobacter), die Alkohol mit Sauerstoff zu Essig veratmen",
      "Eine Schimmelpilztablette",
      "Ein Stück Sauerteigbrot",
      "Wurzeln der Mutterpflanze"
    ],
    "correctIndex": 0,
    "explanationEn": "Acetobacter colonies float at the liquid surface to access atmospheric oxygen, converting wine to vinegar.",
    "explanationDe": "Die Bakterien benötigen Sauerstoff und wandeln Wein oder Apfelmost auf natürliche Weise in Essig um.",
    "qEn": "What is the biological role of the 'Mother of Vinegar' (Essigmutter)?",
    "qDe": "Was ist die 'Essigmutter' bei der traditionellen Essigbereitung?",
    "optEn": [
      "A cellulose biofilm mat of symbiotic acetic acid bacteria (Acetobacter) that oxidize ethanol into acetic acid",
      "A fungal spore tablet",
      "A piece of yeast bread",
      "Mother plant roots"
    ],
    "optDe": [
      "Eine gallertartige Schicht aus Essigsäurebakterien (Acetobacter), die Alkohol mit Sauerstoff zu Essig veratmen",
      "Eine Schimmelpilztablette",
      "Ein Stück Sauerteigbrot",
      "Wurzeln der Mutterpflanze"
    ],
    "correct": 0,
    "expEn": "Acetobacter colonies float at the liquid surface to access atmospheric oxygen, converting wine to vinegar.",
    "expDe": "Die Bakterien benötigen Sauerstoff und wandeln Wein oder Apfelmost auf natürliche Weise in Essig um."
  },
  {
    "id": "q_oil_13",
    "category": "oils_vinegars",
    "questionEn": "Why is Flaxseed Oil (Leinöl) stored in dark refrigerated bottles and consumed within weeks?",
    "questionDe": "Warum muss Leinöl im Kühlschrank aufbewahrt und rasch verbraucht werden?",
    "optionsEn": [
      "Bacteria grow inside",
      "It turns toxic instantly",
      "It freezes into solid ice",
      "Contains over 50% alpha-linolenic omega-3 acid, which oxidizes rapidly into bitter compounds upon exposure to light and warmth"
    ],
    "optionsDe": [
      "Bakterien vermehren sich",
      "Wird sofort giftig",
      "Gefriert zu Eis",
      "Über 50% Alpha-Linolensäure (Omega-3) oxidieren bei Licht und Wärme extrem schnell zu bitterem Firnis"
    ],
    "correctIndex": 3,
    "explanationEn": "Fresh Leinöl has a sweet, nutty, grassy taste; oxidized oil tastes bitter like floor varnish.",
    "explanationDe": "Frisches Leinöl schmeckt buttrig-nussig und ist der gesunde Star zu Quark und Pellkartoffeln.",
    "qEn": "Why is Flaxseed Oil (Leinöl) stored in dark refrigerated bottles and consumed within weeks?",
    "qDe": "Warum muss Leinöl im Kühlschrank aufbewahrt und rasch verbraucht werden?",
    "optEn": [
      "Bacteria grow inside",
      "It turns toxic instantly",
      "It freezes into solid ice",
      "Contains over 50% alpha-linolenic omega-3 acid, which oxidizes rapidly into bitter compounds upon exposure to light and warmth"
    ],
    "optDe": [
      "Bakterien vermehren sich",
      "Wird sofort giftig",
      "Gefriert zu Eis",
      "Über 50% Alpha-Linolensäure (Omega-3) oxidieren bei Licht und Wärme extrem schnell zu bitterem Firnis"
    ],
    "correct": 3,
    "expEn": "Fresh Leinöl has a sweet, nutty, grassy taste; oxidized oil tastes bitter like floor varnish.",
    "expDe": "Frisches Leinöl schmeckt buttrig-nussig und ist der gesunde Star zu Quark und Pellkartoffeln."
  },
  {
    "id": "q_oil_14",
    "category": "oils_vinegars",
    "questionEn": "What is Apple Cider Vinegar (Apfelessig) praised for in vinaigrettes?",
    "questionDe": "Was zeichnet naturtrüben Apfelessig in Salatdressings aus?",
    "optionsEn": [
      "Sweet strawberry flavor",
      "Zero acid taste",
      "Mellow fruity malic and acetic acid balance with prebiotic pectin traces and cloudy fermentation nutrients",
      "It is carbonated like cider"
    ],
    "optionsDe": [
      "Erdbeeraroma",
      "Kein Säuregeschmack",
      "Harmonische Liaison aus Essig- und Äpfelsäure mit feiner Fruchtnote und unfiltrierten Nährstoffen",
      "Kohlensäurehaltig"
    ],
    "correctIndex": 2,
    "explanationEn": "Less aggressive than distilled white vinegar, ideal for cabbage salads, lentil stews, and pork glazes.",
    "explanationDe": "Apfelessig harmoniert wunderbar mit Rohkost, Linsengerichten und herzhaftem Schweinebraten.",
    "qEn": "What is Apple Cider Vinegar (Apfelessig) praised for in vinaigrettes?",
    "qDe": "Was zeichnet naturtrüben Apfelessig in Salatdressings aus?",
    "optEn": [
      "Sweet strawberry flavor",
      "Zero acid taste",
      "Mellow fruity malic and acetic acid balance with prebiotic pectin traces and cloudy fermentation nutrients",
      "It is carbonated like cider"
    ],
    "optDe": [
      "Erdbeeraroma",
      "Kein Säuregeschmack",
      "Harmonische Liaison aus Essig- und Äpfelsäure mit feiner Fruchtnote und unfiltrierten Nährstoffen",
      "Kohlensäurehaltig"
    ],
    "correct": 2,
    "expEn": "Less aggressive than distilled white vinegar, ideal for cabbage salads, lentil stews, and pork glazes.",
    "expDe": "Apfelessig harmoniert wunderbar mit Rohkost, Linsengerichten und herzhaftem Schweinebraten."
  },
  {
    "id": "q_oil_15",
    "category": "oils_vinegars",
    "questionEn": "What defines Avocado Oil for culinary applications?",
    "questionDe": "Was zeichnet Speise-Avocadoöl in der modernen Küche aus?",
    "optionsEn": [
      "Extracted from tree bark",
      "Extracted from the fruit pulp (not the seed), rich in monounsaturated fats with an ultra-high smoke point (~270°C / 520°F)",
      "Extracted from crushed leaves",
      "Has 0% fat"
    ],
    "optionsDe": [
      "Aus Rinde gepresst",
      "Wird aus dem Fruchtfleisch gepresst; reich an Ölsäure mit extrem hohem Rauchpunkt bis zu 270°C",
      "Aus Blättern destilliert",
      "Hat 0% Fett"
    ],
    "correctIndex": 1,
    "explanationEn": "Extra virgin avocado oil is emerald green; refined avocado oil handles searing steaks without smoking.",
    "explanationDe": "Das unraffinierte Öl schmeckt cremig nach Avocado; raffiniert ist es das hitzestabilste Bratöl.",
    "qEn": "What defines Avocado Oil for culinary applications?",
    "qDe": "Was zeichnet Speise-Avocadoöl in der modernen Küche aus?",
    "optEn": [
      "Extracted from tree bark",
      "Extracted from the fruit pulp (not the seed), rich in monounsaturated fats with an ultra-high smoke point (~270°C / 520°F)",
      "Extracted from crushed leaves",
      "Has 0% fat"
    ],
    "optDe": [
      "Aus Rinde gepresst",
      "Wird aus dem Fruchtfleisch gepresst; reich an Ölsäure mit extrem hohem Rauchpunkt bis zu 270°C",
      "Aus Blättern destilliert",
      "Hat 0% Fett"
    ],
    "correct": 1,
    "expEn": "Extra virgin avocado oil is emerald green; refined avocado oil handles searing steaks without smoking.",
    "expDe": "Das unraffinierte Öl schmeckt cremig nach Avocado; raffiniert ist es das hitzestabilste Bratöl."
  },
  {
    "id": "q_oil_16",
    "category": "oils_vinegars",
    "questionEn": "How does storing olive oil in clear glass bottles under supermarket lights damage quality?",
    "questionDe": "Warum schadet die Lagerung in Weißglasflaschen im Supermarktregal der Olivenölqualität?",
    "optionsEn": [
      "Photo-oxidation: Chlorophyll absorbs light energy, producing singlet oxygen that rapidly oxidizes lipids into rancid peroxides",
      "The oil turns into alcohol",
      "The bottle melts",
      "Color turns black"
    ],
    "optionsDe": [
      "Lichtinduzierte Photo-Oxidation: Chlorophyll regt Singulett-Sauerstoff an, der Fette ranzig zersetzt",
      "Das Öl wird Alkohol",
      "Die Flasche schmilzt",
      "Die Farbe wird schwarz"
    ],
    "correctIndex": 0,
    "explanationEn": "Always store olive oil in dark green/amber glass, tin containers, or cool dark pantries.",
    "explanationDe": "Olivenöl immer dunkel und kühl lagern; Licht zerstört Vitamine und macht das Öl kratzig-ranzig.",
    "qEn": "How does storing olive oil in clear glass bottles under supermarket lights damage quality?",
    "qDe": "Warum schadet die Lagerung in Weißglasflaschen im Supermarktregal der Olivenölqualität?",
    "optEn": [
      "Photo-oxidation: Chlorophyll absorbs light energy, producing singlet oxygen that rapidly oxidizes lipids into rancid peroxides",
      "The oil turns into alcohol",
      "The bottle melts",
      "Color turns black"
    ],
    "optDe": [
      "Lichtinduzierte Photo-Oxidation: Chlorophyll regt Singulett-Sauerstoff an, der Fette ranzig zersetzt",
      "Das Öl wird Alkohol",
      "Die Flasche schmilzt",
      "Die Farbe wird schwarz"
    ],
    "correct": 0,
    "expEn": "Always store olive oil in dark green/amber glass, tin containers, or cool dark pantries.",
    "expDe": "Olivenöl immer dunkel und kühl lagern; Licht zerstört Vitamine und macht das Öl kratzig-ranzig."
  },
  {
    "id": "q_oil_17",
    "category": "oils_vinegars",
    "questionEn": "What is Chinese Chinkiang Black Rice Vinegar?",
    "questionDe": "Was ist traditioneller chinesischer Chinkiang-Essig?",
    "optionsEn": [
      "Black pepper vinegar",
      "White vinegar colored with soy sauce",
      "Vinegar mixed with coal ash",
      "A fermented black vinegar brewed from glutinous sticky rice and malt, offering rich, malty, smoky, umami complexity"
    ],
    "optionsDe": [
      "Pfefferessig",
      "Mit Sojasauce gefärbter Essig",
      "Mit Holzkohle versetzter Essig",
      "Aus klebrigem Klebreis und Weizenkleie fermentierter schwarzer Essig mit malzig-rauchigem Umami"
    ],
    "correctIndex": 3,
    "explanationEn": "Essential dipping condiment for Xiaolongbao soup dumplings and braised spare ribs.",
    "explanationDe": "Chinkiang-Essig ist der Balsamico Asiens und der perfekte Partner für gedämpfte Dim Sum.",
    "qEn": "What is Chinese Chinkiang Black Rice Vinegar?",
    "qDe": "Was ist traditioneller chinesischer Chinkiang-Essig?",
    "optEn": [
      "Black pepper vinegar",
      "White vinegar colored with soy sauce",
      "Vinegar mixed with coal ash",
      "A fermented black vinegar brewed from glutinous sticky rice and malt, offering rich, malty, smoky, umami complexity"
    ],
    "optDe": [
      "Pfefferessig",
      "Mit Sojasauce gefärbter Essig",
      "Mit Holzkohle versetzter Essig",
      "Aus klebrigem Klebreis und Weizenkleie fermentierter schwarzer Essig mit malzig-rauchigem Umami"
    ],
    "correct": 3,
    "expEn": "Essential dipping condiment for Xiaolongbao soup dumplings and braised spare ribs.",
    "expDe": "Chinkiang-Essig ist der Balsamico Asiens und der perfekte Partner für gedämpfte Dim Sum."
  },
  {
    "id": "q_oil_18",
    "category": "oils_vinegars",
    "questionEn": "Why is Grapeseed Oil (Traubenkernöl) popular in fondue and mayonnaise?",
    "questionDe": "Warum ist raffiniertes Traubenkernöl für Fondue und Mayonnaise so beliebt?",
    "optionsEn": [
      "It is colored purple",
      "It tastes like sweet red wine",
      "Extremely neutral, clean flavor profile and high smoke point (216°C), allowing delicate herbs and sauces to shine",
      "It has zero calories"
    ],
    "optionsDe": [
      "Ist violett gefärbt",
      "Schmeckt nach Rotwein",
      "Absolut geschmacksneutrales Profil und hohe Hitzestabilität (216°C); überdeckt keine Eigengeschmäcker",
      "Hat keine Kalorien"
    ],
    "correctIndex": 2,
    "explanationEn": "Neutral grapeseed oil creates emulsified dressings where herbs, truffles, or lemon take center stage.",
    "explanationDe": "Da es keinen Eigengeschmack hat, lässt es feine Kräuter, Zitrone oder Trüffel voll zur Geltung kommen.",
    "qEn": "Why is Grapeseed Oil (Traubenkernöl) popular in fondue and mayonnaise?",
    "qDe": "Warum ist raffiniertes Traubenkernöl für Fondue und Mayonnaise so beliebt?",
    "optEn": [
      "It is colored purple",
      "It tastes like sweet red wine",
      "Extremely neutral, clean flavor profile and high smoke point (216°C), allowing delicate herbs and sauces to shine",
      "It has zero calories"
    ],
    "optDe": [
      "Ist violett gefärbt",
      "Schmeckt nach Rotwein",
      "Absolut geschmacksneutrales Profil und hohe Hitzestabilität (216°C); überdeckt keine Eigengeschmäcker",
      "Hat keine Kalorien"
    ],
    "correct": 2,
    "expEn": "Neutral grapeseed oil creates emulsified dressings where herbs, truffles, or lemon take center stage.",
    "expDe": "Da es keinen Eigengeschmack hat, lässt es feine Kräuter, Zitrone oder Trüffel voll zur Geltung kommen."
  }
];
