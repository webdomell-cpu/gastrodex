// GastroDex PWA - High-Performance Hospitality & Gastronomy Encyclopedia
// Offline-first with LocalStorage synchronization & Bilingual EN/DE support

const STORAGE_KEY_ITEMS = 'gastrodex_items_v2';
const STORAGE_KEY_LANG = 'gastrodex_lang';
const STORAGE_KEY_QUIZ_RESULTS = 'gastrodex_quiz_results';

// Firebase Firestore Client Integration
const firebaseConfig = {
  apiKey: "AIzaSyD3FCooDWBQagyDEKMZf0OkmB2FfihEK6E",
  projectId: "gastrodex-823d7",
  authDomain: "gastrodex-823d7.firebaseapp.com"
};
let firestoreDb = null;
try {
  if (typeof firebase !== 'undefined') {
    firebase.initializeApp(firebaseConfig);
    firestoreDb = firebase.firestore();
    console.log("🔥 GastroDex PWA Firestore live connected to gastrodex-823d7");
  }
} catch (e) {
  console.warn("Firestore client init notice:", e);
}


let currentLang = localStorage.getItem(STORAGE_KEY_LANG) || 'de';
let currentTab = 'catalog';
let activeCategory = 'all';
let searchQuery = '';
let filterOnlyStock = false;
let filterOnlyFav = false;
let filterImport = null; // null, true, false
let selectedItem = null;

// Quiz Session State
let quizCategory = 'all';
let quizTargetCount = 10;
let quizQuestionsPool = [];
let activeQuizQuestions = [];
let quizCurrentIndex = 0;
let quizSelectedOption = null;
let quizIsRevealed = false;
let quizScore = 0;
let quizIsCompleted = false;

// INITIAL MASTER DATA (Bilingual)
const MASTER_ITEMS = [
  {
    "id": "spirit_scotch",
    "category": "spirits",
    "nameEn": "Scotch Whisky (Single Malt)",
    "nameDe": "Scotch Whisky (Single Malt)",
    "subtitleEn": "Malted barley distilled in copper pot stills, aged in oak",
    "subtitleDe": "Gerstenmalz über Torf gedarrt, in kupfernen Pot Stills zweifach destilliert",
    "imageUrl": "https://images.unsplash.com/photo-1527281400683-1aae777175f8?w=800&auto=format&fit=crop&q=80",
    "origin": "Scotland (Islay, Speyside, Highlands)",
    "isImport": true,
    "abv": "40% - 58% ABV",
    "tasteEn": "Peaty smoke, medicinal iodine, heather honey, dried fruit, rich malt.",
    "tasteDe": "Torfrauch, Jod, Heidehonig, Trockenfrüchte, kräftige Malzsüße, Eichenvanille.",
    "scienceEn": "Barley starch is converted to maltose by grain amylases during mashing. Peat smoke infuses phenols (measured in PPM). Double distilled in pot stills; ethanol boils at 78.3°C separating from wash water.",
    "scienceDe": "Gerstenstärke wird durch Amylasen zu Maltose enzymatisch gespalten. Torffeuer bindet Phenole (PPM). Doppelte Destillation in Kupferblasen trennt Ethanol (78,3°C) vom Wasser.",
    "culinaryEn": "Neat in Glencairn glass at 18-20°C with drops of soft spring water.",
    "culinaryDe": "Pur im Nosing-Glas bei 18-20°C mit wenigen Tropfen stillem Quellwasser.",
    "faqEn": "Why is it smoky? The smoke comes from drying wet malted barley over smoldering peat moss before fermentation.",
    "faqDe": "Warum schmeckt er rauchig? Das Torffeuer trocknet die feuchte Gerste vor dem Maischen und brennt Raucharomen in das Korn.",
    "allergens": [
      "Gluten (proteins separated by distillation"
    ],
    "tags": [
      "Whisky",
      "Scotch",
      "SingleMalt",
      "Peat",
      "Distillate"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_bourbon",
    "category": "spirits",
    "nameEn": "Bourbon Whiskey",
    "nameDe": "Bourbon Whiskey",
    "subtitleEn": "American spirit distilled from >=51% corn, new charred oak barrels",
    "subtitleDe": "Amerikanischer Whiskey aus mind. 51% Mais, neue ausgekohlte Weißeichenfässer",
    "imageUrl": "https://images.unsplash.com/photo-1569529465841-dfecdab7503b?w=800&auto=format&fit=crop&q=80",
    "origin": "USA (Kentucky)",
    "isImport": true,
    "abv": "40% - 50% ABV",
    "tasteEn": "Sweet corn upfront, rich vanilla, caramel, toasted oak, baking spice.",
    "tasteDe": "Süßer Mais, Vanillin, Karamell, geröstetes Holz, Zimt und Gewürze.",
    "scienceEn": "Aged in brand new charred oak barrels. The char breaks down wood lignin into aromatic vanillin and caramelized hemicellulose sugars.",
    "scienceDe": "Reifung in fabrikneuen ausgekohlten Eichenfässern. Das Ausbrennen zerlegt Lignin in Vanillin und karamellisiert Holzzucker.",
    "culinaryEn": "Neat, on a large cube in a tumbler, or in Old Fashioned & Manhattan.",
    "culinaryDe": "Pur oder on the rocks im Tumbler; Basis für Old Fashioned und Manhattan.",
    "faqEn": "Bourbon vs Scotch? Bourbon is made primarily from corn and aged in new charred barrels; Scotch is primarily barley aged in used casks.",
    "faqDe": "Unterschied Bourbon zu Scotch? Bourbon basiert auf mind. 51% Mais in neuen Fässern (süßer); Scotch auf Gerste meist in gebrauchten Fässern.",
    "allergens": [
      "None declared"
    ],
    "tags": [
      "Bourbon",
      "Corn",
      "USA",
      "Oak",
      "Whiskey"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_weinbrand_brandy",
    "category": "spirits",
    "nameEn": "Brandy, Weinbrand & Cognac",
    "nameDe": "Deutscher Weinbrand, Brandy & Cognac",
    "subtitleEn": "Distilled grape wine matured for years in Limousin oak casks",
    "subtitleDe": "Destillierter Traubenwein, mindestens 6 Monate bis viele Jahre im Eichenfass gereift",
    "imageUrl": "https://images.unsplash.com/photo-1563227812-0ea4c22e6cc8?w=800&auto=format&fit=crop&q=80",
    "origin": "Germany (Weinbrand), France (Cognac/Armagnac), Spain (Jerez)",
    "isImport": false,
    "abv": "36% - 40% ABV",
    "tasteEn": "Ripe grape notes, dried plum, dark chocolate, toasted wood vanilla, warming finish.",
    "tasteDe": "Feine Traubennoten, Dörrpflaume, dunkle Schokolade, Eichenholz, milder samtiger Abgang.",
    "scienceEn": "White wine is double distilled in copper Charentais alembic stills. The clear eau-de-vie extracts wood tannins and lactones during aging. Classifications: VS (min 2 yrs), VSOP (min 4 yrs), XO (min 10 yrs).",
    "scienceDe": "Wein wird in kupfernen Brennblasen destilliert. Die Lagerung in Eichenholzfässern verleiht Bernsteinfarbe und Holztannine. 'Deutscher Weinbrand' ist eine geschützte Bezeichnung für mind. 6 Monate fassgelagertes Weindestillat.",
    "culinaryEn": "Served in a tulip snifter glass at room temperature (18-20°C). Digestif after rich meals.",
    "culinaryDe": "Im Cognac-Schwenker oder Tulpenglas bei 18-20°C als klassischer Digestif servieren.",
    "faqEn": "What is the difference between Brandy and Cognac? Cognac is a strictly protected French regional brandy from the Cognac region made according to precise AOC laws.",
    "faqDe": "Was unterscheidet Cognac von Weinbrand? Cognac ist eine geschützte Ursprungsbezeichnung aus der französischen Region Charente nach strengen AOC-Regeln.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Weinbrand",
      "Brandy",
      "Cognac",
      "Grapes",
      "Digestif"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_aquavit",
    "category": "spirits",
    "nameEn": "Aquavit (Akvavit)",
    "nameDe": "Aquavit (Akvavit)",
    "subtitleEn": "Nordic spirit flavored with caraway (Kümmel) and dill seeds",
    "subtitleDe": "Skandinavische Traditionsspezialität aromatisiert mit Kümmel und Dillsamen",
    "imageUrl": "",
    "origin": "Scandinavia (Norway, Denmark, Sweden) / North Germany",
    "isImport": true,
    "abv": "37.5% - 45% ABV",
    "tasteEn": "Pronounced caraway warmth, herbal anise, fresh dill, citrus peel, dry savory spice.",
    "tasteDe": "Charakteristischer herber Kümmel, frischer Dill, Zitrusnoten, wärmende Kräuterwürze.",
    "scienceEn": "By EU regulation, caraway (Carum carvi) must be the dominant flavor. The essential oil carvone provides the distinct herbal digestive aroma. Norwegian Linje Aquavit matures in sherry casks on ships crossing the equator twice!",
    "scienceDe": "EU-Vorschrift: Kümmel muss das Hauptaroma bestimmen. Das ätherische Öl Carvon wirkt verdauungsfördernd. Berühmt ist 'Linje Aquavit', der in Sherryfässern auf Schiffen zweimal den Äquator überquert.",
    "culinaryEn": "Served chilled or room temperature in a tulip glass alongside hearty herring, smørrebrød, and pork roasts.",
    "culinaryDe": "Klassisch zum 'Herrengedeck' zu Matjes, Hering, Smørrebrød und deftigen Fleischgerichten.",
    "faqEn": "Why is Aquavit associated with digestion? Caraway oils (carvone) stimulate bile production and soothe the gastrointestinal tract after rich meals.",
    "faqDe": "Warum gilt Aquavit als Magenfreund? Das im Kümmel enthaltene ätherische Öl Carvon regt die Magensaftproduktion an und entkrampft nach fettem Essen.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Aquavit",
      "Caraway",
      "Kümmel",
      "Nordic",
      "Digestif"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_ouzo",
    "category": "spirits",
    "nameEn": "Greek Ouzo",
    "nameDe": "Griechischer Ouzo",
    "subtitleEn": "Protected Greek aniseed spirit renowned for the milky 'Louche effect'",
    "subtitleDe": "Griechischer Anisschnaps bekannt für den milchig-weißen Louche-Effekt mit Wasser",
    "imageUrl": "",
    "origin": "Greece (Lesbos / Plomari) & Cyprus",
    "isImport": true,
    "abv": "37.5% - 44% ABV",
    "tasteEn": "Sweet licorice, refreshing menthol cooling, floral fennel, smooth herbal warmth.",
    "tasteDe": "Süßliche Lakritznoten, erfrischende Aniskühle, Fenchel, wärmende Kräuterwürze.",
    "scienceEn": "Anise contains anethole oil, which dissolves completely in ethanol (>38% ABV). When cold water or ice is added, ethanol concentration drops below solubility threshold, causing anethole to precipitate into micro-droplets that scatter light (the spontaneous emulsion 'Ouzo effect').",
    "scienceDe": "Anis enthält ätherisches Anethol, das in reinem Alkohol löslich ist. Wird Wasser hinzugefügt, sinkt der Alkoholgehalt; das Anethol fällt als mikroskopische Tröpfchen aus und bricht das Licht milchig-weiß (Louche-Effekt).",
    "culinaryEn": "Served in highball glasses with cold water and ice alongside Greek Meze (feta, olives, octopus, calamari).",
    "culinaryDe": "Mit stillem kaltem Wasser und Eiswürfeln serviert zu Meze wie gegrilltem Oktopus, Oliven und Feta.",
    "faqEn": "Why does Ouzo turn milky when adding water? Anethole oils are oil-based: lowering the alcohol content forces them to separate into tiny suspended white droplets.",
    "faqDe": "Warum wird Ouzo mit Wasser milchig? Das Anisöl Anethol löst sich nur in starkem Alkohol. Verdünnt man ihn mit Wasser, fällt das Öl als weiße Trübung aus.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Ouzo",
      "Anise",
      "Greece",
      "Louche",
      "Aperitif"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_raki",
    "category": "spirits",
    "nameEn": "Turkish Rakı ('Lion\\'s Milk')",
    "nameDe": "Türkischer Rakı ('Löwenmilch' / Aslan Sütü)",
    "subtitleEn": "Twice-distilled grape suma infused with Pimpinella anisum seeds",
    "subtitleDe": "Zweifach gebrannter Traubendestillat (Suma) mit Anissamen der Pimpinella-Pflanze",
    "imageUrl": "",
    "origin": "Turkey",
    "isImport": true,
    "abv": "40% - 50% ABV",
    "tasteEn": "Intense bold aniseed, herbal raisins, dry mineral warmth, rich licorice body.",
    "tasteDe": "Kräftig-würziger Anis, getrocknete Traubenfrucht, trockene Mineralik, markanter Körper.",
    "scienceEn": "Unlike simple flavored spirits, Rakı strictly requires Suma (raisin/grape distillate). In traditional copper alembics, suma is redistilled with high-grade aniseed. Adding cold water causes the signature cloudy 'Lion's Milk' emulsion.",
    "scienceDe": "Rakı muss aus 'Suma' (Traubenbrand) gebrannt werden. In Kupferblasen wird die Suma mit Anissamen ein zweites Mal destilliert. Gemischt mit Wasser entsteht die milchige 'Löwenmilch'.",
    "culinaryEn": "Served 1:1 with chilled water and separate ice cube glass at a traditional Rakı sofrası with white cheese and melon.",
    "culinaryDe": "1:1 mit kaltem Wasser verdünnt, serviert mit Schafskäse, Honigmelone und warmen Vorspeisen.",
    "faqEn": "What is the difference between Rakı and Ouzo? Rakı must be distilled from grape suma and has a higher minimum ABV and less sugar, resulting in a drier, bolder herbal flavor.",
    "faqDe": "Unterschied Rakı zu Ouzo? Rakı basiert gesetzlich auf Trauben-Suma, ist herber, ungesüßter und besitzt oft einen höheren Alkoholgehalt.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Raki",
      "Anise",
      "Turkey",
      "Suma",
      "Aperitif"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_gin",
    "category": "spirits",
    "nameEn": "London Dry Gin",
    "nameDe": "London Dry Gin",
    "subtitleEn": "Redistilled neutral spirit infused with juniper berries & botanicals",
    "subtitleDe": "Redestillierter Agraralkohol aromatisiert mit Wacholder & Botanicals",
    "imageUrl": "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=800&auto=format&fit=crop&q=80",
    "origin": "England / Europe",
    "isImport": false,
    "abv": "37.5% - 47% ABV",
    "tasteEn": "Crisp piney juniper, bright citrus zest, herbal coriander, dry peppery finish.",
    "tasteDe": "Frischer harziger Wacholder, lebhafte Zitrusnoten, würziger Koriander, trockener Abgang.",
    "scienceEn": "Neutral grain alcohol (96% ABV) is diluted and redistilled in alembic stills with all natural botanicals. For legal 'London Dry' designation, no artificial flavors or sweetening above 0.1g/L may be added.",
    "scienceDe": "Reiner Agraralkohol wird mit natürlichen Botanicals ein zweites Mal destilliert. Bei 'London Dry' dürfen nach dem Brennvorgang keinerlei Aromastoffe oder Zucker über 0,1g/L hinzugefügt werden.",
    "culinaryEn": "Copa glass with premium tonic and lemon peel, or in dry Martini.",
    "culinaryDe": "Im Copa-Ballonglas mit Tonic Water und Zesten, oder im trockenen Martini.",
    "faqEn": "What makes it 'Dry'? 'Dry' means unsweetened without added sugar after distillation.",
    "faqDe": "Was bedeutet 'Dry'? Es bedeutet ungesüßt: Nach dem Destillieren darf kein Zucker beigemengt werden.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Gin",
      "Juniper",
      "Botanicals",
      "Distillate",
      "Cocktails"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_vodka",
    "category": "spirits",
    "nameEn": "Vodka (Grain & Potato)",
    "nameDe": "Wodka (Getreide & Kartoffel)",
    "subtitleEn": "Highly rectified neutral spirit filtered through activated charcoal",
    "subtitleDe": "Hochrektifizierter Neutralalkohol, filtriert über Aktivkohle",
    "imageUrl": "https://images.unsplash.com/photo-1556881286-fc6915169721?w=800&auto=format&fit=crop&q=80",
    "origin": "Poland, Sweden, Baltic region",
    "isImport": false,
    "abv": "37.5% - 40% ABV",
    "tasteEn": "Ultra-clean, subtle grain sweetness or creamy potato texture, silky smooth.",
    "tasteDe": "Klar und neutral, dezente Getreidesüße oder cremige Textur (Kartoffel), samtig.",
    "scienceEn": "Fermented wash is distilled in column stills up to >=96% ABV, stripping away congeners. Passed through activated charcoal filters to remove microscopic impurities.",
    "scienceDe": "Maische wird bis zu 96% Vol. rektifiziert, wodurch Fuselöle abgetrennt werden. Aktivkohlefiltration bindet letzte Spurenaromen für absolute Reinheit.",
    "culinaryEn": "Served iced at -4°C to 0°C. Classic pairing: Beluga caviar, smoked sprats, blinis.",
    "culinaryDe": "Eiskalt bei -4°C bis 0°C serviert. Klassisch zu Kaviar, Blinis und Räucherfisch.",
    "faqEn": "Can you taste potato vs grain vodka? Potato vodka has a thicker, creamier mouthfeel; wheat is crisper and lighter.",
    "faqDe": "Schmeckt man Kartoffel- vs. Weizenwodka? Kartoffelwodka bietet ein spürbar cremigeres, schwereres Mundgefühl.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Vodka",
      "Neutral",
      "Charcoal",
      "Distillate"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_rum",
    "category": "spirits",
    "nameEn": "Caribbean Rum & Rhum Agricole",
    "nameDe": "Karibischer Rum & Rhum Agricole",
    "subtitleEn": "Fermentation & distillation of sugarcane molasses or fresh cane juice",
    "subtitleDe": "Fermentation & Destillation von Zuckerrohrmelasse oder frischem Rohrsaft",
    "imageUrl": "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=800&auto=format&fit=crop&q=80",
    "origin": "Caribbean (Jamaica, Martinique, Cuba, Barbados)",
    "isImport": true,
    "abv": "40% - 54% ABV",
    "tasteEn": "Molasses, brown sugar, tropical banana esters (hogo), vanilla oak, roasted coffee.",
    "tasteDe": "Melasse, brauner Zucker, fruchtige Bananen-Ester (Hogo), Eichenvanille, Röstnoten.",
    "scienceEn": "Sugarcane sucrose is fermented into alcohol. Rhum Agricole uses raw cane juice for vegetal grassy notes; molasses rum gives deep caramel body.",
    "scienceDe": "Rhum Agricole wird aus frischem Zuckerrohrsaft gebrannt (grasig-frisch); Melasse-Rum liefert tiefe Karamell- und Röstnoten.",
    "culinaryEn": "Aged rums neat in nosing glass; white rums in Daiquiri and Mojito.",
    "culinaryDe": "Aged Rum pur; weißer Rum in Daiquiri und Mojito. Für Desserts und Flambieren.",
    "faqEn": "White vs Dark Rum? White rum is unaged or charcoal-filtered; dark rum matures for years in oak absorbing wood pigments.",
    "faqDe": "Weißer vs. dunkler Rum? Weißer ist jung oder kohlfiltriert; dunkler reift jahrelang im Holzfass.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Rum",
      "Sugarcane",
      "Caribbean",
      "Tiki"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spirit_tequila_mezcal",
    "category": "spirits",
    "nameEn": "Tequila 100% Agave & Mezcal",
    "nameDe": "Tequila 100% Agave & Mezcal",
    "subtitleEn": "Distilled spirits from succulent Agave hearts (steamed vs pit-roasted)",
    "subtitleDe": "Destillat aus Agavenherzen (gedämpft vs. in Erdgruben über Holz geröstet)",
    "imageUrl": "https://images.unsplash.com/photo-1516594798947-e65505dbb29d?w=800&auto=format&fit=crop&q=80",
    "origin": "Mexico (Jalisco for Tequila, Oaxaca for Mezcal)",
    "isImport": true,
    "abv": "38% - 46% ABV",
    "tasteEn": "Sweet cooked agave, citrus pepper, herbaceous vegetal notes, campfire smoke (Mezcal).",
    "tasteDe": "Gekochte Agavensüße, Zitruspfeffer, mineralisch-vegetabil, Lagerfeuer-Rauch (Mezcal).",
    "scienceEn": "Inulin stored in mature agave hearts (piñas) is steamed (Tequila) or pit-roasted over mesquite wood in cone-shaped earth pits (Mezcal), converting inulin to fructose.",
    "scienceDe": "Agaven-Inulin wird gedämpft (Tequila) oder tagelang in Erdöfen über Holz geröstet (Mezcal), was das typische Raucharoma erzeugt.",
    "culinaryEn": "Sipped neat in veladora glass with orange slices and sal de gusano (worm salt).",
    "culinaryDe": "Pur bei Zimmertemperatur mit Orangenschnitz und Chilisalz; oder in Paloma.",
    "faqEn": "Is all Mezcal Tequila? Tequila is a specific regional subtype of Mezcal made strictly from Blue Weber Agave.",
    "faqDe": "Ist jeder Tequila ein Mezcal? Tequila ist eine geschützte Unterart von Mezcal, die nur aus der Blauen Weber-Agave hergestellt werden darf.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Agave",
      "Mexico",
      "Mezcal",
      "Tequila"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_champagne_sekt_asti",
    "category": "wine",
    "nameEn": "Champagne, Sekt & Asti Spumante",
    "nameDe": "Champagner vs. Sekt vs. Asti Spumante",
    "subtitleEn": "Comparing Méthode Traditionnelle, Tank fermentation, and sweet Asti",
    "subtitleDe": "Flaschengärung (Méthode Champenoise) vs. Tankgärung vs. lieblicher Asti",
    "imageUrl": "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Champagne), Germany (Sekt), Italy (Piedmont / Asti)",
    "isImport": false,
    "abv": "7.0% - 12.5% ABV",
    "tasteEn": "Champagne: Brioche, green apple, autolytic toast. Sekt: Crisp, fruity. Asti: Sweet floral peach, low alcohol (7%).",
    "tasteDe": "Champagner: Brioche, Hefegebäck, zarte Perlage. Deutscher Sekt: Rassig fruchtig. Asti: Süß, weiße Pfirsiche, Holunderblüte.",
    "scienceEn": "1. Champagne: Méthode Traditionnelle. 2nd fermentation inside each bottle; min 15 months on yeast lees (autolysis releases mannoproteins creating brioche aromas and ultra-fine perlage at 5-6 bar).\\n2. Deutscher Sekt: Can be bottle or charmat tank fermented.\\n3. Asti Spumante: Made from sweet Moscato Bianco grapes in pressurized autoclaves (Metodo Martinotti). Fermentation is intentionally chilled and stopped at ~7% ABV, preserving high natural grape sweetness and delicate bubbles without adding refined sugar.",
    "scienceDe": "1. Champagner: Strikte Flaschengärung (Méthode Traditionnelle). Die 2. Gärung erfolgt in der Flasche; mind. 15 Monate Hefelager lösen Mannoproteine für feine Perlage (5-6 bar) und Brioche-Noten.\\n2. Deutscher Sekt / Winzersekt: Hochwertige Rebsorten (z.B. Riesling), traditionelle Flaschengärung oder Tankgärung.\\n3. Asti Spumante DOCG: Aus süßer Moscato Bianco-Traube im Drucktank. Die Gärung wird bei ~7-9% Vol. durch Kälteschock gestoppt – der Wein behält seine intensive natürliche Traubensüße und zarte Kohlensäure!",
    "culinaryEn": "Champagne: 8-10°C in tulip glasses with oysters. Asti: Chilled at 6-8°C with fruit tarts, panettone, or light desserts.",
    "culinaryDe": "Champagner: 8-10°C im Tulpenglas zu Austern & Kaviar. Asti: 6-8°C perfekt zu Fruchtdesserts, Panettone und Beeren.",
    "faqEn": "Why does Asti have so little alcohol? Asti's fermentation is stopped early, leaving the unfermented sugar in the bottle as natural sweetness instead of turning it into alcohol.",
    "faqDe": "Warum hat Asti so wenig Alkohol? Weil die Gärung frühzeitig gekühlt gestoppt wird; der Zucker bleibt als natürliche Süße im Glas statt zu Alkohol zu werden.",
    "allergens": [
      "Contains Sulphites (SO2"
    ],
    "tags": [
      "Champagne",
      "Sekt",
      "Asti",
      "Spumante",
      "Perlage",
      "Wine"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_riesling_white",
    "category": "wine",
    "nameEn": "Riesling (Queen of White Grapes)",
    "nameDe": "Riesling (Die Königin der Weißweine)",
    "subtitleEn": "Steep slate slopes, electric natural acidity, and slate minerality",
    "subtitleDe": "Steillagen-Schieferböden, lebendige Weinsäure und weltberühmte Mineralität",
    "imageUrl": "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=800&auto=format&fit=crop&q=80",
    "origin": "Germany (Mosel, Rheingau, Pfalz) & Alsace",
    "isImport": false,
    "abv": "8.5% - 13.0% ABV",
    "tasteEn": "Crisp green apple, white peach, lime zest, flint stone minerality, mature petrol note (TDN).",
    "tasteDe": "Grüner Apfel, Weinbergpfirsich, Limette, Schiefermineralik, im Alter edle Petrolnote (TDN).",
    "scienceEn": "Riesling is derived exclusively from the noble Riesling grape. It possesses very high levels of natural tartaric and malic acids that maintain balance from bone-dry (Trocken) all the way to noble sweet botrytized Auslese and Eiswein. Aged Rieslings develop a famous 'petrol/kerosene' aroma caused by the breakdown of carotenoids into 1,1,6-trimethyl-1,2-dihydronaphthalene (TDN).",
    "scienceDe": "Riesling wird reinsortig aus der Riesling-Traube gekeltert. Durch die späte Reife speichert sie hohe Weinsäure, die auch bei Restsüße Frische garantiert. Reife Rieslinge entwickeln durch den Abbau von Carotinoiden die geschätzte edle 'Petrolnote' (TDN-Verbindung).",
    "culinaryEn": "Dry Riesling at 9-11°C with trout, asparagus, and Wiener Schnitzel. Sweet Spätlese with spicy Thai or Indian curries.",
    "culinaryDe": "Trockener Riesling bei 9-11°C perfekt zu Spargel, Forelle und Kalbsschnitzel; feinherb/lieblich ideal zu scharfer asiatischer Küche.",
    "faqEn": "Is Riesling always sweet? No! High-grade German Rieslings (GG - Große Gewächse) are strictly bone-dry, razor-sharp, and complex.",
    "faqDe": "Ist Riesling immer süß? Keineswegs! Die meisten Spitzen-Rieslinge (wie Große Gewächse) werden knochentrocken und mineralisch ausgebaut.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "Riesling",
      "WhiteWine",
      "Germany",
      "Mosel",
      "Minerality"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_sauvignon_chardonnay",
    "category": "wine",
    "nameEn": "Sauvignon Blanc vs. Chardonnay",
    "nameDe": "Sauvignon Blanc vs. Chardonnay",
    "subtitleEn": "Zesty pyrazines & fresh grass vs. creamy oak & malolactic fermentation",
    "subtitleDe": "Frische Pyrazine (Gras & Stachelbeere) vs. buttrig-cremiger Barrique-Ausbau",
    "imageUrl": "https://images.unsplash.com/photo-1558001373-7b93ee48ffa0?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Loire, Burgundy), New Zealand (Marlborough), California",
    "isImport": false,
    "abv": "12.0% - 14.5% ABV",
    "tasteEn": "Sauvignon Blanc: Cut grass, gooseberry, passion fruit. Chardonnay: Ripe pear, buttery vanilla, hazelnut toast.",
    "tasteDe": "Sauvignon Blanc: Frisches Gras, Stachelbeere, Holunder. Chardonnay: Reife Birne, Butter, getoastete Haselnuss, Vanille.",
    "scienceEn": "Sauvignon Blanc is dominated by methoxypyrazines (green bell pepper, grass) and thiols (passionfruit). Chardonnay is a chameleon grape that readily undergoes Malolactic Fermentation (MLF), where sharp malic acid is converted by Oenococcus oeni bacteria into soft lactic acid, producing buttery diacetyl compounds and oak lactones.",
    "scienceDe": "Sauvignon Blanc schmeckt durch Methoxypyrazine grasig-frisch. Chardonnay besitzt weniger Eigengeruch, durchläuft aber oft die 'malolaktische Gärung' (BSA: Äpfelsäure wird zu weicher Milchsäure abgebaut), was im Holzfass den buttrigen Schmelz (Diacetyl) erzeugt.",
    "culinaryEn": "Sauvignon Blanc with goat cheese (Chavignol) and oysters. Oaked Chardonnay with pan-seared sea bass, lobster, and creamy risotto.",
    "culinaryDe": "Sauvignon Blanc zu Ziegenkäse und Meeresfrüchten; holzfassgereifter Chardonnay zu Hummer, Lachs und Trüffelpasta.",
    "faqEn": "Why does oaked Chardonnay taste like butter? Malolactic fermentation creates a compound called diacetyl, the exact aroma molecule found in fresh churned butter.",
    "faqDe": "Woher kommt der Buttergeschmack im Chardonnay? Durch den biologischen Säureabbau entsteht Diacetyl – der gleiche Stoff wie in Butter!",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "WhiteWine",
      "Chardonnay",
      "SauvignonBlanc",
      "Oak",
      "Terroir"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_red_pinot_cabernet",
    "category": "wine",
    "nameEn": "Pinot Noir vs. Cabernet Sauvignon",
    "nameDe": "Spätburgunder (Pinot Noir) vs. Cabernet Sauvignon",
    "subtitleEn": "Thin-skinned delicate forest floor vs. thick-skinned powerhouse of tannins",
    "subtitleDe": "Dünnschalig-eleganter Waldbeerton vs. tanninschweres Kraftpaket aus dem Holzfass",
    "imageUrl": "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Burgundy, Bordeaux), Germany (Baden, Ahr), Napa Valley",
    "isImport": false,
    "abv": "12.5% - 15.0% ABV",
    "tasteEn": "Pinot Noir: Sour cherry, raspberry, forest floor, silky tannins. Cabernet: Cassis, blackcurrant, cedar oak, firm grip.",
    "tasteDe": "Spätburgunder: Sauerkirsche, Himbeere, Waldboden, seidig milde Tannine. Cabernet: Schwarze Johannisbeere (Cassis), Zeder, kräftiges Tannin.",
    "scienceEn": "Pinot Noir has thin grape skins with lower anthocyanin and tannin levels, producing pale ruby, aromatic, and acidic red wines. Cabernet Sauvignon has small berries with thick skins packed with proanthocyanidins (tannins) and pyrazines, requiring long oak barrel maturation to soften.",
    "scienceDe": "Spätburgunder besitzt dünne Beerenhäute mit wenig Tanninen und Farbstoffen, schmeckt samtig und fruchtbetont. Cabernet Sauvignon hat dicke Beerenhäute voller Gerbstoffe (Tannine), die den Mund pelzig zusammenziehen und jahrelange Fassreife verlangen.",
    "culinaryEn": "Pinot Noir at 16-18°C with roast duck, venison, and mushroom risotto. Cabernet Sauvignon with grilled ribeye steak and braised beef shanks.",
    "culinaryDe": "Spätburgunder zu Ente, Lamm und Wild; Cabernet Sauvignon zwingend zu kräftigem Rindersteak, Bäckchen und gereiftem Hartkäse.",
    "faqEn": "What creates the dry, furry sensation in red wine? Condensed tannins extracted from the grape skins and oak barrels bind to salivary proteins, stripping lubrication from the palate.",
    "faqDe": "Warum zieht Rotwein den Mund zusammen? Tannine (Gerbstoffe) aus Beerenhaut und Holz binden Speichelproteine und trocknen die Mundschleimhaut kurzzeitig ab.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "RedWine",
      "PinotNoir",
      "Cabernet",
      "Tannins",
      "Burgundy"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_rose_science",
    "category": "wine",
    "nameEn": "Rosé Wine Production Science",
    "nameDe": "Roséwein & Kelterverfahren",
    "subtitleEn": "Short skin maceration & Saignée 'bleeding' method (never simple mixing)",
    "subtitleDe": "Kurze Maischestandzeit & Saignée-Verfahren (kein simples Mischen von Weiß und Rot)",
    "imageUrl": "https://images.unsplash.com/photo-1558001373-7b93ee48ffa0?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Provence), Spain (Navarra), Germany",
    "isImport": false,
    "abv": "11.5% - 13.0% ABV",
    "tasteEn": "Crisp strawberry, watermelon, crushed stone minerality, fresh redcurrant, dry floral finish.",
    "tasteDe": "Frische Erdbeere, Wassermelone, Johannisbeere, mineralisch frisch, kräuterig-trocken.",
    "scienceEn": "Almost all grape juice inside red grapes is completely clear and white. The red color (anthocyanins) resides exclusively in the skins. For Rosé, red grapes are crushed and allowed contact with skins for only 2 to 12 hours (short maceration) before being pressed off. Saignée method draws off ('bleeds') pink juice early. In the EU, mixing finished white and red wine to make Rosé is strictly illegal (except for Champagne rosé).",
    "scienceDe": "Fast jedes Fruchtfleisch roter Trauben hat hellen, weißen Saft. Die Farbe sitzt in der Schale! Für Rosé bleibt der Saft nur wenige Stunden (2-12h) auf den roten Schalen liegen (Maischestandzeit), bis er zartrosa ist, und wird dann abgepresst. Das simple Zusammenschütten von Weiß- und Rotwein ist für europäischen Qualitäts-Rosé gesetzlich verboten!",
    "culinaryEn": "Chilled at 8-10°C in white wine glasses. Quintessential summer wine for bouillabaisse, tapas, and grilled poultry.",
    "culinaryDe": "Gut gekühlt bei 8-10°C servieren. Der Sommer-Klassiker zu Tapas, gegrilltem Fisch, Salaten und hellem Fleisch.",
    "faqEn": "Is Rosé simply white wine mixed with red wine? No! In the EU, blending red and white wine is illegal for still quality wine. Color is extracted by short contact with red grape skins.",
    "faqDe": "Wird Rosé aus Weiß- und Rotwein gemischt? Nein! Das ist in der EU für Stillweine streng verboten. Die Farbe stammt aus kurzer Schalenmazeration roter Trauben.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "Rose",
      "Provence",
      "Maceration",
      "Saignee",
      "Wine"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_champagne_aoc_brut",
    "category": "wine",
    "nameEn": "Champagne AOC (Brut, Blanc de Blancs & Vintage)",
    "nameDe": "Champagner AOC (Brut, Blanc de Blancs & Millésimé)",
    "subtitleEn": "King of sparkling wines: Chalk terroir, Méthode Champenoise & autolytic brioche notes",
    "subtitleDe": "König der Schaumweine: Kreideböden der Champagne, Flaschengärung & zarter Hefe-Schmelz",
    "imageUrl": "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Champagne: Reims, Épernay, Côte des Blancs - AOC)",
    "isImport": false,
    "abv": "12.0% - 12.5% ABV",
    "tasteEn": "Crisp green apple, toasted brioche, lemon zest, chalk minerality, creamy ultra-fine persistent perlage.",
    "tasteDe": "Grüner Apfel, warmes Brioche-Hefegebäck, Zitronenabrieb, nasser Kreidestein, seidenweiche Perlage.",
    "scienceEn": "Champagne is protected by strict AOC law: grapes must be whole-cluster pressed in traditional pneumatic or Coquard presses to avoid extracting harsh skin tannins. The 2nd fermentation occurs strictly inside each bottle with yeast and sugar liqueur de tirage. Extended aging on dead yeast cells (lees autolysis for min 15 months, min 36 months for Millésimé vintage) releases mannoproteins and amino acids, creating its signature toasted brioche aroma and micro-bubbles under 5 to 6 bar of pressure. Dosages: Brut Nature (0-3g/L), Extra Brut (0-6g/L), Brut (<12g/L).",
    "scienceDe": "Champagner ist eine der strengsten geschützten Herkunftsbezeichnungen der Welt: Die Trauben werden von Hand gelesen und als ganze Trauben gepresst. Die 2. Gärung erfolgt in der Flasche. Mindestens 15 Monate (bei Jahrgangs-Champagner mind. 36 Monate) reift der Wein auf der Hefe (Autolyse). Dabei zerfallen Hefezellen und geben Mannoproteine ab, die das legendäre Brioche- und Röstaroma erzeugen und den Schaumwein bei 5-6 bar Druck seidenweich perlen lassen.",
    "culinaryEn": "Served at 8-10°C in tulip-shaped champagne glasses (not flat coupes). Sublime pairing with Beluga caviar, Gillardeau oysters, and truffled turbot.",
    "culinaryDe": "Bei 8-10°C im Tulpenglas (keine flache Schale!) servieren. Die Krönung zu Austern, Kaviar, pochiertem Steinbutt oder feinstem Comté.",
    "faqEn": "What is Blanc de Blancs? Champagne produced exclusively from 100% white Chardonnay grapes, prized for chalky minerality and razor-sharp elegance.",
    "faqDe": "Was bedeutet 'Blanc de Blancs'? Champagner, der zu 100% aus weißen Chardonnay-Trauben gekeltert wurde – besonders elegant, mineralisch und langlebig.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "Champagne",
      "Brut",
      "France",
      "Perlage",
      "AOC",
      "Luxury"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_prosecco_superiore_docg",
    "category": "wine",
    "nameEn": "Prosecco Superiore DOCG (Conegliano Valdobbiadene)",
    "nameDe": "Prosecco Superiore DOCG (Conegliano Valdobbiadene)",
    "subtitleEn": "Steep UNESCO hill slopes, 100% Glera grape, Martinotti tank perlage & floral aromatics",
    "subtitleDe": "Steillagen der UNESCO-Hügel, Glera-Traube, Metodo Martinotti (Tankgärung) & Blütenfrische",
    "imageUrl": "https://images.unsplash.com/photo-1558001373-7b93ee48ffa0?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Veneto: Conegliano Valdobbiadene - DOCG)",
    "isImport": false,
    "abv": "11.0% - 11.5% ABV",
    "tasteEn": "Crisp white peach, green apple, wisteria blossoms, acacia flowers, delicate frothy bubbles.",
    "tasteDe": "Weißer Pfirsich, grüner Apfel, Glyzinien- und Akazienblüten, erfrischend feinfruchtige Mousse.",
    "scienceEn": "Unlike Champagne's bottle fermentation, Prosecco Superiore uses the Metodo Martinotti / Charmat method: secondary fermentation takes place in temperature-controlled pressurized stainless steel autoclaves for 30-90 days. This preserves the delicate, primary floral and fruity terpene aromas of the aromatic Glera grape without heavy yeast or brioche notes. The superior DOCG classification comes from the steep hillside amphitheaters between Conegliano and Valdobbiadene (a UNESCO World Heritage site).",
    "scienceDe": "Im Gegensatz zur Flaschengärung beim Champagner wird Prosecco Superiore DOCG nach dem Metodo Martinotti (Tankgärung) im Drucktank vergoren. Das erhält die primären, fruchtigen Blütenaromen der Glera-Traube (Akazienblüte, Pfirsich), ohne sie mit hefigem Holz oder Briochenoten zu überlagern. Prosecco DOCG stammt ausschließlich von den spektakulären Steillagen zwischen Conegliano und Valdobbiadene (UNESCO-Welterbe).",
    "culinaryEn": "Chilled at 6-8°C in white wine glasses as the quintessential Italian aperitivo with Prosciutto di San Daniele and cicchetti.",
    "culinaryDe": "Gekühlt bei 6-8°C im Weißweinglas. Der ultimative italienische Aperitivo zu Prosciutto di San Daniele, gegrilltem Scampi und Cicchetti.",
    "faqEn": "Prosecco DOC vs Prosecco Superiore DOCG? Standard DOC is produced in flat valley floors; DOCG comes from steep handcrafted hillside terraces, offering vastly higher aromatics and minerality.",
    "faqDe": "Unterschied Prosecco DOC zu DOCG? Einfacher DOC wächst im Flachland; DOCG stammt von steilsten Hanglagen in Handarbeit mit unvergleichlich feinerer Perlage.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "Prosecco",
      "DOCG",
      "Valdobbiadene",
      "Italy",
      "Aperitivo"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_bordeaux_grand_cru",
    "category": "wine",
    "nameEn": "Bordeaux Grand Cru (Left Bank Médoc vs Right Bank)",
    "nameDe": "Bordeaux Grand Cru (Médoc & Saint-Émilion)",
    "subtitleEn": "Cabernet gravel power vs. Merlot clay velvet, aged in French barrique oak",
    "subtitleDe": "Cabernet-Kiesböden des Médoc vs. samtene Merlot-Opulenz aus Saint-Émilion & Pomerol",
    "imageUrl": "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Bordeaux: Haut-Médoc, Pauillac, Saint-Émilion - AOC)",
    "isImport": false,
    "abv": "13.0% - 14.5% ABV",
    "tasteEn": "Blackcurrant (cassis), graphite pencil shavings, cigar box cedar, leather, ripe structured tannins.",
    "tasteDe": "Schwarze Johannisbeere (Cassis), Zedernholz, Zigarrenkiste, Grafit, samtig-kraftvolles Tannin.",
    "scienceEn": "Bordeaux is divided by the Gironde estuary: 1) Left Bank (Médoc, Pauillac, Margaux): Deep gravel soils warm quickly, ripening thick-skinned Cabernet Sauvignon into wines with firm tannins, high acidity, cassis fruit, and pencil-lead minerality. 2) Right Bank (Saint-Émilion, Pomerol): Cooler clay and limestone soils favor early-ripening Merlot, producing lush, velvety, plum-scented wines. Matured 12-24 months in French oak barriques (225L) that polymerize tannins and infuse vanillin.",
    "scienceDe": "Die Welt von Bordeaux: Links der Gironde (Médoc, Pauillac) dominieren warme Kiesböden, ideal für die dickschalige Cabernet-Sauvignon-Traube (Cassis, Zeder, kraftvolle Gerbstoffe für jahrzehntelange Lagerung). Rechts der Gironde (Saint-Émilion, Pomerol) dominieren kühle Tonböden für die Merlot-Traube (saftig, Pflaume, samtiger Schmelz). Der 18- bis 24-monatige Barrique-Ausbau im Eichenfass bindet Gerbstoffe und sorgt für das legendäre Lagerpotenzial.",
    "culinaryEn": "Decanted at 17-18°C. Outstanding with roast rack of lamb with rosemary, Chateaubriand beef, and game venison.",
    "culinaryDe": "Bei 17-18°C dekantiert servieren. Ein Traum zu rosa Lammkarree mit Rosmarin, Chateaubriand, Hirschrücken und reifem Hartkäse.",
    "faqEn": "Why do fine Bordeaux wines need decanting? Decanting separates sediment in older vintages and introduces oxygen to soften tight tannins in younger bottles.",
    "faqDe": "Warum sollte man Bordeaux dekantieren? Bei reifen Weinen trennt es das Depot; bei jungen Weinen belüftet der Sauerstoff die kräftigen Gerbstoffe.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "Bordeaux",
      "GrandCru",
      "Cabernet",
      "Merlot",
      "Barrique",
      "RedWine"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_barolo_docg",
    "category": "wine",
    "nameEn": "Barolo DOCG ('King of Wines')",
    "nameDe": "Barolo DOCG (Der König der Weine)",
    "subtitleEn": "100% Nebbiolo grape, pale garnet hue, intoxicating tar & roses, ferocious noble tannins",
    "subtitleDe": "100% Nebbiolo-Traube aus dem Piemont, helles Granatrot, Duft nach Teer & Rosen, monumentale Tannine",
    "imageUrl": "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Piedmont: Langhe / Barolo - DOCG)",
    "isImport": false,
    "abv": "13.5% - 15.0% ABV",
    "tasteEn": "Pale translucent ruby, dried rose petals, tar, white truffle, sour cherry, gripping austere tannins.",
    "tasteDe": "Helles durchscheinendes Granatrot, getrocknete Rosenblätter, Teer, weißer Trüffel, Sauerkirsche, gigantisches Tannin.",
    "scienceEn": "Known as 'The Wine of Kings, and the King of Wines', Barolo is vinified exclusively from the late-ripening Nebbiolo grape (harvested in late October when autumn fogs, 'nebbia', blanket the hills). Despite its deceptively pale, brick-orange color, Nebbiolo has one of the highest natural tannin and acidity concentrations of any grape on Earth. DOCG law mandates at least 38 months of aging (min 18 months in oak casks; 62 months for Riserva) to soften its fierce astringency.",
    "scienceDe": "Der 'König der Weine' wird zu 100% aus der Nebbiolo-Traube gekeltert, die erst im späten Oktober bei herbstlichem Nebel ('nebbia') gelesen wird. Das Paradoxon des Barolo: Im Glas schimmert er erstaunlich hell, fast wie ein Spätburgunder; am Gaumen entfaltet er jedoch eine gewaltige Tannin- und Säurestruktur! Gesetzlich muss Barolo mindestens 38 Monate reifen (davon 18 Monate im Holzfass), damit die mächtigen Tannine samtig werden.",
    "culinaryEn": "Served in large Burgundy glasses at 18°C. The ultimate pairing for fresh Alba white truffles, tajarin pasta with sage butter, and brasato al Barolo (braised beef).",
    "culinaryDe": "Im großen Burgunderkelch bei 18°C. Die himmlische Kombination zu frischem weißen Alba-Trüffel über handgemachten Tajarin-Nudeln und piemontesischem Schmorbraten (Brasato).",
    "faqEn": "Why does Barolo look so light in the glass but taste so powerful? Nebbiolo skins are low in coloring anthocyanins but extraordinarily packed with condensed tannins and malic/tartaric acids.",
    "faqDe": "Warum ist Barolo so hellrot, schmeckt aber so wuchtig? Nebbiolo hat wenig Farbpigmente, aber enorme Mengen an edlen Gerbstoffen und Weinsäure.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "Barolo",
      "Nebbiolo",
      "Piedmont",
      "DOCG",
      "TruffleWine"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "wine_chianti_classico_docg",
    "category": "wine",
    "nameEn": "Chianti Classico DOCG (Gallo Nero)",
    "nameDe": "Chianti Classico DOCG (Schwarzer Hahn / Gallo Nero)",
    "subtitleEn": "Tuscan heartland, min 80% Sangiovese, bright sour cherry acidity & dried herbs",
    "subtitleDe": "Toskanisches Kernland, mind. 80% Sangiovese-Traube, animierende Sauerkirsch-Säure & mediterrane Kräuter",
    "imageUrl": "https://images.unsplash.com/photo-1506377247377-2a5b3b417ebb?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Tuscany: between Florence and Siena - DOCG)",
    "isImport": false,
    "abv": "12.5% - 14.0% ABV",
    "tasteEn": "Vibrant sour red cherry, dried oregano, sunbaked earth, violet flowers, food-loving savory acidity.",
    "tasteDe": "Knackige Sauerkirsche, getrockneter Oregano, warmer Waldboden, Veilchen, lebendige bekömmliche Weinsäure.",
    "scienceEn": "Chianti Classico (bearing the historic Black Rooster / Gallo Nero emblem) is strictly produced only in the original historical hill zone between Florence and Siena. The dominant grape is Sangiovese (literally 'Blood of Jove'). Sangiovese is celebrated for high natural acidity and medium-plus firm tannins that cleanse the palate of rich fats. Quality tiers: Annata (min 12 months), Riserva (min 24 months), and Gran Selezione (min 30 months from estate-only fruit).",
    "scienceDe": "Nur Weine aus dem historischen toskanischen Hügelland zwischen Florenz und Siena dürfen das Siegel des Schwarzen Hahns ('Gallo Nero') tragen. Die Sangiovese-Traube liefert die animierende Frische und feinen Gerbstoffe, die Fett im Essen perfekt ausbalancieren. Die Reifestufen: Chianti Classico (mind. 12 Monate), Riserva (mind. 24 Monate) und Gran Selezione (mind. 30 Monate Einzellagen-Spitzenwein).",
    "culinaryEn": "Served at 16-18°C. The iconic partner for Bistecca alla Fiorentina (dry-aged T-bone steak over charcoal), wild boar ragù, and pecorino toscano.",
    "culinaryDe": "Bei 16-18°C serviert. Der Weltklassiker zu Bistecca alla Fiorentina (gegrilltes T-Bone-Steak über Holzkohle), Pappardelle mit Wildschweinragù und gereiftem Pecorino.",
    "faqEn": "What does the Black Rooster on the neck of the bottle signify? The Gallo Nero is the historic symbol of the Chianti Classico Consortium, guaranteeing authentic production from the protected historical territory.",
    "faqDe": "Was bedeutet der schwarze Hahn auf der Banderole? Der Gallo Nero ist das Schutzsiegel des Konsortiums für echten Chianti Classico aus dem historischen Kerngebiet.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "ChiantiClassico",
      "GalloNero",
      "Sangiovese",
      "Tuscany",
      "DOCG"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_english_breakfast",
    "category": "tea",
    "nameEn": "English Breakfast Tea Blend",
    "nameDe": "English Breakfast Tea (Klassische Teemischung)",
    "subtitleEn": "Robust, full-bodied malty blend of Assam, Ceylon & Kenyan black teas",
    "subtitleDe": "Kräftig-malzige Schwarzteemischung aus Assam, Ceylon & Kenia – ideal mit Milch",
    "imageUrl": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80",
    "origin": "Blend (India / Assam, Sri Lanka / Ceylon & East Africa / Kenya)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Bold, rich maltiness, brisk astringency, deep amber liquor, smooth honey warmth with milk.",
    "tasteDe": "Kräftig, vollmundig malzig, lebendige herbe Frische, tief kupferrote Farbe, samtig mit Milch.",
    "scienceEn": "English Breakfast is engineered for milk compatibility. The blend utilizes high-tannin teas with elevated levels of theaflavins and thearubigins produced during full leaf oxidation. When cold whole milk is added, the milk protein casein binds to astringent polyphenols, softening bitterness while accentuating rich caramel and malt notes. Brewing: 100°C boiling water, 3-5 minutes infusion.",
    "scienceDe": "Klassische britische Teemischung, konzipiert für den Genuss mit Milch. Die vollfermentierten Teeblätter bilden Theaflavine und Thearubigine, die für die tiefrote Tassenfarbe und kräftige Tannine sorgen. Das Kasein-Protein der Milch bindet die Gerbstoffe sanft ab. Zubereitung: 100°C kochendes Wasser, 3 bis 5 Minuten Ziehzeit.",
    "culinaryEn": "Served in fine bone china with cold whole milk or lemon alongside full English breakfast, scones with clotted cream, or butter pastries.",
    "culinaryDe": "Klassisch im Porzellan mit einem Schluck kalter Vollmilch serviert zum herzhaften Frühstück, zu Scones mit Clotted Cream oder feinem Gebäck.",
    "faqEn": "Why does black tea turn milky without curdling? Casein proteins in fresh milk are stable in mild tea acidity (pH 5-6), smoothly encapsulating tea tannins.",
    "faqDe": "Warum flockt die Milch im Tee nicht? Die Säure im Schwarztee ist zu schwach (pH 5–6), um Milcheiweiß gerinnen zu lassen; das Kasein bindet stattdessen die herben Gerbstoffe.",
    "allergens": [
      "None"
    ],
    "tags": [
      "BlackTea",
      "Breakfast",
      "Assam",
      "Ceylon",
      "Malt",
      "British"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_earl_grey",
    "category": "tea",
    "nameEn": "Earl Grey (Black Tea with Bergamot)",
    "nameDe": "Earl Grey (Schwarztee mit Bergamotte)",
    "subtitleEn": "Black tea flavored with cold-pressed natural essential oil of Citrus bergamia",
    "subtitleDe": "Kräftig, malzig, zitrisch-herb durch naturreines Bergamotteöl aus Kalabrien",
    "imageUrl": "https://images.unsplash.com/photo-1594631252845-29fc4cc8cde9?w=800&auto=format&fit=crop&q=80",
    "origin": "Origin Blend (China / Ceylon) flavored with Italian Bergamot (Calabria)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Bright citrus freshness, aromatic floral lavender undertones, crisp dry tea finish.",
    "tasteDe": "Kräftig, malzig, zitrisch-herb durch Bergamotteöl; spritzige Eleganz, florale Kopfnote.",
    "scienceEn": "Named after Charles Grey, 2nd Earl Grey. Authentic high-end Earl Grey uses natural essential oil extracted by cold pressing the rind of Citrus bergamia fruits grown in Calabria, southern Italy. The volatile monoterpenes linalool and linalyl acetate provide the signature soothing, floral-citrus bouquet. Brewing: 95-100°C water, 3-4 minutes.",
    "scienceDe": "Benannt nach Premierminister Charles Grey. Das Geheimnis echten Earl Greys liegt im ätherischen Öl der Bergamotte (Citrus bergamia) aus Kalabrien. Die Terpene Linalool und Linalylacetat schenken den unverwechselbaren Duft. Zubereitung: 95–100°C heißes Wasser, 3–4 Minuten ziehen lassen.",
    "culinaryEn": "Served afternoon tea style with a lemon wedge or unadorned alongside shortbread, lemon tart, or chocolate macarons.",
    "culinaryDe": "Klassischer Afternoon Tea; pur oder mit einer Zitronenzeste zu Shortbread, Tarte au Citron oder Macarons servieren.",
    "faqEn": "Can you add milk to Earl Grey? While common in the UK, purists drink it black or with lemon, as milk fats can mute the delicate bergamot aromatics.",
    "faqDe": "Trinkt man Earl Grey mit Milch? Traditionell pur oder nur mit Zitrone genossen, da Milchfett das zarte Bergamottöl überdecken kann.",
    "allergens": [
      "None"
    ],
    "tags": [
      "EarlGrey",
      "Bergamot",
      "Citrus",
      "AfternoonTea",
      "BlackTea"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_sencha_japan",
    "category": "tea",
    "nameEn": "Sencha (Japanese Steamed Green Tea)",
    "nameDe": "Sencha (Japanischer Grüner Tee)",
    "subtitleEn": "Steamed green tea leaves; fresh, grassy, briskly astringent with delicate savory umami",
    "subtitleDe": "Frisch, grasig, leicht adstringierend, feines Umami – der König des japanischen Alltags",
    "imageUrl": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80",
    "origin": "Japan (Shizuoka, Uji / Kyoto, Kagoshima)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Fresh cut spring grass, marine oceanic breeze, sweet vegetal umami, clean refreshing finish.",
    "tasteDe": "Frisch, grasig, Meeresbrise, zarte vegetative Süße, feines Umami, belebend.",
    "scienceEn": "Japanese Sencha is steamed for 30-60 seconds ('Asamushi' light steam or 'Fukamushi' deep steam) rather than pan-fried. Steaming deactivates polyphenol oxidase enzymes instantly while preserving 100% of chlorophyll and catechins (EGCG). Steeping strictly at 70-80°C prevents harsh tannin extraction and highlights sweet amino acid L-Theanine.",
    "scienceDe": "Sencha wird mit heißem Wasserdampf schonend fixiert, wodurch die Enzyme gestoppt werden, ohne das smaragdgrüne Chlorophyll zu verbrennen. Niemals mit kochendem Wasser aufgießen (ideal 70–80°C für 60–90 Sekunden), da sonst Bitterstoffe dominieren und das zarte Umami des L-Theanins überdecken.",
    "culinaryEn": "Steeped in a Kyusu teapot at 75°C. The quintessential companion to sushi, sashimi, tempura, and grilled sea bass.",
    "culinaryDe": "In einer Kyusu-Kanne bei 75°C serviert. Der ideale Begleiter zu Sushi, Sashimi, Meeresfrüchten und Reisgerichten.",
    "faqEn": "Why does boiling water ruin green tea? Water above 85°C burns delicate leaves, extracting bitter catechins and destroying sweet umami amino acids.",
    "faqDe": "Warum wird Grüntee mit kochendem Wasser bitter? Wasser über 80°C löst aggressive Gerbstoffe und zerstört die süßlichen Aminosäuren.",
    "allergens": [
      "None"
    ],
    "tags": [
      "GreenTea",
      "Sencha",
      "Japan",
      "Umami",
      "Antioxidants"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_matcha_japan",
    "category": "tea",
    "nameEn": "Ceremonial Matcha (Stone-Ground Green Tea Powder)",
    "nameDe": "Matcha (Zeremonielles Grünteepulver)",
    "subtitleEn": "Shaded tencha leaves stone-ground into micro-powder; intense vegetal creaminess & deep umami",
    "subtitleDe": "Intensiv pflanzlich, cremig, kräftiges Umami, leicht herb – volles Teeblatt im Aufguss",
    "imageUrl": "https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=800&auto=format&fit=crop&q=80",
    "origin": "Japan (Uji / Kyoto & Nishio / Aichi)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Thick, creamy, intense sweet chlorophyll, deep savory broth-like umami, velvety lingering sweetness.",
    "tasteDe": "Intensiv pflanzlich, cremig, kräftiges Umami, samtig-smaragdgrüner Schaum, mild-herb.",
    "scienceEn": "Matcha bushes are shaded under bamboo/black nets for 3-4 weeks prior to harvest. Sunlight deprivation forces the plant to massively increase chlorophyll and the amino acid L-Theanine. Leaves are deveined (Tencha) and ground on granite stone mills (taking 1 hour to grind 30g). When whisked with a bamboo chasen at 75-80°C, the entire leaf is suspended and consumed, delivering 3x the antioxidants of steeped tea.",
    "scienceDe": "Die Beschattung zwingt die Teepflanze zur massiven Bildung von Chlorophyll und L-Theanin. Die Blattrippen werden entfernt und die Blattspreiten auf Granitmühlen zu 5–10 Mikrometer feinem Puder vermahlen. Mit dem Bambusbesen (Chasen) schaumig geschlagen, wird das gesamte Teeblatt getrunken.",
    "culinaryEn": "Whisked traditionally in a Chawan bowl or as modern Matcha Latte with oat milk, white chocolate, or matcha ice cream.",
    "culinaryDe": "In der Matcha-Schale zeremoniell aufgeschlagen, als Matcha Latte mit Hafermilch oder in edler Patisserie.",
    "faqEn": "Culinary vs. Ceremonial grade Matcha? Ceremonial uses the youngest shaded first-harvest spring leaves; culinary uses later harvests with more astringency for baking.",
    "faqDe": "Unterschied Ceremonial zu Culinary Matcha? Ceremonial nutzt die zartesten Frühlingsblätter für puren Trinkgenuss; Culinary ist herber für Küche und Gebäck.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Matcha",
      "Ceremonial",
      "Japan",
      "Uji",
      "Umami",
      "Chasen"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_jasmin_fujian",
    "category": "tea",
    "nameEn": "Jasmine Green Tea (Moli Hua Cha)",
    "nameDe": "Jasmintee (Blütentee auf Grünteebasis)",
    "subtitleEn": "Tender green tea pearls scented naturally overnight across multiple cycles with night-blooming jasmine flowers",
    "subtitleDe": "Hoch aromatisch, floral, weich, erfrischend süßlich – handgerollt und über echten Blüten bedampft",
    "imageUrl": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80",
    "origin": "China (Fujian Province / Fuzhou)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Intoxicating sweet jasmine perfume, honeyed floral elegance, crisp clean soothing green tea base.",
    "tasteDe": "Hoch aromatisch, betörend floral, weich, erfrischend süßlich ohne jede Bitternis.",
    "scienceEn": "High-grade Jasmine tea is NOT flavored with chemical sprays. Spring green tea is rolled into 'Dragon Pearls'. In midsummer, when Jasminum sambac flowers burst open after sunset, tea is layered with fresh blossoms overnight (up to 7 scenting cycles). The dry tea absorbs moisture and volatile essential oils (benzyl acetate, linalool) before blossoms are sieved out.",
    "scienceDe": "Hochwertiger Jasmintee wird niemals künstlich parfümiert. Im Sommer, wenn die echten Jasminblüten nachts aufbrechen, wird der Tee schichtweise mit frischen Blüten gelagert. Die hygroskopischen Teeblätter saugen das Blütenöl auf. Dieser Prozess wird bis zu siebenmal mit jeweils frischen Blüten wiederholt.",
    "culinaryEn": "Steeped at 80°C in clear glass pots. The premier pairing for steamed dim sum, Cantonese roast duck, and spicy wok dishes.",
    "culinaryDe": "Bei 80°C in der Glaskanne serviert. Unverzichtbar zu Dim Sum, gedämpftem Fisch, Geflügel und scharfen Wok-Gerichten.",
    "faqEn": "Why do jasmine pearls unfurl into whole shoots? Skilled artisans hand-roll young two-leaf shoots around white downy buds, locking in floral oils.",
    "faqDe": "Warum öffnen sich die Perlen im Wasser? Weil die zarten Blatttriebe im Frühling von Hand zu Kugeln gerollt wurden, die sich in heißem Wasser entfalten.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Jasmine",
      "GreenTea",
      "China",
      "Fujian",
      "Floral",
      "DimSum"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_pai_mu_tan_white",
    "category": "tea",
    "nameEn": "Pai Mu Tan / White Peony (Chinese White Tea)",
    "nameDe": "Pai Mu Tan / Weiße Pfingstrose (Weißer Tee)",
    "subtitleEn": "Sun-withered silvery buds & tender leaves; delicate, velvety, subtly fruity with minimal bitterness",
    "subtitleDe": "Zart, samtig, subtil fruchtig, minimale Bitterkeit – der am wenigsten verarbeitete Tee der Welt",
    "imageUrl": "https://images.unsplash.com/photo-1594631252845-29fc4cc8cde9?w=800&auto=format&fit=crop&q=80",
    "origin": "China (Fujian Province / Fuding & Zhenghe)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Delicate floral peony sweetness, subtle white peach, fresh hay, velvety soft mouthfeel, zero astringency.",
    "tasteDe": "Zart, samtig, Noten von weißem Pfirsich und Pfingstrose, feine Heunote, minimale Bitterkeit, süßlicher Nachhall.",
    "scienceEn": "White tea represents the purest, least processed form of tea: leaves are neither steamed, pan-fired, nor deliberately rolled. Freshly plucked shoots with silvery down ('bai hao') are simply withered on bamboo racks in sunlight and gently hot-air dried. This minimal intervention preserves massive concentrations of polyphenols and catechins without breaking cell walls, yielding a liquor that never turns bitter even with long steeping (80-85°C for 4-6 minutes).",
    "scienceDe": "Weißer Tee ist der naturbelassenste Tee der Welt: Er wird weder gerollt noch künstlich fermentiert, sondern nur schonend auf Bambusmatten in der Sonne gewelkt und getrocknet. Der feine weiße Flaum auf den Knospen schützt die zarten Blätter. Wegen der intakten Zellwände werden kaum Gerbstoffe frei – er wird selbst bei langer Ziehzeit (bei 80–85°C) niemals bitter.",
    "culinaryEn": "Served in clear glass or porcelain at 80-85°C. Complements goat cheese, poached white fish, and delicate French pastries.",
    "culinaryDe": "Bei 80–85°C im feinen Porzellan servieren; harmoniert wunderbar mit Ziegenkäse, pochiertem Fisch und Feingebäck.",
    "faqEn": "Why is white tea so pale in the cup? Because it is unoxidized and uncrushed, releasing clear pale-champagne liquor rather than dark tannins.",
    "faqDe": "Warum ist weißer Tee so hell in der Tasse? Weil die Blätter ungequetscht und unfermentiert getrocknet werden – die Tasse schimmert wie heller Champagner.",
    "allergens": [
      "None"
    ],
    "tags": [
      "WhiteTea",
      "PaiMuTan",
      "Fujian",
      "Peony",
      "Delicate",
      "Antioxidants"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_oolong_wuyi_dahongpao",
    "category": "tea",
    "nameEn": "Oolong Tea (Tie Guan Yin & Wuyi Rock Oolong)",
    "nameDe": "Oolong (Teilfermentiert, z. B. Tie Guan Yin)",
    "subtitleEn": "Semi-oxidized artisan tea (20-70%); roasted, nutty with orchid florality & dried stone fruit",
    "subtitleDe": "Röstig, nussig, mit Noten von Orchideen und Trockenobst – Brücke zwischen Grün- und Schwarztee",
    "imageUrl": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80",
    "origin": "China (Fujian / Anxi & Wuyi Mountains) / Taiwan",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Roasted charcoal warmth, toasted hazelnut, delicate sweet orchid aroma, ripe peach, mineral wet-stone finish.",
    "tasteDe": "Röstig, nussig, warme Orchideenblüte, getrocknete Aprikose, samtiger Körper, mineralisch.",
    "scienceEn": "Oolong requires master craftsmanship: leaves are withered and shaken in bamboo baskets ('bruising'). Cell walls at leaf edges break down, initiating oxidation while the core stays green. Oxidation is abruptly halted (20-70%) by wok firing ('shāqīng') followed by rolling and multi-stage charcoal roasting. Gongfu Cha multiple steepings (up to 8 rounds) release successive aromatic layers.",
    "scienceDe": "Oolong ('Schwarzer Drache') vereint die Frische des Grüntees mit der Tiefe des Schwarztees. Die Ränder der Blätter werden durch Schütteln gebrochen und oxidieren rotbraun, während der Kern grün bleibt. Beim traditionellen Gongfu-Aufguss entfalten dieselben Blätter bis zu achtmal neue Geschmacksfacetten.",
    "culinaryEn": "Steeped Gongfu style in Yixing clay teapots with boiling water. Excellent companion to roasted duck, wild mushrooms, and aged Comté cheese.",
    "culinaryDe": "In kleiner Tonkanne (Gongfu Cha) bei 90–95°C serviert. Hervorragend zu gebratener Ente, Pilzgerichten und geröstetem Wurzelgemüse.",
    "faqEn": "Can Oolong tea leaves be steeped multiple times? Yes, premium whole-leaf oolongs yield 6 to 8 rewarding infusions, peaking around steep 3 and 4.",
    "faqDe": "Kann man Oolong mehrfach aufgießen? Ja, Spitzen-Oolongs entfalten ihr reichhaltigstes Aroma oft erst beim dritten oder vierten Aufguss.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Oolong",
      "TieGuanYin",
      "Wuyi",
      "GongfuCha",
      "Orchid",
      "China"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_rooibos_south_africa",
    "category": "tea",
    "nameEn": "Rooibos (Caffeine-Free South African Red Bush)",
    "nameDe": "Rooibos (Rotbuschtee aus Südafrika)",
    "subtitleEn": "Endemic Cape fynbos shrub; naturally caffeine-free, sweet, woody, vanilla & earthy warmth",
    "subtitleDe": "Natürlich süß, holzig, vanillig, erdig – 100% koffeinfrei und extrem säure- und gerbstoffarm",
    "imageUrl": "https://images.unsplash.com/photo-1594631252845-29fc4cc8cde9?w=800&auto=format&fit=crop&q=80",
    "origin": "South Africa (Western Cape / Cederberg Mountains)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Natural honeyed sweetness, warm woody vanilla, earthy caramel, zero bitter tannins, soothing smooth finish.",
    "tasteDe": "Natürlich süß, warm holzig, feine Vanille- und Karamellnote, erdig, vollkommen frei von Bitternis.",
    "scienceEn": "Botanically distinct from Camellia sinensis, Rooibos comes from Aspalathus linearis, a legume shrub growing exclusively in the sandy Cederberg mountains of South Africa. The harvested needle twigs are bruised, watered, and fermented in outdoor heaps in the sun; enzymatic oxidation turns the green plant into a rich mahogany red, synthesizing the unique antioxidant aspalathin. Because it contains ZERO caffeine and minimal tannins, it never turns bitter even if boiled.",
    "scienceDe": "Rooibos ist kein echter Tee, sondern ein Ginstergewächs aus den Cederbergen Südafrikas. Beim Fermentieren in der Sonne oxidieren die Blätter rotbraun und bilden das seltene Flavonoid Aspalathin. Da Rooibos von Natur aus 100% koffeinfrei und extrem tanninarm ist, kann er bedenkenlos abends getrunken werden und wird niemals bitter.",
    "culinaryEn": "Infused with boiling water for 5-8 minutes. Delicious pure, with a splash of oat milk and honey, or iced with apple and cinnamon.",
    "culinaryDe": "Bei 100°C 5–8 Minuten ziehen lassen. Ideal am Abend, mit Hafermilch und Honig oder als Eistee mit Apfelsaft und Zimt.",
    "faqEn": "Can Rooibos cause sleep problems? No: it is 100% naturally caffeine-free and rich in relaxing minerals (magnesium, zinc).",
    "faqDe": "Kann Rooibos den Schlaf stören? Keineswegs: Er ist von Natur aus völlig koffeinfrei und eignet sich perfekt als Schlummertrunk.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Rooibos",
      "CaffeineFree",
      "SouthAfrica",
      "Cederberg",
      "Vanilla",
      "HerbalInfusion"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_pfefferminze_moroccan",
    "category": "tea",
    "nameEn": "Peppermint & Moroccan Nana Mint",
    "nameDe": "Pfefferminze / Marokkanische Minze (Kräuter)",
    "subtitleEn": "Menthol-rich aromatic herbs; intensely cooling, invigorating, digestive powerhouse",
    "subtitleDe": "Kühlend, mentholig, belebend – Klassiker zur Verdauungsförderung und als Erfrischung",
    "imageUrl": "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=800&auto=format&fit=crop&q=80",
    "origin": "Morocco / North Africa & Central Europe (Mentha x piperita / Mentha spicata)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Instant crisp cold rush from menthol, clean herbal sweetness, peppery warmth, intensely refreshing finish.",
    "tasteDe": "Kühlend, intensiv mentholig, kräuterig-frisch, belebend, reinigend auf Gaumen und Atem.",
    "scienceEn": "Peppermint is a natural hybrid of spearmint and water mint. Its active essential oil consists of 40-50% menthol. Menthol specifically binds to the TRPM8 ion channel in sensory nerve fibers, which normally responds to physical cold temperatures; this tricks the brain into perceiving an icy blast of cooling freshness without temperature change. In Moroccan 'Maghrebi mint tea', fresh spearmint is steeped with gunpowder green tea and cane sugar.",
    "scienceDe": "Pfefferminze enthält bis zu 50% Menthol im ätherischen Öl. Menthol bindet an Kälterezeptoren (TRPM8) im Mundraum, wodurch das Gehirn einen eisigen Frischekick registriert. Gleichzeitig entspannt Menthol die glatte Magenmuskulatur, was die Verdauung nach fettreichen Speisen nachweislich unterstützt. In Marokko wird frische Nana-Minze mit Gunpowder-Grüntee im Silberkännchen serviert.",
    "culinaryEn": "Hot digestive tea served after rich feasts, or iced as Moroccan cold brew with fresh lime and honey.",
    "culinaryDe": "Heiß serviert nach fettreichen Speisen; oder eisgekühlt mit Limette und Honig als erfrischender Eistee.",
    "faqEn": "Why does mint water taste ice-cold even when warm? Menthol sensitizes cold receptors (TRPM8) on the tongue, creating the illusion of coldness.",
    "faqDe": "Warum schmeckt Minztee eiskalt, obwohl er heiß ist? Menthol stimuliert die Kälterezeptoren der Zunge, was dem Gehirn Kälte signalisiert.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Peppermint",
      "NanaMint",
      "Morocco",
      "Menthol",
      "Digestive",
      "HerbalTea"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "tea_darjeeling_himalaya",
    "category": "tea",
    "nameEn": "Darjeeling Single Estate ('Champagne of Teas')",
    "nameDe": "Darjeeling Hochlandtee ('Champagner unter den Tees')",
    "subtitleEn": "High-altitude Himalayan terroir, First vs Second Flush, famous muscatel aroma",
    "subtitleDe": "Himalaya-Steillagen auf 2.000m Höhe, First vs. Second Flush, berühmte Muskatellernote",
    "imageUrl": "https://images.unsplash.com/photo-1594631252845-29fc4cc8cde9?w=800&auto=format&fit=crop&q=80",
    "origin": "India (West Bengal / Darjeeling Himalayan Foothills - PGI)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "First Flush: Floral, brisk, spring green grape, peach. Second Flush: Warm amber, ripe muscatel grape, nutty finish.",
    "tasteDe": "First Flush: Zart blumig, spritzig, grüner Pfirsich. Second Flush: Vollmundig, reife Muskatellertraube, nussig.",
    "scienceEn": "Darjeeling tea is cultivated on steep Himalayan slopes under intense mountain UV radiation and cool nights. First Flush (Spring harvest) leaves are only lightly oxidized (~20-40%), producing a liquor resembling fine oolong. Second Flush (Summer harvest) triggers defensive terpenoid compounds that generate the world-famous 'Muscatel' grape character.",
    "scienceDe": "Darjeeling wächst an steilen Hängen des Himalayas auf bis zu 2.000 Metern Höhe unter geschützter geografischer Angabe (g.g.A.). First Flush leuchtet goldgelb und schmeckt blumig-spritzig; Second Flush entwickelt das weltberühmte 'Muscatel-Aroma' – eine warme, traubig-nussige Note.",
    "culinaryEn": "Steeped at 90-95°C for 3 minutes. Served purely black in porcelain cups; never adulterated with milk or sugar.",
    "culinaryDe": "Bei 90–95°C für 3 Minuten ziehen lassen. Ausschließlich pur im feinen Porzellan ohne Milch und ohne Zucker genießen!",
    "faqEn": "Why is Darjeeling called the Champagne of Teas? Like Champagne, it possesses strict geographical protection, unmatched terroir-driven complexity, and rare muscatel flavor.",
    "faqDe": "Warum heißt Darjeeling 'Champagner der Tees'? Wegen der geschützten Herkunft, der extremen Steillagen und der unvergleichlich eleganten Muskatellernote.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Darjeeling",
      "FirstFlush",
      "SecondFlush",
      "Himalaya",
      "PGI",
      "GourmetTea"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "soft_sparkling_water",
    "category": "soft_drinks",
    "nameEn": "Sparkling Mineral Water & CO2",
    "nameDe": "Mineralwasser & Kohlensäurelehre",
    "subtitleEn": "How CO2 dissolves into water forming carbonic acid (H2CO3)",
    "subtitleDe": "Wie gelöstes CO2 Kohlensäure (H2CO3) bildet und prickelt",
    "imageUrl": "https://images.unsplash.com/photo-1559839914-ba2a11b66df8?w=800&auto=format&fit=crop&q=80",
    "origin": "Global / Natural Springs",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Crisp effervescence, clean mineral balance (calcium, magnesium, bicarbonate).",
    "tasteDe": "Frisches Prickeln, belebende Säurespitze, mineralische Klarheit.",
    "scienceEn": "CO2 injected under pressure reacts with water to form carbonic acid (CO2 + H2O <-> H2CO3), lowering pH slightly to ~4.5. On the tongue, bursting bubbles stimulate cold mechanoreceptors and the enzyme carbonic anhydrase.",
    "scienceDe": "Unter Druck gelöstes CO2 bildet schwache Kohlensäure (H2CO3). Der leicht saure pH-Wert und das Platzen der Gasbläschen stimulieren Rezeptoren auf der Zunge und signalisieren maximale Frische.",
    "culinaryEn": "Chilled at 6-8°C. Cleanses the palate between rich courses and wine tastings.",
    "culinaryDe": "Gekühlt bei 6-8°C serviert. Neutralisiert den Gaumen ideal zwischen Gängen.",
    "faqEn": "Why does sparkling water taste slightly sour? Carbonic acid is an actual acid (H2CO3) that slightly lowers the water's pH.",
    "faqDe": "Warum schmeckt Sprudel säuerlich? Weil gelöstes CO2 echte Kohlensäure (H2CO3) bildet und den pH-Wert absenkt.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Water",
      "Carbonation",
      "CO2",
      "Minerals"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "soft_cola",
    "category": "soft_drinks",
    "nameEn": "Classic Cola & Botanical Syrups",
    "nameDe": "Klassische Cola & Sirup-Botanicals",
    "subtitleEn": "Kola nut extract, citrus oils, warm spices, and phosphoric acid",
    "subtitleDe": "Kolanuss-Extrakt, Zitrusöle, warme Gewürze und Phosphorsäure",
    "imageUrl": "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=800&auto=format&fit=crop&q=80",
    "origin": "USA / Worldwide",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet vanilla-caramel, spicy herbal undertone, sharp phosphoric bite.",
    "tasteDe": "Karamell- und Vanillenoten, würziger Kräuterhintergrund, herber Säurebiss.",
    "scienceEn": "Phosphoric acid (H3PO4) provides a dry, sharp bite that balances high sweetness without imparting fruity flavors like citric acid. Kola nuts provide caffeine and theobromine.",
    "scienceDe": "Phosphorsäure (H3PO4) liefert einen trockenen, säuerlichen Biss, der die hohe Zuckersüße bricht, ohne fruchtig zu schmecken. Kolanüsse liefern natürliches Koffein.",
    "culinaryEn": "Cuba Libre (with rum), Long Island Iced Tea, or BBQ marinades.",
    "culinaryDe": "Klassisch im Cuba Libre mit Rum und Limette; oder für herzhafte BBQ-Glasuren.",
    "faqEn": "Why is cola brown? Caramel color (E150d), produced by heating carbohydrates.",
    "faqDe": "Woher die dunkle Farbe? Von Zuckerkulör (E150d), durch kontrolliertes Erhitzen von Zucker.",
    "allergens": [
      "Caffeine"
    ],
    "tags": [
      "Cola",
      "Spices",
      "Phosphoric",
      "SoftDrink"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "soft_tonic_water",
    "category": "soft_drinks",
    "nameEn": "Indian Tonic Water",
    "nameDe": "Indian Tonic Water",
    "subtitleEn": "Quinine bark extract providing bitter counterpoint to spirits",
    "subtitleDe": "Chinin-Rindenextrakt als feinherber Gegenpol zu Spirituosen",
    "imageUrl": "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=800&auto=format&fit=crop&q=80",
    "origin": "India / British Colonial era",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Distinct quinine bitterness, balanced crisp sweetness, lemon-citrus freshness.",
    "tasteDe": "Markant bittere Chininnote, balancierte Süße, frische Zitrusanklänge.",
    "scienceEn": "Quinine from Cinchona bark binds to TAS2R bitter receptors. Under ultraviolet light (UV blacklight), quinine molecules fluoresce bright cyan blue.",
    "scienceDe": "Chinin aus der Rinde des Chinarindenbaums erzeugt die Edle Bitterkeit. Unter UV-Licht (Schwarzlicht) fluoresziert Chinin leuchtend blau.",
    "culinaryEn": "Gin & Tonic in a Copa glass or trendy Espresso Tonic.",
    "culinaryDe": "Klassiker im Gin Tonic oder Trendgetränk Espresso Tonic mit Rosmarinzweig.",
    "faqEn": "Why is it bitter? Quinine is an intensely bitter alkaloid originally used to prevent malaria.",
    "faqDe": "Warum bitter? Chinin ist ein natürliches Bitteralkaloid, das historisch als Malariaprophylaxe diente.",
    "allergens": [
      "Contains Quinine (Chinin"
    ],
    "tags": [
      "Tonic",
      "Quinine",
      "Bitter",
      "Mixer",
      "Fluorescence"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "soft_bitter_lemon",
    "category": "soft_drinks",
    "nameEn": "Bitter Lemon",
    "nameDe": "Bitter Lemon",
    "subtitleEn": "Carbonated mixer combining whole lemon juice & peel oils with quinine",
    "subtitleDe": "Herb-frischer Filler aus Zitronensaft, Schalenöl und Chinin",
    "imageUrl": "https://images.unsplash.com/photo-1577805947697-89e18249d767?w=800&auto=format&fit=crop&q=80",
    "origin": "Europe (1957)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Tart sour citrus, aromatic lemon essential oils, clean dry bitter finish.",
    "tasteDe": "Säuerlich-frische Zitrone, herb-ätherische Schalenöle, trockener Chinin-Nachhall.",
    "scienceEn": "Combines lemon juice (citric acid), cold-pressed flavedo peel oil (limonene), and quinine alkaloid, stimulating sour + bitter receptors simultaneously.",
    "scienceDe": "Verbindet Fruchtsäure, Schalenöle (Limonen) und Chinin zu einem erfrischend herben Dreiklang.",
    "culinaryEn": "In Vodka Lemon or non-alcoholic aperitif on crushed ice with mint.",
    "culinaryDe": "Im Vodka Lemon oder alkoholfrei mit frischer Minze auf Crushed Ice.",
    "faqEn": "How does it differ from lemonade? Bitter Lemon contains quinine and peel oils giving a dry, sophisticated bitterness.",
    "faqDe": "Unterschied zu Zitronenlimonade? Bitter Lemon enthält herbes Chinin und ätherische Schalenöle statt nur Süße.",
    "allergens": [
      "Contains Quinine"
    ],
    "tags": [
      "Lemon",
      "Bitter",
      "Quinine",
      "Mixer"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "soft_ginger_ale_beer",
    "category": "soft_drinks",
    "nameEn": "Ginger Ale vs. Ginger Beer",
    "nameDe": "Ginger Ale vs. Ginger Beer",
    "subtitleEn": "Carbonated ginger soda vs. traditionally brewed fermented spicy ginger root",
    "subtitleDe": "Kohlensäure-Limonade vs. traditionell gebrauter, scharfer Ingwer-Brew",
    "imageUrl": "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=800&auto=format&fit=crop&q=80",
    "origin": "Ireland & England",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Ginger Ale: Mild sweet, gentle warmth. Ginger Beer: Fiery ginger spice, cloudy, peppery bite.",
    "tasteDe": "Ginger Ale: Mild, süffig. Ginger Beer: Kräftig scharf, naturtrüb, feuriger Ingwerbiss.",
    "scienceEn": "Ginger's heat stems from gingerols. When heated, gingerols convert to shogaols (twice as pungent). Ginger beer is traditionally brewed and cloudy.",
    "scienceDe": "Schärfe rührt von Gingerolen her. Ginger Ale ist eine klare Limonade; Ginger Beer wird traditionell gebraut, ist trüb und deutlich schärfer.",
    "culinaryEn": "Ginger Ale: Horse's Neck. Ginger Beer: Moscow Mule and Dark 'n' Stormy.",
    "culinaryDe": "Ginger Beer zwingend im Moscow Mule (im Kupferbecher) und Dark 'n' Stormy.",
    "faqEn": "Is Ginger Beer alcoholic? Commercial bar ginger beers are non-alcoholic (<0.5% ABV).",
    "faqDe": "Enthält Ginger Beer Alkohol? Handelsübliches Bar-Ginger-Beer ist alkoholfrei.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Ginger",
      "Spicy",
      "MoscowMule",
      "SoftDrink"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "soft_energy_drink",
    "category": "soft_drinks",
    "nameEn": "Energy Drinks Composition",
    "nameDe": "Energy Drinks Zusammensetzung",
    "subtitleEn": "Caffeine stimulant, taurine, B-complex vitamins, and glucuronolactone",
    "subtitleDe": "Koffein-Stimulanz, Taurin, B-Vitamine und Glucuronolacton",
    "imageUrl": "https://images.unsplash.com/photo-1527661591475-527312dd65f5?w=800&auto=format&fit=crop&q=80",
    "origin": "Austria / Thailand",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet candy-tart profile, gummy bear aroma, citric acidity.",
    "tasteDe": "Süß-säuerlich, Gummibärchen-Aroma, markante Zitrusfrische.",
    "scienceEn": "Caffeine blocks adenosine receptors. Taurine stabilizes cell hydration. Commercial taurine is 100% synthetically produced and vegan.",
    "scienceDe": "Koffein (EU-Limit: 32mg/100ml) blockiert Müdigkeitsrezeptoren. Das enthaltene Taurin ist rein synthetisch und 100% vegan.",
    "culinaryEn": "Chilled over ice or in nightlife cocktails.",
    "culinaryDe": "Eiskalt serviert in der Nachtgastronomie.",
    "faqEn": "Does taurine come from bulls? No, commercial taurine is 100% synthetically synthesized in certified labs.",
    "faqDe": "Stammt Taurin aus Stieren? Nein, das Bar-Taurin wird rein synthetisch hergestellt und ist komplett vegan.",
    "allergens": [
      "High caffeine content (32mg/100ml"
    ],
    "tags": [
      "Energy",
      "Caffeine",
      "Taurine",
      "Stimulant"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "coffee_espresso",
    "category": "coffee",
    "nameEn": "Espresso & Crema Science",
    "nameDe": "Espresso & Crema-Wissenschaft",
    "subtitleEn": "25-30ml extracted at 9 bar pressure and 90-96°C in 25-30 seconds",
    "subtitleDe": "25-30ml Extraktion unter 9 bar Pumpendruck bei 90-96°C in 25-30 Sekunden",
    "imageUrl": "https://images.unsplash.com/photo-1510591509098-f4fdc6d0ff04?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Turin / Milan)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Intense, concentrated, dark chocolate, hazelnut crema, syrupy body, balanced acidity.",
    "tasteDe": "Konzentriert, intensiv, Bitterschokolade, nussige Crema, samtig-viskoser Körper.",
    "scienceEn": "High pressure (9 bar) forces hot water (92-94°C) through compacted coffee. Crema forms when dissolved CO2 is emulsified by coffee lipids.",
    "scienceDe": "9 bar Pumpendruck und 92-94°C heißes Wasser. Die Crema entsteht als Emulsion aus Kaffeeölen und mikroskopischen CO2-Gasbläschen.",
    "culinaryEn": "Pre-warmed thick ceramic demitasse with a glass of still water.",
    "culinaryDe": "In vorgewärmter Espressotasse mit einem Glas Wasser servieren.",
    "faqEn": "Why does Robusta have more crema? Less lipids and higher CO2 yield thicker foam.",
    "faqDe": "Warum hat Robusta mehr Crema? Robusta enthält weniger hemmende Fette und mehr lösliche Feststoffe.",
    "allergens": [
      "Caffeine"
    ],
    "tags": [
      "Coffee",
      "Espresso",
      "Crema",
      "Italian"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 1,
      "steamedMilkPercent": 0,
      "milkFoamPercent": 0,
      "waterPercent": 0,
      "descriptionEn": "",
      "descriptionDe": ""
    }
  },
  {
    "id": "coffee_cappuccino",
    "category": "coffee",
    "nameEn": "Classic Italian Cappuccino",
    "nameDe": "Klassischer Cappuccino",
    "subtitleEn": "Harmonious rule of thirds: 1/3 espresso, 1/3 steamed milk, 1/3 microfoam",
    "subtitleDe": "Klassische Drittel-Regel: 1/3 Espresso, 1/3 heiße Milch, 1/3 feinporiger Schaum",
    "imageUrl": "https://images.unsplash.com/photo-1534778101976-62847782c213?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy / Austria (Kapuziner)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Velvety sweetness, creamy mouthfeel, prominent espresso backbone, silky texture.",
    "tasteDe": "Cremige Süße, seidige Textur, klar präsentes Espressoroma, samtiger Schaum.",
    "scienceEn": "Milk protein (whey and casein) denatures at 60-65°C, trapping injected steam air into microfoam. Steaming above 70°C scalds proteins.",
    "scienceDe": "Milcheiweiße falten sich bei 60-65°C auf und hüllen Luftblasen mikrofein ein. Über 70°C gerinnt das Eiweiß und der Schaum kollabiert.",
    "culinaryEn": "Wide 150-180ml ceramic cup decorated with latte art.",
    "culinaryDe": "In 150-180ml Tasse mit Latte Art serviert. In Italien traditionell vor 11:00 Uhr.",
    "faqEn": "Cappuccino vs Latte? Cappuccino has equal thirds (~180ml); Latte has much more milk and very thin foam (~250ml+).",
    "faqDe": "Cappuccino vs Café Latte? Cappuccino hat eine kräftige Schaumkrone im Drittel-Verhältnis; Café Latte hat viel mehr Milch.",
    "allergens": [
      "Milk / Dairy"
    ],
    "tags": [
      "Cappuccino",
      "Coffee",
      "Microfoam",
      "Milk"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 0.33,
      "steamedMilkPercent": 0.34,
      "milkFoamPercent": 0.33,
      "waterPercent": 0,
      "descriptionEn": "",
      "descriptionDe": ""
    }
  },
  {
    "id": "coffee_latte_macchiato",
    "category": "coffee",
    "nameEn": "Latte Macchiato",
    "nameDe": "Latte Macchiato",
    "subtitleEn": "Layered drink: Steamed milk, espresso shot poured through, dense foam top",
    "subtitleDe": "Geschichtetes Getränk: Heiße Milch, Espresso durchgegossen, Schaumkrone",
    "imageUrl": "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Mild, milky-sweet, espresso notes concentrated in the middle layer, dessert-like.",
    "tasteDe": "Mild, milchig-süß, sanfte Kaffeenote in der mittleren Schicht, harmonisch.",
    "scienceEn": "3 layers form due to density: warm milk is densest at the bottom; airy foam is lightest at top; hot espresso floats between them.",
    "scienceDe": "3 Schichten durch Dichteunterschied: Schwere Milch unten, leichter Schaum oben; der heiße Espresso schichtet sich exakt dazwischen.",
    "culinaryEn": "Tall transparent heatproof glass with a long spoon.",
    "culinaryDe": "Im hohen transparenten Glas mit langem Löffel servieren.",
    "faqEn": "What does Macchiato mean? 'Stained' or 'spotted'. Latte Macchiato = stained milk.",
    "faqDe": "Was heißt Macchiato? 'Gefleckt'. Latte Macchiato = mit Kaffee gefleckte Milch.",
    "allergens": [
      "Milk / Dairy"
    ],
    "tags": [
      "LatteMacchiato",
      "Coffee",
      "Layered",
      "Milk"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 0.2,
      "steamedMilkPercent": 0.55,
      "milkFoamPercent": 0.25,
      "waterPercent": 0,
      "descriptionEn": "",
      "descriptionDe": ""
    }
  },
  {
    "id": "coffee_tuerkisch_cezve",
    "category": "coffee",
    "nameEn": "Turkish Coffee (Türk Kahvesi & Cezve Decoction)",
    "nameDe": "Türkischer Kaffee (Mokka & Cezve-Zubereitung)",
    "subtitleEn": "UNESCO intangible heritage: Flour-fine grind simmered unfiltered in copper Cezve with cardamom",
    "subtitleDe": "UNESCO-Weltkulturerbe: Staubfein gemahlen, mit Kardamom im Kupferkännchen ungefiltert aufgekocht",
    "imageUrl": "",
    "origin": "Turkey / Middle East & Balkans (UNESCO Cultural Heritage)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Deep, velvety, intense body, dark chocolate, spicy green cardamom warmth, dense aromatic crema foam (Köpük).",
    "tasteDe": "Sehr dicht, samtig, schokoladig-herb, feine Würze von grünem Kardamom, üppige Schaumkrone (Köpük).",
    "scienceEn": "Turkish coffee is the oldest documented method of coffee preparation (dating back to the Ottoman Empire in the 16th century). Beans are ground micro-fine (smaller than 70 microns, feeling like powder or cocoa). In a long-handled copper pot ('Cezve' or 'Ibrik'), grounds, cold water, and sugar are stirred and heated slowly (traditionally in a hot sand pan 'kumda kahve'). As water reaches ~90-95°C, expanding trapped gases push an unctuous, thick foam ('köpük') to the rim. It is immediately removed from heat before boiling. Served unfiltered; grounds settle to the bottom of the cup.",
    "scienceDe": "Türkischer Kaffee (UNESCO-Kulturerbe seit 2013) ist die älteste Brühmethode der Welt. Die Kaffeebohnen werden mehlfein (unter 70 Mikrometer) gemahlen. Im langstieligen Kupferkännchen ('Cezve' oder 'Ibrik') wird das Kaffeemehl mit kaltem Wasser und Zucker langsam erhitzt (traditionell im heißen Sandbad). Kurz vor dem Kochen bildet sich ein dichter, samtiger Schaum ('Köpük'). Der Kaffee wird ungefiltert in kleine Tassen gegossen; das Kaffeemehl setzt sich am Tassenboden ab.",
    "culinaryEn": "Served in small porcelain demitasse cups with a glass of cold water and Turkish delight (Lokum). Never stirred after pouring.",
    "culinaryDe": "In Mokkatassen serviert mit einem Glas kaltem Wasser und Lokum (Turkish Delight). Nach dem Eingießen niemals umrühren!",
    "faqEn": "Can you drink the sludge at the bottom? No, the thick sediment ('telve') stays at the bottom; drinking is stopped when the liquid runs low.",
    "faqDe": "Trinkt man den Kaffeesatz am Boden mit? Nein, der Kaffeesatz bleibt im Tassenboden zurück; man trinkt nur die dichte Flüssigkeit darüber.",
    "allergens": [
      "Caffeine"
    ],
    "tags": [
      "TurkishCoffee",
      "Mokka",
      "Cezve",
      "UNESCO",
      "Cardamom",
      "Coffee"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 0.85,
      "steamedMilkPercent": 0,
      "milkFoamPercent": 0.15,
      "waterPercent": 0,
      "descriptionEn": "Unfiltered Decoction with rich Köpük foam top",
      "descriptionDe": "Ungefilterter Mokka-Auszug mit dichter Schaumkrone"
    }
  },
  {
    "id": "coffee_vietnamesisch_ca_phe",
    "category": "coffee",
    "nameEn": "Vietnamese Iced Coffee (Cà Phê Sữa Đá)",
    "nameDe": "Vietnamesischer Eiskaffee (Cà Phê Sữa Đá)",
    "subtitleEn": "Dark French roast Robusta slow-dripped through metal Phin filter over sweet condensed milk & ice",
    "subtitleDe": "Dunkel gerösteter Robusta-Kaffee aus dem Phin-Metallfilter auf gezuckerte Kondensmilch und Eis",
    "imageUrl": "",
    "origin": "Vietnam (Central Highlands / Buon Ma Thuot)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Intensely bold, bittersweet dark cocoa, roasted nutty notes, decadent creamy dulce de leche sweetness, refreshing cold kick.",
    "tasteDe": "Kräftig-herb, dunkler Kakao, Röstkaramell, üppig-süße Kondensmilch, erfrischend eisgekühlt.",
    "scienceEn": "Vietnam is the world's largest producer of Robusta coffee (Coffea canephora). Robusta has nearly double the caffeine and chlorogenic acids of Arabica, yielding profound bitterness and full body. Because fresh milk spoiled quickly in tropical climates, French colonists introduced canned sweetened condensed milk. Coffee is brewed directly at the table using a 'Phin' (small stainless steel gravity drip filter with a press plate). The boiling water drips drop-by-drop for 4-5 minutes onto thick condensed milk. Stirred together and poured over ice, it creates an addictive dessert-coffee balance.",
    "scienceDe": "Vietnam ist der weltgrößte Robusta-Exporteur. Robusta enthält fast doppelt so viel Koffein wie Arabica und schmeckt kräftig-erdig mit Noten von dunkler Schokolade. Da frische Milch im tropischen Klima früher verdarb, etablierte sich gezuckerte Kondensmilch. Der Kaffee tropft am Tisch aus einem Edelstahlfilter ('Phin') Tröpfchen für Tröpfchen über 4–5 Minuten direkt auf die Kondensmilch. Mit Eiswürfeln verrührt entsteht ein unvergleichlicher Kontrast aus schokoladiger Bitterkeit und cremiger Karamellsüße.",
    "culinaryEn": "Served in a sturdy highball glass with the Phin filter dripping tableside, served with tall ice glass.",
    "culinaryDe": "Im Glas mit aufgesetztem Phin-Tropffilter serviert. Der Gast rührt die Schichten um und gießt ihn über Eiswürfel.",
    "faqEn": "Why does Vietnamese coffee taste so intensely chocolaty? High-caffeine Robusta beans develop intense pyrazines and dark cocoa notes during deep dark roasting.",
    "faqDe": "Warum schmeckt vietnamesischer Kaffee so schokoladig? Robusta-Bohnen entwickeln bei dunkler Röstung kräftige Kakao- und Röstkaramellnoten.",
    "allergens": [
      "Milk / Dairy",
      "Caffeine"
    ],
    "tags": [
      "VietnameseCoffee",
      "CaPheSuaDa",
      "Phin",
      "Robusta",
      "CondensedMilk",
      "IcedCoffee"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 0.5,
      "steamedMilkPercent": 0.35,
      "milkFoamPercent": 0.15,
      "waterPercent": 0,
      "descriptionEn": "",
      "descriptionDe": ""
    }
  },
  {
    "id": "coffee_espresso_doppio",
    "category": "coffee",
    "nameEn": "Espresso Doppio (Double Shot Espresso)",
    "nameDe": "Espresso Doppio (Doppelter Espresso)",
    "subtitleEn": "Double dose extraction (14-18g coffee for 50-60ml liquor) with dense hazelnut crema",
    "subtitleDe": "Doppelter Shot (14–18g Pulver für 50–60ml Auszug): Höchste Aromadichte & samtige Crema",
    "imageUrl": "",
    "origin": "Italy",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Intense, syrupy, concentrated dark chocolate, toasted hazelnut, bright balancing acidity, thick lingering crema.",
    "tasteDe": "Konzentriert, sirupartig dicht, dunkle Schokolade, geröstete Haselnuss, kraftvoll und langanhaltend.",
    "scienceEn": "An Espresso Doppio is NOT simply a single espresso brewed with twice as much water (which would over-extract bitter astringent phenols and wood lignin). It strictly uses a double portafilter basket filled with double the dry coffee mass (14-18g) extracted with double the water volume (50-60ml) in the standard 25-30 second extraction window. Brew ratio is 1:2 to 1:2.5.",
    "scienceDe": "Ein echter Doppio ist KEIN einfacher Espresso, durch den man doppelt so viel Wasser laufen lässt (denn das würde Holzgerbstoffe und Bitterkeit auslaugen!). Ein Doppio nutzt den doppelten Siebträger mit doppelter Kaffeemehlmenge (14–18g) und liefert 50–60ml konzentrierten Extrakt bei unveränderter Durchlaufzeit von 25–28 Sekunden. Brühverhältnis ca. 1:2.",
    "culinaryEn": "Served in a 80-100ml ceramic tulip cup with a glass of cold mineral water.",
    "culinaryDe": "In 80–100ml Tasse serviert, immer begleitet von einem kleinen Glas stillem Wasser.",
    "faqEn": "Single vs Doppio? Doppio doubles both coffee grounds and volume, keeping extraction balanced and rich.",
    "faqDe": "Unterschied Single zu Doppio? Ein Doppio verdoppelt Kaffeemehl und Wasser gleichermaßen – für doppelten Genuss ohne Überextraktion.",
    "allergens": [
      "Caffeine"
    ],
    "tags": [
      "Espresso",
      "Doppio",
      "DoubleShot",
      "Italian",
      "Barista"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 1,
      "steamedMilkPercent": 0,
      "milkFoamPercent": 0,
      "waterPercent": 0,
      "descriptionEn": "",
      "descriptionDe": ""
    }
  },
  {
    "id": "coffee_espresso_macchiato",
    "category": "coffee",
    "nameEn": "Espresso Macchiato (Caffè Macchiato Caldo)",
    "nameDe": "Espresso Macchiato (Kaffee mit Milchschaum-Fleck)",
    "subtitleEn": "Single espresso shot 'stained' with a dollop of velvety steamed milk microfoam",
    "subtitleDe": "Espresso 'gefleckt' mit einem Löffel samtigem Milchschaum in der Espressotasse",
    "imageUrl": "",
    "origin": "Italy",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Immediate contrast of sweet silky milk foam followed by bold, punchy, dark roasted espresso.",
    "tasteDe": "Spannender Kontrast aus kühlerem, süßlichem Milchschaum und heißem, kräftig-würzigem Espresso.",
    "scienceEn": "In Italian, 'macchiato' means marked, spotted, or stained. In busy Italian espresso bars, baristas needed a way to visibly distinguish for servers an espresso with a touch of milk from a plain black espresso. The small dollop of microfoam sweetens the initial sip with milk lactose and coats the tongue, muting initial bitterness without diluting the intense espresso concentration like a cappuccino would.",
    "scienceDe": "'Macchiato' bedeutet auf Italienisch 'gefleckt' oder 'markiert'. An italienischen Bars diente der Schaumlöffel ursprünglich dazu, dem Kellner optisch zu zeigen, dass in diese Tasse ein Schluck Milch gegeben wurde. Der Milchschaum mildert die erste Bitterspitze des Espressos mit süßlicher Laktose ab, ohne den kräftigen Körper wie bei einem Cappuccino zu verwässern.",
    "culinaryEn": "Served in a standard espresso demitasse or small 60ml transparent glass.",
    "culinaryDe": "In Espressotasse oder kleinem 60ml-Glas serviert. Ideal nach dem Mittagessen.",
    "faqEn": "Espresso Macchiato vs Latte Macchiato? Espresso Macchiato is espresso with a drop of milk; Latte Macchiato is a large glass of milk with a drop of espresso.",
    "faqDe": "Unterschied Espresso Macchiato zu Latte Macchiato? Espresso Macchiato ist Kaffee mit einem Klecks Milch; Latte Macchiato ist viel Milch mit einem Schuss Kaffee.",
    "allergens": [
      "Milk / Dairy",
      "Caffeine"
    ],
    "tags": [
      "Macchiato",
      "Espresso",
      "Microfoam",
      "Italian",
      "Barista"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 0.8,
      "steamedMilkPercent": 0.05,
      "milkFoamPercent": 0.15,
      "waterPercent": 0,
      "descriptionEn": "",
      "descriptionDe": ""
    }
  },
  {
    "id": "coffee_ristretto",
    "category": "coffee",
    "nameEn": "Caffè Ristretto (Short Restricted Extraction)",
    "nameDe": "Caffè Ristretto (Verkürzter Espresso)",
    "subtitleEn": "Restricted 1:1 brew ratio (15-20ml), extracting only the sweetest initial aromatic oils without bitter tannins",
    "subtitleDe": "Verkürzte Extraktion (15–20ml): Zieht nur die feinsten Fruchtsäuren und Aromen ohne Bitterstoffe",
    "imageUrl": "",
    "origin": "Italy (Southern Italy / Naples)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Ultra-dense syrup, sweet, intensely fruity, bright acidity, zero harsh bitterness.",
    "tasteDe": "Sirupartig dickflüssig, feine Fruchtsüße, intensiv aromatisch, kaum Bitterstoffe.",
    "scienceEn": "During espresso extraction, flavor compounds dissolve at different rates: 1) First to extract (0-15s) are sweet fruit acids, volatile aromatic terpenes, and sugars. 2) Middle (15-25s) yields balanced caramel and body. 3) End (25-35s) extracts bitter polyphenols, caffeine, and astringent woody chlorogenic acid breakdown products. Ristretto ('restricted') halts the water flow at 15-20ml. It yields less total caffeine and almost no bitter compounds, concentrating the most aromatic fractions into an unctuous liquor.",
    "scienceDe": "Kaffeestoffe lösen sich im Wasser unterschiedlich schnell: In den ersten 15 Sekunden fließen vor allem feine Fruchtsäuren, ätherische Öle und Zuckerstoffe in die Tasse. Die bitteren Gerbstoffe und das meiste Koffein lösen sich erst gegen Ende der Extraktion (nach 25 Sekunden). Beim Ristretto wird der Brühvorgang frühzeitig bei 15–20ml gestoppt. Das Ergebnis ist eine sirupartige Essenz von überwältigender aromatischer Reinheit ohne jede Bitterkeit.",
    "culinaryEn": "Served in a warm demitasse with a glass of still water, savored in a single concentrated sip.",
    "culinaryDe": "In kleiner Espressotasse mit einem Glas Wasser servieren; wird in einem einzigen intensiven Schluck getrunken.",
    "faqEn": "Does Ristretto have more or less caffeine than a regular espresso? Less caffeine, because caffeine extraction requires longer contact time with hot water.",
    "faqDe": "Hat ein Ristretto mehr oder weniger Koffein als ein normaler Espresso? Weniger Koffein! Da Koffein Zeit braucht, um sich zu lösen, bleibt der Ristretto magenschonender.",
    "allergens": [
      "Caffeine"
    ],
    "tags": [
      "Ristretto",
      "Espresso",
      "Napoli",
      "Concentrated",
      "ShortShot"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false,
    "coffeeLayers": {
      "espressoPercent": 1,
      "steamedMilkPercent": 0,
      "milkFoamPercent": 0,
      "waterPercent": 0,
      "descriptionEn": "",
      "descriptionDe": ""
    }
  },
  {
    "id": "pasta_spaghetti_bronze",
    "category": "pasta_rice",
    "nameEn": "Spaghetti (Trafilata al Bronzo)",
    "nameDe": "Spaghetti (Lange Pasta & Bronzedüsen)",
    "subtitleEn": "Long cylindrical strands, extruded through bronze dies for chalky, rough sauce adhesion",
    "subtitleDe": "Zylindrisch, Bronze-rau (trafilata al bronzo); saugt leichte bis mittelschwere Saucen auf",
    "imageUrl": "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Campania: Gragnano PGI, Puglia, Abruzzo)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Firm chewy bite (al dente), nutty toasted wheat grain flavor, holds emulsion perfectly.",
    "tasteDe": "Perfekter federnder Biss (Al dente), nussiger Getreidegeschmack, verbindet sich homogen mit Öl und Emulsionen.",
    "scienceEn": "Bronze dies (Trafilata al bronzo) tear microscopic fissures onto the noodle surface. This porous, chalky texture binds starches into starchy pasta water emulsions. Teflon dies produce smooth yellow pasta where sauce simply slides off. Cooking: 9-11 min. Portion: 80-100g dry.",
    "scienceDe": "Traditionelle Bronze-Düsen reißen die Nudeloberfläche mikroskopisch rau und kreideweiß auf. Dadurch haftet die Sauce an der Nudel, statt auf den Teller abzugleiten. Ein Schöpflöffel des stärkehaltigen Kochwassers bindet mit Öl oder Fett die perfekte Emulsion. Kochzeit: 9–11 Minuten.",
    "culinaryEn": "Carbonara, Aglio Olio e Peperoncino, Pomodoro, Spaghetti alle Vongole.",
    "culinaryDe": "Klassiker für Carbonara, Aglio Olio e Peperoncino, Sugo di Pomodoro und Spaghetti alle Vongole.",
    "faqEn": "Why does cooking pasta water look cloudy? Bronze-die pasta sheds porous surface starch into the water, which cooks transform into silky emulsified pasta sauces.",
    "faqDe": "Warum ist das Nudelwasser trüb? Weil die raue Bronze-Pasta Stärke abgibt. Ein Schöpfer dieses stärkehaltigen Wassers bindet mit Butter oder Öl die Sauce perfekt ab!",
    "allergens": [
      "Cereals containing Gluten (Wheat"
    ],
    "tags": [
      "Pasta",
      "Spaghetti",
      "Bronzo",
      "Gragnano",
      "AlDente",
      "Italian"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "pasta_tagliatelle_emilia_bologna",
    "category": "pasta_rice",
    "nameEn": "Tagliatelle & Pappardelle (Ribbon Pasta)",
    "nameDe": "Tagliatelle / Pappardelle (Bandnudeln)",
    "subtitleEn": "Wide, porous egg ribbon pasta (1 egg per 100g flour), the authentic partner of hearty meat ragù",
    "subtitleDe": "Breit, porös, nimmt schwere Flüssigkeiten optimal auf; 1 Ei auf 100g Mehl",
    "imageUrl": "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Emilia-Romagna: Bologna & Tuscany)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Rich eggy tenderness, delicate toothsome chew, velvety coating, porous meat absorption.",
    "tasteDe": "Intensiv eifrisch, samtig-weicher Biss, poröse Oberfläche saugt dickflüssige Saucen auf.",
    "scienceEn": "Officially decreed at the Bologna Chamber of Commerce: cooked Tagliatelle measure exactly 8mm wide (Pappardelle 20-30mm). Egg yolk fats and lecithin create an elastic, silky gluten matrix that cradles dense minced beef and wild boar ragù. It is a culinary taboo in Italy to serve bolognese with spaghetti.",
    "scienceDe": "In Bologna ist die Breite der Tagliatelle mit 8 mm amtlich fixiert (Pappardelle sind 20–30 mm breit). Frische Eier verleihen Geschmeidigkeit und Porosität. In Italien gehört Fleischragù ausschließlich auf breite Bandnudeln, da dünne Spaghetti zu glatt sind und das Hackfleisch auf den Tellerboden fällt.",
    "culinaryEn": "Ragù alla Bolognese, Tuscan wild boar ragù (cinghiale), porcini mushroom & truffle sauce.",
    "culinaryDe": "Das einzig authentische Original für Ragù alla Bolognese; Pappardelle zu Wildschweinragù (Cinghiale) und Steinpilz-Trüffel-Sauce.",
    "faqEn": "Why do Italians cringe at 'Spaghetti Bolognese'? Spaghetti are too thin and slick for coarse minced meat sauce, which falls to the plate; wide porous Tagliatelle lift the meat.",
    "faqDe": "Warum gibt es in Italien kein 'Spaghetti Bolognese'? Weil Spaghetti zu dünn und glatt für Hackfleisch sind; breite, poröse Tagliatelle binden das Fleischragù an jeder Gabel.",
    "allergens": [
      "Cereals containing Gluten (Wheat"
    ],
    "tags": [
      "Tagliatelle",
      "Pappardelle",
      "EggPasta",
      "Bologna",
      "Ragu",
      "Italian"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "pasta_penne_rigate",
    "category": "pasta_rice",
    "nameEn": "Penne Rigate (Short Ridged Tube Pasta)",
    "nameDe": "Penne Rigate (Kurze Röhrenpasta)",
    "subtitleEn": "Diagonally quill-cut tubes with exterior ridges capturing chunky sauces inside and out",
    "subtitleDe": "Schräg geschnitten, geriffelt, speichert Sauce innen und außen",
    "imageUrl": "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Campania & Liguria, patented 1865 by Giovanni Battista Capurro)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sturdy al dente resistance, hollow center holds pieces of garlic, chili, and tomato pulp.",
    "tasteDe": "Fester Biss, Röhre füllt sich mit Sauce, Außenseite hält Emulsion fest.",
    "scienceEn": "Invented in 1865 with the invention of the diagonal cutting machine. The angled ends mimic a dip-pen quill ('penna'), creating a wide entrance for chunky pieces of vegetables and tomato skins to enter the cavity, while outer grooves ('rigate') act like capillary channels for spicy chili oil.",
    "scienceDe": "Penne wurden 1865 mit der Erfindung der schrägen Schnittmaschine kreiert. Die Rillen ('rigate') wirken wie Kapillaren für Sauce; die schräge Öffnung schaufelt stückige Tomaten, Chilis und Knoblauchstücke direkt ins Innere der Nudel.",
    "culinaryEn": "Penne all'Arrabbiata (spicy chili tomato), Penne alla Vodka, Quattro Formaggi cheese bakes.",
    "culinaryDe": "Klassiker für Penne all'Arrabbiata (feurige Chilitomate), Penne alla Vodka und Quattro Formaggi.",
    "faqEn": "Why choose Penne Rigate over smooth Penne Lisce? Ridged (rigate) pasta holds significantly more emulsion and oil than slippery smooth noodles.",
    "faqDe": "Warum sollte man immer Penne Rigate statt Lisce (glatt) kaufen? Weil an glatten Penne flüssige Sauce abrutscht, während gerillte Nudeln die Sauce festhalten.",
    "allergens": [
      "Cereals containing Gluten (Wheat"
    ],
    "tags": [
      "Penne",
      "PenneRigate",
      "Arrabbiata",
      "ShortPasta",
      "Italian"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "pasta_rigatoni",
    "category": "pasta_rice",
    "nameEn": "Rigatoni (Large Ridged Tubes)",
    "nameDe": "Rigatoni (Große Röhren)",
    "subtitleEn": "Wide straight tubes with thick walls & pronounced ridges; holds whole peas, meat & baked cheese",
    "subtitleDe": "Weite Öffnung, dicke Wandung, stark geriffelt, exzellenter Biss – ideal für Aufläufe (al forno)",
    "imageUrl": "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Lazio / Rome & Southern Italy)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Substantial hearty chew, dense wheat presence, captures large chunks of guanciale, sausage, and cheese.",
    "tasteDe": "Kräftiger herzhafter Biss, dicke Wandung bleibt perfekt al dente, fängt Fleischwürfel auf.",
    "scienceEn": "From 'rigato' (ridged). Rigatoni's large internal caliber allows coarse bits of minced pork, spicy salsiccia sausage, and peas to lodge directly inside the tube during tossing. Thick extruded walls withstand long baking in casseroles (Pasta al Forno) without going soggy.",
    "scienceDe": "Rigatoni (von 'rigato' = gerillt) sind der Liebling der römischen Küche. Durch das große Röhrenvolumen rutschen gebratene Guanciale-Streifen, Erbsen und grobes Wurstbrät direkt in den Hohlraum. Dicke Wände garantieren perfekten Biss auch beim Überbacken im Ofen.",
    "culinaryEn": "Pasta alla Gricia, Rigatoni all'Amatriciana, Ragù di Salsiccia, Rigatoni al Forno.",
    "culinaryDe": "Römische Klassiker: Pasta alla Gricia, Amatriciana, Ragù di Salsiccia und Nudelaufläufe (al Forno).",
    "faqEn": "Rigatoni vs. Penne? Rigatoni have straight square cuts and larger diameter; Penne are diagonal and narrower.",
    "faqDe": "Unterschied Rigatoni zu Penne? Rigatoni sind gerade abgeschnitten, haben dickere Wände und einen deutlich größeren Hohlraum.",
    "allergens": [
      "Cereals containing Gluten (Wheat"
    ],
    "tags": [
      "Rigatoni",
      "Rome",
      "AlForno",
      "Amatriciana",
      "Gricia"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "pasta_fusilli_trottole",
    "category": "pasta_rice",
    "nameEn": "Fusilli / Trottole (Spiral & Twisted Pasta)",
    "nameDe": "Fusilli / Trottole (Gedrehte Formen)",
    "subtitleEn": "Corkscrew 3-blade helical spirals that trap emulsified herb pestos, tuna sauce & salad dressings",
    "subtitleDe": "Spiralform, fängt emulgierte Saucen und Kräuterflocken ein – perfekt für Pesto & Nudelsalate",
    "imageUrl": "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Campania / Gragnano & Southern Italy)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Playful springy mouthfeel, corkscrew traps fine purees, minced herbs, and pine nuts in every turn.",
    "tasteDe": "Federnder Biss, die Spiralwindungen fangen Kräutersaucen und Pinienkerne wie kleine Schaufeln auf.",
    "scienceEn": "Historically made by twisting spaghetti strands around a knitting needle ('fuso'). The 3-dimensional corkscrew acts like Archimedes' screw, locking in smooth emulsions, pestos, and cold vinaigrettes that would run off long noodles. Excellent in cold pasta salads because the twisted structure holds shape when chilled.",
    "scienceDe": "Traditionell wurden Fusilli um eine Stricknadel ('fuso') gewickelt. Die Korkenzieher-Geometrie wirkt wie eine archimedische Schraube: Fein pürierte Pestos, Pinienkerne und Kräuterflocken verfangen sich in den Windungen. Erste Wahl für kalte Nudelsalate, da die Nudel auch abgekühlt bissfest bleibt.",
    "culinaryEn": "Pesto Genovese (basil, pine nuts, pecorino), tuna olive tomato sauce, cold Mediterranean pasta salads.",
    "culinaryDe": "Klassiker für Pesto Genovese mit Basilikum und Pecorino, Thunfisch-Kapernsauce oder mediterrane Pasta Fredda.",
    "faqEn": "Why do Fusilli work best with pesto? Flat noodles let oily pesto slide off; the corkscrew ridges trap the emulsified basil puree.",
    "faqDe": "Warum passen Fusilli so gut zu Pesto? Die Spiralflügel halten das ölhaltige Kräuterpüree in ihren Windungen fest.",
    "allergens": [
      "Cereals containing Gluten (Wheat"
    ],
    "tags": [
      "Fusilli",
      "Trottole",
      "PestoGenovese",
      "PastaSalad",
      "Spirals"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "pasta_orecchiette_pugliesi",
    "category": "pasta_rice",
    "nameEn": "Orecchiette Pugliesi (Little Ear Pasta)",
    "nameDe": "Orecchiette Pugliesi (Geformte Öhrchenpasta)",
    "subtitleEn": "Handmade concave disc cups with thick ridged rim & thin center; the soul of Apulian cime di rapa",
    "subtitleDe": "Muschel-/Öhrchenform, dickerer Rand, dünner Kern – die Seele der apulischen Küche",
    "imageUrl": "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Puglia / Bari)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Dual texture: toothsome chewy thick rim contrasting with a silky tender concave cup center.",
    "tasteDe": "Zwei Texturen in einem Bissen: Kräftiger Biss am Rand, zart-schmelzende Schalenmitte, fängt Bittergemüse auf.",
    "scienceEn": "Orecchiette ('little ears') are rolled on rough wooden boards with the tip of a dull knife, then flipped over the artisan's thumb. The result is a cup with a rough, dome-like exterior and a depression inside that scoops up chunky sauces. The varied thickness creates a unique mouthfeel: the firm rim stays deeply al dente while the center cooks tender.",
    "scienceDe": "In den Gassen von Bari werden Orecchiette ('Öhrchen') von Nonnas mit dem Messer über Holzbretter gezogen und über dem Daumen umgestülpt. Die Wölbung wirkt wie ein kleiner Löffel, der bitteres Stängelkohl-Gemüse (Cime di Rapa), Knoblauch und zerdrücktes Salsiccia-Brät aufschaufelt.",
    "culinaryEn": "Authentic Orecchiette con Cime di Rapa (turnip tops, anchovy, garlic, chili) or with slow-braised beef ragù.",
    "culinaryDe": "Kultgericht: Orecchiette con Cime di Rapa e Salsiccia (Stängelkohl, Fenchelwurst, Sardellen, Knoblauch, Peperoncino).",
    "faqEn": "Why are authentic Orecchiette made without eggs? Southern Italian culinary tradition relied on water and durum semolina due to historic economic thrift and semolina quality.",
    "faqDe": "Warum werden traditionelle Orecchiette ohne Ei gemacht? Der apulische Hartweizen enthält so viel Protein, dass reines Wasser genügt, um festen Teig zu bilden.",
    "allergens": [
      "Cereals containing Gluten (Wheat"
    ],
    "tags": [
      "Orecchiette",
      "Puglia",
      "Bari",
      "CimeDiRapa",
      "ArtisanPasta"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "pasta_ravioli_tortellini_ripiene",
    "category": "pasta_rice",
    "nameEn": "Ravioli & Tortellini (Filled Fresh Pasta)",
    "nameDe": "Ravioli / Tortellini (Gefüllte Frische Pasta)",
    "subtitleEn": "Silky egg pasta parcels filled with ricotta-spinach, meat or pumpkin; tossed in foaming sage butter or broth",
    "subtitleDe": "Teigtaschen mit Füllung (Fleisch, Ricotta-Spinat, Kürbis); in schäumender Salbeibutter oder Kapaunbrühe",
    "imageUrl": "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Emilia-Romagna: Bologna & Modena / Lombardy: Mantova)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Silky toothsome pasta wrapper yielding to a rich, molten, savory or sweet-nutty core.",
    "tasteDe": "Zarte Hülle mit Biss, gefolgt von einer saftigen, cremigen Füllung; aromatische Butternote mit Salbei.",
    "scienceEn": "Filled pasta balances dough elasticity and filling moisture. The pasta sheet ('sfoglia') must be rolled paper-thin (<0.8 mm) so the edges cook through without becoming leathery, while the filling must have controlled free water so steam doesn't rupture the envelope. Traditional Tortellini di Bologna are folded into a naval shape and boiled in rich capon broth ('in Brodo').",
    "scienceDe": "Gefüllte Pasta ist die Krönung der Sfoglina-Kunst: Der Teig muss hauchdünn ausgerollt werden, damit die gefalteten Ränder gleichzeitig mit der Füllung gar werden. Traditionelle Tortellini werden um den Zeigefinger zum 'Bauchnabel der Venus' gewickelt und in Kapaunbrühe serviert; Ravioli werden in Salbeibutter geschwenkt.",
    "culinaryEn": "Burro e Salvia (foaming butter with fried fresh sage leaves), Tortellini in Brodo, shaved white truffles.",
    "culinaryDe": "Burro e Salvia (aufgeschäumte Butter und knuspriger Salbei), Tortellini in Brodo oder mit weißem Trüffel.",
    "faqEn": "Why must filled pasta never be paired with heavy tomato sauce? Heavy sauces mask the delicate artisanal flavor of the interior filling.",
    "faqDe": "Warum serviert man Tortellini nicht mit schwerer Tomatensauce? Weil dicke Tomatensaucen den feinen Geschmack der handgemachten Füllung erschlagen würden.",
    "allergens": [
      "Cereals containing Gluten (Wheat"
    ],
    "tags": [
      "Ravioli",
      "Tortellini",
      "FilledPasta",
      "BurroESalvia",
      "InBrodo",
      "Bologna"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "rice_basmati_himalaya",
    "category": "pasta_rice",
    "nameEn": "Basmati Rice (Himalayan Long Grain)",
    "nameDe": "Basmati-Reis (Himalaya-Edellangkorn)",
    "subtitleEn": "Fragrant long-grain aged rice, doubles in length without sticking, 2-acetyl-1-pyrroline aroma",
    "subtitleDe": "Aromatischer Duftreis aus den Vorgebirgen des Himalayas; extra lang, schlank, locker körnig",
    "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80",
    "origin": "India (Punjab, Haryana) & Pakistan (Punjab)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Delicate roasted popcorn nuttiness, floral aroma, light fluffy separate grains.",
    "tasteDe": "Fein nussiges Popcorn-Aroma, florale Duftnote, federleicht, bleibt perfekt körnig.",
    "scienceEn": "Basmati translates to 'fragrant' in Sanskrit. Its distinctive aroma is caused by 2-acetyl-1-pyrroline (2-AP), present at 12x higher levels than regular rice. Aging for 1-2 years dehydrates starch so grains expand purely longitudinally (doubling in length) without bursting radially. Cooking: 1:1.5 water ratio, 10-12 min.",
    "scienceDe": "Basmati bedeutet auf Sanskrit 'der Duftende'. Der Duft stammt von 2-Acetyl-1-pyrrolin (2-AP), das auch in Pandanblättern vorkommt. Die monatelange Reifung sorgt dafür, dass sich das Korn in die Länge dehnt statt aufzuplatzen. Zubereitung: Gründlich waschen, Verhältnis 1:1,5 Wasser, 10–12 Minuten sanft köcheln.",
    "culinaryEn": "Biryani, Indian curries, Persian saffron polo (Tahdig), tandoori meats.",
    "culinaryDe": "Klassische Beilage zu indischen Currys, Biryani, persischem Safranreis (Tahdig) und Tandoori.",
    "faqEn": "Why does authentic Basmati not stick together? High amylose content (~22%) and aged dehydration prevent starch grains from dissolving into sticky paste.",
    "faqDe": "Warum klebt echter Basmati nicht? Der hohe Gehalt an Amylose-Stärke und die Reifung sorgen dafür, dass die Körner trocken und locker abrollen.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Rice",
      "Basmati",
      "India",
      "Himalaya",
      "FragrantRice",
      "GlutenFree"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "rice_jasmin_duftreis_thailand",
    "category": "pasta_rice",
    "nameEn": "Jasmine Rice (Thai Hom Mali Rice)",
    "nameDe": "Jasminreis / Duftreis (Thai Hom Mali)",
    "subtitleEn": "Tender floral Thai long grain, natural pandan aroma, soft subtle cling ideal for chopsticks & curries",
    "subtitleDe": "Thailändischer Duftreis mit natürlichem Pandan-Pfeilwurz-Aroma und zartem Klebeeffekt",
    "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80",
    "origin": "Thailand (Isan Plateau / Ubon Ratchathani - Hom Mali)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet floral pandan notes, moist tender texture, delicate comforting softness.",
    "tasteDe": "Zarte florale Pandan- und Vanillenoten, feucht-weicher Schmelz, zarter angenehmer Zusammenhalt.",
    "scienceEn": "Unlike aged dry Basmati, Jasmine rice is best enjoyed fresh from the latest harvest ('New Crop'). A slightly higher amylopectin-to-amylose ratio gives the cooked grains a tender, slightly glossy cling that holds rich coconut curries and enables eating with chopsticks without being heavy.",
    "scienceDe": "Jasminreis wird bevorzugt erntefrisch genossen ('New Crop'). Durch den etwas höheren Amylopektin-Anteil besitzt er eine seidig-feuchte Textur mit leichtem Klebeeffekt, sodass man ihn perfekt mit Stäbchen essen kann und er feine Currysaucen optimal bindet.",
    "culinaryEn": "Essential pairing for Thai green/red curries, Tom Yum, Massaman, and Mango Sticky Rice.",
    "culinaryDe": "Die unverzichtbare Basis für thailändische Currys, Wokgerichte, gebratenen Reis und Mango Sticky Rice.",
    "faqEn": "Is Jasmine rice scented with jasmine blossoms? No! It is 100% naturally aromatic; the name 'Hom Mali' refers to the pristine white color resembling jasmine flowers.",
    "faqDe": "Wird Jasminreis mit Jasminblüten parfümiert? Nein! Das Aroma ist 100% natürlich gewachsen; der Name bezieht sich auf die schneeweiße Farbe, die an Jasminblüten erinnert.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Rice",
      "Jasmine",
      "HomMali",
      "Thailand",
      "Curry",
      "GlutenFree"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "rice_carnaroli_arborio_risotto",
    "category": "pasta_rice",
    "nameEn": "Carnaroli & Arborio (Italian Risotto Rice)",
    "nameDe": "Carnaroli / Arborio (Risottoreis)",
    "subtitleEn": "Medium-grain japonica rice rich in surface amylopectin; creates wavy creaminess (all'onda) with firm core",
    "subtitleDe": "Mittelkorn mit hohem Amylopektingehalt; gibt Stärke ab für sämige Bindung bei bissfestem Kern (al dente)",
    "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Po Valley / Piedmont: Vercelli & Lombardy)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Velvety, rich, creamy suspension holding broth, wine and parmesan around a toothsome al dente center.",
    "tasteDe": "Cremig, samtig-schlotzig mit vollem Schmelz, umhüllt einen perfekt bissfesten Kern (Al dente).",
    "scienceEn": "Carnaroli is crowned as 'Il Re dei Risi'. The pearly center ('perla') rich in compact amylose stays al dente, while outer layers packed with amylopectin dissolve during stirring (mantecatura) to form the luxurious starch-butter-cheese emulsion called 'all'onda' (wavy creaminess). Carnaroli resists overcooking far better than Arborio.",
    "scienceDe": "Carnaroli gilt als bruchfester und bissfester als Arborio. Beim Rühren unter schubweiser Zugabe heißer Brühe löst sich die Oberflächenstärke und emulgiert mit kalter Butter und Parmesan zur legendären 'Mantecatura' – einer fließenden Cremigkeit ('all'onda').",
    "culinaryEn": "Risotto alla Milanese (saffron), Porcini mushroom risotto, Radicchio Gorgonzola, crispy Arancini.",
    "culinaryDe": "Klassisch für Risotto alla Milanese (mit Safran), Steinpilz-Risotto, Meeresfrüchte und Arancini-Bällchen.",
    "faqEn": "Why must you NEVER rinse risotto rice before cooking? Rinsing washes away the precious loose amylopectin starch needed to create the signature creamy sauce.",
    "faqDe": "Warum darf man Risotto-Reis vor dem Kochen niemals waschen? Weil das Wasser die wertvolle Oberflächenstärke abwaschen würde, die für die sämige Cremigkeit unverzichtbar ist!",
    "allergens": [
      "None"
    ],
    "tags": [
      "Risotto",
      "Carnaroli",
      "Arborio",
      "Italy",
      "AllOnda",
      "Mantecatura"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "rice_sushi_koshihikari_japonica",
    "category": "pasta_rice",
    "nameEn": "Sushi Rice (Japonica / Koshihikari)",
    "nameDe": "Sushi-Reis (Japonica / Koshihikari)",
    "subtitleEn": "Short-grain polished japonica rice; high moisture, glossy cling, seasoned with sushi-zu vinegar",
    "subtitleDe": "Rundkorn, hoher Feuchtigkeitsgehalt, poliert; gewürzt mit Hangiri/Essig stark klebend, aber intaktes Korn",
    "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80",
    "origin": "Japan (Niigata / Koshihikari cultivar)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet subtle grain, clean rice vinegar tang, glossy, sticky yet firm individual kernels that melt in the mouth.",
    "tasteDe": "Zarte Süße, feinsäuerlich-frischer Essighauch, glänzend, klebend mit spürbarem Einzelkorn.",
    "scienceEn": "Sushi rice relies on short-grain japonica cultivars with high amylopectin. After thorough washing to remove excess powdery starch, it is steamed and transferred to a cedar wood tub ('hangiri'). Seasoned rice vinegar ('sushi-zu') is sliced through the rice with a flat wooden paddle while fanning rapidly. Fanning cools the rice quickly, locking in a mirror-like sheen and ideal cling without crushing kernels.",
    "scienceDe": "Koshihikari ist der unangefochtene Standard für Meister-Sushi. Im Holzfass (Hangiri) wird der heiße Reis mit Sushizu (Reisessig, Zucker, Salz) vermengt und mit dem Fächer abgekühlt. Das Kühlen versiegelt die Stärke und verleiht den Körnern brillanten Glanz und perfekten Zusammenhalt für Nigiri.",
    "culinaryEn": "Hand-formed Nigiri, rolled Maki, Chirashi bowls, Poke Bowls, and Japanese Donburi.",
    "culinaryDe": "Die unverzichtbare Basis für Nigiri, Maki-Rollen, Chirashi, Poke Bowls und japanische Donburi-Gerichte.",
    "faqEn": "Why must sushi rice be eaten at body temperature? Cold refrigerated sushi rice hardens starches (retrogradation); body temperature (36°C) preserves soft melt-in-mouth texture.",
    "faqDe": "Warum sollte Sushi-Reis handwarm serviert werden? Bei Kälte verhärtet die Stärke; körperwarm (ca. 36°C) schmilzt das Korn perfekt zusammen mit dem Fisch am Gaumen.",
    "allergens": [
      "None"
    ],
    "tags": [
      "SushiRice",
      "Koshihikari",
      "Japonica",
      "Hangiri",
      "Nigiri",
      "Japan"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "rice_schwarzer_venere_vollkorn",
    "category": "pasta_rice",
    "nameEn": "Black Venere Rice (Riso Venere)",
    "nameDe": "Schwarzer Venere-Reis (Vollkornreis)",
    "subtitleEn": "Anthocyanin-rich whole-grain aromatic black rice; firm nutty bite, toasted bread and sandalwood bouquet",
    "subtitleDe": "Unpoliertes Vollkorn, anthozyanreich (schwarz-violett), fester Biss, intensives Aroma von gerösteten Nüssen",
    "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Piedmont / Po Valley, cross-bred from ancient Chinese imperial black rice in 1997)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Earthy, intense toasted walnut, freshly baked sourdough crust, firm chewy whole-grain al dente texture.",
    "tasteDe": "Kräftig nussig, Noten von frisch gebackenem Brot und gerösteter Walnuss, fester elastischer Biss.",
    "scienceEn": "Historically reserved exclusively for Chinese emperors ('Forbidden Rice'). In 1997, Italian agronomists in the Po Valley successfully crossed Chinese black rice with Italian varieties to create 'Riso Venere' (named after Venus, goddess of love). The pitch-black color comes from water-soluble anthocyanins (the same antioxidants found in blueberries). Because the bran layer is unpolished, it requires 35-40 minutes of cooking and stays toothsome without going mushy.",
    "scienceDe": "Einst im alten China als 'Verbotener Reis' den Kaisern vorbehalten, wird Riso Venere heute in der Po-Ebene kultiviert. Die tiefschwarze Farbe stammt von wertvollen Anthocyanen (starke Antioxidantien). Da die ballaststoffreiche Schale intakt bleibt, kocht Venere niemals matschig, sondern behält seinen knackigen Biss.",
    "culinaryEn": "Striking visual contrast with seared tiger prawns, scallops, grilled salmon, or cold seafood bowls.",
    "culinaryDe": "Optischer Hingucker zu gebratenen Riesengarnelen, Jakobsmuscheln, Meeresfrüchtesalaten und Edelfisch.",
    "faqEn": "Does black rice turn cooking water purple? Yes, natural anthocyanins dissolve into cooking water, turning it deep aubergine-purple.",
    "faqDe": "Färbt Venere-Reis das Kochwasser lila? Ja, die natürlichen wasserlöslichen Anthocyan-Pigmente färben das Kochwasser tief dunkelviolett.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Venere",
      "BlackRice",
      "WholeGrain",
      "Antioxidants",
      "Piedmont",
      "SeafoodPairing"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "rice_wildreis_zizania_aquatica",
    "category": "pasta_rice",
    "nameEn": "Wild Rice (Zizania Aquatic Grass)",
    "nameDe": "Wildreis (Wasserreis / Zizania)",
    "subtitleEn": "Botanically an aquatic marsh grass (not true rice); long, dark, ultra-snappy with earthy-smoky tea notes",
    "subtitleDe": "Botanisch ein Wassergras (kein echter Reis); lang, dunkelbraun, sehr knackig, erdig-rauchiges Aroma",
    "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80",
    "origin": "North America (Great Lakes region / Minnesota, Canada - Ojibwe Manoomin tradition)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Crunchy pop, smoky toasted wood, wild mushroom, black tea undertone, robust vegetal earthiness.",
    "tasteDe": "Knackiger Biss, erdig, rauchige Holznote, herber Teegeschmack, kernig und nussig.",
    "scienceEn": "Wild rice is botanically NOT rice (Oryza), but an annual aquatic grass (Zizania palustris) native to shallow freshwater lakes of North America. Traditionally canoe-harvested by Native Americans and parched over wood fires to cure the hulls. High in protein (14%) and low in fat, its rigid fibrous outer hull 'curls' open like a blossom when cooked for 40-45 minutes, providing an unbeatable texture contrast in grain blends.",
    "scienceDe": "Botanisch ist Wildreis kein Reis, sondern ein Süßgras, das in den flachen Seen Nordamerikas wächst. Über Holzfeuer getrocknet, erhält es sein rauchiges Aroma. Beim Kochen platzt die harte Hülle nach 40 Minuten blütenartig auf und offenbart einen kernigen, herben Kern. Reich an pflanzlichem Eiweiß und Ballaststoffen.",
    "culinaryEn": "Blended with white long-grain rice as a luxury side dish for roasted venison, duck breast, pheasant, or autumn root salads.",
    "culinaryDe": "Klassische Beilage zu Wildgerichten (Reh, Hirsch), Entenbrust, herbstlichen Salaten oder als Reismischung.",
    "faqEn": "Why is wild rice often blended with long grain rice? Because wild rice is intensely chewy and expensive; blending tempers texture and cost while adding visual appeal.",
    "faqDe": "Warum mischt man Wildreis oft mit Basmati oder Langkornreis? Wegen des sehr kernigen Bisses und des dominanten Aromas; die Mischung balanciert Textur und Geschmack.",
    "allergens": [
      "None"
    ],
    "tags": [
      "WildRice",
      "Zizania",
      "NorthAmerica",
      "GamePairing",
      "HighProtein",
      "Autumn"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "rice_parboiled_science",
    "category": "pasta_rice",
    "nameEn": "Parboiled Rice (Hydrothermal Process)",
    "nameDe": "Parboiled-Reis (Hydrothermisches Nährstoffverfahren)",
    "subtitleEn": "Steam pressure process drives 80% of bran vitamins & minerals into the starchy kernel before milling",
    "subtitleDe": "Druckdampf-Verfahren presst 80% der Vitamine der Schale ins Korninnere – gelingt immer körnig",
    "imageUrl": "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=800&auto=format&fit=crop&q=80",
    "origin": "Global / North America & Europe",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Firm, uniform al dente bite, neutral clean grain flavor, zero stickiness.",
    "tasteDe": "Fester gleichmäßiger Biss, neutraler Reisgeschmack, absolut klebefrei und bissfest.",
    "scienceEn": "Parboiling ('partially boiled') is a nutritional triumph. Raw unhusked paddy rice is soaked, steamed under pressure, and dried. Pressure forces water-soluble B-vitamins (B1, B3) from the bran directly into the endosperm. Starch gelatinizes, hardening the grain so it never goes mushy even during long buffet holding times.",
    "scienceDe": "Das ungeschälte Reiskorn wird unter hohem Dampfdruck behandelt. Dabei wandern bis zu 80% der B-Vitamine und Mineralstoffe aus der Schale ins Korninnere. Die Stärke geliert an der Oberfläche: Parboiled-Reis kocht garantiert körnig und verzeiht stundenlanges Warmhalten im Chafing Dish.",
    "culinaryEn": "Catering operations, rice salads, paella bases, and buffet operations where long holding times are required.",
    "culinaryDe": "Standard für Catering, Reissalate und Buffets, da er selbst nach Stunden nicht matschig wird.",
    "faqEn": "Why does uncooked parboiled rice look amber/yellow? Heat dissolves natural bran pigments that migrate into the grain; it turns brilliant white upon boiling.",
    "faqDe": "Warum schimmert ungekochter Parboiled-Reis bernsteingelb? Durch die Dampfbehandlung lösen sich natürliche Pigmente aus der Schale; beim Kochen wird er strahlend weiß.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Rice",
      "Parboiled",
      "Catering",
      "Vitamins",
      "CookingScience"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_tomatenketchup_umami",
    "category": "sauces_condiments",
    "nameEn": "Classic Tomato Ketchup",
    "nameDe": "Klassischer Tomatenketchup",
    "subtitleEn": "Concentrated ripe tomato paste, vinegar, cane sugar & warm spices (clove, allspice); high natural free glutamates",
    "subtitleDe": "Tomatenmark, Essig, Zucker, Salz, Gewürzextrakte (Piment, Nelke); süß-säuerlich, umamireich, glatt-viskos",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Origin in East Asia (Ke-tsiap fish sauce) refined in 19th Century America (Henry Heinz)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet-tangy equilibrium, deep concentrated sun-dried tomato depth, warm clove spice, savory umami finish.",
    "tasteDe": "Süß-säuerlich, umamireich, glatt-viskos, fruchtige Tomatentiefe, feine Nelkenwürze.",
    "scienceEn": "Ripe tomatoes contain the highest concentration of naturally occurring free L-glutamate of any common fruit (~140-250mg per 100g). Combined with acetic acid and sucrose, it creates a sensory 'flavor synergy' activating sweet, sour, salty, and umami receptors simultaneously. Ketchup is famously thixotropic (shear-thinning): thick at rest, flows when shaken.",
    "scienceDe": "Ketchup ist die vollendete Synergie aus süß, sauer, salzig und umami: Vollreife Tomaten besitzen enorme Mengen freier Glutaminsäure. Physikalisch ist Ketchup thixotrop (strukturviskos): In Ruhe zähflüssig, verflüssigt er sich durch Erschütterung (Klopfen auf den Flaschenhals).",
    "culinaryEn": "Burger topping, French fries, glaze base for barbecue sauces, meatloaf, or currywurst.",
    "culinaryDe": "Klassiker zu Burgern, Pommes Frites, Glasuren für Spareribs und Basis für BBQ- und Currywurstsaucen.",
    "faqEn": "Why does tapping a glass ketchup bottle make it pour? Mechanical force temporarily breaks the colloidal pectin network, lowering viscosity.",
    "faqDe": "Warum hilft Klopfen gegen verstopfte Ketchup-Flaschen? Durch die mechanische Erschütterung wird das zähe Pektin-Gitter kurzzeitig flüssig.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Ketchup",
      "Tomato",
      "Umami",
      "Burger",
      "Condiments"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "mustard_mittelscharf_vs_dijon",
    "category": "sauces_condiments",
    "nameEn": "Dijon Mustard (Moutarde de Dijon)",
    "nameDe": "Dijonsenf (Moutarde de Dijon)",
    "subtitleEn": "Brown/black mustard seeds, verjus or white wine, water, salt; sharp, pungent, unsweetened nasal kick",
    "subtitleDe": "Braune/schwarze Senfsaat, Verjus oder Weißwein, Wasser, Salz; scharf, stechend, säurebetont, ungesüßt",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Burgundy / Dijon)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Piercing nasal heat, clean pungent sharpness, dry white wine acidity, smooth fine texture, zero sugar.",
    "tasteDe": "Scharf, stechend in der Nase, säurebetont, feinherb, ungesüßt, seidig-cremig.",
    "scienceEn": "Dijon mustard uses brown or black mustard seeds containing Sinigrin. When seeds are crushed in cold liquid, the enzyme myrosinase hydrolyzes sinigrin into volatile Allyl Isothiocyanate—a vaporous gas that evaporates into nasal passages (identical to wasabi/horseradish). Verjus or white wine acid stabilizes the enzyme reaction.",
    "scienceDe": "Dijonsenf basiert auf brauner Senfsaat mit dem Wirkstoff Sinigrin. Bei mechanischem Aufbrechen spaltet das Enzym Myrosinase das Sinigrin in flüchtiges Allylisothiocyanat – ein stechendes Senföl, das direkt in die Nase aufsteigt. Die Säure des Verjus/Weißweins bewahrt die Schärfe über Monate.",
    "culinaryEn": "Essential binding agent for French vinaigrettes, pan gravies, beef tartare, and herb crusts for rack of lamb.",
    "culinaryDe": "Unverzichtbarer Emulsionsanker für französische Vinaigrettes, Sauce Hollandaise, Beef Tartar und Lammkrusten.",
    "faqEn": "Why does cooking mustard make it lose heat? High cooking heat denatures the fragile myrosinase enzyme; add mustard near the end of cooking.",
    "faqDe": "Warum verliert Senf beim Kochen seine Schärfe? Hitze zerstört das hitzeempfindliche Enzym Myrosinase; Senf in Saucen daher erst zum Schluss einrühren!",
    "allergens": [
      "Mustard"
    ],
    "tags": [
      "Dijon",
      "Mustard",
      "Sinigrin",
      "FrenchCuisine",
      "Emulsion"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "mustard_bayerischer_suesser_senf",
    "category": "sauces_condiments",
    "nameEn": "Coarse Wholegrain & Bavarian Sweet Mustard",
    "nameDe": "Grobe Senfsorten (Körniger / Bayerischer Senf)",
    "subtitleEn": "Whole & coarsely cracked mustard seeds, caramelized beet sugar, cider vinegar; sweet-spicy with tactile crunch",
    "subtitleDe": "Ganze Senfkörner, karamellisierter Zucker, Essig; süß-würzig mit Texturbiss",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Germany (Bavaria / Munich, invented 1854 by Johann Conrad Develey) & France (Moutarde à l'ancienne)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Malty caramel sweetness, pleasant rustic seed pop, mellow mustard warmth without nasal burn.",
    "tasteDe": "Süß-würzig mit kernigem Texturbiss, Malz- und Karamellschmelz, milde Würze ohne stechende Schärfe.",
    "scienceEn": "Created in 1854 by Munich mustard pioneer Johann Conrad Develey. To accompany delicate Munich Weißwurst (which contains fragile veal and parsley that would be ruined by sharp mustard), Develey roasted mustard seeds to deactivate burning enzymes and stirred in caramelized sugar. Whole seeds pop pleasantly between the teeth.",
    "scienceDe": "1854 für die Münchner Weißwurst erfunden: Die Senfsaat wird geröstet (was scharfe Enzyme dämpft), nur grob gebrochen und mit karamellisiertem Zucker verfeinert. Das Knacken der intakten Senfkörner und die milde Süße harmonieren ideal mit Salzgebäck und Brühwürsten.",
    "culinaryEn": "Authentic Bavarian Weißwurst, warm Leberkäse, charcuterie boards, ham sandwiches, and roast pork glazes.",
    "culinaryDe": "Kultbegleiter zu Münchner Weißwurst, warmem Leberkäse, Charcuterie-Boards und Schinkenbroten.",
    "faqEn": "Can sweet mustard be used for roasts? Yes, caramelized sugars glaze ham, pork belly, and salmon beautifully in the oven.",
    "faqDe": "Kann man süßen Senf zum Kochen nutzen? Perfekt für Krusten auf Schweinebraten, Schäufele oder als Glasur für Lachsfilet.",
    "allergens": [
      "Mustard"
    ],
    "tags": [
      "SweetMustard",
      "Bavaria",
      "Weißwurst",
      "Develey",
      "Wholegrain"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_mayonnaise_echt_kewpie",
    "category": "sauces_condiments",
    "nameEn": "Mayonnaise (Classic French vs. Japanese Kewpie)",
    "nameDe": "Mayonnaise (Klassisch Französisch / Japanische Kewpie)",
    "subtitleEn": "Cold oil-in-water emulsion; egg yolks, vegetable oil, vinegar/lemon (Kewpie uses rice vinegar & MSG)",
    "subtitleDe": "Eigelb, Öl, Essig/Zitronensaft (Kewpie: Reisessig & MSG); fettreich, seidig, cremig, mild-säuerlich",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Spain (Menorca / Mahón), France & Japan (Kewpie created 1925 by Toichiro Nakashima)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Rich, unctuous, silky, creamy, mild acidity; Kewpie has intense egg-rich savoriness and umami depth.",
    "tasteDe": "Fettreich, seidig, cremig, mild-säuerlich; Kewpie schmeckt deutlich eireicher und intensiver umami.",
    "scienceEn": "Mayonnaise is a physical wonder: 75-80% oil suspended in 20% water. Egg yolk lecithin bridges hydrophobic oil and hydrophilic water. Kewpie mayonnaise uses ONLY egg yolks (roughly 4 yolks per 500g vs 1-2 whole eggs in western mayo), malt/apple vinegar, and monosodium glutamate (MSG), producing a distinctly yellow, ultra-custardy, umami-rich emulsion.",
    "scienceDe": "Mayonnaise ist eine Wasser-in-Öl-Emulsion: Eidotter-Lecithin hält Billionen mikroskopischer Öltröpfchen in der Schwebe. Die japanische Kewpie-Mayo nutzt ausschließlich Eigelb (kein Eiklar), milden Reisessig und einen Hauch MSG – wodurch sie gelber, dicker und geschmacklich unvergleichlich umamireich ist.",
    "culinaryEn": "Sandwich spreads, base for Remoulade, Tartare sauce, Aioli, Japanese Okonomiyaki, and sushi rolls.",
    "culinaryDe": "Mutter aller kalten Saucen: Sandwich-Spread, Basis für Remoulade, Aioli, Cocktailsauce und Sushi-Rolls.",
    "faqEn": "Why does Kewpie taste richer than Western mayo? Kewpie uses exclusively egg yolks (no egg whites) and naturally fermented vinegars with umami seasoning.",
    "faqDe": "Warum schmeckt japanische Kewpie-Mayo so viel cremiger? Weil sie nur das reine Eigelb (kein wässriges Eiklar) und aromatischen Reisessig verwendet.",
    "allergens": [
      "Eggs",
      "Mustard (in French mayo"
    ],
    "tags": [
      "Mayonnaise",
      "Kewpie",
      "Emulsion",
      "Lecithin",
      "Umami"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_tabasco_fermented",
    "category": "sauces_condiments",
    "nameEn": "Tabasco (Oak Barrel Fermented Pepper Sauce)",
    "nameDe": "Tabasco (Fermentierte Pepper Sauce)",
    "subtitleEn": "Tabasco chilies mashed with Avery Island salt, aged for 3 years in white oak bourbon barrels, blended with distilled vinegar",
    "subtitleDe": "Tabasco-Chilis (3 Jahre im Eichenfass gereift), Essig, Salz; essigscharf, dünnflüssig, fermentierte Säure",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "USA (Louisiana / Avery Island, McIlhenny Company since 1868)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Sharp vinegar tang, pungent chili burn (2,500-5,000 Scoville), fermented oak wood depth, clean piercing finish.",
    "tasteDe": "Essigscharf, dünnflüssig, fermentierte pikante Säure, stechender Capsaicin-Kick, feine Holznote.",
    "scienceEn": "Created in 1868 by Edmund McIlhenny. Ripe red tabasco chilies are crushed with salt into a mash, packed into reclaimed white oak whiskey barrels, sealed with salt crusts, and aged for up to THREE YEARS. Fermentation transforms harsh grassy chili notes into complex floral, lactic, and woody esters. Strained and stirred with distilled vinegar for 4 weeks before bottling.",
    "scienceDe": "Seit 1868 auf Avery Island (Louisiana) hergestellt: Die Chilis werden gemahlen und reifen DREI JAHRE in alten Weißeichen-Bourbonfässern. Durch die langsame Milchsäuregärung im Holz entwickeln sich komplexe Fruchtester. Anschließend wird die Maische wochenlang mit Branntweinessig gerührt und gefiltert.",
    "culinaryEn": "Dash on raw oysters, Bloody Mary cocktails, clam chowder, gumbo, chili con carne, or eggs Benedict.",
    "culinaryDe": "Tröpfchenweise auf frische Austern, in den Bloody Mary Cocktail, zu Eintöpfen, Gumbo oder Rührei.",
    "faqEn": "Why does Tabasco taste more acidic than other hot sauces? High ratio of distilled vinegar cuts through rich animal fats and seafood brine.",
    "faqDe": "Warum ist Tabasco so essigbetont? Die Essigsäure schneidet perfekt durch fette Speisen, Meeresfrüchte und reinigt den Gaumen.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Tabasco",
      "OakAged",
      "FermentedChili",
      "Louisiana",
      "BloodyMary"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_sriracha_chili",
    "category": "sauces_condiments",
    "nameEn": "Sriracha Hot Chili Sauce",
    "nameDe": "Sriracha (Knoblauch-Chilisauce)",
    "subtitleEn": "Sun-ripened red jalapeño chilies ground with garlic, sugar & vinegar; thick, sweet-garlicky, medium heat",
    "subtitleDe": "Rote Jalapeños/Chilis, Knoblauch, Essig, Zucker, Salz; mittelscharf, süßlich-knoblauchig, dickflüssig",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Thailand (Si Racha coastal town) & USA (Huy Fong Foods / David Tran)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet upfront, pungent roasted garlic, medium chili glow (1,000-2,500 Scoville), thick clingy texture.",
    "tasteDe": "Mittelscharf, süßlich-knoblauchig, dickflüssig, ausgewogene Säure, haftet perfekt an Speisen.",
    "scienceEn": "Originating in the Thai town of Si Racha as a seafood dipping sauce, Sriracha was popularized globally by David Tran (Huy Fong). Red jalapeños are harvested at peak ripeness (producing high capsanthin pigments and natural sweetness) and processed within hours. Sugar balances capsaicin burn, while garlic supplies allicin-derived umami.",
    "scienceDe": "Aus der thailändischen Küstenstadt Si Racha stammend, wurde Sriracha weltweit zum Kult: Reife rote Jalapeños werden erntefrisch mit Knoblauch und Zucker verarbeitet. Die milde Schärfe (ca. 2.000 Scoville) brennt nicht aggressiv, sondern verbindet sich durch den Zucker homogen mit Fett und Fleisch.",
    "culinaryEn": "Asian street food, Vietnamese Phở soup, poke bowls, and blended with mayonnaise to create Spicy Mayo.",
    "culinaryDe": "Unverzichtbar für asiatisches Street Food, Phở-Suppen, Poke Bowls und verrührt mit Mayo zu 'Spicy Mayo'.",
    "faqEn": "What is Spicy Mayo? A 50/50 blend of Japanese Kewpie mayonnaise and Sriracha sauce.",
    "faqDe": "Wie macht man Spicy Mayo? Zu gleichen Teilen japanische Kewpie-Mayonnaise und Sriracha-Sauce glattrühren.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Sriracha",
      "ChiliSauce",
      "Garlic",
      "SpicyMayo",
      "AsianStreetFood"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_barbecue_kansas_city",
    "category": "sauces_condiments",
    "nameEn": "Barbecue Sauce (Kansas City Style)",
    "nameDe": "Barbecue Sauce (Kansas City Style)",
    "subtitleEn": "Tomato paste, blackstrap molasses, brown sugar, cider vinegar, Worcestershire & liquid hickory smoke",
    "subtitleDe": "Tomate, Melasse/brauner Zucker, Apfelessig, Liquid Smoke; rauchig, dickflüssig, tief-süß, dunkel",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "USA (Missouri & Kansas / Kansas City BBQ tradition)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Deep hickory smoke, caramelized molasses sweetness, tangy vinegar bite, thick glossy lacquered texture.",
    "tasteDe": "Rauchig, dickflüssig, tief-süß, dunkles Karamell, balancierte Essigsäure, würziger Abgang.",
    "scienceEn": "Kansas City style is the world's quintessential barbecue sauce. Molasses and brown sugar contain unrefined reducing sugars that caramelize rapidly under grill heat (Maillard reaction), forming a sticky, lacquered glaze on smoked meats. Natural liquid smoke (condensed hardwood vapor) provides guaiacol and syringol smoke phenols without bitter soot.",
    "scienceDe": "Kansas City BBQ-Sauce ist der Weltstandard: Die Kombination aus dunkler Melasse und Tomatenmark karamellisiert auf gegrilltem Fleisch zu einer glänzenden Lack-Kruste. Apfelessig balanciert den hohen Zuckergehalt, während Hickory-Raucharomen authentischen Barbecue-Geschmack liefern.",
    "culinaryEn": "Brushed on pork ribs during the final 15 minutes of smoking, pulled pork sandwiches, brisket, and burgers.",
    "culinaryDe": "Klassische Glasur für Spareribs, Pulled Pork, Beef Brisket, Burger-Finish und BBQ-Marinaden.",
    "faqEn": "Why must sweet BBQ sauce only be brushed on at the end of grilling? High sugar content burns and chars bitter black if exposed to direct fire for more than 15-20 minutes.",
    "faqDe": "Warum BBQ-Sauce erst in den letzten 15 Minuten auftragen? Weil der hohe Zuckergehalt bei direkter Hitze sonst verbrennt und bitter wird.",
    "allergens": [
      "Fish (in Worcestershire sauce"
    ],
    "tags": [
      "BBQSauce",
      "KansasCity",
      "Smoky",
      "Molasses",
      "Ribs",
      "PulledPork"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_salsa_roja_verde_mexico",
    "category": "sauces_condiments",
    "nameEn": "Salsa Roja & Salsa Verde (Mexican Table Salsas)",
    "nameDe": "Salsa Roja / Salsa Verde (Mexikanisch)",
    "subtitleEn": "Charred roasted tomatoes (Roja) or tart tomatillos (Verde) crushed with serrano chilies, white onion, cilantro & lime",
    "subtitleDe": "Geröstete Tomaten (Roja) bzw. Tomatillos (Verde), Zwiebeln, Koriander, Limette; frisch, säuerlich, pikant, stückig",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Mexico (Traditional Molcajete table salsas)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Roja: Smoky char, sweet roasted tomato, warming chili heat. Verde: Tart, citrusy, herbaceous, vibrant fresh acidity.",
    "tasteDe": "Frisch, säuerlich, pikant, stückig; Roja mit Rauchnote, Verde mit spritziger Tomatillo-Fruchtsäure.",
    "scienceEn": "Authentic Mexican salsa is crushed in a volcanic stone mortar ('Molcajete'). 1) Salsa Roja chars tomatoes on a comal until black-spotted, producing smoky furans and sweet caramelization. 2) Salsa Verde uses tomatillos (Physalis philadelphica), which are not unripe tomatoes but lantern fruits rich in natural pectin and citric acid, giving a clean tart acidity that cuts through rich braised carnitas and melted cheese.",
    "scienceDe": "Traditionell im Mörser aus Vulkangestein (Molcajete) gestampft: Bei Salsa Roja werden Tomaten auf der heißen Platte angekohlt, was rauchige Röstnoten erzeugt. Salsa Verde nutzt Tomatillos (mexikanische Blasenkirschen), deren natürliche Fruchtsäure und Pektin das Fett von gegrilltem Fleisch perfekt brechen.",
    "culinaryEn": "Table staple for tacos al pastor, carne asada, tortilla chips, huevos rancheros, and quesadillas.",
    "culinaryDe": "Unverzichtbar zu Tacos, Nachos, gegrilltem Rindfleisch, Quesadillas und Huevos Rancheros.",
    "faqEn": "What is a Tomatillo? A member of the nightshade family encased in a paper husk; tart, firm, and essential for authentic green salsa.",
    "faqDe": "Was ist eine Tomatillo? Keine grüne Tomate, sondern eine papierhüllige Frucht (Physalis-Gattung) mit erfrischender Säure.",
    "allergens": [
      "None"
    ],
    "tags": [
      "SalsaRoja",
      "SalsaVerde",
      "Tomatillo",
      "Mexico",
      "Tacos",
      "Molcajete"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dressing_franzoesische_vinaigrette",
    "category": "sauces_condiments",
    "nameEn": "Classic French Vinaigrette",
    "nameDe": "Klassische Vinaigrette (Französischer Stil)",
    "subtitleEn": "The golden 3:1 oil-to-acid ratio bound by Dijon mustard, minced shallot & fine wine vinegar into a silky emulsion",
    "subtitleDe": "3:1 Öl zu Essig (z. B. Dijon, Weißweinessig, Schalotte, Olivenöl); hell, säurebetont, emulgiert, pikant",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Classical French Bistro Cooking)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Zesty, bright, peppery, harmonious acid punch tempered by fruity oil and mustard warmth.",
    "tasteDe": "Hell, säurebetont, emulgiert, pikant, fruchtiges Öl und Schalottenfrische.",
    "scienceEn": "Governed by the culinary golden ratio: 3 parts oil to 1 part vinegar. Salt must be dissolved in the vinegar FIRST, because salt cannot dissolve in hydrophobic oil. Dijon mustard acts as a culinary stabilizer: the mucilage polysaccharides from mustard seeds coat suspended oil droplets, preventing separation into a greasy slick.",
    "scienceDe": "Folgt der goldenen Küchenregel: 3 Teile Öl auf 1 Teil Essig. Salz MUSS zuerst im Essig aufgelöst werden, da es sich in Öl nicht löst. Dijonsenf liefert pflanzliche Schleimstoffe als Emulsionsanker, die das Öl in der Schwebe halten.",
    "culinaryEn": "Tossed freshly with butterhead lettuce, frisée with warm bacon, warm potato salads, or steamed asparagus.",
    "culinaryDe": "Klassisch zu Blattsalaten, Frisée mit Speck, lauwarmem Kartoffelsalat oder gedämpftem Spargel.",
    "faqEn": "Why should salad only be dressed immediately before serving? Vinegar acids and salt draw water out of lettuce leaf cells by osmosis within minutes, causing wilting.",
    "faqDe": "Warum Salat erst kurz vor dem Servieren marinieren? Säure und Salz entziehen den Blättern durch Osmose Wasser – der Salat fällt zusammen.",
    "allergens": [
      "Mustard"
    ],
    "tags": [
      "Vinaigrette",
      "FrenchBistro",
      "SaladDressing",
      "Dijon",
      "Emulsion"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dressing_italienisches_dressing",
    "category": "sauces_condiments",
    "nameEn": "Italian Herb Dressing (Italian)",
    "nameDe": "Italienisches Dressing (Italian Dressing)",
    "subtitleEn": "Extra virgin olive oil, aged red wine vinegar, crushed garlic, dried oregano, basil, thyme & lemon zest",
    "subtitleDe": "Olivenöl, Rotweinessig, Knoblauch, getrockneter Oregano, Basilikum, Zitrone; krautig, spritzig, mediterran",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy & Italian-American Restaurant Tradition",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Herbaceous, punchy garlic aroma, zesty red wine vinegar bite, fruity olive oil richness, sun-drenched Mediterranean finish.",
    "tasteDe": "Krautig, spritzig, leicht ölig, pikante Knoblauchnote, aromatischer Oregano und frische Zitrone.",
    "scienceEn": "Dried herbs (especially oregano and basil) contain fat-soluble terpenes (carvacrol, thymol) that extract and bloom far more effectively in warm olive oil than in water. Crushing dried herbs directly into the oil releases essential oils before whisking with acidic red wine vinegar and lemon juice.",
    "scienceDe": "Getrocknete mediterrane Kräuter (Oregano, Thymian) enthalten fettlösliche ätherische Öle, die sich am besten in Olivenöl lösen. Das Dressing schmeckt kräftig kräuterig und spritzig-sauer und bindet feuchte Tomaten-Gurken-Kombinationen perfekt ab.",
    "culinaryEn": "Tossed with chopped mixed garden salads, tomato-cucumber-onion combos, cold pasta salads, or grilled chicken marinade.",
    "culinaryDe": "Klassisch zu gemischten Salaten, Tomaten-Gurken-Salat, kaltem Nudelsalat oder als Marinade für Grillhähnchen.",
    "faqEn": "Why dried herbs instead of fresh in Italian dressing? Dried herbs have concentrated oils that infuse vinegar without turning brown or slimy.",
    "faqDe": "Warum getrocknete Kräuter statt frischer? Getrocknete Kräuter laugen ihr Aroma stabil ins Öl aus, ohne im sauren Essig braun zu werden.",
    "allergens": [
      "None"
    ],
    "tags": [
      "ItalianDressing",
      "Oregano",
      "RedWineVinegar",
      "Mediterranean",
      "Salad"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dressing_caesar_anchovis_parmigiano",
    "category": "sauces_condiments",
    "nameEn": "Authentic Caesar Salad Dressing",
    "nameDe": "Original Caesar Salad Dressing",
    "subtitleEn": "Egg yolk, salted anchovies, garlic, Dijon, lemon, Worcestershire & Parmigiano Reggiano DOP; savory umami powerhouse",
    "subtitleDe": "Eigelb, Sardellen, Knoblauch, Parmesan, Zitronensaft, Worcestershire, Olivenöl; salzig-cremig, starkes Umami",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Mexico (Tijuana / Caesar Cardini, July 4, 1924)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Bold, savory umami explosion, garlic warmth, salty brine from anchovies, nutty aged cheese richness, thick creamy cling.",
    "tasteDe": "Salzig-cremig, starkes Umami, nussig, dicht, Knoblauchschärfe und feine Sardellenwürze.",
    "scienceEn": "Invented on July 4, 1924, by Caesar Cardini in Tijuana. The secret is synergistic umami: inosinates from cured anchovies multiply the sensory impact of free glutamates from Parmigiano Reggiano by 8x. The dense emulsion clings tightly to the sturdy, waxy ribs of chilled Romaine lettuce without sliding off.",
    "scienceDe": "1924 von Cesare Cardini erfunden: Die Kombination aus Inosinat (Anchovis) und freiem Glutamat (Parmigiano Reggiano) potenziert den Umami-Geschmack um das Achtfache. Emulgiert mit Eigelb und Knoblauch haftet das schwere Dressing perfekt an knackigen Römersalatblättern.",
    "culinaryEn": "Tossed with chilled Romaine hearts, garlic butter croutons, shaved parmesan, and grilled chicken breast or tiger prawns.",
    "culinaryDe": "Klassisch zu Römersalat (Romaine), Knoblauch-Croutons, gehobeltem Parmesan und saftigen Hähnchenstreifen.",
    "faqEn": "Did the original 1924 Caesar Salad have anchovies? Caesar Cardini used Worcestershire sauce (which contains fermented anchovies); later whole anchovies were mashed in for richer depth.",
    "faqDe": "Waren 1924 ganze Sardellen im Rezept? Cardini nutzte anfangs nur Worcestershire-Sauce; später wurden pürierte Sardellenfilets zum weltweiten Standard.",
    "allergens": [
      "Eggs",
      "Fish (Anchovies"
    ],
    "tags": [
      "CaesarSalad",
      "Anchovies",
      "Parmigiano",
      "Umami",
      "SaladDressing"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dressing_joghurt_kraeuter_dressing",
    "category": "sauces_condiments",
    "nameEn": "Creamy Yogurt & Fresh Herb Dressing",
    "nameDe": "Joghurt-Kräuter-Dressing",
    "subtitleEn": "Natural whole milk yogurt, sour cream, fresh dill, flat-leaf parsley, chives & lemon juice; lactic, cooling & light",
    "subtitleDe": "Naturjoghurt, Sauerrahm, Zitrone, Dill, Petersilie, Schnittlauch; milchsauer, frisch, kühlend, leicht",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Central Europe & Eastern Mediterranean / Balkan",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Lactic tang, cooling creamy freshness, vibrant garden herbs, gentle garlic hum, refreshing light body.",
    "tasteDe": "Milchsauer, frisch, kühlend, leicht, aromatische Gartenkräuter (Dill, Petersilie, Schnittlauch).",
    "scienceEn": "Unlike heavy oil emulsions, yogurt-based dressings rely on fermented dairy proteins (micellar casein gels). Lactic acid from Lactobacillus fermentation provides clean tartness without high acetic acidity. Dill and chives contribute sulfurous and apiol freshness that cuts through raw vegetable bitterness.",
    "scienceDe": "Basiert auf Milchsäure und Kasein-Eiweißen statt Pflanzenöl: Deutlich kalorienärmer als Mayonnaise, mit natürlicher Milchsäurefrische. Frischer Dill und Schnittlauch spenden ätherische Öle, die Gurken und Rohkost perfekt umhüllen.",
    "culinaryEn": "Tossed with cucumber salad (Gurkensalat), raw vegetable crudités, falafel bowls, baked jacket potatoes, or grilled fish.",
    "culinaryDe": "Klassiker zu Gurkensalat, Rohkost-Platten, Falafel-Bowls, Ofenkartoffeln und gegrilltem Lachs.",
    "faqEn": "How do you keep yogurt dressing from turning watery on cucumbers? Salt cucumbers beforehand and drain excess water before tossing with yogurt.",
    "faqDe": "Warum wird Gurkensalat mit Joghurt oft wässrig? Gurken vorher einsalzen und ausdrücken – so bleibt das Joghurtdressing wunderbar cremig.",
    "allergens": [
      "Milk / Dairy"
    ],
    "tags": [
      "YogurtDressing",
      "Herbs",
      "Cooling",
      "Dill",
      "LowCalorie"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dressing_french_dressing_cremig",
    "category": "sauces_condiments",
    "nameEn": "Classic Creamy French Dressing",
    "nameDe": "French Dressing (Klassisch-Cremig)",
    "subtitleEn": "Oil, vinegar, egg yolk/mayo, tomato paste & sweet paprika; sweet, mild-creamy & orange-pink hue",
    "subtitleDe": "Öl, Essig, Mayonnaise oder Eigelb, Tomatenmark/Paprikapulver, Zwiebel; süßlich, mild-cremig, orangerot",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "USA & International Hotel / Buffet Cuisine",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet and mellow, creamy mild tang, savory tomato warmth, velvety orange-red emulsion.",
    "tasteDe": "Süßlich, mild-cremig, orangerot, samtig auf der Zunge, milde Säure mit fruchtiger Paprika.",
    "scienceEn": "In international hotel catering, 'French Dressing' evolved from clear vinaigrette into an emulsified creamy, reddish-orange dressing. Tomato paste and sweet Hungarian paprika provide natural red carotenoid pigments and pectin body, while emulsified egg yolk and oil give a velvety, crowd-pleasing richness that clings to crisp iceberg lettuce.",
    "scienceDe": "Im Hotel- und Buffet-Bereich bezeichnet 'French Dressing' die cremige, orangerote Sauce: Tomatenmark und Paprika verleihen die charakteristische Farbe und fruchtige Milde; emulgiertes Öl sorgt für dichte Sämigkeit, die selbst an glattem Eisbergsalat haftet.",
    "culinaryEn": "Standard for crisp Iceberg lettuce wedges, prawn cocktails, mixed hotel dinner salads, and club sandwiches.",
    "culinaryDe": "Klassiker zu knackigem Eisbergsalat, Garnelen-Cocktails, gemischten Salattellern und Sandwich-Platten.",
    "faqEn": "French Dressing vs Thousand Island? Thousand Island contains chopped hard-boiled egg and pickle relish; French Dressing is completely smooth and sweeter.",
    "faqDe": "Unterschied French zu Thousand Island? Thousand Island enthält gehackte Gurkenstückchen und Ei; French Dressing ist vollkommen glatt püriert.",
    "allergens": [
      "Eggs"
    ],
    "tags": [
      "FrenchDressing",
      "Creamy",
      "Iceberg",
      "PrawnCocktail",
      "Buffet"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dressing_honig_senf_dressing",
    "category": "sauces_condiments",
    "nameEn": "Honey-Mustard Dressing",
    "nameDe": "Honig-Senf-Dressing",
    "subtitleEn": "Wholegrain & smooth mustard, raw flower honey, apple cider vinegar & mild rapeseed oil; balanced sweet-heat harmony",
    "subtitleDe": "Körniger/mittelscharfer Senf, Bienenhonig, Apfelessig, Rapsöl; ausbalanciert süß-scharf, bindend",
    "imageUrl": "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&auto=format&fit=crop&q=80",
    "origin": "Central Europe & Modern Bistro Gastronomy",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet floral honey upfront, sharp pungent mustard warmth, clean cider vinegar tang, rich emulsified texture.",
    "tasteDe": "Ausbalanciert süß-scharf, bindend, samtige Konsistenz, fruchtige Honigsüße trifft pikanten Senfbiss.",
    "scienceEn": "Honey and mustard form a natural culinary synergy. Honey's high fructose and glucose viscosity slows down oil droplet movement, naturally stabilizing the emulsion. Meanwhile, mustard's allyl isothiocyanate pungency cuts through the honey's sweet coating, preventing cloying heaviness while seasoning bitter greens like arugula.",
    "scienceDe": "Honig und Senf bilden ein unschlagbares Paar: Die zähe Viskosität des Honigs und die pflanzlichen Schleimstoffe des Senfs emulgieren Öl und Essig zu einer cremigen Sauce, die sich nicht trennt. Die Schärfe des Senfs bricht die Süße des Honigs perfekt.",
    "culinaryEn": "Warm goat cheese salad with walnuts, wild arugula, smoked salmon platters, or grilled chicken breast.",
    "culinaryDe": "Hervorragend zu gratiniertem Ziegenkäse mit Walnüssen, Rucola, Räucherlachs und Hähnchenbrust.",
    "faqEn": "Can honey mustard dressing be made ahead? Yes, honey is a natural preservative; it keeps refrigerated for 2-3 weeks.",
    "faqDe": "Wie lange hält Honig-Senf-Dressing? Durch den konservierenden Honig und Essig bleibt es im Kühlschrank mindestens 2–3 Wochen frisch.",
    "allergens": [
      "Mustard"
    ],
    "tags": [
      "HoneyMustard",
      "SaladDressing",
      "GoatCheese",
      "SmokedSalmon",
      "SweetSpicy"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_hollandaise_emulsion",
    "category": "sauces_condiments",
    "nameEn": "Sauce Hollandaise (Warm Butter Emulsion)",
    "nameDe": "Sauce Hollandaise (Klassische warme Buttersauce)",
    "subtitleEn": "French mother sauce: Delicate warm emulsion of egg yolks, clarified butter & white wine reduction at 60-65°C",
    "subtitleDe": "Mutter aller Buttersaucen: Warme Emulsion aus Eigelb, geklärter Butter & Weißwein-Reduktion",
    "imageUrl": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Classical French Haute Cuisine / Carême & Escoffier)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Luxuriously velvety, rich dairy butteriness, bright lemony acidity, warm comforting froth.",
    "tasteDe": "Samtig, cremig-schmelzend, vollmundige Butternote mit feiner Säure-Frische von Zitrone und Weißwein.",
    "scienceEn": "Sauce Hollandaise is one of the five French Mother Sauces. Egg yolk lecithin bridges wine reduction and liquid butter fat. Over a gentle water bath strictly between 60°C and 65°C, egg yolks whisk into a thick sabayon ribbon. Exceeding 68°C curdles egg protein irreversibly into scrambled eggs; cold butter crystallizes and splits.",
    "scienceDe": "Empfindliche warme Wasser-in-Öl-Emulsion: Eidotter-Lecithin emulgiert Butterfett und Weinreduktion. Im Wasserbad muss die Temperatur exakt zwischen 60°C und 65°C gehalten werden. Bei über 68°C gerinnt das Eiprotein zu Rührei; ist die Butter zu kalt, stockt das Fett.",
    "culinaryEn": "Served warm (55-60°C) with boiled white asparagus, Eggs Benedict, poached salmon, or steamed turbot.",
    "culinaryDe": "Klassiker der Spargelsaison zu weißem Stangenspargel; außerdem zu Eggs Benedict, pochiertem Lachs oder zartem Rinderfilet.",
    "faqEn": "Can Hollandaise be reheated in a microwave? Never: intense microwaves overheat egg proteins, causing the butter to separate completely into oil.",
    "faqDe": "Kann man Sauce Hollandaise wieder aufwärmen? Niemals in der Mikrowelle: Bei erneuter Hitze gerinnt das Ei und die Butter trennt sich als Fettsee.",
    "allergens": [
      "Eggs",
      "Milk (Butter"
    ],
    "tags": [
      "Hollandaise",
      "ButterSauce",
      "Emulsion",
      "Asparagus",
      "FrenchCuisine",
      "Escoffier"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "sauce_bearnaise_estragon",
    "category": "sauces_condiments",
    "nameEn": "Sauce Béarnaise (Tarragon & Chervil Butter Sauce)",
    "nameDe": "Sauce Béarnaise (Kräuter-Buttersauce mit Estragon)",
    "subtitleEn": "Warm butter emulsion flavored with concentrated tarragon vinegar, shallots, fresh tarragon & chervil",
    "subtitleDe": "Klassische Ableitung der Hollandaise mit Reduktion aus Estragonessig, Schalotten, frischem Estragon & Kerbel",
    "imageUrl": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Saint-Germain-en-Laye near Paris, created 1836 by Chef Collinet)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Herbaceous anise warmth from fresh tarragon, rich buttery body, bright wine vinegar acidity, peppery aroma.",
    "tasteDe": "Charakteristische herbe Anisnote durch Estragon, reichhaltiger Butterschmelz, pikante Essigfrische und Kerbelaroma.",
    "scienceEn": "Created in 1836 and named in honor of King Henry IV of France. The base technique is identical to Hollandaise, but driven by an intense reduction of tarragon vinegar, white wine, shallots, and black pepper. Volatile phenylpropanoid estragole in tarragon infuses a warm licorice-anise perfume that cuts through rich steak fats.",
    "scienceDe": "1836 bei Paris erfunden: Basiert auf der Hollandaise, wird jedoch durch eine kräftige Reduktion aus Estragonessig, Weißwein, Schalotten und Mörserpfeffer angesetzt. Das ätherische Estragol des Estragons verleiht die typische Anisnote, die perfekt mit den Röstaromen von kurzgebratenem Rindfleisch harmoniert.",
    "culinaryEn": "The holy grail sauce for grilled steaks: Chateaubriand, Tournedos Rossini, Ribeye, and grilled salmon.",
    "culinaryDe": "Die ultimative Steak-Sauce zu gegrilltem Rinderfilet, Chateaubriand, Entrecôte oder Lammkoteletts.",
    "faqEn": "What is the difference between Hollandaise and Béarnaise? Hollandaise is seasoned with lemon juice; Béarnaise uses a reduction of tarragon vinegar, shallots, and fresh tarragon and chervil.",
    "faqDe": "Unterschied Hollandaise zu Béarnaise? Hollandaise wird mit Zitrone abgeschmeckt; Béarnaise basiert auf einer kräftigen Reduktion aus Estragonessig, Schalotten und frischen Kräutern.",
    "allergens": [
      "Eggs",
      "Milk (Butter"
    ],
    "tags": [
      "Bearnaise",
      "SteakSauce",
      "Tarragon",
      "Chateaubriand",
      "FrenchCuisine"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "fruit_strawberry",
    "category": "fruits",
    "nameEn": "Garden Strawberry",
    "nameDe": "Garten-Erdbeere",
    "subtitleEn": "Botanical 'pseudofruit' (aggregate accessory fruit) growing low on the ground",
    "subtitleDe": "Botanische Sammelnussfrucht – wächst an bodennahen mehrjährigen Rosengewächsen",
    "imageUrl": "https://images.unsplash.com/photo-1464965911861-746a04b4bca6?w=800&auto=format&fit=crop&q=80",
    "origin": "Central Europe / Worldwide (Fragaria ananassa)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet aromatic floral fragrance, crisp balance of citric and malic acids, juicy texture.",
    "tasteDe": "Süß-aromatischer Duft, ausgewogene Fruchtsäure (Zitronen- und Äpfelsäure), saftig-frisch.",
    "scienceEn": "Botanically, the red strawberry is NOT a berry! It is an aggregate accessory fruit (pseudofruit). The actual fruits are the tiny yellow specks ('achenes') dotting the red skin, each containing a single seed. Grows on perennial stolon-spreading rosette herbs close to the soil.",
    "scienceDe": "Botanisch ist die Erdbeere gar keine Beere, sondern eine 'Sammelnussfrucht'. Das rote Fruchtfleisch ist nur der verdickte Blütenboden; die eigentlichen Früchte sind die kleinen gelben Körnchen (Nüsschen) auf der Oberfläche!",
    "culinaryEn": "Fresh with cream, in strawberry daiquiris, balsamic macerations, tartlets, and champagne pairings.",
    "culinaryDe": "Frisch mit Sahne, mazeriert mit altem Balsamico, auf Torten oder in Champagner-Cocktails.",
    "faqEn": "Why is it not a berry? True berries (like blueberries) have seeds inside the fleshy ovary wall; strawberries display their seeds on the outside of a swollen stem receptacle.",
    "faqDe": "Warum ist sie botanisch keine Beere? Weil echte Beeren Samen im Fruchtfleisch tragen; bei der Erdbeere sitzen die eigentlichen Nüsse außen auf der Haut.",
    "allergens": [
      "None (rare oral allergy syndrome"
    ],
    "tags": [
      "Strawberry",
      "Erdbeere",
      "Berry",
      "Regional",
      "Fruit"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "fruit_raspberry",
    "category": "fruits",
    "nameEn": "Wild & Garden Raspberry",
    "nameDe": "Wald- & Garten-Himbeere",
    "subtitleEn": "Aggregate of drupelets growing on biennial prickly cane shrubs",
    "subtitleDe": "Sammelsteinfrucht – wächst an zweijährigen stacheligen Halbsträuchern",
    "imageUrl": "https://images.unsplash.com/photo-1577069808021-5079a4059d64?w=800&auto=format&fit=crop&q=80",
    "origin": "Europe & Northern Asia (Rubus idaeus)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Intensely aromatic, floral perfume, delicate velvety tartness, melt-in-mouth.",
    "tasteDe": "Intensiv aromatisch, beerig-blumig, samtige Säure, schmilzt auf der Zunge.",
    "scienceEn": "A raspberry is an aggregate of drupelets (tiny stone fruits, each with its own mini stone). When picked, the hollow thimble detaches cleanly from the receptacle (unlike blackberries where the core stays in). Essential raspberry ketone (4-(4-hydroxyphenyl)butan-2-one) gives its iconic perfume.",
    "scienceDe": "Die Himbeere ist eine 'Sammelsteinfrucht'. Sie besteht aus vielen winzigen Steinfrüchten mit je einem winzigen Kern. Beim Pflücken löst sich die 'Hütchen'-Frucht vom Zapfen ab. Himbeerketon erzeugt den betörenden Duft.",
    "culinaryEn": "Clover Club cocktail, Himbeergeist eau-de-vie, coulis for venison, patisserie decoration.",
    "culinaryDe": "Im Clover Club Cocktail, als Himbeergeist, Fruchtspiegel zu Wildgerichten und Panna Cotta.",
    "faqEn": "How do raspberries grow? On biennial woody canes (canes produce leaves the 1st year, fruit the 2nd year, then die).",
    "faqDe": "Woran wachsen Himbeeren? An bis zu 2 Meter hohen, stacheligen Rutensträuchern im Halbschatten oder Waldrand.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Raspberry",
      "Himbeere",
      "Berries",
      "Regional",
      "Fruit"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "fruit_blueberry",
    "category": "fruits",
    "nameEn": "Wild Bilberry vs. Cultivated Blueberry",
    "nameDe": "Wald-Heidelbeere vs. Kultur-Blaubeere",
    "subtitleEn": "Wild dark-fleshed anthocyanin bombs vs. white-fleshed tall-bush berries",
    "subtitleDe": "Wildheidelbeere (durchgefärbt blau) vs. Kulturblaubeere (weißes Fruchtfleisch)",
    "imageUrl": "https://images.unsplash.com/photo-1498557850523-fd3d118b962e?w=800&auto=format&fit=crop&q=80",
    "origin": "Europe (Wild Bilberry) & North America (Highbush)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Wild: Deep woodland sweetness, tart, stains mouth violet. Cultivated: Mild, firm, crisp, subtle sweet.",
    "tasteDe": "Wild: Intensiv waldig-süß, färbt Zunge blau. Kultur: Knackig fest, mild süß, sauberes weißes Fleisch.",
    "scienceEn": "True wild European bilberries (Vaccinium myrtillus) grow on low heather dwarf shrubs in acidic forest soils. Their pulp is saturated with dark blue anthocyanin pigments throughout. Cultivated highbush blueberries grow on 2m tall bushes and have clear, white flesh.",
    "scienceDe": "Echte Wald-Heidelbeeren wachsen an 20-50cm niedrigen Zwergsträuchern im Nadelwald. Ihr Fruchtfleisch ist komplett dunkelblau mit Anthocyanen durchfärbt. Großfrüchtige Kultur-Blaubeeren stammen aus Amerika, wachsen an hohen Büschen und haben innen weißes Fruchtfleisch.",
    "culinaryEn": "Pancakes, blueberry tart, gin infusions, game sauce reduction (venison, duck).",
    "culinaryDe": "Klassisch in Heidelbeer-Pfannkuchen, zu Wildfleischsauce, Sorbet oder Bar-Infusionen.",
    "faqEn": "Why do wild blueberries turn your teeth blue? Wild bilberries contain anthocyanins in both the skin AND the interior flesh, staining skin and teeth instantly.",
    "faqDe": "Warum färben echte Heidelbeeren Mund und Zähne blau? Weil bei der Waldheidelbeere auch das Innere voll von blauen Pflanzenfarbstoffen (Anthocyanen) ist.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Blueberry",
      "Heidelbeere",
      "Forest",
      "Antioxidant",
      "Berries"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "fruit_mango",
    "category": "fruits",
    "nameEn": "Mango ('King of Tropical Fruits')",
    "nameDe": "Mango ('König der Tropenfrüchte')",
    "subtitleEn": "Large tropical drupe growing on massive evergreen canopy trees up to 30m high",
    "subtitleDe": "Große Steinfrucht – wächst an mächtigen, bis zu 30 Meter hohen Urwaldbäumen",
    "imageUrl": "https://images.unsplash.com/photo-1553279768-865429fa0078?w=800&auto=format&fit=crop&q=80",
    "origin": "South Asia (India, Pakistan) / South America (Alphonso, Kent, Keitt)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Lush tropical honey sweetness, resinous pine notes, peach-citrus undertone, melting texture.",
    "tasteDe": "Üppig honigsüß, feine harzige Kiefernnote, Aprikose, buttrig-schmelzendes Fruchtfleisch.",
    "scienceEn": "Mangos are drupes belonging to the Anacardiaceae family (related to cashews and pistachios!). They grow on massive evergreen trees that live over 100 years. Packed with terpene aromatics (myrcene, pinene), providing their signature pine-mango fragrance.",
    "scienceDe": "Die Mango gehört botanisch zur Familie der Sumachgewächse (verwandt mit Pistazien!). Sie wächst an riesigen, bis zu 30 Meter hohen Tropenbäumen. Ätherische Terpene (Myrcen) erzeugen den feinen waldig-harzigen Duft.",
    "culinaryEn": "Mango Chutney for curry, Mango Lassi, Sticky Rice with Mango, ceviche, Tropical cocktails.",
    "culinaryDe": "Zu indischem Mango-Lassi, Chutneys, feinem Rinder- oder Lachs-Ceviche und exotischen Desserts.",
    "faqEn": "Which mango is the most prized? The Indian 'Alphonso' (Hapus) from Maharashtra is hailed as the gold standard for its saffron color and intense saffron-honey sweetness.",
    "faqDe": "Welche Sorte gilt als die beste der Welt? Die indische 'Alphonso'-Mango (Hapus) wegen ihres safranfarbenen Fleisches und unvergleichlich intensiven Aromas.",
    "allergens": [
      "Anacardiaceae peel contact sensitivity (urushiol traces on raw skin"
    ],
    "tags": [
      "Mango",
      "Tropical",
      "Drupe",
      "Import",
      "Exotic"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "fruit_dragon_fruit",
    "category": "fruits",
    "nameEn": "Dragon Fruit (Pitaya)",
    "nameDe": "Drachenfrucht (Pitahaya)",
    "subtitleEn": "Cactus fruit with striking magenta skin and edible poppy-like seeds",
    "subtitleDe": "Kaktusfrucht mit leuchtend magentafarbener Schale und zarten schwarzen Kernen",
    "imageUrl": "https://images.unsplash.com/photo-1527324688151-0e627063f2b1?w=800&auto=format&fit=crop&q=80",
    "origin": "Central America / Vietnam / Thailand",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Subtle sweetness, kiwi-pear blend, watery refreshing crunch.",
    "tasteDe": "Milde Süße, Anklänge an Kiwi und Melone, erfrischend saftig und knackig.",
    "scienceEn": "Grows on night-blooming epiphytic climbing cacti. Vibrant color stems from betalains, natural pigments that remain stable in cocktail syrups without artificial dyes.",
    "scienceDe": "Wächst an kletternden Nachtkaktus-Arten in den Tropen. Die magentafarbene Leuchtkraft verdankt sie Betalainen.",
    "culinaryEn": "Wheels for cocktail garnish, fruit ceviche, smoothie bowls.",
    "culinaryDe": "Spektakuläre Deko an der Bar, in Fruchtsalaten oder exotischen Sorbets.",
    "faqEn": "Is it an import? Yes, tropical cactus fruit imported by air/sea into Europe.",
    "faqDe": "Ist sie ein Importprodukt? Ja, Tropenkaktusfrucht, die in Europa ganzjährig importiert werden muss.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Pitaya",
      "Cactus",
      "Tropical",
      "Import",
      "Fruit"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "fruit_mangosteen",
    "category": "fruits",
    "nameEn": "Mangosteen ('Queen of Fruits')",
    "nameDe": "Mangostane ('Königin der Früchte')",
    "subtitleEn": "Thick leathery purple rind hiding snow-white segments of divine sweetness",
    "subtitleDe": "Dicke purpurne Schale birgt schneeweiße Segmente von edler Frische",
    "imageUrl": "https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?w=800&auto=format&fit=crop&q=80",
    "origin": "Southeast Asia (Thailand, Malaysia, Indonesia)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Floral, delicate balance of sweet lychee, peach, strawberry, and citrus.",
    "tasteDe": "Fein blumig, edle Harmonie aus Litschi, Pfirsich und milder Zitrusnote.",
    "scienceEn": "Pericarp is rich in polyphenolic xanthones. Aril flesh contains balanced fructose and citric acidity, melting on the tongue.",
    "scienceDe": "Wächst an bis zu 25m hohen Tropenbäumen. Das schneeweiße Fleisch schmilzt mit perfekter Zucker-Säure-Balance auf der Zunge.",
    "culinaryEn": "Cut horizontally around equator, served fresh on crushed ice at fine dining tables.",
    "culinaryDe": "Rundum anritzen und aufklappen; pur auf Crushed Ice zu Champagner servieren.",
    "faqEn": "Why 'Queen of Fruits'? Queen Victoria reportedly prized this fruit above all others.",
    "faqDe": "Warum Königin der Früchte? Wegen ihres majestätisch feinen Geschmacks und der königlichen Krone am Stielansatz.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Mangosteen",
      "Luxury",
      "Tropical",
      "Import"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "veg_potatoes_science",
    "category": "vegetables",
    "nameEn": "Potato Cooking Types (Waxy vs. Starchy)",
    "nameDe": "Kartoffel-Kochtypen: Fest vs. Mehlig",
    "subtitleEn": "Starch ratios (<14% vs >16%), cell wall rupture, and optimal kitchen uses",
    "subtitleDe": "Stärkegehalt (<14% vs. >16%), Zellwandplatzung und die richtige Küchenanwendung",
    "imageUrl": "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=800&auto=format&fit=crop&q=80",
    "origin": "Central Europe / Andes (Solanum tuberosum)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Earthy, nutty, sweet starch umami, distinct mouthfeel texture depending on type.",
    "tasteDe": "Erdig, nussig, dezente Süße, Textur von schnittfest-feucht bis locker-mehlig.",
    "scienceEn": "1. Festkochend (Waxy): Starch <14%. Low amylose; cell walls stay tightly glued together upon heating. Never falls apart -> Essential for potato salad, gratin, and fried potatoes (Bratkartoffeln).\\n2. Vorwiegend festkochend (Semi-waxy): Starch 14-16%. All-rounder for boiled potatoes, french fries, and stews.\\n3. Mehligkochend (Floury/Starchy): Starch >16%. Starch granules swell enormously, bursting the cell walls during cooking -> Yields fluffy, dry, airy mash for mashed potatoes, dumplings (Knödel), and gnocchi!",
    "scienceDe": "1. Festkochend: Stärke unter 14%. Die Pflanzenzellen bleiben beim Kochen fest verbunden. Scheiben zerfallen nicht -> Zwingend für Kartoffelsalat, Bratkartoffeln und Gratin!\\n2. Vorwiegend festkochend: Stärke 14-16%. Der Allrounder für Salzkartoffeln, Eintöpfe und Pommes Frites.\\n3. Mehligkochend: Stärke über 16%. Die Stärkekörner quellen so stark auf, dass die Zellwände platzen -> Ergibt locker-trockene Flocken für samtiges Püree, Klöße, Reibekuchen und Gnocchi!",
    "culinaryEn": "Always choose the right cooking type! Using floury potatoes for potato salad creates mush; using waxy potatoes for mash creates gluey wallpaper paste.",
    "culinaryDe": "Die Küchenregel: Festkochend für Salat & Bratkartoffeln; Mehligkochend für Püree & Knödel (festkochende Kartoffeln für Püree ergeben klebrigen Kleister!).",
    "faqEn": "Why does potato mash turn gummy? Overworking with a blender shears open cell walls, leaking free starch that forms wallpaper paste. Always use a manual ricer or masher!",
    "faqDe": "Warum wird Püree klebrig wie Kleister? Wenn man den Pürierstab nimmt! Schnelle Klingen zerschlagen die Zellen und setzen reine Stärke frei. Immer den Kartoffelstampfer nutzen!",
    "allergens": [
      "None"
    ],
    "tags": [
      "Potato",
      "Kartoffel",
      "Starch",
      "KitchenBasics",
      "Regional"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "veg_white_truffle_alba",
    "category": "vegetables",
    "nameEn": "White Alba Truffle vs. Black Périgord",
    "nameDe": "Weiße Alba-Trüffel vs. Schwarze Périgord-Trüffel",
    "subtitleEn": "The holy grail of Piedmont gastronomy (must never be cooked, only shaved raw)",
    "subtitleDe": "Der weiße Diamant des Piemont – darf NIEMALS erhitzt werden, nur roh gehobelt!",
    "imageUrl": "https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Alba, Piedmont) / Istria (Tuber magnatum pico)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Intoxicating garlic-shallot perfume, aged cheese, wild honey, delicate earthy decadence.",
    "tasteDe": "Betörendes Knoblauch-Schalotten-Aroma, gereifter Parmesan, Waldhonig, pure Dekadenz.",
    "scienceEn": "White truffle cannot be cultivated; it grows strictly wild from October to December. Its fragrance is dominated by bismethylthiomethane (a volatile organic sulfur compound). Heat completely destroys its aroma molecules within seconds, so it is strictly shaved raw at the table over warm buttery dishes.",
    "scienceDe": "Weiße Trüffel lassen sich bis heute nicht züchten. Das flüchtige Schwefelaroma (Bismethylthiomethan) verfliegt bei Hitze sofort! Deshalb darf weiße Trüffel niemals mitgekocht werden – sie wird ausschließlich am Tisch hauchfein über warme Butterpasta oder Ei gehobelt.",
    "culinaryEn": "Shaved paper-thin with a rosewood truffle slicer directly over Tajarin butter pasta, fried eggs, or fonduta.",
    "culinaryDe": "Mit dem Trüffelhobel hauchfein über Tajarin-Butterpasta, Spiegelei oder Risotto gehobelt.",
    "faqEn": "Can you cook white truffle? Absolute cardinal sin! Cooking destroys 100% of its intoxicating perfume. Black truffles, however, can be gently infused in warm butter.",
    "faqDe": "Darf man weiße Trüffel kochen? Niemals! Hitze zerstört die kostbaren Aromen binnen Sekunden. Schwarze Trüffel dagegen vertragen sanfte Wärme in Saucen.",
    "allergens": [
      "None"
    ],
    "tags": [
      "WhiteTruffle",
      "Alba",
      "Piedmont",
      "Luxury",
      "Fungus"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "veg_edible_mushrooms",
    "category": "vegetables",
    "nameEn": "Wild Forest Mushrooms (Porcini & Chanterelle)",
    "nameDe": "Edle Waldpilze (Steinpilz & Pfifferling)",
    "subtitleEn": "King Bolete & Chanterelle – pure wild mycorrhizal symbiosis that cannot be farmed",
    "subtitleDe": "Steinpilz & Pfifferling – wilde Baum-Symbionten, die nicht gezüchtet werden können",
    "imageUrl": "https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80",
    "origin": "Central Europe & Northern Forests",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Porcini: Deep forest hazelnut, meaty texture, intense umami. Chanterelle: Peppery apricot aroma, firm bite.",
    "tasteDe": "Steinpilz: Nussig, feines Waldaroma, fleischige Textur. Pfifferling: Pfeffrig-würzig mit feiner Aprikosennote.",
    "scienceEn": "Both Porcini and Chanterelles live in obligate mycorrhizal symbiosis with live tree roots (pine, spruce, beech). Because they require a living tree network, commercial indoor farming is impossible. 1-octen-3-ol provides the quintessential wild mushroom aroma.",
    "scienceDe": "Beide Pilzarten sind Mykorrhiza-Pilze, die zwingend im Wurzelgeflecht lebender Waldbäume leben. Sie lassen sich in Zuchtfabriken nicht anbauen! 1-Octen-3-ol und Glutaminsäure erzeugen den intensiven Umami-Geschmack.",
    "culinaryEn": "Never wash with water (they act like sponges!). Clean with a dry brush; sauté in foaming butter with shallots and parsley.",
    "culinaryDe": "Niemals ins Wasserbad legen (saugen sich voll wie ein Schwamm!). Nur trocken abbürsten und in brauner Butter mit Schalotten braten.",
    "faqEn": "Can you cultivate chanterelles or porcini? No, unlike button mushrooms (champignons) which eat compost, wild forest mushrooms require living tree partners.",
    "faqDe": "Kann man Pfifferlinge züchten? Nein! Anders als Champignons brauchen Waldpilze lebende Baumpartner und können nur in der freien Natur gesammelt werden.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Mushrooms",
      "Steinpilz",
      "Pfifferling",
      "Forest",
      "Umami"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "veg_asparagus",
    "category": "vegetables",
    "nameEn": "White vs. Green Asparagus",
    "nameDe": "Weißer vs. Grüner Spargel",
    "subtitleEn": "Etiolation underground vs. chlorophyll photosynthesis in open sunlight",
    "subtitleDe": "Lichtentzug im Erdwall vs. Chlorophyll-Photosynthese im Sonnenlicht",
    "imageUrl": "https://images.unsplash.com/photo-1515471209610-dae1c92d8777?w=800&auto=format&fit=crop&q=80",
    "origin": "Central Europe (Germany, France, Italy)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "White: Tender, mild bittersweet. Green: Grassy, nutty, robust pea-like flavor.",
    "tasteDe": "Weiß: Zart, mild, feine Bitternote. Grün: Knackig, nussig, kräuterig-herzhaft.",
    "scienceEn": "White asparagus grows buried underground in mounded earth (etiolation). Green asparagus grows in open sunlight, synthesizing green chlorophyll and higher Vitamin C.",
    "scienceDe": "Weißer Spargel wächst unter Erddämmen ohne Licht (Etiolement). Grüner Spargel wächst über der Erde, betreibt Photosynthese und bildet grünes Blattgrün.",
    "culinaryEn": "White: Peeled, poached with butter and Sauce Hollandaise. Green: Unpeeled, roasted or grilled.",
    "culinaryDe": "Weiß: Geschält, pochiert mit Sauce Hollandaise. Grün: Ungeschält kurz gegrillt.",
    "faqEn": "When does season end? Traditionally strictly on St. John's Day (June 24th).",
    "faqDe": "Wann endet die Spargelzeit? Traditionell exakt am Johannistag (24. Juni).",
    "allergens": [
      "None"
    ],
    "tags": [
      "Asparagus",
      "Seasonal",
      "Regional",
      "Spring"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "nuts_bronte_pistachio",
    "category": "nuts",
    "nameEn": "Bronte Pistachio DOP ('Green Gold')",
    "nameDe": "Bronte Pistazie DOP ('Grünes Gold')",
    "subtitleEn": "Emerald nuts grown on the steep volcanic lava rocks of Mount Etna",
    "subtitleDe": "Smaragdgrüne Pistazien von den vulkanischen Lavahängen des Ätna",
    "imageUrl": "",
    "origin": "Italy (Bronte, Sicily - DOP)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Intensely aromatic, resinous sweetness, vibrant emerald color, sweet mineral crunch.",
    "tasteDe": "Süß-würzig, intensiv harzig, smaragdgrün, mineralischer Schmelz.",
    "scienceEn": "Volcanic ash provides minerals. Trees are rested every second year, concentrating chlorophyll and fatty acids.",
    "scienceDe": "Ernte nur alle zwei Jahre von Hand auf Steilhängen. Extreme Konzentration von Chlorophyll und Aroma.",
    "culinaryEn": "Sicilian cannoli, authentic pistachio gelato, pesto, lamb crust.",
    "culinaryDe": "In sizilianischem Pesto, authentischem Gelato, Cannoli und Lammkrusten.",
    "faqEn": "Why so expensive? Hand-picked along precipitous volcanic slopes where machines cannot operate.",
    "faqDe": "Warum so teuer? Keine Maschinen möglich – alles wird in Handarbeit auf Lavagestein geerntet.",
    "allergens": [
      "Tree nuts (Pistachios"
    ],
    "tags": [
      "Pistachio",
      "Bronte",
      "Sicily",
      "DOP",
      "Nuts"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "nuts_marcona_almonds",
    "category": "nuts",
    "nameEn": "Spanish Marcona Almonds",
    "nameDe": "Spanische Marcona-Mandeln",
    "subtitleEn": "Rounder, sweeter Spanish queen of almonds, fried in olive oil & sea salt",
    "subtitleDe": "Rundliche spanische Königsmandel, geröstet in Olivenöl & Meersalz",
    "imageUrl": "",
    "origin": "Spain (Mediterranean Coast)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Buttery, sweet almond flavor, delicate tender crunch, velvety oil finish.",
    "tasteDe": "Butterweich, feine natürliche Süße, zarter Biss, nussiger Schmelz.",
    "scienceEn": "Higher natural oil and moisture content than standard almonds, keeping interior soft when roasted in olive oil.",
    "scienceDe": "Höherer natürlicher Fettgehalt. Bleibt beim kurzen Rösten in Olivenöl saftig und zart.",
    "culinaryEn": "Tapas bar snack with Manchego cheese, Jamón Ibérico, and Dry Sherry.",
    "culinaryDe": "Klassischer Bar-Snack zu Manchego-Käse, Schinken und trockenem Sherry.",
    "faqEn": "How does Marcona differ? Standard almonds are hard and dry; Marcona is softer, rounder, and buttery.",
    "faqDe": "Unterschied zu normalen Mandeln? Runder, saftiger und unvergleichlich buttrig.",
    "allergens": [
      "Tree nuts (Almonds"
    ],
    "tags": [
      "Almonds",
      "Spain",
      "Tapas",
      "Nuts"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "nuts_walnuss",
    "category": "nuts",
    "nameEn": "Persian Walnut (Juglans regia)",
    "nameDe": "Echte Walnuss (Baumnuss & Gehirnfrucht)",
    "subtitleEn": "High in Omega-3 alpha-linolenic acid (ALA), bitter-tannic papery skin & rich kernel",
    "subtitleDe": "Reichste pflanzliche Omega-3-Quelle (ALA), feinherbe Samenhaut & aromatischer Kern",
    "imageUrl": "https://images.unsplash.com/photo-1536599018102-9f803c140fc1?w=800&auto=format&fit=crop&q=80",
    "origin": "Central Europe / France (Grenoble PDO) / California",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Rich earthy nuttiness, buttery sweet kernel, distinctive pleasant astringency from skin tannins.",
    "tasteDe": "Intensiv nussig, erdig, buttriger Kern mit feinherbem Gerbstoff-Abgang durch die Samenhaut.",
    "scienceEn": "Botanically not a true nut, but the stone of a drupaceous fruit. Walnuts contain the highest proportion of polyunsaturated fatty acids of any common nut, especially Alpha-Linolenic Acid (ALA, ~9g per 100g), an essential Omega-3 fatty acid. The thin papery brown skin is packed with polyphenolic ellagitannins.",
    "scienceDe": "Botanisch eine Steinfrucht. Die Walnuss besitzt unter allen Nüssen den höchsten Gehalt an lebenswichtigen Omega-3-Fettsäuren (Alpha-Linolensäure ALA). Die zarte braune Haut enthält wertvolle Ellagitannine, die für das typisch herbe Geschmackserlebnis sorgen.",
    "culinaryEn": "Classic Waldorf salad, gorgonzola and walnut pasta, French walnut tarts, artisanal cheese boards.",
    "culinaryDe": "Klassiker im Waldorfsalat, zu Blauschimmelkäse (Roquefort/Gorgonzola), Ziegenkäse mit Honig und feinem Walnussbrot.",
    "faqEn": "Why do walnuts sometimes taste bitter? The papery brown seed coat contains antioxidant tannins; peeling it leaves only the mild sweet white kernel.",
    "faqDe": "Warum schmecken Walnüsse leicht herb? Die dünne braune Haut enthält Gerbstoffe; schält man sie ab, schmeckt der Kern rein buttrig-süß.",
    "allergens": [
      "Tree nuts (Walnuts"
    ],
    "tags": [
      "Walnut",
      "Omega3",
      "Baking",
      "Nuts",
      "CheesePairing"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "nuts_haselnuss_piemont",
    "category": "nuts",
    "nameEn": "Piedmont Hazelnut IGP (Tonda Gentile)",
    "nameDe": "Piemonteser Haselnuss g.g.A. (Tonda Gentile)",
    "subtitleEn": "The world's benchmark gourmet hazelnut, perfect sphere, sweet toasted aroma & zero bitterness",
    "subtitleDe": "Königin der Haselnüsse: Kugelrunde Frucht aus den Hügeln der Langhe mit feinstem Röstaroma",
    "imageUrl": "",
    "origin": "Italy (Piedmont / Langhe - IGP)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Intensely aromatic after roasting, milk chocolate nuances, sweet hazelnut oil, silky texture.",
    "tasteDe": "Überragendes Nougat- und Röstaroma, schokoladig, süß, samtig ohne jede Bitterkeit.",
    "scienceEn": "The Tonda Gentile delle Langhe is universally considered by chocolatiers and pastry chefs as the finest hazelnut in existence. After gentle roasting (ca. 160°C), its papery skin peels off 100% cleanly without leaving bitter remnants. The high concentration of monounsaturated oleic acid prevents rancidity and creates a melt-in-the-mouth sensory experience (the birthplace of Gianduja and hazelnut praline).",
    "scienceDe": "Die Tonda Gentile aus der piemontesischen Hügellandschaft der Langhe gilt weltweit als beste Haselnuss der Pâtisserie. Nach sanftem Rösten löst sich die braune Haut restlos ab. Durch den extrem hohen Ölgehalt (über 65% Ölsäure) schmilzt sie auf der Zunge und war der historische Ursprung des echten piemontesischen Gianduja-Nougat.",
    "culinaryEn": "Authentic Gianduja chocolate, Piedmontese hazelnut cake (Torta di Nocciole), browned butter noisette sauces.",
    "culinaryDe": "Piemonteser Haselnusskuchen (ohne Mehl), Gianduja-Pralinen, Eiscreme oder geröstet über Steinpilz-Risotto.",
    "faqEn": "Why is the Piedmont hazelnut so celebrated? Its spherical shape roasts with absolute uniformity, shedding its skin completely and delivering unmatched sweet nutty perfume.",
    "faqDe": "Was macht die Piemont-Nuss so besonders? Sie ist perfekt kugelrund, lässt sich absolut gleichmäßig anrösten und wird niemals bitter.",
    "allergens": [
      "Tree nuts (Hazelnuts"
    ],
    "tags": [
      "Hazelnut",
      "Piedmont",
      "IGP",
      "Gianduja",
      "Pastry"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "nuts_macadamia",
    "category": "nuts",
    "nameEn": "Macadamia Nut",
    "nameDe": "Macadamia-Nuss",
    "subtitleEn": "The hardest shell on Earth protecting the creamiest, highest-oil kernel",
    "subtitleDe": "Härteste Nussschale der Welt birgt den sahnigsten Kern mit über 75% Ölgehalt",
    "imageUrl": "",
    "origin": "Australia / Hawaii / South Africa",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Ultra-rich, creamy dairy-like butteriness, sweet coconut hint, tender crunch.",
    "tasteDe": "Extrem cremig, butterähnlicher Schmelz, dezente Kokossüße.",
    "scienceEn": "Over 75% healthy monounsaturated oils (palmitoleic acid). Hard spherical shell requires 300 psi to crack.",
    "scienceDe": "Über 75% Ölgehalt. Die Steinschale widersteht normalen Nussknackern und braucht Spezialwalzen.",
    "culinaryEn": "Roasted and salted as a luxury hotel lounge amenity, sea bass crusts.",
    "culinaryDe": "Geröstet als Luxus-Bar-Nuss oder für Krusten auf Edelfischen.",
    "faqEn": "Why always sold shelled? The spherical woody shell breaks household nutcrackers.",
    "faqDe": "Warum nie in der Schale? Weil normale Nussknacker an der 20-bar-harten Schale scheitern.",
    "allergens": [
      "Tree nuts (Macadamia"
    ],
    "tags": [
      "Macadamia",
      "Luxury",
      "Nuts"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dairy_milk_types",
    "category": "dairy",
    "nameEn": "Milk Fat Grades & Pasteurization",
    "nameDe": "Milch-Fettstufen & Wärmebehandlung",
    "subtitleEn": "Whole milk (3.5%), semi-skimmed (1.5%), skimmed (<0.5%), Raw vs. UHT",
    "subtitleDe": "Vollmilch (3,5%), fettarme Milch (1,5%), Magermilch (<0,5%), Roh- vs. H-Milch",
    "imageUrl": "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=800&auto=format&fit=crop&q=80",
    "origin": "Europe / Global (Bovine Dairy)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Whole: Rich, sweet, creamy, velvety mouthfeel. Skimmed: Watery, thin, sweet lactose note.",
    "tasteDe": "Vollmilch: Vollmundig, sahnig-süß, cremig. Magermilch: Wässrig, dünn, süßliche Laktosenote.",
    "scienceEn": "1. Fat Standardization: Whole milk has natural min 3.5% fat (or 'Heumilch' 3.8-4.2%); semi-skimmed has 1.5-1.8%; skimmed <0.5%.\\n2. Pasteurization: Heated to 72-75°C for 15-30s killing pathogens while preserving native proteins.\\n3. UHT (H-Milch): Heated to 135-150°C for 2-4s. Kills all spores, shelf-stable for months, but caramelizes traces of lactose creating a distinct boiled/cooked flavor.\\n4. Homogenization: High pressure (200 bar) smashes fat globules into micro-droplets preventing cream from floating to top.",
    "scienceDe": "1. Fettstufen: Vollmilch mind. 3,5% Fett; fettarme Milch 1,5–1,8%; Magermilch <0,5%.\\n2. Pasteurisierung: 72–75°C für 15–30 Sek. Tötet Keime, erhält Proteinstruktur.\\n3. H-Milch (UHT): 135–150°C für 2–4 Sek. Keimfrei und ungekühlt monatelang haltbar, entwickelt aber durch Maillard-Reaktion von Laktose den typischen Kochgeschmack.\\n4. Homogenisierung: Presst Milch mit 200 bar durch Düsen, zerkleinert Fettkügelchen und verhindert das Aufrahmen.",
    "culinaryEn": "Barista: Whole milk (3.5-3.8%) creates the glossiest, sweetest microfoam for latte art; skimmed milk foams stiff and dry.",
    "culinaryDe": "Barista-Regel: Vollmilch (3,5-3,8%) ergibt den cremigsten, süßesten Mikroschaum für Latte Art; Magermilch schäumt trocken und steif.",
    "faqEn": "Why does whole milk froth better in coffee? Milk fat stabilizes the micro-bubbles against collapsing and coats bitter coffee tannins on the tongue.",
    "faqDe": "Warum schmeckt Cappuccino mit Vollmilch runder? Milchfett puffert Bitterstoffe des Espresso ab und erzeugt mit 65°C warmer Laktose natürliche Süße.",
    "allergens": [
      "Milk / Dairy (Lactose, Casein"
    ],
    "tags": [
      "Milk",
      "Dairy",
      "Pasteurization",
      "Barista",
      "Fat"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dairy_yogurt_vs_quark",
    "category": "dairy",
    "nameEn": "Yogurt vs. Quark & Greek Yogurt",
    "nameDe": "Joghurt vs. Quark & Griechischer Joghurt",
    "subtitleEn": "Thermophilic bacterial fermentation vs. acid/rennet curdling & whey straining",
    "subtitleDe": "Thermophile Milchsäuregärung vs. Lab-Dicklegung & echtes Abtropfverfahren",
    "imageUrl": "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=800&auto=format&fit=crop&q=80",
    "origin": "Balkans / Greece / Central Europe",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Yogurt: Tangy, lactic freshness, fluid. Greek: Ultra-thick, decadent, mild acidity. Quark: Firm, creamy, clean curd flavor.",
    "tasteDe": "Joghurt: Säuerlich-frisch, fließend. Griechisch: Extrem dicht, samtig, 10% Fett. Quark: Standfest, mild-cremig, löffelfest.",
    "scienceEn": "1. Classic Yogurt: Milk fermented at 40-45°C with Lactobacillus bulgaricus and Streptococcus thermophilus converting lactose into lactic acid until pH drops to 4.5, coagulating casein.\\n2. Greek Yogurt (Strained): Liquid acid whey is mechanically filtered/strained out. Concentration doubles protein (~10%) and fat (typically 10%), removing lactose.\\n3. Quark (Curd): Milk is coagulated with lactic cultures plus a dash of rennet (Chymosin). The curd is separated from liquid whey through centrifuges, yielding pure concentrated casein curd.",
    "scienceDe": "1. Joghurt: Reines Fermentationsprodukt. Bakterien wandeln Milchzucker bei 42°C in Milchsäure um; Kasein geliert säurebedingt.\\n2. Griechischer Joghurt: Traditionell im Tuchbeutel abgetropft (Strained). Der Entzug der flüssigen Molke verdoppelt den Proteingehalt (~10%) und hinterlässt eine sahnige 10%-Fett-Textur bei weniger Laktose.\\n3. Quark: Wird mit Milchsäurebakterien UND Enzym-Lab dickgelegt. Die feste Kaseinmasse wird durch Separatoren von der Molke getrennt.",
    "culinaryEn": "Greek yogurt in Tsatsiki, breakfast bowls. Quark in German cheesecake (Käsekuchen), Kräuterquark with jacket potatoes.",
    "culinaryDe": "Griechischer Joghurt für echtes Tzatziki und Desserts mit Walnüssen; Quark unverzichtbar für Käsekuchen und Pellkartoffeln.",
    "faqEn": "Is 'Greek Style' the same as authentic Greek Yogurt? No! 'Greek Style' often thickens ordinary yogurt with starch or cream; authentic Greek yogurt is strained to remove whey naturally.",
    "faqDe": "Ist 'Joghurt griechischer Art' echter griechischer Joghurt? Nein! Griechische Art wird oft mit Milchpulver oder Verdickungsmitteln gestreckt; echter griechischer Joghurt wird rein abgetropft.",
    "allergens": [
      "Milk / Dairy (Lactose, Casein"
    ],
    "tags": [
      "Yogurt",
      "Quark",
      "GreekYogurt",
      "Fermentation",
      "Protein"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "dairy_whey_vs_fresh_cheese",
    "category": "dairy",
    "nameEn": "Whey Cheese (Ricotta) vs. Fresh Cheese",
    "nameDe": "Molkenkäse (Ricotta) vs. Frischkäse",
    "subtitleEn": "Heat precipitation of whey albumins (85-90°C) vs. casein curd cheese",
    "subtitleDe": "Hitzeausfällung von Molkeneiweiß (85-90°C) vs. klassischer Kasein-Frischkäse",
    "imageUrl": "https://images.unsplash.com/photo-1559561853-08451507cbe7?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Ricotta) / Norway (Brunost) / Europe",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Ricotta: Light, sweet, delicate granular curds, milky. Cream Cheese: Rich, spreadable, tangy, dense.",
    "tasteDe": "Ricotta: Zart-krümelig, natürlich milchsüß, federleicht. Frischkäse: Vollmundig, streichfähig, sahnig.",
    "scienceEn": "Ordinary cheeses (Gouda, Cheddar, Mozzarella) are made from CASEIN proteins coagulated by rennet. The remaining green liquid is 'whey' (Molke). Ricotta ('re-cooked') is made by heating this leftover whey to 85-90°C with an acidifier: heat denatures the dissolved ALBUMIN and GLOBULIN whey proteins, causing them to float to the top as delicate sweet curds!\\nNorwegian Brunost boils whey for hours until lactose caramelizes into brown fudge.",
    "scienceDe": "Klassischer Käse entsteht aus KASEIN. Die ablaufende Restflüssigkeit ist Molke. Ricotta ('nochmals gekocht') nutzt genau diese Restmolke: Bei 85–90°C flocken die hitzeempfindlichen Molkenproteine (ALBUMIN & GLOBULIN) aus und steigen als süßer Schaum auf!\\nNorwegischer Brunost kocht Molke stundenlang ein, bis der Milchzucker braun karamellisiert.",
    "culinaryEn": "Ricotta in ravioli fillings, cannoli cream, cheesecake. Cream cheese in New York cheesecake and bagel spreads.",
    "culinaryDe": "Ricotta unverzichtbar für Ravioli-Füllungen, sizilianische Cannoli und Tartes; Frischkäse für Bagels und Dips.",
    "faqEn": "Why is Ricotta so low in fat and naturally sweet? It is made from whey proteins rather than butterfat curd, and retains natural dissolved milk sugar (lactose).",
    "faqDe": "Warum schmeckt Ricotta natürlich süß und hat wenig Fett? Weil er aus Molkenproteinen statt reinem Butterfett besteht und gelösten Milchzucker bindet.",
    "allergens": [
      "Milk / Dairy"
    ],
    "tags": [
      "Ricotta",
      "Whey",
      "Molke",
      "FreshCheese",
      "Italian"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "cheese_dop_appellation_science",
    "category": "cheese",
    "nameEn": "Protected Designation of Origin (DOP / g.U.)",
    "nameDe": "Geschützte Ursprungsbezeichnungen (g.U. / DOP / AOP)",
    "subtitleEn": "Why true Champagne, Parmigiano, and Roquefort enjoy strict EU legal protection",
    "subtitleDe": "Warum echter Champagner, Parmesan & Feta rechtlich streng geschützt sind",
    "imageUrl": "https://images.unsplash.com/photo-1452195100486-9cc805987862?w=800&auto=format&fit=crop&q=80",
    "origin": "European Union (Protected Appellations)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Authentic terroir expression, depth of flavor from unpasteurized raw milk and aged crystals.",
    "tasteDe": "Unverfälschtes Terroir, komplexe Aromen durch Rohmilchflora, Reifekristalle und Tradition.",
    "scienceEn": "EU Law establishes Protected Designation of Origin (PDO / g.U. / AOP):\\n1. All production, processing, and preparation must take place in the specific defined region.\\n2. Why is 'Emmentaler' produced worldwide but 'Emmentaler Switzerland AOC' protected? Generic names lost protection in the early 20th century before trademark treaties; newer designations like Parmigiano Reggiano or Feta won strict exclusive rights.\\n3. The Champagne Principle: Sparkling wine produced identically outside Champagne cannot use the name 'Champagne' by international treaty (Treaty of Madrid 1891, Treaty of Versailles).",
    "scienceDe": "Die EU schützt traditionelle Spezialitäten durch 'Geschützte Ursprungsbezeichnung' (g.U. / DOP / AOP):\\n1. Erzeugung, Verarbeitung und Herstellung müssen zu 100% im definierten Herkunftsgebiet nach strengem Pflichtenheft erfolgen.\\n2. Warum gibt es 'Emmentaler' aus aller Welt, aber geschützten 'Emmentaler Switzerland AOP'? Weil der Name vor internationalen Verträgen als Gattungsbegriff galt; Parmigiano Reggiano und Feta erstritten dagegen exklusiven Gebietsschutz.\\n3. Das Champagner-Prinzip: Auch wer die identische Flaschengärung nutzt, darf sein Produkt außerhalb der Champagne niemals Champagner nennen!",
    "culinaryEn": "High-end gastronomy standard: Highlight genuine DOP/AOP certification on the menu to justify guest pricing.",
    "culinaryDe": "Gastronomie-Regel: Echte g.U./DOP-Siegel auf der Speisekarte ausweisen – das rechtfertigt Premiumpreise am Gast.",
    "faqEn": "Why can't Danish cow's milk white cheese be called 'Feta'? In 2002, the EU Court ruled that Feta is a protected Greek DOP made exclusively from sheep/goat milk in Greece.",
    "faqDe": "Warum darf weißer Kuhmilchkäse nicht 'Feta' heißen? Weil der Europäische Gerichtshof Feta 2002 als geschützte griechische g.U. aus Schaf- und Ziegenmilch festschrieb. Anderes heißt 'Salzlakenkäse'.",
    "allergens": [
      "Milk / Dairy"
    ],
    "tags": [
      "DOP",
      "PDO",
      "AOP",
      "Cheese",
      "Law",
      "Terroir"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "cheese_parmigiano_reggiano",
    "category": "cheese",
    "nameEn": "Parmigiano Reggiano DOP ('King of Cheese')",
    "nameDe": "Parmigiano Reggiano DOP ('König der Käse')",
    "subtitleEn": "Raw cow's milk aged 12 to 36+ months, packed with crunchy tyrosine crystals",
    "subtitleDe": "Rohmilch-Hartkäse, 12 bis 36+ Monate gereift, voller knuspriger Tyrosinkristalle",
    "imageUrl": "https://images.unsplash.com/photo-1552767059-ce182ead6c1b?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Parma, Reggio Emilia, Modena - DOP)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Explosive savory umami, pineapple fruitiness, toasted butter, crunchy calcium-tyrosine crunch.",
    "tasteDe": "Gewaltiges Umami (Glutamat), nussig, fruchtige Ananasnoten, knusprige Reifekristalle.",
    "scienceEn": "By DOP decree, cows cannot eat fermented silage or animal feed. Milk is never heat-pasteurized. As wheels mature for 24-36 months in aging rooms, proteolytic enzymes cleave long casein proteins into free amino acids. Free glutamic acid creates natural umami, while tyrosine amino acids precipitate into crunchy white crystals (often mistaken for salt!).",
    "scienceDe": "DOP-Gesetz: Die Kühe dürfen ausschließlich Heu und Gras fressen (Silagefutter streng verboten!). Während der 24–36 monatigen Reife spalten Enzyme das Kasein in freie Aminosäuren. Freie Glutaminsäure erzeugt maximales Umami; die Aminosäure Tyrosin kristallisiert zu den beliebten knusprigen weißen Kristallen (kein Salz!).",
    "culinaryEn": "Broken with an almond knife into natural shards with aged balsamic vinegar of Modena, or grated over pasta.",
    "culinaryDe": "Mit dem Mandelblattholz-Messer in Brocken gebrochen zu 25 Jahre altem Aceto Balsamico Tradizionale.",
    "faqEn": "What is the difference between Parmesan and Grana Padano? Grana Padano covers a wider region, permits silage feed with lysozyme preservative, and matures for a shorter period (min 9 months).",
    "faqDe": "Unterschied zu Grana Padano? Grana Padano darf Silagefutter (mit Konservierungsstoff Lysozym) verwenden und reift kürzer (ab 9 Monate); Parmigiano ist reines Naturprodukt ohne Zusatzstoffe.",
    "allergens": [
      "Milk / Dairy (Lactose naturally depleted to 0g during aging"
    ],
    "tags": [
      "Parmigiano",
      "DOP",
      "RawMilk",
      "Umami",
      "HardCheese"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "cheese_roquefort_blue",
    "category": "cheese",
    "nameEn": "Roquefort AOP & Blue Cheese Science",
    "nameDe": "Roquefort AOP & Blauschimmel-Käsekunde",
    "subtitleEn": "Raw sheep's milk aged in natural limestone caves of Combalou with Penicillium roqueforti",
    "subtitleDe": "Schafs-Rohmilch gereift in natürlichen Kalksteinhöhlen mit Penicillium roqueforti",
    "imageUrl": "https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Roquefort-sur-Soulzon, AOP)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Intensely salty, piquant blue spice, creamy sheep fat sweetness, metallic sharpness.",
    "tasteDe": "Pikant-würzig, feine Schafsmilchsüße, cremiger Schmelz, edle Schimmelschärfe.",
    "scienceEn": "The natural caves of Mont Combalou have geological fissures ('fleurines') that circulate cool, moist air (95% humidity, 9°C). Long needles pierce the young cheese wheels to create oxygen tunnels. Penicillium roqueforti spores germinate in these air channels, hydrolyzing butterfat into methyl ketones (2-heptanone) that deliver the pungent, piquant blue aroma.",
    "scienceDe": "In den Kalksteinhöhlen von Roquefort strömt durch Felsspalten (Fleurines) feuchte Höhlenluft. Edelstahlnadeln stechen Belüftungskanäle in den Käselaib: Nur bei Sauerstoffzufuhr wächst der Edelschimmel Penicillium roqueforti und spaltet Fette in würzige Methylketone auf.",
    "culinaryEn": "Classic sommelier pairing: Sweet dessert wines like Sauternes, Port wine, or dried figs and walnuts.",
    "culinaryDe": "Die Königs-Kombination der Sommelerie: Roquefort zu edelsüßem Sauternes oder Vintage Portwein.",
    "faqEn": "Why does sweet Sauternes wine pair so magically with Roquefort? High saltiness in the cheese suppresses the perception of sweetness in the wine, revealing hidden honey and apricot aromas.",
    "faqDe": "Warum passt edelsüßer Sauternes so genial zu Roquefort? Das Salz des Käses dämpft die Süße des Weins und bringt komplexe Frucht- und Botrytis-Nuancen zum Vorschein.",
    "allergens": [
      "Milk / Dairy (Sheep milk"
    ],
    "tags": [
      "Roquefort",
      "BlueCheese",
      "AOP",
      "France",
      "SheepMilk"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "cheese_emmentaler_dop",
    "category": "cheese",
    "nameEn": "Emmentaler AOP vs. Generic Swiss Cheese",
    "nameDe": "Emmentaler AOP vs. Internationaler Großlochkäse",
    "subtitleEn": "Why 'Emmentaler' became a generic term while 'Emmentaler Switzerland AOP' is protected",
    "subtitleDe": "Warum 'Emmentaler' zur Gattung wurde, während 'Emmentaler Switzerland AOP' geschützt ist",
    "imageUrl": "https://images.unsplash.com/photo-1552767059-ce182ead6c1b?w=800&auto=format&fit=crop&q=80",
    "origin": "Switzerland (Emmental Valley, Bern) / Global generic",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet hazelnut, mild buttery acidity, faint hay notes, smooth elastic texture.",
    "tasteDe": "Nussig-mild, feine Buttersüße, dezente Heunote, elastisch-zarter Teig.",
    "scienceEn": "1. The Holes (Eyes): Formed during warm fermentation room storage (20-24°C). Propionibacterium freudenreichii bacteria consume lactic acid and release Carbon Dioxide (CO2) gas. Because the cheese rind is solid and dense, the gas cannot escape, collecting in natural micro-voids to form the iconic round holes.\\n2. The Protection Dilemma: In the 19th/20th century, Swiss cheesemakers failed to protect the name 'Emmentaler' internationally before it became a generic recipe term across Germany, France, and the US. Today, only 'Emmentaler Switzerland AOP' enjoys strict geographic origin protection, requiring raw milk, silage-free feed, and min 4 to 12+ months cave aging.",
    "scienceDe": "1. Die berühmten Löcher: In warmen Gärkellern (20–24°C) wandeln Propionsäurebakterien Milchsäure in Kohlendioxid (CO2) um. Das Gas kann durch die feste Rinde nicht entweichen und bildet die runden Gärlöcher.\\n2. Das Schutz-Dilemma: Im 19. Jahrhundert verpasste man den Markenschutz, weshalb 'Emmentaler' weltweit als Gattungsbegriff für Großlochkäse produziert werden darf. Nur 'Emmentaler Switzerland AOP' ist die echte geschützte Ursprungsbezeichnung aus Rohmilch ohne Silagefütterung.",
    "culinaryEn": "Swiss Cheese Fondue (mixed 50/50 with Gruyère AOP), cold cuts, Reuben sandwich.",
    "culinaryDe": "Klassiker im Schweizer Käsefondue (50/50 mit Gruyère AOP), Brotzeit und Vesperplatte.",
    "faqEn": "Why do cheap supermarket Emmentalers have small or uneven holes? Industrial versions use pasteurized milk and artificial gas injection or lack the traditional 6-week warm aging cellars.",
    "faqDe": "Warum haben billige Industrie-Emmentaler oft kaum Löcher? Weil pasteurisierte Milch und verkürzte Reifung die Aktivität der Propionsäurebakterien bremsen.",
    "allergens": [
      "Milk / Dairy (Naturally lactose-free due to long aging"
    ],
    "tags": [
      "Emmentaler",
      "AOP",
      "Switzerland",
      "Holes",
      "Propionibacterium"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "cheese_mozzarella_bufala",
    "category": "cheese",
    "nameEn": "Mozzarella di Bufala Campana DOP",
    "nameDe": "Büffelmozzarella (Mozzarella di Bufala DOP)",
    "subtitleEn": "Water buffalo milk Pasta Filata spun cheese vs. cow's milk Fior di Latte",
    "subtitleDe": "Echtes Pasta-Filata-Knetverfahren aus Wasserbüffelmilch vs. Kuhmilch-Fior di Latte",
    "imageUrl": "https://images.unsplash.com/photo-1559561853-08451507cbe7?w=800&auto=format&fit=crop&q=80",
    "origin": "Italy (Campania, Caserta, Salerno - DOP)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Porcelain milk sweetness, delicate musk, rich buttery juiciness, pleasantly lactic tang.",
    "tasteDe": "Porzellanweiße Milchsüße, saftiger Rahmkern, leicht säuerlich-moschusartig, ultra-zart.",
    "scienceEn": "Pasta Filata ('spun paste') method: Fresh curd is immersed in near-boiling water (85-90°C), kneaded and stretched like taffy until smooth and elastic, then pinched off ('mozzare') into balls. Buffalo milk has twice the fat content (~8%) and protein of cow's milk, yielding incomparable juiciness.",
    "scienceDe": "Pasta-Filata-Verfahren: Der Bruchteig wird mit 85°C heißem Wasser übergossen, geknetet und zu elastischen Fäden gezogen, bevor Kugeln abgetrennt ('mozzare') werden. Büffelmilch besitzt mit ca. 8% doppelt so viel Fett wie Kuhmilch und keine gelben Karotinoide – daher die strahlend weiße Farbe und der saftige Milchaustritt beim Anschneiden.",
    "culinaryEn": "Insalata Caprese with heirloom oxheart tomatoes, fresh basil, and extra virgin olive oil. Never serve ice cold (always room temperature 18-20°C!).",
    "culinaryDe": "Klassische Caprese mit Ochsenherztomaten und Basilikum. Wichtig: Niemals kühlschrankkalt servieren, sondern temperiert bei 18–20°C!",
    "faqEn": "Difference between Mozzarella and Fior di Latte? Fior di Latte is made from cow's milk (firmer, milder, melts dry on pizza); Buffalo Mozzarella is richer, tangier, and much juicier.",
    "faqDe": "Unterschied Fior di Latte zu Büffelmozzarella? Fior di Latte stammt von der Kuh (fester, milder); echter Büffelmozzarella ist cremiger, saftiger und hat den DOP-Herkunftsschutz.",
    "allergens": [
      "Milk / Dairy (Water buffalo milk"
    ],
    "tags": [
      "Mozzarella",
      "Bufala",
      "DOP",
      "PastaFilata",
      "Campania"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "eggs_soft_boiled",
    "category": "eggs",
    "nameEn": "Soft-Boiled Egg (Wachsei / 6-Minute Egg)",
    "nameDe": "Weichgekochtes Ei (Wachsweich / 6-Minuten-Ei)",
    "subtitleEn": "6 to 6.5 minutes at 100°C: set tender albumen, warm golden flowing yolk",
    "subtitleDe": "6 bis 6,5 Minuten Garzeit: gestocktes zartes Eiklar, warm flüssiger Eidotter",
    "imageUrl": "https://images.unsplash.com/photo-1506976785307-8732e854ad03?w=800&auto=format&fit=crop&q=80",
    "origin": "Classic European Breakfast & Ramen (Ajitsuke Tamago)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Luxurious, warm velvety yolk coating the palate, delicate tender white.",
    "tasteDe": "Cremig-zerfließender warmer Dotter, samtiges Mundgefühl, zartes Eiklar.",
    "scienceEn": "Because egg white coagulates at 62-65°C and yolk proteins thicken at 65-70°C, a 6.0-6.5 minute boiling window brings the interior core yolk precisely to 63-65°C: warm, liquid, and velvety without hardening.",
    "scienceDe": "Da Eiklar bei 62–65°C gerinnt und Eigelb erst ab 65–70°C fest wird, bringt eine Kochzeit von genau 6 bis 6,5 Minuten das Zentrum auf 64°C: Das Eiweiß ist schnittfest, der Eidotter flüssig-wachsweich.",
    "culinaryEn": "Served in an egg cup with toasted brioche soldiers (Mouillettes), or marinated in soy-mirin for ramen bowls.",
    "culinaryDe": "Im Eierbecher mit Toastbrot-Soldaten ('Mouillettes') oder in Soja-Mirin mariniert auf japanischer Ramen-Suppe.",
    "faqEn": "Why does size matter? An XL egg takes ~7 minutes for the same yolk runny texture as an M egg at 6 minutes.",
    "faqDe": "Warum ist die Eigröße entscheidend? Ein XL-Ei braucht rund 45 Sekunden länger als ein M-Ei, um im Kern dieselbe Temperatur zu erreichen.",
    "allergens": [
      "Eggs"
    ],
    "tags": [
      "SoftBoiled",
      "Breakfast",
      "Wachsei",
      "Eggs",
      "Yolk"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "eggs_hard_boiled",
    "category": "eggs",
    "nameEn": "Hard-Boiled Egg (Hartgekochtes Ei)",
    "nameDe": "Hartgekochtes Ei (Perfekte 9-10 Minuten)",
    "subtitleEn": "Firm golden center without sulfuric green-grey iron sulfide ring",
    "subtitleDe": "Fester cremig-gelber Dotter ohne unansehnlichen grau-grünen Schwefelrand",
    "imageUrl": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80",
    "origin": "Hotel Breakfast Buffet & Catering Standard",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Firm, clean, rich savory egg umami, moist yolk without dry chalkiness.",
    "tasteDe": "Schnittfest, saftig, aromatisch-vollmundig, kein trockener mehliger Dotter.",
    "scienceEn": "Boiled for exactly 9-10 minutes followed by instant ice water bath. Overcooking beyond 11 minutes triggers a chemical reaction: sulfur amino acids in the white release hydrogen sulfide (H2S), which migrates toward the iron-rich yolk to form dark greenish-grey Iron(II) Sulfide (FeS). Shocking in ice water drops the internal pressure, drawing steam outwards and stopping FeS precipitation.",
    "scienceDe": "Exakt 9–10 Minuten kochen, dann sofort in Eiswasser abschrecken! Wer Eier länger als 11 Minuten kocht, provoziert eine chemische Reaktion: Schwefelwasserstoff aus dem Eiklar reagiert mit dem Eisen des Dotters zu grau-grünem Eisensulfid (FeS). Das Eisbad stoppt diesen Prozess sofort.",
    "culinaryEn": "Breakfast buffet, egg salad, Deviled eggs (Gefüllte Eier), Tartar sauce garnish.",
    "culinaryDe": "Frühstücksbuffet, Eiersalat, Frankfurter Grüne Soße und gefüllte Eier mit Senfcreme.",
    "faqEn": "Why do very fresh eggs peel horribly? Fresh eggs have low pH (8.0); albumen clings firmly to the inner shell membrane. After a week, CO2 escapes through shell pores, raising pH to 9.0 and loosening the membrane.",
    "faqDe": "Warum lassen sich tagesfrische Eier so schwer pellen? Weil die Schalenhaut bei ganz frischen Eiern am Eiklar klebt. Nach einer Woche entweicht CO2, der pH-Wert steigt und die Schale löst sich kinderleicht.",
    "allergens": [
      "Eggs"
    ],
    "tags": [
      "HardBoiled",
      "Buffet",
      "IronSulfide",
      "Peeling",
      "Breakfast"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "eggs_fried_sunny_side",
    "category": "eggs",
    "nameEn": "Fried Egg (Spiegelei: Sunny Side Up & Over Easy)",
    "nameDe": "Spiegelei (Sunny Side Up vs. Over Easy)",
    "subtitleEn": "Crisp golden underside, glistening tender white, liquid sunshine yolk",
    "subtitleDe": "Krosser Rand, glänzend-weißes Eiklar und flüssig-cremiger Dotter",
    "imageUrl": "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?w=800&auto=format&fit=crop&q=80",
    "origin": "International Breakfast & Bistro Classics (Strammer Max)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Crispy buttered lace edges, delicate soft albumen, flowing warm yolk.",
    "tasteDe": "Nussige Butternote, knuspriger Rand, zartes Eiklar und flüssiger Dotter.",
    "scienceEn": "Sunny Side Up is fried on one side only without flipping. Basting foaming butter over the white helps set the top without hardening the yolk. 'Over Easy' flips the egg for 15-20 seconds to lightly set the top while keeping yolk molten. Seasoning rule: Salt the white only, as direct salt on the raw yolk draws moisture via osmosis and creates white spots.",
    "scienceDe": "Sunny Side Up wird nur von unten gebraten. Mit einem Löffel schäumende Butter über das Eiweiß gießen ('Arrosieren') lässt das obere Weiß stocken, ohne den Dotter zu garen. 'Over Easy' wendet das Ei für 20 Sekunden. Wichtig: Salz nur auf das Eiweiß streuen, denn Salz auf dem Dotter erzeugt durch Osmose unschöne weiße Flecken!",
    "culinaryEn": "On burger patties, classic German 'Strammer Max' (rye bread, ham, fried egg), or English fry-up.",
    "culinaryDe": "Klassisch auf 'Strammer Max' (Graubrot mit Schinken), zu Bratkartoffeln oder auf Gourmet-Burgern.",
    "faqEn": "Why should salt not be sprinkled directly on the yolk? Salt draws water out of the yolk membrane by osmosis, leaving pale bleached spots.",
    "faqDe": "Warum salzt man das Spiegelei nicht auf den Dotter? Weil Salzkörner dem Dotter Feuchtigkeit entziehen und fleckige Stellen hinterlassen.",
    "allergens": [
      "Eggs"
    ],
    "tags": [
      "FriedEgg",
      "Spiegelei",
      "SunnySideUp",
      "OverEasy",
      "Breakfast"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "eggs_scrambled_eggs",
    "category": "eggs",
    "nameEn": "Velvety Scrambled Eggs (Gourmet Rührei)",
    "nameDe": "Französisches Rührei (Velvety Scrambled Eggs)",
    "subtitleEn": "Low gentle heat, continuous whisking, cold butter cubes for silky curds",
    "subtitleDe": "Sanfte Hitze, ständiges Schlagen und kalte Butterflocken für saftigen Schmelz",
    "imageUrl": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80",
    "origin": "French Haute Cuisine & Luxury Hotel Breakfast",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Silky, custard-like, incredibly rich and juicy, melts like sauce on tongue.",
    "tasteDe": "Cremig wie eine Sauce, saftig, nussige Butternote, niemals trocken oder gummiartig.",
    "scienceEn": "High heat causes egg proteins to contract violently, squeezing out water (syneresis) and leaving scrambled eggs watery and rubbery. Gourmet technique cooks beaten eggs over very low heat (or bain-marie water bath) with cold butter cubes. Continuous stirring shears developing curds into tiny micro-clusters, and adding a dollop of cold cream or crème fraîche at the end drops temperature instantly to prevent carryover overcooking.",
    "scienceDe": "Hohe Pfannenhitze lässt Proteine schlagartig schrumpfen und Wasser herausquetschen (Synärese) – das Rührei wird trocken und wässrig. Die Meistertechnik: Bei kleinster Hitze mit kalten Butterwürfeln rühren. Vor dem vollständigen Stocken vom Herd nehmen und mit einem Löffel kalter Crème fraîche abschrecken, um die Resthitze zu stoppen.",
    "culinaryEn": "Served on toasted brioche with smoked salmon, truffles, or oscietra caviar.",
    "culinaryDe": "Auf gerösteter Brioche mit Räucherlachs, Trüffelhobeln oder Schnittlauch.",
    "faqEn": "Why does buffet scrambled egg turn watery on the heat lamp? Overheating causes egg proteins to squeeze out trapped liquid. High-end hotels prepare scrambled eggs à la minute.",
    "faqDe": "Warum steht auf Hotel-Buffets oft Wasser unter dem Rührei? Durch zu langes Warmhalten ziehen sich die Eiweißstränge zusammen und pressen das Wasser heraus.",
    "allergens": [
      "Eggs",
      "Milk / Dairy (Butter"
    ],
    "tags": [
      "ScrambledEggs",
      "Rührei",
      "Butter",
      "Gourmet",
      "Breakfast"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "eggs_french_omelette",
    "category": "eggs",
    "nameEn": "Classic French Omelet (Omelette Baveuse)",
    "nameDe": "Französisches Gourmet-Omelett (Baveuse)",
    "subtitleEn": "Smooth rolled cylinder, zero browning, trembling molten center",
    "subtitleDe": "Glatte zylindrische Rolle ohne Bräunung, innen zart schmelzend flüssig ('baveuse')",
    "imageUrl": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80",
    "origin": "France (The ultimate test for apprentice chefs)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Tender pillowy outer envelope, decadent flowing creamy core, herbal elegance.",
    "tasteDe": "Zarte blassgelbe Hülle, innen saftig-schmelzender Kern, edle Kräuterbutter.",
    "scienceEn": "The traditional test of a chef: Cooked in 45-60 seconds in a hot non-stick pan with foaming butter. The pan is shaken vigorously while stirring with a fork to create tiny micro-curds. As soon as the bottom sets into a paper-thin skin while the top remains custard-like ('baveuse'), it is tapped to roll into a cigar/almond shape and tipped onto the plate seam-side down, brushed with melted butter.",
    "scienceDe": "Die Königsdisziplin der Kochausbildung: In nur 45–60 Sekunden in schäumender Butter zubereitet. Die Pfanne wird gerüttelt, während die Gabel rührt. Sobald die Unterseite glatt ist und das Innere cremig ('baveuse') glänzt, wird das Omelett zylindrisch eingerollt und auf den Teller gestürzt. Null Bräunung!",
    "culinaryEn": "Brushed with clarified butter for a mirror shine, garnished with chives and chervil.",
    "culinaryDe": "Mit flüssiger Butter lackiert, bestreut mit feinem Schnittlauch und Blattsalaten.",
    "faqEn": "What does 'baveuse' mean? French for runny/custardy center – the signature sign of a perfectly executed French omelet.",
    "faqDe": "Was bedeutet 'baveuse'? Es ist der französische Fachbegriff für den saftig-cremigen, noch leicht flüssigen Innenkern.",
    "allergens": [
      "Eggs",
      "Milk / Dairy (Butter"
    ],
    "tags": [
      "Omelet",
      "FrenchOmelette",
      "Baveuse",
      "ChefStandard",
      "Breakfast"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "eggs_poached_benedict",
    "category": "eggs",
    "nameEn": "Poached Eggs & Eggs Benedict",
    "nameDe": "Pochierte Eier & Eggs Benedict (Verlorene Eier)",
    "subtitleEn": "Vinegar whirlpool technique at 80-85°C, velvety warm flowing center",
    "subtitleDe": "Strudeltechnik im 80–85°C Wasser mit Essig, Basis für Eggs Benedict & Florentine",
    "imageUrl": "https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&auto=format&fit=crop&q=80",
    "origin": "International Fine Brunch (New York / Paris)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Silky envelope giving way to warm, rich liquid yolk, cut by buttery lemon Hollandaise.",
    "tasteDe": "Zarte seidige Hülle, explosionsartig zerfließender Dotter, perfekt zur buttrigen Hollandaise.",
    "scienceEn": "1. Acid & Temperature: Water is kept at 80-85°C (bubbles tear the white). Vinegar lowers water pH, accelerating ovotransferrin crosslinking so the outer albumen coagulates in seconds without scattering.\\n2. Centripetal Force: Stirring the pot creates a vortex that draws the egg white around the heavier yolk into a neat spherical package.\\n3. Cooking time: Exactly 3 to 3.5 minutes for a tender solid outer white and completely molten liquid yolk.",
    "scienceDe": "1. Säure & Temperatur: Wasser bei 80–85°C halten (kochendes Wasser zerreißt das Ei!). Der Essig senkt den pH-Wert und lässt die äußere Eiweißhaut blitzschnell gerinnen.\\n2. Strudeltechnik: Der mit dem Löffel erzeugte Wirbel wickelt das Eiklar durch Zentripetalkraft eng um den Dotter.\\n3. Garzeit: Exakt 3 bis 3,5 Minuten für ein schnittfestes Eiklar und einen herrlich flüssigen Dotter.",
    "culinaryEn": "Eggs Benedict: Toasted English muffin half, Canadian ham/bacon, poached egg, warm Hollandaise. Eggs Florentine replaces ham with sautéed buttered spinach; Eggs Royale with smoked salmon.",
    "culinaryDe": "Eggs Benedict: Muffin, gebratener Schinken, pochiertes Ei und warme Sauce Hollandaise. Als Eggs Florentine mit Blattspinat; als Eggs Royale mit feinem Räucherlachs.",
    "faqEn": "Does the egg taste like vinegar? No, as long as only 1-2 tablespoons are used in 2 liters of water. The vinegar stays in the water and does not penetrate the cooked white.",
    "faqDe": "Schmeckt das Ei nach Essig? Nein, der sparsame Schuss Essig im Kochwasser dient nur der chemischen Gerinnung und überträgt keinen Essiggeschmack auf das Ei.",
    "allergens": [
      "Eggs"
    ],
    "tags": [
      "Poached",
      "EggsBenedict",
      "Brunch",
      "Whirlpool",
      "Hollandaise"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_meersalz_fleur_de_sel",
    "category": "spices_herbs",
    "nameEn": "Sea Salt & Fleur de Sel",
    "nameDe": "Meersalz & Fleur de Sel (Salzblume)",
    "subtitleEn": "Hand-harvested sea salt flakes, natural moisture, magnesium & mineral crunch",
    "subtitleDe": "Handgeschöpftes Meersalz aus Atlantik-Salinen, natürliche Restfeuchte & Edelschmelz",
    "imageUrl": "https://images.unsplash.com/photo-1509358271058-acd22cc93898?w=800&auto=format&fit=crop&q=80",
    "origin": "France (Guérande, Camargue) / Portugal (Algarve)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Clean briny mineral crunch, soft salinity, lingering ocean freshness without harsh bitterness.",
    "tasteDe": "Zarter mineralischer Knusper-Biss, milde harmonische Salzigkeit, kein stechender Geschmack.",
    "scienceEn": "In coastal salt marshes (salines), sea water evaporates slowly under sunlight and Atlantic breezes. On hot, windless summer afternoons, delicate crystal crusts form on the water's surface: 'Fleur de Sel' (Flower of Salt). It is gently skimmed off by hand with wooden lousse rakes. It contains natural residual moisture (ca. 5-8%) and trace minerals (magnesium, calcium) that dissolve slowly on the tongue, creating a soft crunch rather than a sharp salty hit.",
    "scienceDe": "In Salzgärten (Salinen) verdunstet Meerwasser in flachen Becken durch Sonne und Wind. An windstillen Sommertagen bilden sich an der Wasseroberfläche hauchdünne Salzkristallblumen: Fleur de Sel. Diese werden vorsichtig von Hand mit Holzrechen abgeschöpft. Durch die natürliche Restfeuchte und Mineralien (Magnesium, Calcium) schmelzen die Kristalle langsam auf der Zunge – das berühmte 'Finishing Salt', das niemals mitgekocht werden darf!",
    "culinaryEn": "Finishing salt sprinkled over grilled dry-aged steak, heirloom tomatoes, dark chocolate ganache, and cultured butter.",
    "culinaryDe": "Ausschließlich als 'Finishing-Salz' kurz vor dem Servieren auf gegrilltes Steak, Fleischtomaten, Sauerteigbrot mit Butter oder Schokoladendesserts gestreut.",
    "faqEn": "Why should Fleur de Sel not be used during cooking? High heat dissolves its unique microscopic pyramidal crystal structure instantly; its expensive crunchy texture is wasted in boiling water.",
    "faqDe": "Warum darf Fleur de Sel nicht mitgekocht werden? Weil die zarten pyramidenförmigen Kristalle im Kochwasser sofort schmelzen und ihr wertvoller Knusper-Effekt verloren geht.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Salt",
      "FleurDeSel",
      "SeaSalt",
      "FinishingSalt",
      "Minerals"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_steinsalz_himalaya",
    "category": "spices_herbs",
    "nameEn": "Rock Salt & Himalayan Pink Salt",
    "nameDe": "Steinsalz & Himalaya-Kristallsalz",
    "subtitleEn": "Ancient primordial seabed deposits, iron-oxide rose tint, pure dry salinity",
    "subtitleDe": "Urmeersalz aus 250 Mio. Jahre alten Erdschichten, Eisenoxid-Tönung & reine Mineralik",
    "imageUrl": "",
    "origin": "Pakistan (Punjab / Salt Range) / Central Europe",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Dry, direct, pure and potent salinity, subtle earthy undertones, highly soluble.",
    "tasteDe": "Trocken, direkt, kräftig salzig, reine mineralische Schärfe ohne Eigengeruch.",
    "scienceEn": "Over 250 million years ago, ancient oceans evaporated and were sealed beneath tectonic rock strata. Mined deep underground (notably in the Khewra salt mines of Pakistan), this halite mineral is free of modern microplastics. The distinctive rose-pink hue comes from natural trace amounts of iron oxide (Fe2O3). With less than 0.1% moisture, it grinds razor-sharp in salt mills.",
    "scienceDe": "Vor 250 Millionen Jahren trockneten urzeitliche Meere aus. Unter hohem Gebirgsdruck bildete sich kristallines Halit (Steinsalz). Das berühmte rosa Kristallsalz stammt aus den Khewra-Salzminen in Pakistan; die zarte Rosafärbung entsteht durch natürliche Spuren von Eisenoxid. Da es unter Tag trocken gelagert ist, verklumpt es nicht und eignet sich perfekt für Gewürzmühlen.",
    "culinaryEn": "Ideal for salt mills, boiling pasta water, curing gravlax, and seasoning stocks.",
    "culinaryDe": "Ideal für den täglichen Kücheneinsatz in der Mühle, zum Beizen von Lachs (Graved Lachs), Kochen von Pasta und Ansetzen von Fonds.",
    "faqEn": "Is Himalayan pink salt healthier than table salt? Chemically it is ~98% sodium chloride; trace iron gives color, but nutritionally it functions like high-purity uniodized rock salt.",
    "faqDe": "Ist Himalaya-Salz gesünder als normales Salz? Chemisch besteht es zu ca. 98% aus Natriumchlorid. Das Eisen verleiht die schöne Farbe; ernährungsphysiologisch ist es reines, unjodiertes Steinsalz.",
    "allergens": [
      "None"
    ],
    "tags": [
      "RockSalt",
      "Himalaya",
      "Halite",
      "Unrefined",
      "KitchenStaple"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_schwarzer_pfeffer",
    "category": "spices_herbs",
    "nameEn": "Black Pepper (Piper nigrum)",
    "nameDe": "Schwarzer Pfeffer (Echter Pfeffer & Tellicherry)",
    "subtitleEn": "Sun-oxidized berries of Piper nigrum, piperine pungency & woody terpenes",
    "subtitleDe": "Fermentierte Beeren der Pfefferpflanze, scharfer Piperin-Kern & holzige Terpene",
    "imageUrl": "https://images.unsplash.com/photo-1532336414038-cf19250c5757?w=800&auto=format&fit=crop&q=80",
    "origin": "India (Malabar Coast), Vietnam, Cambodia (Kampot PGI)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Biting heat, woody pine warmth, camphor notes, citrus zest, bold lingering pungency.",
    "tasteDe": "Prickelnde Schärfe, waldig-harzige Wärme, Kampfernoten, dezente Zitrusfrische.",
    "scienceEn": "Black pepper is the unripe green berry of the tropical woody vine Piper nigrum. After harvest, the berries are briefly scalded in hot water and dried in the sun for several days. Endogenous polyphenol oxidase enzymes oxidize the outer fruit skin, turning it wrinkled and black. The nitrogenous alkaloid piperine (C17H19NO3) triggers TRPV1 heat receptors on the tongue, creating fiery pungency, while essential oils (pinene, limonene, caryophyllene) deliver complex woody aroma.",
    "scienceDe": "Schwarzer Pfeffer wird halbreif (grün) von Hand gepflückt. Beim anschließenden Trocknen in der heißen Sonne oxidieren pflanzliche Enzyme (Polyphenoloxidasen) die äußere Fruchthaut runzelig und schwarz. Das Alkaloid Piperin reizt die Schmerzrezeptoren der Zunge (TRPV1) und sorgt für die Schärfe, während ätherische Öle (Pinen, Caryophyllen) den warmen Duft liefern. 'Tellicherry' bezeichnet besonders große, aromatische Beeren.",
    "culinaryEn": "Freshly ground at table side over steaks, cacio e pepe pasta, carpaccio, and rich sauces.",
    "culinaryDe": "Immer frisch aus der Mühle mahlen! Klassiker für Steak au Poivre, Pasta Cacio e Pepe, Rinder-Carpaccio und kräftige Schmorgerichte.",
    "faqEn": "Why does ground pre-packaged pepper taste dusty? Volatile essential terpene oils evaporate within hours of grinding; pre-ground pepper retains only piperine heat without fragrant complexity.",
    "faqDe": "Warum schmeckt fertig gemahlener Pfeffer aus der Dose staubig? Die flüchtigen Aromaterpene verfliegen wenige Stunden nach dem Mahlen; es bleibt nur noch flache Schärfe ohne Aroma.",
    "allergens": [
      "None"
    ],
    "tags": [
      "BlackPepper",
      "Piperine",
      "Tellicherry",
      "Kampot",
      "SpiceKing"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_weisser_pfeffer",
    "category": "spices_herbs",
    "nameEn": "White Pepper (Muntok & Sarawak)",
    "nameDe": "Weißer Pfeffer (Vollreife Pfeffersamen)",
    "subtitleEn": "Fully ripe red berries steeped in water to remove pulp, refined clean heat",
    "subtitleDe": "Vollreif rot geerntete Beeren, durch Wässern von der Fruchtschale befreit",
    "imageUrl": "",
    "origin": "Indonesia (Bangka / Muntok), Malaysia (Sarawak), Madagascar",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Sharp, pungent, animalic warmth, grassy fermented undertones, no woody sweetness.",
    "tasteDe": "Klare, prägnante Schärfe, animalisch-würzige Tiefe, trocken, keine holzige Süße.",
    "scienceEn": "White pepper is made from fully ripe red pepper berries. The harvested berries are submerged in running river or tank water for 7-14 days. Microbial fermentation softens and dissolves the outer red pericarp (flesh). The berries are then washed, rubbed mechanically, and sun-dried, leaving only the spherical white-grey core seed. Lacking the terpene-rich outer skin, white pepper delivers pure piperine pungency and a distinct fermented warmth.",
    "scienceDe": "Für weißen Pfeffer lässt man die Beeren an der Pflanze vollreif rot werden. Sie werden in Säcken tagelang in fließendem Wasser eingeweicht. Durch natürliche Milchsäure-Fermentation löst sich die rote Fruchthaut (Perikarp) vollständig ab. Übrig bleibt der reine weiße Steinkern. Da die harzige Schale fehlt, schmeckt weißer Pfeffer schärfer, geradliniger und hinterlässt keine schwarzen Punkte in hellen Gerichten.",
    "culinaryEn": "Indispensable in classical French cuisine: Béchamel sauce, potato purée, cream soups, poultry velouté, and fish dishes.",
    "culinaryDe": "Der Standard der klassischen Haute Cuisine: Béchamel-Sauce, Sauce Hollandaise, Kartoffelpüree, helle Geflügel-Veloutés und Fischgerichte.",
    "faqEn": "Why use white pepper instead of black? Esthetic and taste: it doesn't leave black speckles in pristine white sauces and provides an immediate, sharp, non-sweet heat.",
    "faqDe": "Warum nutzt die gehobene Küche weißen Pfeffer? Ästhetik und Geschmack: Er verhindert unansehnliche schwarze Pünktchen in hellen Saucen und wirkt sofort scharf ohne Fruchtsüße.",
    "allergens": [
      "None"
    ],
    "tags": [
      "WhitePepper",
      "Bechamel",
      "HauteCuisine",
      "Fermented",
      "Piperine"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_gruener_rosa_pfeffer",
    "category": "spices_herbs",
    "nameEn": "Green & Pink Peppercorns",
    "nameDe": "Grüner Pfeffer & Rosa Beeren (Schinus)",
    "subtitleEn": "Brined green Piper nigrum berries vs. sweet floral Schinus terebinthifolius",
    "subtitleDe": "Früh geernteter Lake-Pfeffer vs. süßlich-harzige Schinus-Beeren (Falscher Pfeffer)",
    "imageUrl": "",
    "origin": "India / Madagascar (Green) | Brazil / Réunion (Pink)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Green: Tart, herbal, juicy pop. Pink: Sweet floral, fruity resin, delicate fragile crunch, mild.",
    "tasteDe": "Grün: Würzig-säuerlich, saftiger Knack. Rosa: Süßlich-blumig, harzig, hauchzart, kaum scharf.",
    "scienceEn": "1. Green Peppercorns: Immature Piper nigrum berries pickled immediately in brine or freeze-dried to deactivate polyphenol oxidase enzymes, halting black oxidation.\\n2. Pink Peppercorns: NOT true pepper! They are the dried berries of the Brazilian pepper tree (Schinus terebinthifolius, Sumac family). They contain virtually no piperine; their delicate papery skins contain sweet sugars, pinene, and myrcene, delivering fruity and floral perfume.",
    "scienceDe": "1. Grüner Pfeffer: Unreife Beeren, die sofort in Salzlake eingelegt oder schockgefrostet werden, um das Schwarzwerden zu stoppen. Saftig und ideal für Pfeffersaucen.\\n2. Rosa Beeren: Botanisch KEIN echter Pfeffer, sondern die Früchte des Peruanischen Pfefferbaums (Anakardiengewächs!). Sie enthalten fast kein Piperin, dafür Zucker und ätherische Harze. Süßlich-aromatisch mit hauchdünner Knusperhülle.",
    "culinaryEn": "Green: Classic French green pepper steak sauce with cognac and heavy cream. Pink: Gravlax, goat cheese logs, carpaccio garnish.",
    "culinaryDe": "Grün: Klassische Rahm-Pfeffersauce zum Rinderfilet mit Cognac. Rosa: Zu gebeiztem Lachs, Ziegenkäserollen, Jakobsmuscheln und als Farbspiel.",
    "faqEn": "Can people with nut allergies eat pink peppercorns? Caution: As members of the Anacardiaceae family, pink peppercorns are related to cashews and pistachios and may trigger allergic cross-reactions.",
    "faqDe": "Vorsicht bei Nussallergie? Rosa Beeren gehören zur Familie der Sumach-/Anakardiengewächse (verwandt mit Cashews und Pistazien) und können Kreuzallergien auslösen!",
    "allergens": [
      "Anacardiaceae / Tree nut cross-reactivity (Pink peppercorns only"
    ],
    "tags": [
      "GreenPepper",
      "PinkPepper",
      "Schinus",
      "SteakSauce",
      "Gourmet"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_szechuan_pfeffer",
    "category": "spices_herbs",
    "nameEn": "Sichuan Pepper (Zanthoxylum)",
    "nameDe": "Szechuanpfeffer (Zanthoxylum)",
    "subtitleEn": "Citrus family husk inducing electric tingling paresthesia & buzzing numbness",
    "subtitleDe": "Getrocknete Kapseln von Rautengewächsen: Elektrisierendes Prickeln & Taubheitsgefühl (Mala)",
    "imageUrl": "",
    "origin": "China (Sichuan Province)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Vibrant citrus zest, lemongrass perfume, lavender, followed by electric buzzing tingling sensation.",
    "tasteDe": "Intensive Zitrus- und Zitronengrasnoten, Bergamotte, gefolgt von prickelnder Vibration auf der Zunge.",
    "scienceEn": "Sichuan pepper is not related to black pepper or chili peppers; it belongs to the citrus family (Rutaceae). Only the aromatic pinkish-red outer husks are consumed (the hard black inner seeds are discarded as bitter and gritty). The active compound hydroxy-alpha-sanshool stimulates tactile sensory mechanoreceptors in tongue papillae at ~50 Hertz, inducing an extraordinary electric vibration and mild anesthetic numbness ('Mala' flavor: Ma = numbing, La = spicy chili).",
    "scienceDe": "Szechuanpfeffer ist weder mit Pfeffer noch mit Chili verwandt, sondern gehört zu den Rautengewächsen (wie Zitronen!). Gegessen werden nur die roten Schalen. Der Inhaltsstoff Hydroxy-alpha-sanshool stimuliert die Berührungsnerven der Zunge mit ca. 50 Hertz Schwingung: Es entsteht ein vibrierendes, taubes Prickeln, das zusammen mit Chilis die weltberühmte 'Mala'-Schärfe der Sichuan-Küche definiert.",
    "culinaryEn": "Mapo Tofu, Sichuan hotpot, Kung Pao chicken, spiced salt for crispy duck, modern craft gin botanicals.",
    "culinaryDe": "Mapo Tofu, Sichuan-Feuertopf, Kung Pao Huhn, geröstet mit Meersalz als Gewürzsalz zu knuspriger Ente oder Rinderfilet.",
    "faqEn": "Why does water taste sweet after chewing Sichuan pepper? Hydroxy-alpha-sanshool alters sensitivity of taste bud receptors, temporarily modulating aftertaste sensations.",
    "faqDe": "Warum schmeckt Wasser danach seltsam kühl und süß? Der Wirkstoff Sanshool betäubt vorübergehend bestimmte Rezeptoren und verändert das Geschmacksempfinden für Minuten.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Sichuan",
      "Sanshool",
      "Numbing",
      "Citrus",
      "AsianCuisine"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_safran",
    "category": "spices_herbs",
    "nameEn": "Saffron (Crocus sativus)",
    "nameDe": "Safran (Rotes Gold & Crocus sativus)",
    "subtitleEn": "Hand-picked crimson stigmas of autumn crocus, crocin yellow dye & safranal perfume",
    "subtitleDe": "Handgepflückte rote Narbenfäden der Safrankrokus-Blüte – teuerstes Gewürz der Welt",
    "imageUrl": "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=800&auto=format&fit=crop&q=80",
    "origin": "Iran (Khorasan), Spain (La Mancha DOP), Greece (Kozani PDO)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet hay-like floral aroma, metallic iodine note, subtle earthy honey bitterness, vibrant golden color.",
    "tasteDe": "Edel-herb, bittersüß, Noten von sonnengetrocknetem Heu und Honig, leuchtendes Sonnengelb.",
    "scienceEn": "Saffron is the world's costliest spice: it takes roughly 150,000 to 200,000 delicate violet crocus flowers harvested entirely by hand at dawn to produce just 1 kilogram of dried saffron threads. Its sensory properties stem from three key chemical compounds: 1) Crocin: a carotenoid pigment that dissolves readily in warm water/broth turning it brilliant luminous gold; 2) Safranal: volatile essential oil creating the warm hay-like aroma; 3) Picrocrocin: glucoside delivering its characteristic bittersweet taste.",
    "scienceDe": "Für 1 kg getrockneten Safran müssen bis zu 200.000 Krokusblüten frühmorgens vor Sonnenaufgang von Hand gepflückt und die drei feinen roten Narbenfäden herausgezupft werden. Die Chemie: 1) Crocin löst sich im Wasser und färbt Gerichte sonnengelb; 2) Safranal erzeugt den heuartigen Duft; 3) Picrocrocin liefert die edle Bitternote. Fäden immer in warmem Wasser oder Weißwein 15 Min. vorziehen, nie direkt in heißes Fett werfen!",
    "culinaryEn": "Spanish Paella Valenciana, Milanese saffron risotto (Risotto alla Milanese), Bouillabaisse fish stew, Swedish Lussekatter.",
    "culinaryDe": "Spanische Paella, Risotto alla Milanese mit Rindermark, Marseiller Bouillabaisse, Safransaucen zu Edelfischen und Edelgebäck.",
    "faqEn": "How do you detect fake saffron? Real saffron threads are trumpet-shaped, flared at the tip, never melt into a single red blob, and turn liquid golden yellow (never artificial neon pink or red).",
    "faqDe": "Woran erkennt man echten Safran? Echte Fäden sind trompetenförmig am Ende dicker, färben Wasser stets leuchtend gelb (nie chemisch rot!) und riechen nach Heu und Honig.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Saffron",
      "Safran",
      "Luxury",
      "Paella",
      "Risotto"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_ceylon_cassia_zimt",
    "category": "spices_herbs",
    "nameEn": "Ceylon Cinnamon vs. Cassia Cinnamon",
    "nameDe": "Ceylon-Zimt vs. Cassia-Zimt",
    "subtitleEn": "Multi-layered delicate true quills (low coumarin) vs. thick hard cassia bark",
    "subtitleDe": "Feinschichtiger echter Edel-Zimt (cumarinarm) vs. dicke harte Holzborke mit hohem Cumarin",
    "imageUrl": "",
    "origin": "Sri Lanka (Ceylon Cinnamon) | China / Indonesia / Vietnam (Cassia)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Ceylon: Delicate, floral, sweet woody perfume, mild warmth. Cassia: Bold, punchy, sharp, pungent winter spice.",
    "tasteDe": "Ceylon: Zart, blumig, edle Zimtnote, feine Süße. Cassia: Kräftig, holzig-scharf, intensiv dominant.",
    "scienceEn": "1. Ceylon Cinnamon (Cinnamomum verum): Harvested from paper-thin shaved inner bark layers, tightly rolled together into fragile, multi-layered 'cigar-like' quills that can easily be crushed with fingers. Crucially, it contains virtually zero coumarin (<0.004%), making it completely safe in high culinary doses.\\n2. Cassia Cinnamon (Cinnamomum cassia): Made from a single thick, rock-hard curved tree bark layer with a hollow center. Contains high concentrations of hepatotoxic coumarin (up to 1%), requiring regulatory intake limits in the EU.",
    "scienceDe": "1. Ceylon-Zimt (Echter Zimt): Besteht aus hauchdünnen, zigarrenartig ineinandergeschobenen Rindenschichten. Er lässt sich mit der Hand zerbröseln, duftet blumig-mild und ist praktisch frei vom leberschädigenden Cumarin.\\n2. Cassia-Zimt (Chinesischer Zimt): Eine dicke, steinhart eingerollte Holzrinde mit Hohlraum. Schmeckt sehr scharf-würzig, enthält aber hohe Mengen Cumarin, weshalb das Bundesinstitut für Risikobewertung bei regelmäßigem Verzehr zu Ceylon-Zimt rät.",
    "culinaryEn": "Ceylon for delicate patisserie, crèmes, braised lamb tagines, and glühwein. Cassia commonly in industrial bakery products.",
    "culinaryDe": "Ceylon für feine Pâtisserie, Apfeldesserts, orientalische Lamm-Tajines, Glühwein und feine Bar-Sirups. Cassia meist in der industriellen Weihnachtsbäckerei.",
    "faqEn": "How can you visually tell Ceylon from Cassia cinnamon sticks? Look at the cross section: Ceylon looks like a layered cigar filled with many paper-thin rolls; Cassia is a thick, single hollow wooden tube.",
    "faqDe": "Wie unterscheidet man die Zimtstangen optisch? Am Querschnitt: Ceylon gleicht einer Zigarre aus vielen dünnen Blättern; Cassia ist ein dickes, hartes, hohles Einzelrohr.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Cinnamon",
      "Zimt",
      "Ceylon",
      "Cassia",
      "BakingSpice"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_mediterrane_kraeuter",
    "category": "spices_herbs",
    "nameEn": "Mediterranean Herbs (Rosemary, Thyme, Basil, Oregano)",
    "nameDe": "Mediterrane Kräuter (Rosmarin, Thymian, Basilikum, Oregano)",
    "subtitleEn": "Heat-resistant woody shrubs (cineole, thymol) vs. heat-sensitive tender leaf herbs",
    "subtitleDe": "Hitzestabile holzige Nadelsträucher (Schmorkräuter) vs. empfindliche Blattkräuter",
    "imageUrl": "",
    "origin": "Mediterranean Basin (Italy, France, Greece, Spain)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Pine resin, camphor, lemon thyme freshness, peppery clove warmth (basil), savory umami boost.",
    "tasteDe": "Harzig-waldig (Rosmarin), würzig-herb (Thymian), pfeffrig-frisch (Basilikum), warm (Oregano).",
    "scienceEn": "Culinary chemistry divides herbs into two fundamental gastronomic categories: 1) Woody, resinous herbs (Rosemary, Thyme, Winter Savory): Native to dry rocky soils, they protect themselves with thick waxy cuticles containing heavy, heat-stable essential oils (rosmarinic acid, carvacrol, thymol). They thrive in hot oil and long cooking times. 2) Tender leaf herbs (Sweet Basil, Chervil, Tarragon): High in water and volatile monoterpenes (linalool, eugenol). High heat destroys their aromatic structure within seconds; they must be torn and added raw just before plating.",
    "scienceDe": "Die Gastronomie unterscheidet zwei Welten: 1) Robuste Holz- und Nadelkräuter (Rosmarin, Thymian, Salbei, Oregano): Wachsen auf kargen Felsböden, haben derbe Schutzwachsschichten und hitzestabile atherische Öle (Thymol, Cineol). Sie müssen in heißem Fett oder Schmorgerichten mitgekocht werden, um ihr Aroma ans Fett abzugeben.\\n2) Zarte Blattkräuter (Basilikum, Kerbel, Estragon): Hitze zerstört die zarten Aromamoleküle (Linalool) in Sekunden; Basilikum darf erst ganz zum Schluss frisch über Pasta oder Caprese gerupft werden.",
    "culinaryEn": "Rosemary & Thyme roasted with lamb racks, ribeye, and potatoes. Basil torn over fresh Mozzarella di Bufala and tomato passata.",
    "culinaryDe": "Rosmarin & Thymian mit Knoblauch in aufgeschäumter Butter zum Arrosieren von Steaks, Lammkarree und Röstkartoffeln. Basilikum frisch über Caprese und Tomatensaucen.",
    "faqEn": "Why should basil never be chopped with a dull knife? Bruising crushes cells, releasing polyphenol oxidases that react with oxygen and turn the cut leaves unsightly black and bitter.",
    "faqDe": "Warum wird Basilikum schwarz, wenn man es mit einem stumpfen Messer hackt? Durch das Quetschen oxidieren die Enzyme mit Sauerstoff; Basilikum lieber mit scharfem Messer schneiden oder zupfen.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Herbs",
      "Rosemary",
      "Thyme",
      "Basil",
      "Mediterranean"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_zaatar_ras_el_hanout",
    "category": "spices_herbs",
    "nameEn": "Za'atar & Ras el Hanout (Middle Eastern Blends)",
    "nameDe": "Za'atar & Ras el Hanout (Orientalische Würztradition)",
    "subtitleEn": "Levantine wild hyssop-thyme with sumac & sesame vs Moroccan 30-spice blend",
    "subtitleDe": "Levantinischer Wildthymian mit fruchtigem Sumach & Sesam vs. marokkanische Königsmischung",
    "imageUrl": "",
    "origin": "Middle East (Levant: Lebanon, Palestine, Jordan) & North Africa (Morocco)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Za'atar: Nutty roasted sesame, tangy citric tartness (sumac), herbal thyme warmth. Ras el Hanout: Complex warm floral sweetness, cumin, pepper.",
    "tasteDe": "Za'atar: Nussig gerösteter Sesam, fruchtig-zitronige Säure (Sumach), herber Wildthymian. Ras el Hanout: Vielschichtig, warm, blumig, zimtig-pfeffrig.",
    "scienceEn": "1. Za'atar: The iconic spice blend of Levantine cuisine. Combines wild mountain oregano/thyme (Origanum syriacum) with ground sumac berries (Rhus coriaria) and toasted sesame seeds. Sumac contains abundant natural malic and citric acids, providing refreshing acidity without adding wet lemon juice.\\n2. Ras el Hanout ('Top of the Shop'): Master blend created by North African spice merchants using up to 30 choice aromatic botanicals (cardamom, mace, cinnamon, nutmeg, rose petals, grains of paradise, allspice, turmeric), crafting harmonious sweet-savory depth.",
    "scienceDe": "1. Za'atar: Das Herz der levantinischen Esskultur aus dem arabischen Raum. Besteht aus wildem Thymian, geröstetem Sesam und dunkelrotem Sumach. Sumach liefert eine fruchtig-herbe Zitrussäure (Äpfelsäure), ohne das Gericht zu wässern.\\n2. Ras el Hanout ('Chef des Ladens'): Die marokkanische Königsdisziplin der Gewürzkunst. Aus bis zu 30 edlen Gewürzen (Muskatblüte, Kardamom, Rosenknospen, Paradieskörner, Kreuzkümmel) meisterhaft komponiert – verleiht Tajines und Couscous ihre tiefe, warme Magie.",
    "culinaryEn": "Za'atar mixed with extra virgin olive oil as dip for flatbread (Man'ouche), labneh, roasted vegetables. Ras el Hanout in lamb tagines, couscous, and roasted carrots.",
    "culinaryDe": "Za'atar 1:1 mit bestem Olivenöl verrührt als Dip zu warmem Fladenbrot, über Labneh (Frischkäse), Hummus oder Ofengemüse. Ras el Hanout für Schmortöpfe (Tajine), Lamm und Couscous.",
    "faqEn": "What is the red berry in Za'atar that tastes like lemon? That is Sumac: dried and crushed sour berries of Rhus coriaria, the historic citric acid of the Middle East before lemons were widespread.",
    "faqDe": "Was ist das säuerliche rote Pulver im Za'atar? Das ist Sumach: gemahlene Beeren des Färberbaums, die seit Jahrtausenden im Orient als natürlicher Zitronenersatz dienen.",
    "allergens": [
      "Sesame seeds"
    ],
    "tags": [
      "Zaatar",
      "RasElHanout",
      "MiddleEast",
      "Sumac",
      "Orient"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "spice_paprika_kreuzkuemmel_muskat",
    "category": "spices_herbs",
    "nameEn": "Noble Sweet Paprika, Cumin & Nutmeg",
    "nameDe": "Paprika edelsüß, Kreuzkümmel (Cumin) & Muskatnuss",
    "subtitleEn": "Carotenoid-rich sweet pepper vs. earthy cuminaldehyde vs. myristicin nut magic",
    "subtitleDe": "Ungarischer Edelsüß-Paprika vs. erdiger Kreuzkümmel vs. frisch geriebene Muskatnuss",
    "imageUrl": "https://images.unsplash.com/photo-1596040033229-a9821ebd058d?w=800&auto=format&fit=crop&q=80",
    "origin": "Hungary / Spain (Paprika), Egypt / India (Cumin), Indonesia / Grenada (Nutmeg)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Paprika: Deep fruity-sweet red warmth. Cumin: Pungent earthy-warm lemon undertone. Nutmeg: Sweet, woody, warm balsamic aroma.",
    "tasteDe": "Paprika: Fruchtig-milde Süße, tiefrot. Cumin: Erdig-warm, unverwechselbar würzig. Muskat: Balsamisch-süß, warm, feinherb.",
    "scienceEn": "Gastronomic kitchen chemistry of three essentials: 1) Paprika edelsüß: Dried ripe red pepper pods milled without hot capsaicin placenta ribs; rich in red carotenoids (capsanthin). Warning: Overheating in dry hot fat turns natural sugars black and acrid-bitter within seconds! 2) Cumin (Kreuzkümmel): Dominated by cuminaldehyde; essential for Indian curries, Mexican chili, and Middle Eastern falafel. 3) Nutmeg (Muskatnuss): Seed of Myristica fragrans containing myristicin and elemicin oils; always freshly grated into dairy/potato fats where lipid molecules capture the volatile aromas.",
    "scienceDe": "Drei unentbehrliche Säulen der Profiküche: 1) Paprika edelsüß: Aus getrockneten roten Schoten ohne scharfe Scheidewände gemahlen, reich an Carotinoiden. Wichtig: Paprikapulver darf nie in kochend heißem Fett verbrennen, sonst karamellisiert der Fruchtzucker bitter!\\n2) Kreuzkümmel (Cumin): Geprägt vom ätherischen Cuminaldehyd – das Rückgrat für Falafel, Hummus, Chili con Carne und orientalische Eintöpfe.\\n3) Muskatnuss: Der Samen des Muskatnussbaums; immer frisch über die Reibe gerieben in Kartoffelpüree, Béchamel, Blumenkohl und Spinat, da Fette die flüchtigen Aromen perfekt binden.",
    "culinaryEn": "Paprika for Goulash and chicken paprikash. Cumin for shakshuka, falafel, and lamb tagine. Nutmeg freshly grated into potato purée and spinach.",
    "culinaryDe": "Paprika für ungarisches Gulasch. Kreuzkümmel für Shakshuka, Hummus und Lamm. Muskat frisch gerieben in Kartoffelpüree, Rahmspinat und Blumenkohl.",
    "faqEn": "Why does paprika turn bitter when frying? The natural high fructose in sweet paprika chars at temperatures above 130°C; always remove the pan from direct heat when adding paprika!",
    "faqDe": "Warum wird Paprikapulver beim Anbraten bitter? Weil der natürliche Fruchtzucker bei über 130°C verbrennt; den Topf beim Einrühren immer kurz von der Hitze nehmen!",
    "allergens": [
      "None"
    ],
    "tags": [
      "Paprika",
      "Cumin",
      "Nutmeg",
      "Muskat",
      "KitchenStaple"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "olive_kalamata_pdo",
    "category": "olives",
    "nameEn": "Kalamata Olives PDO (Greece)",
    "nameDe": "Kalamata-Oliven g.U. (Griechenland)",
    "subtitleEn": "Almond-shaped, deep aubergine-purple, cured in red wine vinegar and extra virgin olive oil",
    "subtitleDe": "Mandelform, tiefdunkles Violett, traditionell in Rotweinessig und nativem Olivenöl gereift",
    "imageUrl": "https://images.unsplash.com/photo-1586370434639-0fe43b2d32e6?w=800&auto=format&fit=crop&q=80",
    "origin": "Greece (Peloponnese / Messenia - PDO)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Rich, meaty flesh, winey fruity tartness from red wine vinegar, savory umami depth, gentle bitterness.",
    "tasteDe": "Fleischig-saftiger Biss, feine Weinessigsäure, edle herbe Fruchtnote, voller öliger Schmelz.",
    "scienceEn": "Kalamata olives (Kalamon cultivar) are harvested only when fully tree-ripened to a dark purple-black color in late autumn. Fresh raw olives are intensely bitter due to the defensive polyphenol oleuropein. Traditional Greek curing involves slitting each olive ('charaktis') and soaking them in brine to leach out bitterness, followed by curing in red wine vinegar and extra virgin olive oil. This preserves their firm yet juicy flesh and infuses characteristic winey acidity.",
    "scienceDe": "Kalamata-Oliven (Sorte Kalamon) dürfen nur vollreif und dunkelviolett im Spätherbst von Hand gepflückt werden. Frisch vom Baum sind alle Oliven durch den Bitterstoff Oleuropein ungenießbar. Das traditionelle Verfahren: Die Früchte werden seitlich eingeschnitten, wochenlang in Salzlake gewässert und anschließend in Rotweinessig und Olivenöl eingelegt. Das verleiht ihnen den unnachahmlichen saftigen Biss und die feinsäuerliche Note.",
    "culinaryEn": "Classic Greek salad (Horiatiki) with authentic Feta PDO, oregano, tapas platters, and Mediterranean braised lamb.",
    "culinaryDe": "Klassisch im echten Bauernsalat (Choriatiki) mit Feta g.U., Oregano, Tomaten und Gurke; auf Meze-Platten oder zu geschmortem Lamm.",
    "faqEn": "Why are real Kalamata olives never jet-black? Kalamata olives ripen naturally into shades of aubergine, dark purple, and deep maroon; uniform jet-black indicates artificial chemical dyeing.",
    "faqDe": "Warum sind echte Kalamata-Oliven nie pechschwarz? Weil sie natürlich am Baum reifen: Echte Kalamatas schimmern edel dunkelviolett, pflaumenblau bis weinrot – niemals gleichförmig kohlschwarz!",
    "allergens": [
      "None"
    ],
    "tags": [
      "Kalamata",
      "Olives",
      "Greece",
      "PDO",
      "Meze"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "olive_spanische_gruen_manzanilla",
    "category": "olives",
    "nameEn": "Spanish Green Olives (Manzanilla & Gordal)",
    "nameDe": "Spanische Grüne Oliven (Manzanilla & Gordal)",
    "subtitleEn": "Seville-style green table olives, crisp snap, lactic brine fermentation & tapas stuffing",
    "subtitleDe": "Nach Sevilla-Art fermentiert, knackig-fester Biss, ideal zum Füllen mit Pimientos oder Mandeln",
    "imageUrl": "",
    "origin": "Spain (Andalusia / Seville)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Crisp firm snap, refreshing herbal tang, delicate mild bitterness, savory brine.",
    "tasteDe": "Knackiger, fester Biss, mild-herbes Fruchtfleisch, angenehm salzig-erfrischend.",
    "scienceEn": "Spanish green olives are picked while firm and green in early autumn. In the 'Spanish/Seville method', olives are treated with a dilute food-grade alkaline solution (sodium hydroxide lye) for 6-8 hours to hydrolyze bitter oleuropein into non-bitter hydroxytyrosol. They are thoroughly washed with fresh water and placed in brine, where natural lactic acid bacteria (Lactobacillus plantarum) ferment sugars into lactic acid (lowering pH to ~3.8), creating their crisp texture and pleasant tangy bite.",
    "scienceDe": "Grüne spanische Oliven werden frühreif geerntet. Beim berühmten 'Sevillana-Verfahren' wird das bittere Oleuropein in kurzer Zeit durch verdünnte alkalische Lösung (Natronlauge für wenige Stunden) neutralisiert. Nach gründlichem Wässern reifen die Oliven in Salzlake durch natürliche Milchsäurebakterien heran. Das erhält das knackige, feste Fruchtfleisch, das sich perfekt entkernen und mit Paprikapaste, Mandeln oder Anchovis füllen lässt.",
    "culinaryEn": "Classic Spanish tapas bars served with ice-cold fino sherry, Marcona almonds, or skewered with anchovies (Gilda pintxo).",
    "culinaryDe": "Der Inbegriff der spanischen Tapas-Kultur: Zu trockenem Fino-Sherry, Manchego-Käse oder als Baskischer Pintxo 'Gilda' mit Anchovis und eingelegter Peperoni am Spieß.",
    "faqEn": "What does Gordal mean? 'Gordal' translates to 'The Fat One' in Spanish, referring to its giant, juicy, plump size (queen olive).",
    "faqDe": "Was bedeutet 'Gordal'? Gordal heißt auf Spanisch 'die Dicke' – sie ist die größte Königsolive mit besonders üppigem Fruchtfleisch.",
    "allergens": [
      "None (unless stuffed with fish or nuts"
    ],
    "tags": [
      "Manzanilla",
      "Gordal",
      "Spain",
      "Tapas",
      "TabelOlives"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "olive_throuba_thassos_runzel",
    "category": "olives",
    "nameEn": "Throuba Thassos PDO (Wrinkled Sun-Dried Olives)",
    "nameDe": "Throuba Thassos g.U. (Griechische Runzeloliven)",
    "subtitleEn": "Naturally debittered on the branch by morning sea air, sun-dried without chemicals",
    "subtitleDe": "Am Baum natürlich entbittert, in der Seeluft sonnengetrocknet – ohne chemische Lauge",
    "imageUrl": "",
    "origin": "Greece (Island of Thassos - PDO)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Soft raisin-like texture, rich concentrated olive oil flavor, mellow fruity sweetness, no watery brine.",
    "tasteDe": "Samtig-weiche Rosinen-Textur, hochkonzentriertes Olivenölaroma, milde Trockenfruchtsüße, kein Wassergeschmack.",
    "scienceEn": "Throuba Thassos is a rare natural miracle of Mediterranean botany. Unlike virtually all other table olives on Earth, it does NOT require lye, boiling, or long water soaking to remove bitterness. As the fruit fully ripens on the tree into late November, a harmless symbiotic fungus (Phoma oleae) develops in the Aegean sea breeze, producing enzymes that hydrolyze bitter oleuropein directly while the olive is still attached to the branch. The olives naturally wrinkle and dry under the autumn sun.",
    "scienceDe": "Die Throuba-Olive von der Insel Thassos ist eine botanische Weltsensation: Sie muss weder in Lauge noch in Essig eingelegt werden! Beim Ausreifen am Baum bis in den Spätherbst bildet sich durch die feuchte ägäische Meeresbrise ein natürlicher Hefepilz (Phoma oleae), der den Bitterstoff Oleuropein direkt am Zweig enzymatisch abbaut. Die Oliven schrumpfen am Ast in der Herbstsonne zu delikaten Runzeloliven mit intensivem Olivenölschmelz.",
    "culinaryEn": "Drizzled with extra virgin olive oil and oregano, alongside baked goat cheese, fresh country bread, and red wine.",
    "culinaryDe": "Nur mit etwas nativem Olivenöl und Wild-Oregano beträufelt; perfekt zu Ziegenkäse, warmem Fladenbrot und gehaltvollem Rotwein.",
    "faqEn": "Why do wrinkled Throuba olives look like black prunes? They lose moisture naturally on the branch, concentrating natural olive oils without water dilution.",
    "faqDe": "Warum sehen Runzeloliven aus wie Pflaumen? Weil sie das Wasser direkt am Baum durch Verdunstung verlieren; dadurch schmecken sie extrem cremig und ölreich.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Throuba",
      "Thassos",
      "Greece",
      "PDO",
      "SunDried"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "olive_echt_schwarz_vs_gefaerbt",
    "category": "olives",
    "nameEn": "Naturally Black vs. Chemically Blackened Olives (E579)",
    "nameDe": "Echte schwarze vs. chemisch geschwärzte Oliven (E579)",
    "subtitleEn": "Essential hospitality staff knowledge: Tree-ripened purple fruits vs lye-blackened green olives",
    "subtitleDe": "Unverzichtbares Gastro-Wissen: Natürlich am Baum gereift vs. mit Eisengluconat künstlich geschwärzt",
    "imageUrl": "",
    "origin": "Mediterranean Basin (Global Gastronomy)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Real Black: Soft, tender, oily, complex savory fruit. Dyed Black: Rubber-firm, watery, metallic aftertaste.",
    "tasteDe": "Echt schwarz: Zart, weich, saftig, ölig-fruchtig. Künstlich geschwärzt: Gummig-hart, wässrig, metallischer Beigeschmack.",
    "scienceEn": "A vital quality distinction in gastronomy: 1) Naturally black olives remain on the tree for months until fully ripe, changing from green to purple to deep brownish-black; their flesh is soft, rich in oleic acid, and contains authentic olive fruit complexity. 2) Chemically blackened olives are cheap, rock-hard, UNRIPE green olives soaked in lye, injected with compressed air/oxygen bubbles to oxidize the skin black, and fixed with Iron(II) gluconate (E579) or Iron lactate (E585). In the EU, these must be legally labeled as 'geschwärzt' (blackened).",
    "scienceDe": "Eines der wichtigsten Unterscheidungsmerkmale im Restaurant: 1) Echte schwarze Oliven reifen bis zu 6 Monate am Baum, bis sie tiefviolett bis schwarzbraun sind. Sie sind weich, voller gesunder Fettsäuren und haben einen aromatischen Schmelz.\\n2) Chemisch geschwärzte Oliven (Standard auf Billigpizzen): Es sind billige, unreife, steinhart geerntete GRÜNE Oliven. Sie werden in Natronlauge gebadet, mit Sauerstoff begast und mit dem Zusatzstoff Eisen-II-gluconat (E579) tiefschwarz gefärbt. Sie schmecken wässrig-metallisch und bleiben unnatürlich zäh.",
    "culinaryEn": "High-end restaurants serve only naturally ripe black olives with pits intact (pitted olives lose volatile oils much faster).",
    "culinaryDe": "Die gehobene Gastronomie serviert ausschließlich natürlich gereifte schwarze Oliven – am besten mit Stein, da entsteinte Oliven schnell wässern und an Geschmack verlieren.",
    "faqEn": "How can a guest tell if a black olive is fake? Check the pit and texture: if the olive is jet-black, rock-hard, and rubbery with a metallic hint, it was dyed with iron gluconate (E579).",
    "faqDe": "Wie erkennt der Gast geschwärzte Oliven? An der unnatürlichen Festigkeit und Farbe: Tief rabenschwarz, gummig-fest und oft mit metallischem Unterton.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Olives",
      "BlackOlives",
      "E579",
      "QualityCheck",
      "GastronomyKnowledge"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "olive_arabisch_beldi_marokko",
    "category": "olives",
    "nameEn": "Moroccan Beldi & Arab Spiced Olives",
    "nameDe": "Marokkanische Beldi & Arabisch Gewürzte Oliven",
    "subtitleEn": "Dry-cured wrinkled black olives marinated with preserved lemons, coriander, harissa & cumin",
    "subtitleDe": "Trockengesalzene Runzelfrüchte mariniert mit Salzzitronen, frischem Koriander, Kreuzkümmel & Harissa",
    "imageUrl": "",
    "origin": "Morocco (Atlas region) & Arab Levant",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Tangy, intensely savory, floral lemon salinity, warm cumin spice, gentle chili heat from harissa.",
    "tasteDe": "Pikant-würzig, feine Säure eingelegter Salzzitronen, erdiger Kreuzkümmel, dezente Harissa-Schärfe.",
    "scienceEn": "Beldi olives from Morocco are harvested late and dry-salted in layers of coarse sea salt ('dry-curing') for several weeks, draining moisture through woven baskets without water brine. The olives are then rinsed and tossed with preserved lemons (fermented in salt and their own juice until the rinds turn tender and fragrant), freshly toasted cumin, garlic, and hot harissa paste. This creates the quintessential Arab mezze staple, where rich olive oil balances spicy capsaicin and citrus.",
    "scienceDe": "In der arabischen und nordafrikanischen Gastronomie sind Beldi-Oliven der Star jeder Vorspeisentafel (Mezze). Sie werden nach der Ernte in grobem Meersalz trocken geschichtet, wodurch das Bitterwasser abtropft. Anschließend werden sie mit gehackten marokkanischen Salzzitronen (die wochenlang in Salzlake gereift sind), Knoblauch, Koriandersamen, Kreuzkümmel und scharfer Harissa mariniert – eine unvergleichliche Geschmacksexplosion zu frischem Fladenbrot.",
    "culinaryEn": "Arab mezze table served with warm pita or khobz flatbread, hummus, labneh, and braised lamb tagine with prunes.",
    "culinaryDe": "Mittelpunkt der arabischen Mezze-Tafel: Mit warmem Fladenbrot (Khobz), Hummus, Baba Ghanoush und zu marokkanischen Schmortöpfen (Tajine).",
    "faqEn": "Why are preserved lemons used with olives? Salt-preserved lemons (L'hamd Marakad) have tender, non-bitter rinds rich in floral limonene oils that cut through the richness of cured olives.",
    "faqDe": "Warum Salzzitronen dazu? Durch die Fermentation verliert die Zitronenschale ihre Bitterkeit und schmeckt betörend blumig-herb – die perfekte Frische zum Olivenöl.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Beldi",
      "Morocco",
      "ArabCuisine",
      "Mezze",
      "PreservedLemon"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "olive_taggiasca_liguria",
    "category": "olives",
    "nameEn": "Ligurian Taggiasca Olives (Italy)",
    "nameDe": "Ligurische Taggiasca-Oliven (Italien)",
    "subtitleEn": "Tiny, precious brown-violet gourmet olives, sweet buttery finish, zero harsh bitterness",
    "subtitleDe": "Winzige, braun-violette Edelfrucht von ligurischen Steilhängen mit süß-buttrigem Schmelz",
    "imageUrl": "",
    "origin": "Italy (Liguria / Imperia)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Sweet, delicate, nutty almond notes, buttery smooth texture, completely free of harsh tannin.",
    "tasteDe": "Süßlich-mild, feine Haselnuss- und Mandelnoten, buttrig, keinerlei kratzende Bitterkeit.",
    "scienceEn": "Taggiasca olives were brought to Liguria by Benedictine monks in the 17th century. Growing on precipitous, sun-drenched dry-stone terraces facing the sea, the small fruits develop exceptionally high lipid (oil) content and minimal bitter glucoside levels. Harvested carefully with wooden poles over nets, their delicate, sweet, hazelnut-scented pulp makes them a prized favorite in Michelin-starred gastronomy.",
    "scienceDe": "Die Taggiasca-Olive wurde von Benediktinermönchen nach Ligurien gebracht. Auf steilen Trockenstein-Terrassen direkt über dem Meer gewachsen, reifen die winzigen Früchte bunt von grün über violett bis braun. Sie besitzen einen extrem hohen natürlichen Ölgehalt und kaum Gerbstoffe. Ihr buttrig-süßer, nussiger Geschmack macht sie zum Liebling der europäischen Sterneköche.",
    "culinaryEn": "Paired with delicate white fish (sea bass / orata), veal scallopini, pasta with rabbit ragù, and focaccia ligure.",
    "culinaryDe": "Klassiker der feinen ligurischen Küche: Zu gegrilltem Wolfsbarsch (Branzino), Rinderfilet, ligurischer Focaccia und feinen Salaten.",
    "faqEn": "Why are Taggiasca olives so small and varied in color? Genuine Taggiasca olives are harvested when ripeness is mixed; their small size concentrates sugars and fats instead of water.",
    "faqDe": "Warum sind Taggiasca-Oliven so klein und verschiedenfarbig? Weil sie am Baum bunt gemischt reifen; das kleine Format enthält kaum Wasser, dafür geballtes Aroma und edles Öl.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Taggiasca",
      "Liguria",
      "Italy",
      "Gourmet",
      "FineDining"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "olive_arabisch_souri_nabali",
    "category": "olives",
    "nameEn": "Levantine Souri & Nabali Olives (Arab World)",
    "nameDe": "Levantinische Souri- & Nabali-Oliven (Arabischer Raum)",
    "subtitleEn": "Ancient millenary olive cultivars of the Levant, cracked green olives & wild za'atar curing",
    "subtitleDe": "Jahrtausendealte Ursorten der Levante: Angeklopfte grüne Oliven mit Zitronen, Chili & Wildthymian",
    "imageUrl": "https://images.unsplash.com/photo-1540420773420-3366772f4999?w=800&auto=format&fit=crop&q=80",
    "origin": "Middle East (Lebanon, Palestine, Jordan, Syria)",
    "isImport": true,
    "abv": "0.0% ABV",
    "tasteEn": "Vibrant peppery bite, crisp firm crunch, aromatic citrus acidity, spicy chili kick, deep grassy olive fruit.",
    "tasteDe": "Pfeffrige Schärfe, lebendige Zitrusfrische, angenehm herber Biss, feurige Chili-Note, vollfruchtiges Olivenaroma.",
    "scienceEn": "The Levant is the evolutionary birthplace of olive domestication (dating back over 6,000 years). The Souri (named after the historic Phoenician city of Tyre/Sour) and Nabali cultivars are prized for very high oil yields and bold polyphenol levels. Traditional Arab preparation: Green olives are carefully 'cracked' (bruised with a stone or mallet, 'Makbous' or 'Zaytoun Majrouh') to allow brine, fresh lemon juice, garlic, and hot green peppers to penetrate directly into the flesh. Fermented naturally in 10% sea salt brine, maintaining crisp crunch and invigorating sharpness.",
    "scienceDe": "Der Nahe Osten ist die Wiege des Olivenbaums: Schon vor über 6.000 Jahren wurden in der Levante Oliven kultiviert. Die Sorten Souri (benannt nach der phönizischen Hafenstadt Tyros/Sour) und Nabali sind weltberühmt für ihren extrem hohen Ölgehalt und pfeffrige Polyphenole. Die arabische Zubereitung: Die grünen Früchte werden mit einem Holzhammer einzeln angeklopft ('Zeitoun Makbous'), damit Salzlake, Zitronensaft, Knoblauch und frische Chilis direkt ins Fruchtfleisch einziehen können – der unverzichtbare König jeder levantinischen Mezze-Tafel.",
    "culinaryEn": "Essential Arab breakfast and mezze: Served with freshly pressed olive oil, za'atar, warm pita bread, labneh balls, and shakshuka.",
    "culinaryDe": "Unverzichtbar zum arabischen Frühstück und zur Mezze: Mit frischem Olivenöl, Za'atar, warmem Fladenbrot, Labneh (Frischkäsebällchen) und Falafel.",
    "faqEn": "Why are the olives cracked before brining? Cracking the skin allows bitter oleuropein to leach out much faster while infusing fresh lemon juice and chili deep into the fruit pulp.",
    "faqDe": "Warum werden die Oliven angeklopft? Das Anklopfen öffnet die Fruchthaut, sodass Bitterstoffe schneller entweichen und der Zitronen-Chili-Sud tief ins Fleisch zieht.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Souri",
      "Nabali",
      "Levant",
      "ArabCuisine",
      "Mezze",
      "Makbous"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "oil_natives_olivenoel_extra",
    "category": "oils_vinegars",
    "nameEn": "Extra Virgin Olive Oil (EVOO / Nativ Extra)",
    "nameDe": "Natives Olivenöl Extra (Nativ Extra)",
    "subtitleEn": "Top legal grade, strictly cold extraction (<27°C), free fatty acidity <=0.8%",
    "subtitleDe": "Höchste Güteklasse, rein mechanische Kaltextraktion (<27°C), freie Fettsäuren <=0,8%",
    "imageUrl": "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=800&auto=format&fit=crop&q=80",
    "origin": "Mediterranean Basin (Spain, Greece, Italy)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Fresh cut grass, green tomato leaf, artichoke, pleasant peppery throat tickle (oleocanthal).",
    "tasteDe": "Frisches Gras, grüne Tomate, Artischocke, zartbitter mit markantem pfeffrigem Kratzen im Hals.",
    "scienceEn": "By strict EU Regulation (2022/2104), 'Extra Virgin' requires: 1) Free acidity (free oleic acid) of 0.8g per 100g or lower (top artisan EVOOs achieve <0.2%); 2) Strict physical extraction below 27°C (cold extraction), without solvents or chemical refining; 3) Certified sensory test confirming zero sensory defects and positive attributes: fruitiness, bitterness, and pungency. The peppery tickle in the throat is caused by Oleocanthal, a natural phenolic antioxidant possessing anti-inflammatory properties identical to ibuprofen.",
    "scienceDe": "Die europäische Güteklasse 'Nativ Extra' (Extra Virgin) verlangt strengste Grenzwerte: 1) Freie Fettsäuren (Ölsäure) dürfen maximal 0,8 g pro 100 g betragen (Spitzenöle liegen unter 0,2 g); 2) Rein mechanische Kaltextraktion unter 27°C – keinerlei Erhitzung oder chemische Lösungsmittel; 3) Sensorische Fehlerfreiheit: Es muss fruchtig riechen und schmecken. Das charakteristische Kratzen/Brennen im Hals bei Spitzenölen ist kein Mangel, sondern der Beweis für den Wirkstoff Oleocanthal – ein kraftvolles natürliches Antioxidans.",
    "culinaryEn": "Finishing oil drizzled raw over burrata, carpaccio, pasta, grilled fish, and sourdough bread.",
    "culinaryDe": "Ausschließlich roh als Vollendung über heiße Pasta, Bistecca Fiorentina, Burrata, Salate oder edles Sauerteigbrot träufeln. Nie über 180°C stark erhitzen!",
    "faqEn": "Why does premium olive oil burn slightly in the back of the throat? That burning sensation is Oleocanthal, a prized polyphenol antioxidant; tasting panels rate EVOO quality by 'one-cough' or 'two-cough' pungency!",
    "faqDe": "Warum kratzt hochwertiges Olivenöl im Hals? Das Kratzen stammt von Oleocanthal, einem hochwirksamen natürlichen Entzündungshemmer. Je mehr Polyphenole, desto gesünder und kratziger das frische Öl!",
    "allergens": [
      "None"
    ],
    "tags": [
      "EVOO",
      "OliveOil",
      "Oleocanthal",
      "ColdPressed",
      "HealthyFats"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "oil_terroirs_koroneiki_picual_arbequina",
    "category": "oils_vinegars",
    "nameEn": "Olive Oil Terroirs (Koroneiki vs. Picual vs. Arbequina)",
    "nameDe": "Olivenöl-Terroirs (Koroneiki vs. Picual vs. Arbequina)",
    "subtitleEn": "Greek peppery herbs vs. Spanish robust polyphenols vs. Catalonian sweet butter",
    "subtitleDe": "Griechisches Kräuterfeuer vs. andalusische Polyphenol-Kraft vs. katalanische Buttermilde",
    "imageUrl": "",
    "origin": "Greece (Koroneiki) | Spain (Jaén / Picual & Catalonia / Arbequina)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Koroneiki: Herbaceous, wild thyme, intense peppery kick. Picual: Green tomato, fig leaf, bold bitterness. Arbequina: Sweet apple, banana, buttery almond.",
    "tasteDe": "Koroneiki: Wildkräuter, feuriger Pfefferabgang. Picual: Grüne Tomate, Feigenblatt, markant bitter. Arbequina: Süßer Apfel, Mandel, butterweich.",
    "scienceEn": "Olive varieties express dramatically different fatty acid and polyphenol profiles: 1) Koroneiki (Greece): Tiny drought-hardy fruit with over 75% oleic acid and herbaceous aromas of wild thyme and green pepper. 2) Picual (Spain / Jaén): World's most planted variety; massive polyphenol content (up to 800+ mg/kg) gives intense stability and natural bitterness, making it the most heat-resistant olive oil. 3) Arbequina (Spain): Low in bitter polyphenols, creamy, ripe with aromas of green almond and apple—ideal for desserts or guests sensitive to bitterness.",
    "scienceDe": "Sortenreine Olivenöle besitzen faszinierende Charakterunterschiede: 1) Koroneiki (Griechenland / Kalamata): Winzige Frucht, schmeckt grasig nach Wildkräutern mit feurigem Abgang. 2) Picual (Spanien / Andalusien): Der König der Polyphenole; kräftig-herb, schmeckt nach Tomatenstrunk und ist durch den Schutzstoffgehalt extrem lange haltbar. 3) Arbequina (Spanien): Sehr mild, fruchtig, schmeckt nach grünem Apfel und Haselnuss – perfekt für Gäste, die bittere Öle ablehnen, oder für Mayonnaisen und Desserts.",
    "culinaryEn": "Koroneiki for grilled octopus and Greek salads; Picual for rich lamb roasts and tomato gazpacho; Arbequina for dressings and olive oil ice cream.",
    "culinaryDe": "Koroneiki zu gegrilltem Fisch und Bauernsalat; Picual zu Rindfleisch, Lamm und Gazpacho; Arbequina für feine Vinaigrettes, Fisch-Carpaccio und Schokoladendesserts.",
    "faqEn": "Which olive oil is best for guests who dislike bitterness? Recommend Arbequina olive oil: it is naturally sweet, delicate, buttery, and devoid of astringent sharpness.",
    "faqDe": "Welches Öl empfiehlt man Gästen, die keine Bitterkeit mögen? Ein sortenreines Arbequina-Öl: Es ist wunderbar mild, fruchtig und butterweich ohne Bitterstoffe.",
    "allergens": [
      "None"
    ],
    "tags": [
      "Koroneiki",
      "Picual",
      "Arbequina",
      "Terroir",
      "OliveVarieties"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "oil_gesunde_oele_rauchpunkte",
    "category": "oils_vinegars",
    "nameEn": "Culinary Cooking Oils: Smoke Points & Omega Fatty Acids",
    "nameDe": "Speiseöle im Vergleich: Rauchpunkte, Hitze & Fettsäuren",
    "subtitleEn": "High heat frying oils vs. delicate cold-pressed finishing oils (Omega-3 balance)",
    "subtitleDe": "Welches Öl für die heiße Pfanne, welches für Salate? Rauchpunkte & Fettsäuren-Wissenschaft",
    "imageUrl": "",
    "origin": "Global / Central Europe",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Refined: Neutral, clean, odorless. Cold-Pressed Rapeseed: Nutty, golden. Pumpkin Seed: Dark green, intense roasted pumpkin.",
    "tasteDe": "Raffiniert: Geschmacksneutral, rein. Kaltgepresstes Rapsöl: Nussig, saatig. Steirisches Kürbiskernöl: Tiefgrün, intensiv röstig.",
    "scienceEn": "The critical kitchen chemistry of cooking oils: 1) Smoke Point: The temperature at which volatile free fatty acids break down into toxic blue smoke and carcinogenic acrolein. Unrefined virgin oils (flaxseed 107°C, extra virgin olive oil 190°C, cold-pressed rapeseed 110°C) must never be used for searing steaks or deep-frying! 2) Refined oils (refined high-oleic sunflower, refined canola, peanut oil) have free acids stripped out, raising smoke points above 225-240°C. 3) Omega-3 vs Omega-6: Cold-pressed rapeseed oil has an optimal 1:2 ratio of Omega-3 to Omega-6; standard sunflower oil is high in inflammatory Omega-6.",
    "scienceDe": "Das unverzichtbare Küchenwissen über Speiseöle: 1) Der Rauchpunkt: Die Temperatur, bei der Fettsäuren zerfallen und giftiges Acrolein verdampft. Kaltgepresste Öle (Leinöl 107°C, kaltgepresstes Rapsöl 120°C, Walnussöl 160°C) dürfen NIEMALS zum heißen Anbraten genutzt werden! 2) Raffinierte Öle (raffiniertes Rapsöl, Erdnussöl, High-Oleic-Sonnenblumenöl) sind von Trübstoffen befreit, rauchen erst ab 220-240°C und sind ideal für Pfanne und Fritteuse. 3) Kaltgepresstes Steirisches Kürbiskernöl g.g.A. ist ein reines Kaltöl – bei Hitze verbrennen die edlen Aromen sofort!",
    "culinaryEn": "Refined high-oleic oil for schnitzel and high-heat searing. Cold-pressed pumpkin seed oil drizzled over vanilla ice cream and pumpkin soup.",
    "culinaryDe": "Raffiniertes Rapsöl/High-Oleic-Öl zum scharfen Braten von Steaks und Wiener Schnitzel. Steirisches Kürbiskernöl ausschließlich kalt über Kürbissuppe oder Vanilleeis.",
    "faqEn": "Can you fry with extra virgin olive oil? High-quality low-acidity EVOO can handle gentle pan frying up to 180°C, but deep frying destroys its expensive polyphenols.",
    "faqDe": "Darf man mit nativem Olivenöl braten? Zum sanften Dünsten bis 170-180°C ja, aber scharfes Anbraten oder Frittieren zerstört die wertvollen Aromen und ist reine Geldverschwendung.",
    "allergens": [
      "Tree nuts (Walnut oil only"
    ],
    "tags": [
      "CookingOil",
      "SmokePoint",
      "Rapeseed",
      "PumpkinSeed",
      "Omega3"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "vinegar_balsamico_tradizionale_dop",
    "category": "oils_vinegars",
    "nameEn": "Aceto Balsamico Tradizionale di Modena DOP",
    "nameDe": "Aceto Balsamico Tradizionale di Modena DOP",
    "subtitleEn": "12 to 25+ years aged in battery casks of progressive woods, cooked grape must only",
    "subtitleDe": "Mindestens 12 bis über 25 Jahre im Holzfass-Batterie gereifter eingekochter Traubenmost",
    "imageUrl": "",
    "origin": "Italy (Modena & Reggio Emilia - DOP)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Syrupy dense velvet, harmonic sweet-sour equilibrium, dried fig, dark plum, toasted oak vanilla.",
    "tasteDe": "Sirupartig dickflüssig, perfektes Gleichgewicht aus Edelsüße und Weinsäure, getrocknete Feigen, Holznoten.",
    "scienceEn": "One of the crowning glories of world gastronomy: 'Tradizionale DOP' is strictly NOT made from finished wine. Late-harvested Trebbiano and Lambrusco grape must is simmered gently over direct fire for 24-36 hours, concentrating sugars and acids. It enters a 'batteria' of 5 to 7 barrels of decreasing size made of different woods: oak (vanilla), chestnut (tannins), cherry (sweetness), ash (porosity), and juniper/mulberry (aroma). Through annual 'rincalzo' (transferring and topping up), water evaporates through the wood over 12 years (Affinato - red cap) or 25+ years (Extravecchio - gold cap). It is thick without any starch or sugar additives.",
    "scienceDe": "Die Königsdisziplin des Essigs: Tradizionale DOP wird NICHT aus Wein gemacht! Frischer Traubenmost wird über offenem Feuer bis zu 36 Stunden eingekocht. Anschließend wandert er in eine 'Batteria' aus 5 bis 7 Holzfässern abnehmender Größe aus verschiedenen Hölzern: Eiche, Kastanie, Kirsche, Esche und Maulbeere. Über 12 Jahre ('Affinato') oder über 25 Jahre ('Extravecchio') verdunstet das Wasser durch das Holz. Das Ergebnis ist eine sirupartige, dunkle Essenz von unvergleichlicher aromatischer Dichte.",
    "culinaryEn": "Served in drops from a glass pipette over 36-month Parmigiano Reggiano, vanilla gelato, strawberries, or grilled beef tenderloin.",
    "culinaryDe": "Tropfenweise aus der Pipette serviert zu 36 Monate gereiftem Parmigiano Reggiano, frischen Erdbeeren, cremigem Vanilleeis oder rosa gebratenem Rinderfilet.",
    "faqEn": "Why does a 100ml bottle cost over 100 euros? It takes over 100 kg of grapes and 25 years of barrel evaporation to yield one small bottle of Extravecchio!",
    "faqDe": "Warum kostet ein Fläschchen 100 Euro? Weil man über 100 kg Trauben und 25 Jahre geduldige Holzfassreifung braucht, um 100 ml Extravecchio zu gewinnen!",
    "allergens": [
      "Natural Sulphites"
    ],
    "tags": [
      "Balsamico",
      "Tradizionale",
      "DOP",
      "Modena",
      "LuxuryVinegar"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "vinegar_balsamico_igp_condimento_bianco",
    "category": "oils_vinegars",
    "nameEn": "Commercial Balsamico IGP vs. White Balsamic (Condimento Bianco)",
    "nameDe": "Aceto Balsamico di Modena IGP & Weißer Balsamico",
    "subtitleEn": "Grape must blended with wine vinegar vs. concentrated pale white grape must",
    "subtitleDe": "Gastro-Balsamico mit Weinessig-Zusatz vs. heller Traubenmost-Essig (Condimento Bianco)",
    "imageUrl": "",
    "origin": "Italy (Modena / Emilia-Romagna - IGP)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Balsamico IGP: Fruity sweet-sour, lively acidity, caramel depth. Condimento Bianco: Bright golden, crisp floral sweetness, clean acidity.",
    "tasteDe": "Balsamico IGP: Fruchtig-säuerlich, dunkle Süße, Weinsäure. Condimento Bianco: Helles Goldgelb, spritzig-süß, sauber fruchtig.",
    "scienceEn": "1. Aceto Balsamico di Modena IGP: The ubiquitous restaurant standard. Unlike the rare 'Tradizionale', IGP is a blend of cooked/concentrated grape must and finished quality wine vinegar (aged min 60 days in wood, min 3 years for 'Invecchiato'). Up to 2% caramel coloring (E150d) is legally permitted for dark gloss.\\n2. Condimento Bianco (White Balsamic): Made from white Trebbiano grape must evaporated under vacuum at low temperatures so natural sugars do NOT caramelize brown. Blended with premium white wine vinegar, it delivers balsamic sweet-sour fruitiness without staining light salads or fish dishes dark brown.",
    "scienceDe": "1. Aceto Balsamico di Modena IGP: Der weltweite Gastronomie-Allrounder. Eine geschützte Mischung aus konzentriertem Traubenmost und echtem Weinessig, mindestens 60 Tage im Holzfass gereift (ab 3 Jahren 'Invecchiato'). Karamelldezusatz (E150d) ist gesetzlich erlaubt, um die dunkle Glanzfarbe zu sichern.\\n2. Condimento Bianco (Weißer Balsamico): Weißer Traubenmost wird im Vakuum bei niedriger Temperatur schonend eingedampft, damit der Traubenzucker NICHT karamellisiert. Mit Weißweinessig vermählt, liefert er die balsamische Süße-Säure-Balance, ohne Salate, Geflügel oder hellen Fisch grau-braun zu färben!",
    "culinaryEn": "Balsamico IGP for tomato salads, marinades, and pan reductions. Condimento Bianco for crisp green salads, fennel carpaccio, and seafood tartare.",
    "culinaryDe": "Balsamico IGP für Tomatensalate, Bratensaucen und Vinaigrettes. Condimento Bianco zwingend für helle Blattsalate, Fenchel-Carpaccio und Jakobsmuscheln.",
    "faqEn": "Why use white balsamic instead of regular balsamic in fine dining? Color esthetics: regular dark balsamic turns light lettuce, white fish, and goat cheese an unappetizing muddy brown.",
    "faqDe": "Warum nutzt die Küche weißen Balsamico? Aus optischen Gründen: Dunkler Balsamico färbt helle Blattsalate, Ziegenkäse und Meeresfrüchte unansehnlich schmutzig-braun.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "Balsamico",
      "IGP",
      "CondimentoBianco",
      "SaladDressing",
      "Modena"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "vinegar_weinessig_vs_branntweinessig",
    "category": "oils_vinegars",
    "nameEn": "Wine Vinegar vs. Spirit / Distilled White Vinegar",
    "nameDe": "Weißwein- & Rotweinessig vs. Branntweinessig (Tafelessig)",
    "subtitleEn": "Authentic grape wine fermentation vs. industrial diluted ethanol from plant waste",
    "subtitleDe": "Echte biologische Traubenwein-Vergärung vs. Industrie-Essig aus verdünntem Agraralkohol",
    "imageUrl": "",
    "origin": "Europe (Wine Vinegar) | Global Industrial (Spirit Vinegar)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Wine Vinegar: Noble fruit bouquet, wine acidity, round body. Spirit Vinegar: Harte, piercing, chemical, monochromatic sharp acidity.",
    "tasteDe": "Weinessig: Edles Weinbouquet, zarte Fruchtsäure, weich. Branntweinessig: Stechend scharf, aggressiv sauer, null Eigengeschmack.",
    "scienceEn": "How vinegar is created biochemically: Acetic acid bacteria (Acetobacter aceti) oxidize ethanol in the presence of oxygen into acetic acid (CH3COOH). 1) Wine Vinegar (Red & White): Made by fermenting finished grape wine; it preserves natural tartaric acid, esters, and secondary grape aromas, maturing into a rounded, culinary acidifier. 2) Spirit Vinegar (Branntweinessig / Distilled white vinegar): Synthetically fermented in submerged aeration tanks from cheap 96% industrial neutral ethanol (made from agricultural molasses, potatoes, or cellulose plant waste). It has zero aroma, pure 5-10% harsh acetic acid, and is mainly used as an industrial preservative or household cleaner.",
    "scienceDe": "Die biochemische Essigentstehung: Essigsäurebakterien (Acetobacter) veratmen Alkohol mit Luftsauerstoff zu Essigsäure. 1) Echter Wein-Essig (Weißwein- & Rotweinessig): Entsteht aus echtem Traubenwein! Er enthält wertvolle Weinsäure, Glycerin und flüchtige Ester des Weins und schmeckt harmonisch und vielschichtig.\\n2) Branntweinessig (Tafelessig): Entsteht im Turbo-Industrieverfahren aus billigem 96%-igem Industriealkohol (aus Zuckerrübenmelasse, Mais oder Holzresten). Er besitzt keinerlei Weinaroma, schmeckt extrem aggressiv und stechend und gehört nur zum Entkalken oder für billigen Senf, niemals in die feine Küche!",
    "culinaryEn": "Red wine vinegar for Beef Bourguignon, vinaigrettes for frisée salad. White wine vinegar for Sauce Béarnaise, Hollandaise, and beurre blanc.",
    "culinaryDe": "Rotweinessig für Schmorbraten, Gulasch und dunkle Vinaigrettes. Weißweinessig für klassische Sauce Béarnaise, Sauce Hollandaise, Beurre Blanc und pochiertes Ei.",
    "faqEn": "Can spirit vinegar be used for fine dining salad dressings? Never in professional kitchens: its aggressive, harsh acetic acid overpowers delicate vegetables and herbs.",
    "faqDe": "Gehört Branntweinessig in die Salatsauce? In der Gastronomie ein absolutes No-Go: Die stechende Säure betäubt die Geschmacksnerven und zerstört das feine Aroma frischer Kräuter.",
    "allergens": [
      "Contains Sulphites (Wine vinegar only"
    ],
    "tags": [
      "WineVinegar",
      "Weinessig",
      "Branntweinessig",
      "AcidScience",
      "CulinaryBasics"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  },
  {
    "id": "vinegar_sherry_vinagre_de_jerez",
    "category": "oils_vinegars",
    "nameEn": "Sherry Vinegar PDO (Vinagre de Jerez)",
    "nameDe": "Sherry-Essig g.U. (Vinagre de Jerez)",
    "subtitleEn": "Aged in American oak casks using the historic Solera system in Andalusia",
    "subtitleDe": "Gereift im andalusischen Solera-Verfahren in alten Eichenfässern – D.O.P.-Status",
    "imageUrl": "",
    "origin": "Spain (Jerez-Xérès-Sherry / Andalusia - PDO)",
    "isImport": false,
    "abv": "0.0% ABV",
    "tasteEn": "Rich mahogany color, toasted hazelnut, dried raisins, vanilla oak, intense concentrated mellow acidity.",
    "tasteDe": "Dunkles Mahagoni, geröstete Haselnuss, Rosinen, altes Eichenholz, konzentrierte milde Säure.",
    "scienceEn": "Originating strictly within the 'Sherry Triangle' of Andalusia, Spain, Vinagre de Jerez is produced from genuine Sherry wines (primarily the Palomino grape). It matures for years in stacked rows of American oak barrels called a Solera and Criaderas system. Micro-oxidation through the oak wood and continuous fractional blending yields intense volatile acidity, enriched with aromas of roasted nuts, dried fruits, and wood lactones. Classifications: Vinagre de Jerez (min 6 months), Reserva (min 2 years), Gran Reserva (min 10 years).",
    "scienceDe": "Aus dem andalusischen Sherry-Dreieck stammend, reift Vinagre de Jerez g.U. über Jahre im berühmten Solera-System in Fässern aus amerikanischer Weißeiche. Durch die langsame Sauerstoffzufuhr im Fass verdunstet Wasser, und der Essig nimmt nussige Aromen von gerösteten Haselnüssen, Rosinen und Eichenholz an. Gesetzliche Reifestufen: Vinagre de Jerez (mind. 6 Monate), Reserva (mind. 2 Jahre im Fass), Gran Reserva (mind. 10 Jahre im Eichenfass).",
    "culinaryEn": "The secret weapon of Andalusian Gazpacho, warm goat cheese salads, lentil stews, and pan deglazing for duck breast.",
    "culinaryDe": "Das unverzichtbare Geheimnis für echtes andalusisches Gazpacho, lauwarme Linsensalate, Ziegenkäse und zum Ablöschen von Entenbrustsaucen.",
    "faqEn": "Why does Sherry vinegar taste so much deeper than red wine vinegar? Years of barrel maturation in oak soleras evaporate water and infuse concentrated wood vanillin and hazelnut notes.",
    "faqDe": "Was macht Sherry-Essig so einzigartig? Die jahrelange Fassreife im Solera-System: Das Holz bindet Schärfe ab und schenkt komplexe Röst- und Nussaromen.",
    "allergens": [
      "Contains Sulphites"
    ],
    "tags": [
      "SherryVinegar",
      "VinagreDeJerez",
      "Solera",
      "Spain",
      "GourmetVinegar"
    ],
    "inStock": true,
    "stockQuantity": 5,
    "storageLocation": "Zentrallager",
    "isFavorite": false
  }
];

const MASTER_QUIZ = [
  {
    "id": "q_spirits_01",
    "category": "spirits",
    "questionEn": "What is the legal minimum corn percentage for Bourbon Whiskey?",
    "questionDe": "Wie hoch ist der gesetzliche Mindestanteil an Mais für Bourbon Whiskey?",
    "optionsEn": [
      "51%",
      "75%",
      "100%",
      "33%"
    ],
    "optionsDe": [
      "51%",
      "75%",
      "100%",
      "33%"
    ],
    "correctIndex": 0,
    "explanationEn": "US law mandates at least 51% corn in the mash bill for Bourbon.",
    "explanationDe": "Nach US-Bundesrecht muss Bourbon zu mindestens 51% aus Mais gebrannt werden.",
    "qEn": "What is the legal minimum corn percentage for Bourbon Whiskey?",
    "qDe": "Wie hoch ist der gesetzliche Mindestanteil an Mais für Bourbon Whiskey?",
    "optEn": [
      "51%",
      "75%",
      "100%",
      "33%"
    ],
    "optDe": [
      "51%",
      "75%",
      "100%",
      "33%"
    ],
    "correct": 0,
    "expEn": "US law mandates at least 51% corn in the mash bill for Bourbon.",
    "expDe": "Nach US-Bundesrecht muss Bourbon zu mindestens 51% aus Mais gebrannt werden."
  },
  {
    "id": "q_spirits_02",
    "category": "spirits",
    "questionEn": "What causes the milky Louche effect in Ouzo or Rakı?",
    "questionDe": "Was verursacht den milchigen Louche-Effekt in Ouzo oder Rakı?",
    "optionsEn": [
      "Anethole oil from anise precipitates as microscopic droplets when water is added",
      "Added milk powder",
      "Ice crystallization",
      "Sugar precipitation"
    ],
    "optionsDe": [
      "Anisöl (Anethol) fällt bei Wasserzugabe als mikroskopische Tröpfchen aus",
      "Zusatz von Milchpulver",
      "Eiskristallbildung",
      "Zuckerausfällung"
    ],
    "correctIndex": 0,
    "explanationEn": "Anethole is soluble only in high alcohol; diluting forces spontaneous micro-emulsification.",
    "explanationDe": "Anethol ist nur in hochprozentigem Alkohol löslich und emulgiert bei Wasserzugabe.",
    "qEn": "What causes the milky Louche effect in Ouzo or Rakı?",
    "qDe": "Was verursacht den milchigen Louche-Effekt in Ouzo oder Rakı?",
    "optEn": [
      "Anethole oil from anise precipitates as microscopic droplets when water is added",
      "Added milk powder",
      "Ice crystallization",
      "Sugar precipitation"
    ],
    "optDe": [
      "Anisöl (Anethol) fällt bei Wasserzugabe als mikroskopische Tröpfchen aus",
      "Zusatz von Milchpulver",
      "Eiskristallbildung",
      "Zuckerausfällung"
    ],
    "correct": 0,
    "expEn": "Anethole is soluble only in high alcohol; diluting forces spontaneous micro-emulsification.",
    "expDe": "Anethol ist nur in hochprozentigem Alkohol löslich und emulgiert bei Wasserzugabe."
  },
  {
    "id": "q_spirits_03",
    "category": "spirits",
    "questionEn": "What is Rhum Agricole distilled from?",
    "questionDe": "Woraus wird Rhum Agricole (AOC Martinique) destilliert?",
    "optionsEn": [
      "Fresh pressed sugarcane juice",
      "Sugarcane molasses",
      "Beet syrup",
      "Barley mash"
    ],
    "optionsDe": [
      "Frischem Zuckerrohrsaft",
      "Zuckerrohrmelasse",
      "Rübensirup",
      "Gerstenmaische"
    ],
    "correctIndex": 0,
    "explanationEn": "Rhum Agricole uses 100% pure fresh sugarcane juice, giving herbal terroir notes.",
    "explanationDe": "Rhum Agricole wird direkt aus frischem Zuckerrohrsaft gebrannt.",
    "qEn": "What is Rhum Agricole distilled from?",
    "qDe": "Woraus wird Rhum Agricole (AOC Martinique) destilliert?",
    "optEn": [
      "Fresh pressed sugarcane juice",
      "Sugarcane molasses",
      "Beet syrup",
      "Barley mash"
    ],
    "optDe": [
      "Frischem Zuckerrohrsaft",
      "Zuckerrohrmelasse",
      "Rübensirup",
      "Gerstenmaische"
    ],
    "correct": 0,
    "expEn": "Rhum Agricole uses 100% pure fresh sugarcane juice, giving herbal terroir notes.",
    "expDe": "Rhum Agricole wird direkt aus frischem Zuckerrohrsaft gebrannt."
  },
  {
    "id": "q_spirits_04",
    "category": "spirits",
    "questionEn": "Which agave species is legally required for 100% Tequila?",
    "questionDe": "Welche Agavenart ist für 100% Tequila vorgeschrieben?",
    "optionsEn": [
      "Blue Agave (Agave tequilana Weber)",
      "Agave Espadín",
      "Agave Tobalá",
      "Agave Americana"
    ],
    "optionsDe": [
      "Blaue Agave (Agave tequilana Weber)",
      "Agave Espadín",
      "Agave Tobalá",
      "Agave Americana"
    ],
    "correctIndex": 0,
    "explanationEn": "Only Blue Agave Weber is permitted under the Tequila DOT denomination.",
    "explanationDe": "Für Tequila ist ausschließlich die Blaue Agave Weber zugelassen.",
    "qEn": "Which agave species is legally required for 100% Tequila?",
    "qDe": "Welche Agavenart ist für 100% Tequila vorgeschrieben?",
    "optEn": [
      "Blue Agave (Agave tequilana Weber)",
      "Agave Espadín",
      "Agave Tobalá",
      "Agave Americana"
    ],
    "optDe": [
      "Blaue Agave (Agave tequilana Weber)",
      "Agave Espadín",
      "Agave Tobalá",
      "Agave Americana"
    ],
    "correct": 0,
    "expEn": "Only Blue Agave Weber is permitted under the Tequila DOT denomination.",
    "expDe": "Für Tequila ist ausschließlich die Blaue Agave Weber zugelassen."
  },
  {
    "id": "q_spirits_05",
    "category": "spirits",
    "questionEn": "What defines Single Malt Scotch Whisky?",
    "questionDe": "Was bedeutet Single Malt Scotch Whisky gesetzlich?",
    "optionsEn": [
      "100% malted barley from a single distillery, pot still distilled, aged 3+ years in Scotland",
      "Single grain from one harvest",
      "Unblended single cask only",
      "Distilled from rye and corn"
    ],
    "optionsDe": [
      "100% gemälzte Gerste aus einer einzigen Destillerie, Kupferblase, mind. 3 Jahre Reife",
      "Aus einer einzigen Getreideernte",
      "Aus einem unverschnittenen Einzelfass",
      "Aus Roggen und Mais"
    ],
    "correctIndex": 0,
    "explanationEn": "'Single' means one distillery; 'Malt' means 100% malted barley.",
    "explanationDe": "'Single' bezeichnet eine einzige Brennerei und 'Malt' gemälzte Gerste.",
    "qEn": "What defines Single Malt Scotch Whisky?",
    "qDe": "Was bedeutet Single Malt Scotch Whisky gesetzlich?",
    "optEn": [
      "100% malted barley from a single distillery, pot still distilled, aged 3+ years in Scotland",
      "Single grain from one harvest",
      "Unblended single cask only",
      "Distilled from rye and corn"
    ],
    "optDe": [
      "100% gemälzte Gerste aus einer einzigen Destillerie, Kupferblase, mind. 3 Jahre Reife",
      "Aus einer einzigen Getreideernte",
      "Aus einem unverschnittenen Einzelfass",
      "Aus Roggen und Mais"
    ],
    "correct": 0,
    "expEn": "'Single' means one distillery; 'Malt' means 100% malted barley.",
    "expDe": "'Single' bezeichnet eine einzige Brennerei und 'Malt' gemälzte Gerste."
  },
  {
    "id": "q_spirits_06",
    "category": "spirits",
    "questionEn": "What is the maximum sugar addition permitted in London Dry Gin after distillation?",
    "questionDe": "Wie viel Zucker darf London Dry Gin nach der Destillation maximal zugesetzt werden?",
    "optionsEn": [
      "0.1 g/L",
      "10 g/L",
      "50 g/L",
      "Unlimited"
    ],
    "optionsDe": [
      "0,1 g/L",
      "10 g/L",
      "50 g/L",
      "Unbegrenzt"
    ],
    "correctIndex": 0,
    "explanationEn": "London Dry permits virtually zero sugar (max 0.1g/L) and no artificial flavors post-distillation.",
    "explanationDe": "London Dry erlaubt maximal 0,1 g/L Zucker und keinerlei nachträgliche Aromazusätze.",
    "qEn": "What is the maximum sugar addition permitted in London Dry Gin after distillation?",
    "qDe": "Wie viel Zucker darf London Dry Gin nach der Destillation maximal zugesetzt werden?",
    "optEn": [
      "0.1 g/L",
      "10 g/L",
      "50 g/L",
      "Unlimited"
    ],
    "optDe": [
      "0,1 g/L",
      "10 g/L",
      "50 g/L",
      "Unbegrenzt"
    ],
    "correct": 0,
    "expEn": "London Dry permits virtually zero sugar (max 0.1g/L) and no artificial flavors post-distillation.",
    "expDe": "London Dry erlaubt maximal 0,1 g/L Zucker und keinerlei nachträgliche Aromazusätze."
  },
  {
    "id": "q_spirits_07",
    "category": "spirits",
    "questionEn": "Which region is the Premier Cru of Cognac?",
    "questionDe": "Welche Lage ist das Premier Cru von Cognac?",
    "optionsEn": [
      "Grande Champagne",
      "Petite Champagne",
      "Borderies",
      "Fins Bois"
    ],
    "optionsDe": [
      "Grande Champagne",
      "Petite Champagne",
      "Borderies",
      "Fins Bois"
    ],
    "correctIndex": 0,
    "explanationEn": "Grande Champagne has the chalkiest soil, yielding refined, long-aging spirits.",
    "explanationDe": "Grande Champagne besitzt die kalkreichsten Böden für langlebigen Cognac.",
    "qEn": "Which region is the Premier Cru of Cognac?",
    "qDe": "Welche Lage ist das Premier Cru von Cognac?",
    "optEn": [
      "Grande Champagne",
      "Petite Champagne",
      "Borderies",
      "Fins Bois"
    ],
    "optDe": [
      "Grande Champagne",
      "Petite Champagne",
      "Borderies",
      "Fins Bois"
    ],
    "correct": 0,
    "expEn": "Grande Champagne has the chalkiest soil, yielding refined, long-aging spirits.",
    "expDe": "Grande Champagne besitzt die kalkreichsten Böden für langlebigen Cognac."
  },
  {
    "id": "q_spirits_08",
    "category": "spirits",
    "questionEn": "What is Italian Grappa distilled from?",
    "questionDe": "Woraus wird italienische Grappa destilliert?",
    "optionsEn": [
      "Grape pomace (skins, seeds, stems after pressing)",
      "Whole fermented wine",
      "Dried raisins",
      "Cider"
    ],
    "optionsDe": [
      "Traubentrester (Schalen, Kerne, Stiele nach dem Keltern)",
      "Vollwein",
      "Rosinen",
      "Apfelmost"
    ],
    "correctIndex": 0,
    "explanationEn": "Grappa is a pomace spirit distilled from solid residues of wine pressing.",
    "explanationDe": "Grappa wird ausschließlich aus den festen Rückständen der Traubenpressung gebrannt.",
    "qEn": "What is Italian Grappa distilled from?",
    "qDe": "Woraus wird italienische Grappa destilliert?",
    "optEn": [
      "Grape pomace (skins, seeds, stems after pressing)",
      "Whole fermented wine",
      "Dried raisins",
      "Cider"
    ],
    "optDe": [
      "Traubentrester (Schalen, Kerne, Stiele nach dem Keltern)",
      "Vollwein",
      "Rosinen",
      "Apfelmost"
    ],
    "correct": 0,
    "expEn": "Grappa is a pomace spirit distilled from solid residues of wine pressing.",
    "expDe": "Grappa wird ausschließlich aus den festen Rückständen der Traubenpressung gebrannt."
  },
  {
    "id": "q_spirits_09",
    "category": "spirits",
    "questionEn": "How does Islay Scotch acquire its intense peaty smoky aroma?",
    "questionDe": "Wodurch entsteht das rauchig-torfige Aroma in Islay Scotch Whiskys?",
    "optionsEn": [
      "Drying damp malted barley over peat fires in kilns",
      "Adding liquid smoke",
      "Aging in charred pine barrels",
      "Charcoal filtration"
    ],
    "optionsDe": [
      "Darren des feuchten Grünmalzes über schwelendem Torffeuer (Peat Kiln)",
      "Zugabe von Raucharoma",
      "Reifung in Kiefernholzfässern",
      "Kohlefiltration"
    ],
    "correctIndex": 0,
    "explanationEn": "Peat smoke phenols bind to moist malt during kiln drying.",
    "explanationDe": "Phenole aus dem Torfrauch binden sich während des Trocknens an die feuchte Gerste.",
    "qEn": "How does Islay Scotch acquire its intense peaty smoky aroma?",
    "qDe": "Wodurch entsteht das rauchig-torfige Aroma in Islay Scotch Whiskys?",
    "optEn": [
      "Drying damp malted barley over peat fires in kilns",
      "Adding liquid smoke",
      "Aging in charred pine barrels",
      "Charcoal filtration"
    ],
    "optDe": [
      "Darren des feuchten Grünmalzes über schwelendem Torffeuer (Peat Kiln)",
      "Zugabe von Raucharoma",
      "Reifung in Kiefernholzfässern",
      "Kohlefiltration"
    ],
    "correct": 0,
    "expEn": "Peat smoke phenols bind to moist malt during kiln drying.",
    "expDe": "Phenole aus dem Torfrauch binden sich während des Trocknens an die feuchte Gerste."
  },
  {
    "id": "q_spirits_10",
    "category": "spirits",
    "questionEn": "What is the primary fruit base of French Calvados AOC from Normandy?",
    "questionDe": "Was ist die primäre Fruchtbasis von französischem Calvados AOC?",
    "optionsEn": [
      "Cider apples and perry pears",
      "Plums",
      "Cherries",
      "Grapes"
    ],
    "optionsDe": [
      "Cidre-Äpfel und Mostbirnen",
      "Pflaumen",
      "Sauerkirschen",
      "Weintrauben"
    ],
    "correctIndex": 0,
    "explanationEn": "Calvados is an apple brandy distilled from fermented cider and perry.",
    "explanationDe": "Calvados wird aus vergorenem Apfelcidre und Mostbirnen destilliert.",
    "qEn": "What is the primary fruit base of French Calvados AOC from Normandy?",
    "qDe": "Was ist die primäre Fruchtbasis von französischem Calvados AOC?",
    "optEn": [
      "Cider apples and perry pears",
      "Plums",
      "Cherries",
      "Grapes"
    ],
    "optDe": [
      "Cidre-Äpfel und Mostbirnen",
      "Pflaumen",
      "Sauerkirschen",
      "Weintrauben"
    ],
    "correct": 0,
    "expEn": "Calvados is an apple brandy distilled from fermented cider and perry.",
    "expDe": "Calvados wird aus vergorenem Apfelcidre und Mostbirnen destilliert."
  },
  {
    "id": "q_spirits_11",
    "category": "spirits",
    "questionEn": "Why is premium vodka traditionally filtered through activated birch charcoal?",
    "questionDe": "Warum wird Wodka mehrfach über Birken-Aktivkohle filtriert?",
    "optionsEn": [
      "To adsorb trace fusel oils and aldehydes for neutral purity",
      "To turn red raw spirit clear",
      "To infuse birch sweetness",
      "To reduce alcohol proof"
    ],
    "optionsDe": [
      "Um Fuselöle und Aldehyde zu binden und maximale Reinheit zu erzielen",
      "Um roten Rohbrand zu entfärben",
      "Um Birkensüße einzutragen",
      "Um Alkohol abzubauen"
    ],
    "correctIndex": 0,
    "explanationEn": "Activated charcoal binds long-chain impurities without stripping character.",
    "explanationDe": "Aktivkohle adsorbiert Verunreinigungen und Begleitöle für samtige Milde.",
    "qEn": "Why is premium vodka traditionally filtered through activated birch charcoal?",
    "qDe": "Warum wird Wodka mehrfach über Birken-Aktivkohle filtriert?",
    "optEn": [
      "To adsorb trace fusel oils and aldehydes for neutral purity",
      "To turn red raw spirit clear",
      "To infuse birch sweetness",
      "To reduce alcohol proof"
    ],
    "optDe": [
      "Um Fuselöle und Aldehyde zu binden und maximale Reinheit zu erzielen",
      "Um roten Rohbrand zu entfärben",
      "Um Birkensüße einzutragen",
      "Um Alkohol abzubauen"
    ],
    "correct": 0,
    "expEn": "Activated charcoal binds long-chain impurities without stripping character.",
    "expDe": "Aktivkohle adsorbiert Verunreinigungen und Begleitöle für samtige Milde."
  },
  {
    "id": "q_spirits_12",
    "category": "spirits",
    "questionEn": "Which herb supplies the compound thujone to authentic Absinthe?",
    "questionDe": "Welche Heilpflanze liefert das wirksame Terpen Thujon im traditionellen Absinth?",
    "optionsEn": [
      "Grande Wormwood (Artemisia absinthium)",
      "Fennel seed",
      "Star anise",
      "Hyssop"
    ],
    "optionsDe": [
      "Echter Wermut (Artemisia absinthium)",
      "Fenchelsamen",
      "Sternanis",
      "Ysop"
    ],
    "correctIndex": 0,
    "explanationEn": "Grande Wormwood is macerated and distilled alongside anise and fennel.",
    "explanationDe": "Echter Wermut bildet mit Anis und Fenchel die Heilige Dreifaltigkeit des Absinths.",
    "qEn": "Which herb supplies the compound thujone to authentic Absinthe?",
    "qDe": "Welche Heilpflanze liefert das wirksame Terpen Thujon im traditionellen Absinth?",
    "optEn": [
      "Grande Wormwood (Artemisia absinthium)",
      "Fennel seed",
      "Star anise",
      "Hyssop"
    ],
    "optDe": [
      "Echter Wermut (Artemisia absinthium)",
      "Fenchelsamen",
      "Sternanis",
      "Ysop"
    ],
    "correct": 0,
    "expEn": "Grande Wormwood is macerated and distilled alongside anise and fennel.",
    "expDe": "Echter Wermut bildet mit Anis und Fenchel die Heilige Dreifaltigkeit des Absinths."
  },
  {
    "id": "q_spirits_13",
    "category": "spirits",
    "questionEn": "How is Armagnac traditionally distilled differently than Cognac?",
    "questionDe": "Wie unterscheidet sich die Destillation von Armagnac im Vergleich zu Cognac?",
    "optionsEn": [
      "Single continuous distillation in column stills (alambic armagnacais)",
      "Double pot still distillation",
      "Cold vacuum distillation",
      "Triple pot still"
    ],
    "optionsDe": [
      "Einfache kontinuierliche Destillation im Alambic Armagnacais",
      "Zweifache Destillation in Kupferblasen",
      "Kaltvakuumdestillation",
      "Dreifache Brennblase"
    ],
    "correctIndex": 0,
    "explanationEn": "Armagnac column distillation retains heavier aromatic esters and fruit congeners.",
    "explanationDe": "Die Säulendestillation im Alambic Armagnacais erhält mehr schwere Fruchtaromen.",
    "qEn": "How is Armagnac traditionally distilled differently than Cognac?",
    "qDe": "Wie unterscheidet sich die Destillation von Armagnac im Vergleich zu Cognac?",
    "optEn": [
      "Single continuous distillation in column stills (alambic armagnacais)",
      "Double pot still distillation",
      "Cold vacuum distillation",
      "Triple pot still"
    ],
    "optDe": [
      "Einfache kontinuierliche Destillation im Alambic Armagnacais",
      "Zweifache Destillation in Kupferblasen",
      "Kaltvakuumdestillation",
      "Dreifache Brennblase"
    ],
    "correct": 0,
    "expEn": "Armagnac column distillation retains heavier aromatic esters and fruit congeners.",
    "expDe": "Die Säulendestillation im Alambic Armagnacais erhält mehr schwere Fruchtaromen."
  },
  {
    "id": "q_spirits_14",
    "category": "spirits",
    "questionEn": "What is the mandatory principal botanical in Scandinavian Aquavit?",
    "questionDe": "Welches Gewürz ist das gesetzlich vorgeschriebene Leitgewürz in Aquavit?",
    "optionsEn": [
      "Caraway and/or dill seed",
      "Juniper berry",
      "Cinnamon",
      "Cardamom"
    ],
    "optionsDe": [
      "Kümmel (Carum carvi) und/oder Dillsamen",
      "Wacholderbeere",
      "Zimt",
      "Kardamom"
    ],
    "correctIndex": 0,
    "explanationEn": "EU law mandates caraway or dill as predominant flavor in Aquavit.",
    "explanationDe": "Nach EU-Recht muss der vorherrschende Geschmack aus Kümmel- oder Dillsamen stammen.",
    "qEn": "What is the mandatory principal botanical in Scandinavian Aquavit?",
    "qDe": "Welches Gewürz ist das gesetzlich vorgeschriebene Leitgewürz in Aquavit?",
    "optEn": [
      "Caraway and/or dill seed",
      "Juniper berry",
      "Cinnamon",
      "Cardamom"
    ],
    "optDe": [
      "Kümmel (Carum carvi) und/oder Dillsamen",
      "Wacholderbeere",
      "Zimt",
      "Kardamom"
    ],
    "correct": 0,
    "expEn": "EU law mandates caraway or dill as predominant flavor in Aquavit.",
    "expDe": "Nach EU-Recht muss der vorherrschende Geschmack aus Kümmel- oder Dillsamen stammen."
  },
  {
    "id": "q_spirits_15",
    "category": "spirits",
    "questionEn": "Why does artisanal Mezcal taste smoky compared to Tequila?",
    "questionDe": "Warum schmeckt traditioneller Mezcal rauchig im Vergleich zu Tequila?",
    "optionsEn": [
      "Agave hearts are roasted in underground stone pits over wood fire",
      "Liquid smoke added during bottling",
      "Boiled in steel smokeboxes",
      "Matured in burned coal silos"
    ],
    "optionsDe": [
      "Agavenherzen (Piñas) werden in Grubenöfen über Holzfeuer und Stein geröstet",
      "Raucharoma wird bei der Abfüllung zugegeben",
      "In Rauchkammern gekocht",
      "In Kohlesilos gelagert"
    ],
    "correctIndex": 0,
    "explanationEn": "Underground pit cooking infuses deep wood smoke into agave fibers.",
    "explanationDe": "Das Rösten in Erdgruben imprägniert die Agavenfasern mit tiefem Rauch.",
    "qEn": "Why does artisanal Mezcal taste smoky compared to Tequila?",
    "qDe": "Warum schmeckt traditioneller Mezcal rauchig im Vergleich zu Tequila?",
    "optEn": [
      "Agave hearts are roasted in underground stone pits over wood fire",
      "Liquid smoke added during bottling",
      "Boiled in steel smokeboxes",
      "Matured in burned coal silos"
    ],
    "optDe": [
      "Agavenherzen (Piñas) werden in Grubenöfen über Holzfeuer und Stein geröstet",
      "Raucharoma wird bei der Abfüllung zugegeben",
      "In Rauchkammern gekocht",
      "In Kohlesilos gelagert"
    ],
    "correct": 0,
    "expEn": "Underground pit cooking infuses deep wood smoke into agave fibers.",
    "expDe": "Das Rösten in Erdgruben imprägniert die Agavenfasern mit tiefem Rauch."
  },
  {
    "id": "q_spirits_16",
    "category": "spirits",
    "questionEn": "What is Brazilian Cachaça legally distilled from?",
    "questionDe": "Woraus wird brasilianischer Cachaça gesetzlich gebrannt?",
    "optionsEn": [
      "Fresh fermented sugarcane juice (38–48% ABV)",
      "Cane molasses",
      "Grain alcohol",
      "Fruit syrup"
    ],
    "optionsDe": [
      "Frischem fermentiertem Zuckerrohrsaft (38–48% Vol.)",
      "Zuckerrohrmelasse",
      "Getreidealkohol",
      "Fruchtsirup"
    ],
    "correctIndex": 0,
    "explanationEn": "Cachaça is a protected Brazilian spirit made from fresh pressed cane juice.",
    "explanationDe": "Cachaça ist eine geschützte brasilianische Spirituose aus frischem Rohrsaft.",
    "qEn": "What is Brazilian Cachaça legally distilled from?",
    "qDe": "Woraus wird brasilianischer Cachaça gesetzlich gebrannt?",
    "optEn": [
      "Fresh fermented sugarcane juice (38–48% ABV)",
      "Cane molasses",
      "Grain alcohol",
      "Fruit syrup"
    ],
    "optDe": [
      "Frischem fermentiertem Zuckerrohrsaft (38–48% Vol.)",
      "Zuckerrohrmelasse",
      "Getreidealkohol",
      "Fruchtsirup"
    ],
    "correct": 0,
    "expEn": "Cachaça is a protected Brazilian spirit made from fresh pressed cane juice.",
    "expDe": "Cachaça ist eine geschützte brasilianische Spirituose aus frischem Rohrsaft."
  },
  {
    "id": "q_spirits_17",
    "category": "spirits",
    "questionEn": "How is authentic Peruvian Pisco produced regarding proof and aging?",
    "questionDe": "Wie wird peruanischer Pisco bezüglich Trinkstärke und Reifung hergestellt?",
    "optionsEn": [
      "Distilled directly to bottle proof without water dilution or oak contact",
      "Aged 12 years in charred oak",
      "Sweetened with sugar syrup",
      "Diluted with spring water"
    ],
    "optionsDe": [
      "Direkt auf Trinkstärke gebrannt; kein Wasserzusatz, kein Holzfasskontakt",
      "12 Jahre im Eichenfass",
      "Mit Zuckersirup gesüßt",
      "Mit Quellwasser gestreckt"
    ],
    "correctIndex": 0,
    "explanationEn": "Peruvian Pisco is rested in neutral vessels and never diluted.",
    "explanationDe": "Peruanischer Pisco wird direkt auf Trinkstärke gebrannt und ruht in neutralen Tanks.",
    "qEn": "How is authentic Peruvian Pisco produced regarding proof and aging?",
    "qDe": "Wie wird peruanischer Pisco bezüglich Trinkstärke und Reifung hergestellt?",
    "optEn": [
      "Distilled directly to bottle proof without water dilution or oak contact",
      "Aged 12 years in charred oak",
      "Sweetened with sugar syrup",
      "Diluted with spring water"
    ],
    "optDe": [
      "Direkt auf Trinkstärke gebrannt; kein Wasserzusatz, kein Holzfasskontakt",
      "12 Jahre im Eichenfass",
      "Mit Zuckersirup gesüßt",
      "Mit Quellwasser gestreckt"
    ],
    "correct": 0,
    "expEn": "Peruvian Pisco is rested in neutral vessels and never diluted.",
    "expDe": "Peruanischer Pisco wird direkt auf Trinkstärke gebrannt und ruht in neutralen Tanks."
  },
  {
    "id": "q_spirits_18",
    "category": "spirits",
    "questionEn": "Where does the subtle almond note in Black Forest Kirschwasser originate?",
    "questionDe": "Woher stammt die feine Mandelnote in Schwarzwälder Kirschwasser?",
    "optionsEn": [
      "Crushed cherry pits releasing benzaldehyde during fermentation",
      "Almond extract infusion",
      "Almond wood casks",
      "Added marzipan paste"
    ],
    "optionsDe": [
      "Ein kontrollierter Anteil angequetschter Kirschkerne setzt Benzaldehyd frei",
      "Zusatz von Bittermandelöl",
      "Fässer aus Mandelbaumholz",
      "Zugabe von Marzipanpaste"
    ],
    "correctIndex": 0,
    "explanationEn": "Cherry stones release amygdalin, converting to aromatic benzaldehyde.",
    "explanationDe": "Die Kirschsteine enthalten Amygdalin, das zu feinem Benzaldehyd gespalten wird.",
    "qEn": "Where does the subtle almond note in Black Forest Kirschwasser originate?",
    "qDe": "Woher stammt die feine Mandelnote in Schwarzwälder Kirschwasser?",
    "optEn": [
      "Crushed cherry pits releasing benzaldehyde during fermentation",
      "Almond extract infusion",
      "Almond wood casks",
      "Added marzipan paste"
    ],
    "optDe": [
      "Ein kontrollierter Anteil angequetschter Kirschkerne setzt Benzaldehyd frei",
      "Zusatz von Bittermandelöl",
      "Fässer aus Mandelbaumholz",
      "Zugabe von Marzipanpaste"
    ],
    "correct": 0,
    "expEn": "Cherry stones release amygdalin, converting to aromatic benzaldehyde.",
    "expDe": "Die Kirschsteine enthalten Amygdalin, das zu feinem Benzaldehyd gespalten wird."
  },
  {
    "id": "q_wine_01",
    "category": "wine",
    "questionEn": "Why does Asti Spumante DOCG retain high sweetness and low alcohol?",
    "questionDe": "Warum hat Asti Spumante DOCG viel Restsüße und wenig Alkohol?",
    "optionsEn": [
      "Fermentation is stopped early by refrigeration and pressure filtration",
      "Cane sugar added",
      "Grape juice mixed with neutral spirits",
      "Grapes grown in dark shade"
    ],
    "optionsDe": [
      "Gärung wird vorzeitig durch Kälte und Druckfiltration gestoppt",
      "Rohrzucker beigemischt",
      "Traubensaft mit Alkohol versetzt",
      "Ohne Sonne angebaut"
    ],
    "correctIndex": 0,
    "explanationEn": "Asti method arrests fermentation at 7% ABV to capture natural grape sugar.",
    "explanationDe": "Kälte stoppt die Hefe vorzeitig ab, um natürliche Fruktose zu erhalten.",
    "qEn": "Why does Asti Spumante DOCG retain high sweetness and low alcohol?",
    "qDe": "Warum hat Asti Spumante DOCG viel Restsüße und wenig Alkohol?",
    "optEn": [
      "Fermentation is stopped early by refrigeration and pressure filtration",
      "Cane sugar added",
      "Grape juice mixed with neutral spirits",
      "Grapes grown in dark shade"
    ],
    "optDe": [
      "Gärung wird vorzeitig durch Kälte und Druckfiltration gestoppt",
      "Rohrzucker beigemischt",
      "Traubensaft mit Alkohol versetzt",
      "Ohne Sonne angebaut"
    ],
    "correct": 0,
    "expEn": "Asti method arrests fermentation at 7% ABV to capture natural grape sugar.",
    "expDe": "Kälte stoppt die Hefe vorzeitig ab, um natürliche Fruktose zu erhalten."
  },
  {
    "id": "q_wine_02",
    "category": "wine",
    "questionEn": "What is the function of the Liqueur de dosage in Champagne?",
    "questionDe": "Welche Funktion hat die Versanddosage beim Champagner?",
    "optionsEn": [
      "Balances acidity and establishes the final sweetness style (Brut, Extra Dry)",
      "Kills yeast with sulfur",
      "Colors wine red",
      "Creates the initial bubbles"
    ],
    "optionsDe": [
      "Stellt die finale Geschmacksstufe (Brut, Extra Dry) und Süße-Balance ein",
      "Tötet Hefe mit Schwefel",
      "Färbt den Wein rot",
      "Erzeugt die ersten Bläschen"
    ],
    "correctIndex": 0,
    "explanationEn": "Dosage balances high acidity after disgorgement.",
    "explanationDe": "Die Dosage gleicht Säure aus und definiert die Süßestufe.",
    "qEn": "What is the function of the Liqueur de dosage in Champagne?",
    "qDe": "Welche Funktion hat die Versanddosage beim Champagner?",
    "optEn": [
      "Balances acidity and establishes the final sweetness style (Brut, Extra Dry)",
      "Kills yeast with sulfur",
      "Colors wine red",
      "Creates the initial bubbles"
    ],
    "optDe": [
      "Stellt die finale Geschmacksstufe (Brut, Extra Dry) und Süße-Balance ein",
      "Tötet Hefe mit Schwefel",
      "Färbt den Wein rot",
      "Erzeugt die ersten Bläschen"
    ],
    "correct": 0,
    "expEn": "Dosage balances high acidity after disgorgement.",
    "expDe": "Die Dosage gleicht Säure aus und definiert die Süßestufe."
  },
  {
    "id": "q_wine_03",
    "category": "wine",
    "questionEn": "Why decant a young, tannic Barolo or Cabernet Sauvignon?",
    "questionDe": "Warum dekantiert man einen jungen, gerbstoffreichen Barolo?",
    "optionsEn": [
      "Aeration softens aggressive tannins and releases volatile bouquet aromas",
      "To extract sugar crystals",
      "To warm it to boiling",
      "To remove alcohol"
    ],
    "optionsDe": [
      "Sauerstoffkontakt mildert schroffe Tannine und öffnet Bukettaromen",
      "Um Zucker abzuscheiden",
      "Um ihn zu kochen",
      "Um Alkohol zu entziehen"
    ],
    "correctIndex": 0,
    "explanationEn": "Oxygen promotes polymerization of harsh catechin tannins.",
    "explanationDe": "Sauerstoff bindet scharfe Tannine und setzt Aromen frei.",
    "qEn": "Why decant a young, tannic Barolo or Cabernet Sauvignon?",
    "qDe": "Warum dekantiert man einen jungen, gerbstoffreichen Barolo?",
    "optEn": [
      "Aeration softens aggressive tannins and releases volatile bouquet aromas",
      "To extract sugar crystals",
      "To warm it to boiling",
      "To remove alcohol"
    ],
    "optDe": [
      "Sauerstoffkontakt mildert schroffe Tannine und öffnet Bukettaromen",
      "Um Zucker abzuscheiden",
      "Um ihn zu kochen",
      "Um Alkohol zu entziehen"
    ],
    "correct": 0,
    "expEn": "Oxygen promotes polymerization of harsh catechin tannins.",
    "expDe": "Sauerstoff bindet scharfe Tannine und setzt Aromen frei."
  },
  {
    "id": "q_wine_04",
    "category": "wine",
    "questionEn": "Which three grape varieties dominate traditional Champagne?",
    "questionDe": "Welche drei Rebsorten dominieren traditionellen Champagner?",
    "optionsEn": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "optionsDe": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "correctIndex": 0,
    "explanationEn": "These three varieties form over 99% of Champagne plantings.",
    "explanationDe": "Diese drei Sorten bilden das Rückgrat der Champagne.",
    "qEn": "Which three grape varieties dominate traditional Champagne?",
    "qDe": "Welche drei Rebsorten dominieren traditionellen Champagner?",
    "optEn": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "optDe": [
      "Chardonnay, Pinot Noir, Pinot Meunier",
      "Riesling, Sauvignon Blanc, Merlot",
      "Syrah, Grenache, Mourvèdre",
      "Cabernet, Chenin, Sémillon"
    ],
    "correct": 0,
    "expEn": "These three varieties form over 99% of Champagne plantings.",
    "expDe": "Diese drei Sorten bilden das Rückgrat der Champagne."
  },
  {
    "id": "q_wine_05",
    "category": "wine",
    "questionEn": "What happens during Malolactic Fermentation (MLF)?",
    "questionDe": "Was geschieht bei der Malolaktischen Gärung (BSA)?",
    "optionsEn": [
      "Sharp malic acid is converted by lactic bacteria into softer lactic acid and diacetyl",
      "Sugar turns into alcohol",
      "Tannins turn to vinegar",
      "Acid precipitates as diamonds"
    ],
    "optionsDe": [
      "Scharfe Äpfelsäure wird in milde Milchsäure und buttriges Diacetyl umgewandelt",
      "Zucker wird Alkohol",
      "Gerbstoff wird Essig",
      "Säure kristallisiert"
    ],
    "correctIndex": 0,
    "explanationEn": "MLF reduces perceived tartness and adds round creamy mouthfeel.",
    "explanationDe": "Milchsäurebakterien mildern die aggressive Äpfelsäure ab.",
    "qEn": "What happens during Malolactic Fermentation (MLF)?",
    "qDe": "Was geschieht bei der Malolaktischen Gärung (BSA)?",
    "optEn": [
      "Sharp malic acid is converted by lactic bacteria into softer lactic acid and diacetyl",
      "Sugar turns into alcohol",
      "Tannins turn to vinegar",
      "Acid precipitates as diamonds"
    ],
    "optDe": [
      "Scharfe Äpfelsäure wird in milde Milchsäure und buttriges Diacetyl umgewandelt",
      "Zucker wird Alkohol",
      "Gerbstoff wird Essig",
      "Säure kristallisiert"
    ],
    "correct": 0,
    "expEn": "MLF reduces perceived tartness and adds round creamy mouthfeel.",
    "expDe": "Milchsäurebakterien mildern die aggressive Äpfelsäure ab."
  },
  {
    "id": "q_wine_06",
    "category": "wine",
    "questionEn": "How does Botrytis cinerea create Sauternes and Trockenbeerenauslese?",
    "questionDe": "Wie erzeugt Botrytis cinerea Weltklasse-Edelsüßweine?",
    "optionsEn": [
      "Fungus perforates grape skins, evaporating water and concentrating sugars and nectar",
      "Converts alcohol to sugar",
      "Freezes grapes on vine",
      "Dyes grapes amber"
    ],
    "optionsDe": [
      "Der Pilz perforiert Schalen, Wasser verdunstet, Zucker und Säure konzentrieren sich",
      "Wandelt Alkohol in Zucker um",
      "Lässt Beeren gefrieren",
      "Färbt Beeren bernsteinfarben"
    ],
    "correctIndex": 0,
    "explanationEn": "Noble rot dehydrates berries while concentrating acids and honeyed aromatics.",
    "explanationDe": "Edelfäule lässt Wasser verdunsten und konzentriert Zucker und Aromen.",
    "qEn": "How does Botrytis cinerea create Sauternes and Trockenbeerenauslese?",
    "qDe": "Wie erzeugt Botrytis cinerea Weltklasse-Edelsüßweine?",
    "optEn": [
      "Fungus perforates grape skins, evaporating water and concentrating sugars and nectar",
      "Converts alcohol to sugar",
      "Freezes grapes on vine",
      "Dyes grapes amber"
    ],
    "optDe": [
      "Der Pilz perforiert Schalen, Wasser verdunstet, Zucker und Säure konzentrieren sich",
      "Wandelt Alkohol in Zucker um",
      "Lässt Beeren gefrieren",
      "Färbt Beeren bernsteinfarben"
    ],
    "correct": 0,
    "expEn": "Noble rot dehydrates berries while concentrating acids and honeyed aromatics.",
    "expDe": "Edelfäule lässt Wasser verdunsten und konzentriert Zucker und Aromen."
  },
  {
    "id": "q_wine_07",
    "category": "wine",
    "questionEn": "At what temperature must grapes be picked and pressed for German Eiswein?",
    "questionDe": "Bei welcher Mindestkälte müssen Eisweintrauben gelesen und gepresst werden?",
    "optionsEn": [
      "At -7°C or colder",
      "At 0°C",
      "At +4°C",
      "At -25°C strictly"
    ],
    "optionsDe": [
      "Bei mindestens -7°C oder kälter",
      "Bei 0°C",
      "Bei +4°C",
      "Bei exakt -25°C"
    ],
    "correctIndex": 0,
    "explanationEn": "Freezing leaves ice in the press, concentrating rich sugar syrup.",
    "explanationDe": "Das Wasser bleibt als Eis in der Kelter zurück; zuckersüßer Most fließt ab.",
    "qEn": "At what temperature must grapes be picked and pressed for German Eiswein?",
    "qDe": "Bei welcher Mindestkälte müssen Eisweintrauben gelesen und gepresst werden?",
    "optEn": [
      "At -7°C or colder",
      "At 0°C",
      "At +4°C",
      "At -25°C strictly"
    ],
    "optDe": [
      "Bei mindestens -7°C oder kälter",
      "Bei 0°C",
      "Bei +4°C",
      "Bei exakt -25°C"
    ],
    "correct": 0,
    "expEn": "Freezing leaves ice in the press, concentrating rich sugar syrup.",
    "expDe": "Das Wasser bleibt als Eis in der Kelter zurück; zuckersüßer Most fließt ab."
  },
  {
    "id": "q_wine_08",
    "category": "wine",
    "questionEn": "Why does tannic red wine pair brilliantly with marbled beef steak?",
    "questionDe": "Warum passt gerbstoffbetonter Rotwein ideal zu marmoriertem Steak?",
    "optionsEn": [
      "Meat fats and proteins bind to astringent saliva-coating tannins",
      "Fat neutralizes alcohol into water",
      "Wine dissolves meat fibers",
      "Tannins cook the meat"
    ],
    "optionsDe": [
      "Fett und Eiweiß binden herbe Gerbstoffe und mildern Adstringenz",
      "Fett macht Alkohol zu Wasser",
      "Wein löst Fleischfasern auf",
      "Tannine garen das Fleisch"
    ],
    "correctIndex": 0,
    "explanationEn": "Proteins buffer oral tannin perception, smoothing the mouthfeel.",
    "explanationDe": "Fleischeiweiße neutralisieren die pelzige Wirkung der Gerbstoffe am Gaumen.",
    "qEn": "Why does tannic red wine pair brilliantly with marbled beef steak?",
    "qDe": "Warum passt gerbstoffbetonter Rotwein ideal zu marmoriertem Steak?",
    "optEn": [
      "Meat fats and proteins bind to astringent saliva-coating tannins",
      "Fat neutralizes alcohol into water",
      "Wine dissolves meat fibers",
      "Tannins cook the meat"
    ],
    "optDe": [
      "Fett und Eiweiß binden herbe Gerbstoffe und mildern Adstringenz",
      "Fett macht Alkohol zu Wasser",
      "Wein löst Fleischfasern auf",
      "Tannine garen das Fleisch"
    ],
    "correct": 0,
    "expEn": "Proteins buffer oral tannin perception, smoothing the mouthfeel.",
    "expDe": "Fleischeiweiße neutralisieren die pelzige Wirkung der Gerbstoffe am Gaumen."
  },
  {
    "id": "q_wine_09",
    "category": "wine",
    "questionEn": "What is meant by 'Terroir' in viticulture?",
    "questionDe": "Was umfasst der französische Begriff 'Terroir'?",
    "optionsEn": [
      "Interplay of soil, climate, topography, and human craftsmanship",
      "Only bottle glass design",
      "Only vineyard land price",
      "Fertilizer brand used"
    ],
    "optionsDe": [
      "Zusammenspiel von Boden, Mikroklima, Hangneigung und Winzerhandwerk",
      "Nur das Flaschendesign",
      "Nur den Hektarpreis",
      "Die Düngermarke"
    ],
    "correctIndex": 0,
    "explanationEn": "Terroir represents the holistic identity of geographical origin.",
    "explanationDe": "Terroir vereint natürliche Gegebenheiten und menschliche Tradition.",
    "qEn": "What is meant by 'Terroir' in viticulture?",
    "qDe": "Was umfasst der französische Begriff 'Terroir'?",
    "optEn": [
      "Interplay of soil, climate, topography, and human craftsmanship",
      "Only bottle glass design",
      "Only vineyard land price",
      "Fertilizer brand used"
    ],
    "optDe": [
      "Zusammenspiel von Boden, Mikroklima, Hangneigung und Winzerhandwerk",
      "Nur das Flaschendesign",
      "Nur den Hektarpreis",
      "Die Düngermarke"
    ],
    "correct": 0,
    "expEn": "Terroir represents the holistic identity of geographical origin.",
    "expDe": "Terroir vereint natürliche Gegebenheiten und menschliche Tradition."
  },
  {
    "id": "q_wine_10",
    "category": "wine",
    "questionEn": "How does the Solera blending system work for Jerez Sherry?",
    "questionDe": "Wie funktioniert das Solera-System beim andalusischen Sherry?",
    "optionsEn": [
      "Wine drawn from bottom barrels is refreshed continuously from younger tiers above",
      "Heated in ovens for months",
      "Straw mat dried raisins only",
      "Aged 100 years untouched"
    ],
    "optionsDe": [
      "Entnommener Wein der untersten Reihe wird schrittweise von oben nachgefüllt",
      "Im Heißofen erwärmt",
      "Auf Strohmatten getrocknet",
      "100 Jahre unberührt"
    ],
    "correctIndex": 0,
    "explanationEn": "Fractional blending maintains stylistic continuity over generations.",
    "explanationDe": "Kaskadierendes Verschneiden garantiert über Jahrzehnte gleichbleibende Güte.",
    "qEn": "How does the Solera blending system work for Jerez Sherry?",
    "qDe": "Wie funktioniert das Solera-System beim andalusischen Sherry?",
    "optEn": [
      "Wine drawn from bottom barrels is refreshed continuously from younger tiers above",
      "Heated in ovens for months",
      "Straw mat dried raisins only",
      "Aged 100 years untouched"
    ],
    "optDe": [
      "Entnommener Wein der untersten Reihe wird schrittweise von oben nachgefüllt",
      "Im Heißofen erwärmt",
      "Auf Strohmatten getrocknet",
      "100 Jahre unberührt"
    ],
    "correct": 0,
    "expEn": "Fractional blending maintains stylistic continuity over generations.",
    "expDe": "Kaskadierendes Verschneiden garantiert über Jahrzehnte gleichbleibende Güte."
  },
  {
    "id": "q_wine_11",
    "category": "wine",
    "questionEn": "What is 'Flor' yeast in Sherry production?",
    "questionDe": "Was ist der 'Flor' beim Fino-Sherry?",
    "optionsEn": [
      "Biological yeast veil floating on wine surface preventing oxidation",
      "Raisin syrup additive",
      "Wood rot fungus",
      "Artificial chemical"
    ],
    "optionsDe": [
      "Schwimmende Hefedecke, die den Wein hermetisch vor Sauerstoff schützt",
      "Rosinensirup",
      "Holzpilz",
      "Chemisches Pulver"
    ],
    "correctIndex": 0,
    "explanationEn": "Flor shields Fino from oxygen and creates crisp nutty saline flavors.",
    "explanationDe": "Flor schützt vor Luft und schenkt Noten von Mandeln und Meersalz.",
    "qEn": "What is 'Flor' yeast in Sherry production?",
    "qDe": "Was ist der 'Flor' beim Fino-Sherry?",
    "optEn": [
      "Biological yeast veil floating on wine surface preventing oxidation",
      "Raisin syrup additive",
      "Wood rot fungus",
      "Artificial chemical"
    ],
    "optDe": [
      "Schwimmende Hefedecke, die den Wein hermetisch vor Sauerstoff schützt",
      "Rosinensirup",
      "Holzpilz",
      "Chemisches Pulver"
    ],
    "correct": 0,
    "expEn": "Flor shields Fino from oxygen and creates crisp nutty saline flavors.",
    "expDe": "Flor schützt vor Luft und schenkt Noten von Mandeln und Meersalz."
  },
  {
    "id": "q_wine_12",
    "category": "wine",
    "questionEn": "Which compound causes the 'Cork Taint' fault?",
    "questionDe": "Welche Verbindung verursacht den typischen 'Korkschmecker'?",
    "optionsEn": [
      "2,4,6-Trichloroanisole (TCA)",
      "Ethyl acetate",
      "Sulfur dioxide",
      "Lactic acid"
    ],
    "optionsDe": [
      "2,4,6-Trichloranisol (TCA)",
      "Ethylacetat",
      "Schwefeldioxid",
      "Milchsäure"
    ],
    "correctIndex": 0,
    "explanationEn": "TCA causes musty damp cardboard smells at tiny parts-per-trillion.",
    "explanationDe": "TCA erzeugt selbst in Nanogrammen Geruch nach feuchtem Kellerkarton.",
    "qEn": "Which compound causes the 'Cork Taint' fault?",
    "qDe": "Welche Verbindung verursacht den typischen 'Korkschmecker'?",
    "optEn": [
      "2,4,6-Trichloroanisole (TCA)",
      "Ethyl acetate",
      "Sulfur dioxide",
      "Lactic acid"
    ],
    "optDe": [
      "2,4,6-Trichloranisol (TCA)",
      "Ethylacetat",
      "Schwefeldioxid",
      "Milchsäure"
    ],
    "correct": 0,
    "expEn": "TCA causes musty damp cardboard smells at tiny parts-per-trillion.",
    "expDe": "TCA erzeugt selbst in Nanogrammen Geruch nach feuchtem Kellerkarton."
  },
  {
    "id": "q_wine_13",
    "category": "wine",
    "questionEn": "Why is Pinot Noir considered the most terroir-transparent grape?",
    "questionDe": "Warum gilt Pinot Noir als die terroir-empfindlichste Rebsorte?",
    "optionsEn": [
      "Thin skins and low pigment directly transmit soil and microclimate nuances",
      "Grows in volcanic soil only",
      "Never ripens fully",
      "Requires artificial yeast"
    ],
    "optionsDe": [
      "Dünne Beerenhaut und feine Pigmente spiegeln Boden und Klima präzise wider",
      "Wächst nur auf Vulkanboden",
      "Wird nie reif",
      "Braucht Reinzuchthefen"
    ],
    "correctIndex": 0,
    "explanationEn": "Its delicate anthocyanins and low tannin expose subtle site differences.",
    "explanationDe": "Wegen feiner Tannine schmeckt man kleinste Lagenunterschiede sofort heraus.",
    "qEn": "Why is Pinot Noir considered the most terroir-transparent grape?",
    "qDe": "Warum gilt Pinot Noir als die terroir-empfindlichste Rebsorte?",
    "optEn": [
      "Thin skins and low pigment directly transmit soil and microclimate nuances",
      "Grows in volcanic soil only",
      "Never ripens fully",
      "Requires artificial yeast"
    ],
    "optDe": [
      "Dünne Beerenhaut und feine Pigmente spiegeln Boden und Klima präzise wider",
      "Wächst nur auf Vulkanboden",
      "Wird nie reif",
      "Braucht Reinzuchthefen"
    ],
    "correct": 0,
    "expEn": "Its delicate anthocyanins and low tannin expose subtle site differences.",
    "expDe": "Wegen feiner Tannine schmeckt man kleinste Lagenunterschiede sofort heraus."
  },
  {
    "id": "q_wine_14",
    "category": "wine",
    "questionEn": "Why must mature Vintage Port be decanted through a fine strainer?",
    "questionDe": "Warum muss reifer Vintage Port filtriert und dekantiert werden?",
    "optionsEn": [
      "Bottled unfiltered after 2 years, casting heavy sediment over decades",
      "To separate sugar crystals",
      "To lower alcohol vapor",
      "Cork dissolves inside"
    ],
    "optionsDe": [
      "Nach nur 2 Jahren unfiltriert abgefüllt; bildet massives Flaschendepot",
      "Um Zucker abzuscheiden",
      "Um Alkohol zu senken",
      "Kork löst sich auf"
    ],
    "correctIndex": 0,
    "explanationEn": "Polymerized tannins fall out as thick crust over 20-50 years in glass.",
    "explanationDe": "Gerbstoffe und Farbstoffe flocken über Jahrzehnte als schweres Depot aus.",
    "qEn": "Why must mature Vintage Port be decanted through a fine strainer?",
    "qDe": "Warum muss reifer Vintage Port filtriert und dekantiert werden?",
    "optEn": [
      "Bottled unfiltered after 2 years, casting heavy sediment over decades",
      "To separate sugar crystals",
      "To lower alcohol vapor",
      "Cork dissolves inside"
    ],
    "optDe": [
      "Nach nur 2 Jahren unfiltriert abgefüllt; bildet massives Flaschendepot",
      "Um Zucker abzuscheiden",
      "Um Alkohol zu senken",
      "Kork löst sich auf"
    ],
    "correct": 0,
    "expEn": "Polymerized tannins fall out as thick crust over 20-50 years in glass.",
    "expDe": "Gerbstoffe und Farbstoffe flocken über Jahrzehnte als schweres Depot aus."
  },
  {
    "id": "q_wine_15",
    "category": "wine",
    "questionEn": "What is the Appassimento method in Amarone della Valpolicella?",
    "questionDe": "Was ist das Appassimento-Verfahren beim Amarone?",
    "optionsEn": [
      "Drying harvested grapes on wooden trays for months to concentrate sugar and extract",
      "Freezing in mountain snow",
      "Fortifying must with brandy",
      "Boiling grape juice"
    ],
    "optionsDe": [
      "Monatelanges Antrocknen der Trauben auf Holzgestellen zur Saftkonzentration",
      "Im Schnee gefrieren",
      "Mit Weingeist aufspriten",
      "Most einkochen"
    ],
    "correctIndex": 0,
    "explanationEn": "Grapes lose 30-40% water weight, producing rich dry wines with high extract.",
    "explanationDe": "Trauben verlieren bis zu 40% Wasser; der konzentrierte Most vergärt trocken.",
    "qEn": "What is the Appassimento method in Amarone della Valpolicella?",
    "qDe": "Was ist das Appassimento-Verfahren beim Amarone?",
    "optEn": [
      "Drying harvested grapes on wooden trays for months to concentrate sugar and extract",
      "Freezing in mountain snow",
      "Fortifying must with brandy",
      "Boiling grape juice"
    ],
    "optDe": [
      "Monatelanges Antrocknen der Trauben auf Holzgestellen zur Saftkonzentration",
      "Im Schnee gefrieren",
      "Mit Weingeist aufspriten",
      "Most einkochen"
    ],
    "correct": 0,
    "expEn": "Grapes lose 30-40% water weight, producing rich dry wines with high extract.",
    "expDe": "Trauben verlieren bis zu 40% Wasser; der konzentrierte Most vergärt trocken."
  },
  {
    "id": "q_wine_16",
    "category": "wine",
    "questionEn": "Why can German Mosel Riesling age for 30+ years despite low alcohol?",
    "questionDe": "Warum altert Mosel-Riesling trotz geringen Alkohols exzellent über Jahrzehnte?",
    "optionsEn": [
      "High natural fruit acidity, mineral extract, and residual sugar preserve it",
      "Fortified with neutral brandy",
      "Sealed with hot wax",
      "Aged in deep new oak"
    ],
    "optionsDe": [
      "Hohe natürliche Weinsäure, Mineralität und harmonischer Zucker konservieren",
      "Mit Schnaps aufgespritet",
      "Mit Wachs versiegelt",
      "Im Neuholz gereift"
    ],
    "correctIndex": 0,
    "explanationEn": "Low pH and vibrant acids resist oxidation for decades.",
    "explanationDe": "Hohe Weinsäure und niedriger pH-Wert schützen vor dem Verfall.",
    "qEn": "Why can German Mosel Riesling age for 30+ years despite low alcohol?",
    "qDe": "Warum altert Mosel-Riesling trotz geringen Alkohols exzellent über Jahrzehnte?",
    "optEn": [
      "High natural fruit acidity, mineral extract, and residual sugar preserve it",
      "Fortified with neutral brandy",
      "Sealed with hot wax",
      "Aged in deep new oak"
    ],
    "optDe": [
      "Hohe natürliche Weinsäure, Mineralität und harmonischer Zucker konservieren",
      "Mit Schnaps aufgespritet",
      "Mit Wachs versiegelt",
      "Im Neuholz gereift"
    ],
    "correct": 0,
    "expEn": "Low pH and vibrant acids resist oxidation for decades.",
    "expDe": "Hohe Weinsäure und niedriger pH-Wert schützen vor dem Verfall."
  },
  {
    "id": "q_wine_17",
    "category": "wine",
    "questionEn": "How is Prosecco Superiore DOCG made sparkling?",
    "questionDe": "Wie entsteht die Kohlensäure bei Prosecco Superiore DOCG?",
    "optionsEn": [
      "Secondary fermentation in stainless steel pressure autoclaves (Charmat method)",
      "Bottle fermentation like Champagne",
      "Injected CO2 gas",
      "Dry ice added"
    ],
    "optionsDe": [
      "Zweite Gärung im Edelstahldrucktank (Charmat-/Martinotti-Verfahren)",
      "Flaschengärung wie Champagner",
      "Kohlensäure eingepumpt",
      "Trockeneiszugabe"
    ],
    "correctIndex": 0,
    "explanationEn": "Tank fermentation preserves fresh floral and fruit aromatics of Glera.",
    "explanationDe": "Die Tankgärung bewahrt die frischen Primäraromen der Glera-Traube.",
    "qEn": "How is Prosecco Superiore DOCG made sparkling?",
    "qDe": "Wie entsteht die Kohlensäure bei Prosecco Superiore DOCG?",
    "optEn": [
      "Secondary fermentation in stainless steel pressure autoclaves (Charmat method)",
      "Bottle fermentation like Champagne",
      "Injected CO2 gas",
      "Dry ice added"
    ],
    "optDe": [
      "Zweite Gärung im Edelstahldrucktank (Charmat-/Martinotti-Verfahren)",
      "Flaschengärung wie Champagner",
      "Kohlensäure eingepumpt",
      "Trockeneiszugabe"
    ],
    "correct": 0,
    "expEn": "Tank fermentation preserves fresh floral and fruit aromatics of Glera.",
    "expDe": "Die Tankgärung bewahrt die frischen Primäraromen der Glera-Traube."
  },
  {
    "id": "q_wine_18",
    "category": "wine",
    "questionEn": "What defines Orange Wine?",
    "questionDe": "Was kennzeichnet sogenannten Orange Wine?",
    "optionsEn": [
      "White grapes fermented with skins and seeds for weeks/months like red wine",
      "White wine with orange zest",
      "Fermented Spanish oranges",
      "Red wine bleached with charcoal"
    ],
    "optionsDe": [
      "Weißweintrauben werden wie Rotwein lange auf der Maische (Schalen) vergoren",
      "Weißwein mit Zitrusschale",
      "Aus Orangen vergoren",
      "Mit Kohle entfärbter Rotwein"
    ],
    "correctIndex": 0,
    "explanationEn": "Skin contact gives amber hue and tannic structure to white grapes.",
    "explanationDe": "Die Maischegärung verleiht dem Weißwein Gerbstoffe und Bernsteinfarbe.",
    "qEn": "What defines Orange Wine?",
    "qDe": "Was kennzeichnet sogenannten Orange Wine?",
    "optEn": [
      "White grapes fermented with skins and seeds for weeks/months like red wine",
      "White wine with orange zest",
      "Fermented Spanish oranges",
      "Red wine bleached with charcoal"
    ],
    "optDe": [
      "Weißweintrauben werden wie Rotwein lange auf der Maische (Schalen) vergoren",
      "Weißwein mit Zitrusschale",
      "Aus Orangen vergoren",
      "Mit Kohle entfärbter Rotwein"
    ],
    "correct": 0,
    "expEn": "Skin contact gives amber hue and tannic structure to white grapes.",
    "expDe": "Die Maischegärung verleiht dem Weißwein Gerbstoffe und Bernsteinfarbe."
  },
  {
    "id": "q_tea_01",
    "category": "tea",
    "questionEn": "Which essential oil gives Earl Grey tea its citrus aroma?",
    "questionDe": "Welches ätherische Öl aromatisiert klassischen Earl Grey Tee?",
    "optionsEn": [
      "Bergamot orange peel oil",
      "Lemon grass oil",
      "Orange blossom water",
      "Lime leaf oil"
    ],
    "optionsDe": [
      "Öl aus der Schale der Bergamotte",
      "Zitronengrasöl",
      "Orangenblütenwasser",
      "Limettenblattöl"
    ],
    "correctIndex": 0,
    "explanationEn": "Earl Grey is black tea scented with oil of Citrus bergamia.",
    "explanationDe": "Earl Grey wird mit kaltgepresstem Bergamottöl aromatisiert.",
    "qEn": "Which essential oil gives Earl Grey tea its citrus aroma?",
    "qDe": "Welches ätherische Öl aromatisiert klassischen Earl Grey Tee?",
    "optEn": [
      "Bergamot orange peel oil",
      "Lemon grass oil",
      "Orange blossom water",
      "Lime leaf oil"
    ],
    "optDe": [
      "Öl aus der Schale der Bergamotte",
      "Zitronengrasöl",
      "Orangenblütenwasser",
      "Limettenblattöl"
    ],
    "correct": 0,
    "expEn": "Earl Grey is black tea scented with oil of Citrus bergamia.",
    "expDe": "Earl Grey wird mit kaltgepresstem Bergamottöl aromatisiert."
  },
  {
    "id": "q_tea_02",
    "category": "tea",
    "questionEn": "Why are Matcha tea bushes shaded before harvest?",
    "questionDe": "Warum werden Matcha-Teesträucher vor der Ernte wochenlang beschattet?",
    "optionsEn": [
      "Increases chlorophyll and L-theanine for intense umami and sweet notes",
      "Protects against hail",
      "Dries leaves on bush",
      "Reduces caffeine to zero"
    ],
    "optionsDe": [
      "Fördert Chlorophyll und L-Theanin für tiefes Umami und mindert Bitterkeit",
      "Schützt vor Hagel",
      "Dörrt Blätter am Strauch",
      "Senkt Koffein auf null"
    ],
    "correctIndex": 0,
    "explanationEn": "Shading blocks photosynthesis, preserving savory theanine amino acids.",
    "explanationDe": "Lichtentzug verhindert den Abbau von süßem L-Theanin zu herben Catechinen.",
    "qEn": "Why are Matcha tea bushes shaded before harvest?",
    "qDe": "Warum werden Matcha-Teesträucher vor der Ernte wochenlang beschattet?",
    "optEn": [
      "Increases chlorophyll and L-theanine for intense umami and sweet notes",
      "Protects against hail",
      "Dries leaves on bush",
      "Reduces caffeine to zero"
    ],
    "optDe": [
      "Fördert Chlorophyll und L-Theanin für tiefes Umami und mindert Bitterkeit",
      "Schützt vor Hagel",
      "Dörrt Blätter am Strauch",
      "Senkt Koffein auf null"
    ],
    "correct": 0,
    "expEn": "Shading blocks photosynthesis, preserving savory theanine amino acids.",
    "expDe": "Lichtentzug verhindert den Abbau von süßem L-Theanin zu herben Catechinen."
  },
  {
    "id": "q_tea_03",
    "category": "tea",
    "questionEn": "Why should high-grade Japanese green tea (Gyokuro) never be brewed with 100°C water?",
    "questionDe": "Warum darf edler Gyokuro-Grüntee nicht mit kochendem 100°C Wasser gebrüht werden?",
    "optionsEn": [
      "Boiling water scalds leaves and extracts bitter catechins excessively",
      "Boiling destroys caffeine",
      "Tea cup cracks",
      "Leaves dissolve completely"
    ],
    "optionsDe": [
      "Kochendes Wasser löst aggressive Bitterstoffe und zerstört zartes Umami",
      "Kochen zerstört Koffein",
      "Tassen zerspringen",
      "Blätter lösen sich auf"
    ],
    "correctIndex": 0,
    "explanationEn": "60°C to 70°C gently extracts amino acids without bitter tannin astringency.",
    "explanationDe": "Ideale Temperaturen von 60-70°C lösen Aminosäuren ohne aggressive Herbe.",
    "qEn": "Why should high-grade Japanese green tea (Gyokuro) never be brewed with 100°C water?",
    "qDe": "Warum darf edler Gyokuro-Grüntee nicht mit kochendem 100°C Wasser gebrüht werden?",
    "optEn": [
      "Boiling water scalds leaves and extracts bitter catechins excessively",
      "Boiling destroys caffeine",
      "Tea cup cracks",
      "Leaves dissolve completely"
    ],
    "optDe": [
      "Kochendes Wasser löst aggressive Bitterstoffe und zerstört zartes Umami",
      "Kochen zerstört Koffein",
      "Tassen zerspringen",
      "Blätter lösen sich auf"
    ],
    "correct": 0,
    "expEn": "60°C to 70°C gently extracts amino acids without bitter tannin astringency.",
    "expDe": "Ideale Temperaturen von 60-70°C lösen Aminosäuren ohne aggressive Herbe."
  },
  {
    "id": "q_tea_04",
    "category": "tea",
    "questionEn": "What defines Oolong tea in processing?",
    "questionDe": "Was zeichnet Oolong-Tee verarbeitungstechnisch aus?",
    "optionsEn": [
      "Semi-oxidized (partially fermented) between green and black tea (15-80%)",
      "Underground vinegar fermented",
      "Smoked over pine wood",
      "100% white tea buds"
    ],
    "optionsDe": [
      "Teilfermentiert (teiloxidiert) zwischen Grün- und Schwarztee (15-80%)",
      "Mit Essig fermentiert",
      "Über Kiefernholz geräuchert",
      "Reine weiße Knospen"
    ],
    "correctIndex": 0,
    "explanationEn": "Controlled bruising and roasting create complex floral and roasted fruit nuances.",
    "explanationDe": "Durch gezieltes Anschlagen der Blattränder wird der Oxidationsgrad präzise gesteuert.",
    "qEn": "What defines Oolong tea in processing?",
    "qDe": "Was zeichnet Oolong-Tee verarbeitungstechnisch aus?",
    "optEn": [
      "Semi-oxidized (partially fermented) between green and black tea (15-80%)",
      "Underground vinegar fermented",
      "Smoked over pine wood",
      "100% white tea buds"
    ],
    "optDe": [
      "Teilfermentiert (teiloxidiert) zwischen Grün- und Schwarztee (15-80%)",
      "Mit Essig fermentiert",
      "Über Kiefernholz geräuchert",
      "Reine weiße Knospen"
    ],
    "correct": 0,
    "expEn": "Controlled bruising and roasting create complex floral and roasted fruit nuances.",
    "expDe": "Durch gezieltes Anschlagen der Blattränder wird der Oxidationsgrad präzise gesteuert."
  },
  {
    "id": "q_tea_05",
    "category": "tea",
    "questionEn": "What distinguishes Darjeeling First Flush from Second Flush?",
    "questionDe": "Was unterscheidet Darjeeling First Flush von Second Flush?",
    "optionsEn": [
      "First Flush is spring harvested, pale, brisk, and floral; Second Flush is amber and muscatel",
      "First Flush is mint tea",
      "First Flush has zero caffeine",
      "Second Flush is artificially flavored"
    ],
    "optionsDe": [
      "First Flush (Frühjahr) ist spritzig-hell und blumig; Second Flush ist bernsteinfarben mit Muskatellernote",
      "First Flush ist Kräutertee",
      "First Flush hat kein Koffein",
      "Second Flush ist künstlich aromatisiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Spring flushes yield fresh green brightness; summer sun develops ripe muscatel notes.",
    "explanationDe": "Die Frühjahrsernte bringt zarte Frische, die Sommersonne reife Muskatellertöne.",
    "qEn": "What distinguishes Darjeeling First Flush from Second Flush?",
    "qDe": "Was unterscheidet Darjeeling First Flush von Second Flush?",
    "optEn": [
      "First Flush is spring harvested, pale, brisk, and floral; Second Flush is amber and muscatel",
      "First Flush is mint tea",
      "First Flush has zero caffeine",
      "Second Flush is artificially flavored"
    ],
    "optDe": [
      "First Flush (Frühjahr) ist spritzig-hell und blumig; Second Flush ist bernsteinfarben mit Muskatellernote",
      "First Flush ist Kräutertee",
      "First Flush hat kein Koffein",
      "Second Flush ist künstlich aromatisiert"
    ],
    "correct": 0,
    "expEn": "Spring flushes yield fresh green brightness; summer sun develops ripe muscatel notes.",
    "expDe": "Die Frühjahrsernte bringt zarte Frische, die Sommersonne reife Muskatellertöne."
  },
  {
    "id": "q_tea_06",
    "category": "tea",
    "questionEn": "Where is caffeine-free Rooibos tea cultivated?",
    "questionDe": "Wo wird der koffeinfreie Rooibos-Tee angebaut?",
    "optionsEn": [
      "Cederberg mountains of South Africa",
      "Mount Fuji in Japan",
      "Argentine pampas",
      "Atlas mountains in Morocco"
    ],
    "optionsDe": [
      "Cederberge in Südafrika",
      "Fuji in Japan",
      "Argentinische Pampa",
      "Atlasgebirge in Marokko"
    ],
    "correctIndex": 0,
    "explanationEn": "Aspalathus linearis is endemic to the Western Cape of South Africa.",
    "explanationDe": "Rooibos wächst als endemischer Rotbusch ausschließlich in Südafrika.",
    "qEn": "Where is caffeine-free Rooibos tea cultivated?",
    "qDe": "Wo wird der koffeinfreie Rooibos-Tee angebaut?",
    "optEn": [
      "Cederberg mountains of South Africa",
      "Mount Fuji in Japan",
      "Argentine pampas",
      "Atlas mountains in Morocco"
    ],
    "optDe": [
      "Cederberge in Südafrika",
      "Fuji in Japan",
      "Argentinische Pampa",
      "Atlasgebirge in Marokko"
    ],
    "correct": 0,
    "expEn": "Aspalathus linearis is endemic to the Western Cape of South Africa.",
    "expDe": "Rooibos wächst als endemischer Rotbusch ausschließlich in Südafrika."
  },
  {
    "id": "q_tea_07",
    "category": "tea",
    "questionEn": "What describes Pai Mu Tan (White Peony) processing?",
    "questionDe": "Was kennzeichnet die Herstellung von Weißem Tee (Pai Mu Tan)?",
    "optionsEn": [
      "Minimal processing: young silvery buds and leaves naturally sun-withered without rolling",
      "Heavy charcoal roasting",
      "Crushed by rollers",
      "Smoked in bamboo baskets"
    ],
    "optionsDe": [
      "Minimale Verarbeitung: zarte Knospen werden nur sonnengetrocknet, ohne Rollen oder Hitze",
      "Starke Röstung",
      "Maschinell zerkleinert",
      "In Bambus geräuchert"
    ],
    "correctIndex": 0,
    "explanationEn": "White tea is the least processed tea, retaining silvery down hairs and sweet melon notes.",
    "explanationDe": "Weißer Tee wird kaum bearbeitet und behält seinen samtig-milden Charakter.",
    "qEn": "What describes Pai Mu Tan (White Peony) processing?",
    "qDe": "Was kennzeichnet die Herstellung von Weißem Tee (Pai Mu Tan)?",
    "optEn": [
      "Minimal processing: young silvery buds and leaves naturally sun-withered without rolling",
      "Heavy charcoal roasting",
      "Crushed by rollers",
      "Smoked in bamboo baskets"
    ],
    "optDe": [
      "Minimale Verarbeitung: zarte Knospen werden nur sonnengetrocknet, ohne Rollen oder Hitze",
      "Starke Röstung",
      "Maschinell zerkleinert",
      "In Bambus geräuchert"
    ],
    "correct": 0,
    "expEn": "White tea is the least processed tea, retaining silvery down hairs and sweet melon notes.",
    "expDe": "Weißer Tee wird kaum bearbeitet und behält seinen samtig-milden Charakter."
  },
  {
    "id": "q_tea_08",
    "category": "tea",
    "questionEn": "How is Chinese Jasmine tea naturally scented?",
    "questionDe": "Wie wird traditioneller Jasmintee aromatisiert?",
    "optionsEn": [
      "Fresh night-blooming jasmine blossoms are layered with green tea leaves repeatedly",
      "Jasmine oil is sprayed",
      "Boiled in jasmine water",
      "Stored in jasmine wood"
    ],
    "optionsDe": [
      "Frische, nachts duftende Jasminblüten werden schichtweise mit Teeblättern vermengt",
      "Jasminöl wird aufgesprüht",
      "In Jasminwasser gekocht",
      "In Jasmingefäßen gelagert"
    ],
    "correctIndex": 0,
    "explanationEn": "Green tea leaves absorb the natural essential oils of opening flowers.",
    "explanationDe": "Teeblätter nehmen das ätherische Öl frisch aufblühender Jasminblüten auf.",
    "qEn": "How is Chinese Jasmine tea naturally scented?",
    "qDe": "Wie wird traditioneller Jasmintee aromatisiert?",
    "optEn": [
      "Fresh night-blooming jasmine blossoms are layered with green tea leaves repeatedly",
      "Jasmine oil is sprayed",
      "Boiled in jasmine water",
      "Stored in jasmine wood"
    ],
    "optDe": [
      "Frische, nachts duftende Jasminblüten werden schichtweise mit Teeblättern vermengt",
      "Jasminöl wird aufgesprüht",
      "In Jasminwasser gekocht",
      "In Jasmingefäßen gelagert"
    ],
    "correct": 0,
    "expEn": "Green tea leaves absorb the natural essential oils of opening flowers.",
    "expDe": "Teeblätter nehmen das ätherische Öl frisch aufblühender Jasminblüten auf."
  },
  {
    "id": "q_tea_09",
    "category": "tea",
    "questionEn": "What transformation occurs during aging of Pu-Erh tea?",
    "questionDe": "Was passiert während der Reifung von Pu-Erh-Tee?",
    "optionsEn": [
      "True post-fermentation driven by microbial fungi and bacteria over years",
      "Alcoholic fermentation into beer",
      "Carbonation by yeast",
      "Dairy yogurt fermentation"
    ],
    "optionsDe": [
      "Echte mikrobielle Nachfermentation durch Edelschimmel und Bakterien über Jahre",
      "Alkoholische Gärung",
      "Kohlensäurebildung",
      "Milchsäuregärung"
    ],
    "correctIndex": 0,
    "explanationEn": "Pu-Erh matures living cultures, developing earthy, forest floor and leather aromatics.",
    "explanationDe": "Pu-Erh reift mikrobiell und entwickelt tiefe erdige, holzige Noten.",
    "qEn": "What transformation occurs during aging of Pu-Erh tea?",
    "qDe": "Was passiert während der Reifung von Pu-Erh-Tee?",
    "optEn": [
      "True post-fermentation driven by microbial fungi and bacteria over years",
      "Alcoholic fermentation into beer",
      "Carbonation by yeast",
      "Dairy yogurt fermentation"
    ],
    "optDe": [
      "Echte mikrobielle Nachfermentation durch Edelschimmel und Bakterien über Jahre",
      "Alkoholische Gärung",
      "Kohlensäurebildung",
      "Milchsäuregärung"
    ],
    "correct": 0,
    "expEn": "Pu-Erh matures living cultures, developing earthy, forest floor and leather aromatics.",
    "expDe": "Pu-Erh reift mikrobiell und entwickelt tiefe erdige, holzige Noten."
  },
  {
    "id": "q_tea_10",
    "category": "tea",
    "questionEn": "Which tea region gives English Breakfast its bold malty body?",
    "questionDe": "Welche Teeregion schenkt dem English Breakfast seinen malzigen Körper?",
    "optionsEn": [
      "Assam in India",
      "Darjeeling",
      "Japanese Shizuoka",
      "Fujian white tea"
    ],
    "optionsDe": [
      "Assam in Indien",
      "Darjeeling",
      "Shizuoka in Japan",
      "Fujian in China"
    ],
    "correctIndex": 0,
    "explanationEn": "Assam black tea provides deep malty strength that cuts through whole milk.",
    "explanationDe": "Assam liefert den kräftigen Malzkörper, der perfekt mit Milch harmoniert.",
    "qEn": "Which tea region gives English Breakfast its bold malty body?",
    "qDe": "Welche Teeregion schenkt dem English Breakfast seinen malzigen Körper?",
    "optEn": [
      "Assam in India",
      "Darjeeling",
      "Japanese Shizuoka",
      "Fujian white tea"
    ],
    "optDe": [
      "Assam in Indien",
      "Darjeeling",
      "Shizuoka in Japan",
      "Fujian in China"
    ],
    "correct": 0,
    "expEn": "Assam black tea provides deep malty strength that cuts through whole milk.",
    "expDe": "Assam liefert den kräftigen Malzkörper, der perfekt mit Milch harmoniert."
  },
  {
    "id": "q_tea_11",
    "category": "tea",
    "questionEn": "How is Lapsang Souchong smoked?",
    "questionDe": "Wie wird Lapsang Souchong geräuchert?",
    "optionsEn": [
      "Over burning pine wood fires (Pinus massoniana)",
      "With liquid hickory smoke",
      "Over volcanic coals",
      "In peated whisky barrels"
    ],
    "optionsDe": [
      "Über brennendem harzreichem Kiefernholzfeuer",
      "Mit künstlichem Raucharoma",
      "Über Vulkankohle",
      "In Torffässern"
    ],
    "correctIndex": 0,
    "explanationEn": "Pine resin smoke permeates the tea cells with campfire and dried prune notes.",
    "explanationDe": "Kiefernharzfeuer verleiht dem Tee harzige Rauch- und Teernoten.",
    "qEn": "How is Lapsang Souchong smoked?",
    "qDe": "Wie wird Lapsang Souchong geräuchert?",
    "optEn": [
      "Over burning pine wood fires (Pinus massoniana)",
      "With liquid hickory smoke",
      "Over volcanic coals",
      "In peated whisky barrels"
    ],
    "optDe": [
      "Über brennendem harzreichem Kiefernholzfeuer",
      "Mit künstlichem Raucharoma",
      "Über Vulkankohle",
      "In Torffässern"
    ],
    "correct": 0,
    "expEn": "Pine resin smoke permeates the tea cells with campfire and dried prune notes.",
    "expDe": "Kiefernharzfeuer verleiht dem Tee harzige Rauch- und Teernoten."
  },
  {
    "id": "q_tea_12",
    "category": "tea",
    "questionEn": "Why use a bamboo whisk (Chasen) for Matcha?",
    "questionDe": "Warum schlägt man Matcha mit dem Bambusbesen (Chasen)?",
    "optionsEn": [
      "Creates a micro-foamed silky suspension of powdered leaf in water",
      "Measures temperature",
      "Strains leaves",
      "Sweetens the drink"
    ],
    "optionsDe": [
      "Schlägt das feine Blattpulver zu einer sämigen Emulsion mit feinstem Schaum auf",
      "Misst Temperatur",
      "Filtert Blätter",
      "Süßt den Tee"
    ],
    "correctIndex": 0,
    "explanationEn": "Matcha is ingested as whole ground leaf, requiring mechanical aeration.",
    "explanationDe": "Der Chasen emulgiert das unlösliche Teepulver zu einer sämigen Schaumkrone.",
    "qEn": "Why use a bamboo whisk (Chasen) for Matcha?",
    "qDe": "Warum schlägt man Matcha mit dem Bambusbesen (Chasen)?",
    "optEn": [
      "Creates a micro-foamed silky suspension of powdered leaf in water",
      "Measures temperature",
      "Strains leaves",
      "Sweetens the drink"
    ],
    "optDe": [
      "Schlägt das feine Blattpulver zu einer sämigen Emulsion mit feinstem Schaum auf",
      "Misst Temperatur",
      "Filtert Blätter",
      "Süßt den Tee"
    ],
    "correct": 0,
    "expEn": "Matcha is ingested as whole ground leaf, requiring mechanical aeration.",
    "expDe": "Der Chasen emulgiert das unlösliche Teepulver zu einer sämigen Schaumkrone."
  },
  {
    "id": "q_tea_13",
    "category": "tea",
    "questionEn": "How is Japanese green tea enzyme activity halted?",
    "questionDe": "Wie wird die Fermentation bei japanischem Grüntee gestoppt?",
    "optionsEn": [
      "Brief steaming (preserving green color and maritime vegetal flavor)",
      "Pan-firing in woks",
      "Sun-basking",
      "Smoking"
    ],
    "optionsDe": [
      "Kurzes Dämpfen mit heißem Wasserdampf (erhält smaragdgrüne Farbe)",
      "Rösten im Wok",
      "Sonnenbad",
      "Räuchern"
    ],
    "correctIndex": 0,
    "explanationEn": "Steaming preserves chlorophyll and marine grassy sweetness.",
    "explanationDe": "Wasserdampf schont das Chlorophyll und erzeugt das maritime Grasprofil.",
    "qEn": "How is Japanese green tea enzyme activity halted?",
    "qDe": "Wie wird die Fermentation bei japanischem Grüntee gestoppt?",
    "optEn": [
      "Brief steaming (preserving green color and maritime vegetal flavor)",
      "Pan-firing in woks",
      "Sun-basking",
      "Smoking"
    ],
    "optDe": [
      "Kurzes Dämpfen mit heißem Wasserdampf (erhält smaragdgrüne Farbe)",
      "Rösten im Wok",
      "Sonnenbad",
      "Räuchern"
    ],
    "correct": 0,
    "expEn": "Steaming preserves chlorophyll and marine grassy sweetness.",
    "expDe": "Wasserdampf schont das Chlorophyll und erzeugt das maritime Grasprofil."
  },
  {
    "id": "q_tea_14",
    "category": "tea",
    "questionEn": "What grain is added to Genmaicha?",
    "questionDe": "Welches Getreide wird japanischem Genmaicha beigemischt?",
    "optionsEn": [
      "Roasted brown rice grains (partly popped)",
      "Toasted sesame seeds",
      "Puffed barley",
      "Fried corn"
    ],
    "optionsDe": [
      "Gerösteter Naturreis (teilweise gepoppt)",
      "Gerösteter Sesam",
      "Gerste",
      "Maisflocken"
    ],
    "correctIndex": 0,
    "explanationEn": "Roasted brown rice adds warm popcorn and nutty toast flavors.",
    "explanationDe": "Gerösteter Naturreis schenkt eine nussige, wärmende Getreidenote.",
    "qEn": "What grain is added to Genmaicha?",
    "qDe": "Welches Getreide wird japanischem Genmaicha beigemischt?",
    "optEn": [
      "Roasted brown rice grains (partly popped)",
      "Toasted sesame seeds",
      "Puffed barley",
      "Fried corn"
    ],
    "optDe": [
      "Gerösteter Naturreis (teilweise gepoppt)",
      "Gerösteter Sesam",
      "Gerste",
      "Maisflocken"
    ],
    "correct": 0,
    "expEn": "Roasted brown rice adds warm popcorn and nutty toast flavors.",
    "expDe": "Gerösteter Naturreis schenkt eine nussige, wärmende Getreidenote."
  },
  {
    "id": "q_tea_15",
    "category": "tea",
    "questionEn": "Which base tea is used in Moroccan mint tea?",
    "questionDe": "Welcher Basis-Tee wird für marokkanischen Minztee verwendet?",
    "optionsEn": [
      "Chinese Gunpowder green tea",
      "Matcha powder",
      "Silver Needle",
      "English Breakfast"
    ],
    "optionsDe": [
      "Chinesischer Gunpowder-Grüntee (gerollte Kügelchen)",
      "Matcha-Pulver",
      "Weißer Tee",
      "Schwarztee"
    ],
    "correctIndex": 0,
    "explanationEn": "Pelletized Gunpowder holds up to boiling water and fresh Nana mint.",
    "explanationDe": "Fest gerollter Gunpowder verträgt das Aufkochen mit Minze und Zucker.",
    "qEn": "Which base tea is used in Moroccan mint tea?",
    "qDe": "Welcher Basis-Tee wird für marokkanischen Minztee verwendet?",
    "optEn": [
      "Chinese Gunpowder green tea",
      "Matcha powder",
      "Silver Needle",
      "English Breakfast"
    ],
    "optDe": [
      "Chinesischer Gunpowder-Grüntee (gerollte Kügelchen)",
      "Matcha-Pulver",
      "Weißer Tee",
      "Schwarztee"
    ],
    "correct": 0,
    "expEn": "Pelletized Gunpowder holds up to boiling water and fresh Nana mint.",
    "expDe": "Fest gerollter Gunpowder verträgt das Aufkochen mit Minze und Zucker."
  },
  {
    "id": "q_tea_16",
    "category": "tea",
    "questionEn": "Why does oversteeped black tea taste bitter and dry?",
    "questionDe": "Warum wird Schwarztee nach mehr als 5 Minuten bitter und pelzig?",
    "optionsEn": [
      "Heavy polyphenolic tannins leach out continuously after initial caffeine release",
      "Water turns into syrup",
      "All oxygen escapes",
      "Calcium precipitates"
    ],
    "optionsDe": [
      "Schwere Gerbstoffe (Tannine) diffundieren nach den ersten Minuten massiv aus",
      "Wasser verdampft",
      "Sauerstoff fehlt",
      "Kalk flockt aus"
    ],
    "correctIndex": 0,
    "explanationEn": "After 3 minutes, bitter tannins dominate the liquor and bind to tongue proteins.",
    "explanationDe": "Nach 3 Minuten lösen sich schwere Gerbsäuren, die den Mund austrocknen.",
    "qEn": "Why does oversteeped black tea taste bitter and dry?",
    "qDe": "Warum wird Schwarztee nach mehr als 5 Minuten bitter und pelzig?",
    "optEn": [
      "Heavy polyphenolic tannins leach out continuously after initial caffeine release",
      "Water turns into syrup",
      "All oxygen escapes",
      "Calcium precipitates"
    ],
    "optDe": [
      "Schwere Gerbstoffe (Tannine) diffundieren nach den ersten Minuten massiv aus",
      "Wasser verdampft",
      "Sauerstoff fehlt",
      "Kalk flockt aus"
    ],
    "correct": 0,
    "expEn": "After 3 minutes, bitter tannins dominate the liquor and bind to tongue proteins.",
    "expDe": "Nach 3 Minuten lösen sich schwere Gerbsäuren, die den Mund austrocknen."
  },
  {
    "id": "q_tea_17",
    "category": "tea",
    "questionEn": "Which whole spices belong in classic Indian Masala Chai?",
    "questionDe": "Welche Gewürze gehören in traditionellen indischen Masala Chai?",
    "optionsEn": [
      "Cardamom, fresh ginger, cinnamon, cloves, and black pepper",
      "Vanilla, chili, and nutmeg",
      "Cumin, coriander, and garlic",
      "Dill and bay leaves"
    ],
    "optionsDe": [
      "Kardamom, Ingwer, Zimt, Nelken und schwarzer Pfeffer",
      "Vanille, Chili und Muskat",
      "Kreuzkümmel und Knoblauch",
      "Dill und Lorbeer"
    ],
    "correctIndex": 0,
    "explanationEn": "Simmering spices with full-fat milk and black tea creates comforting emulsified warmth.",
    "explanationDe": "In Milch ausgekochte Gewürze ergeben das wärmende Chai-Aroma.",
    "qEn": "Which whole spices belong in classic Indian Masala Chai?",
    "qDe": "Welche Gewürze gehören in traditionellen indischen Masala Chai?",
    "optEn": [
      "Cardamom, fresh ginger, cinnamon, cloves, and black pepper",
      "Vanilla, chili, and nutmeg",
      "Cumin, coriander, and garlic",
      "Dill and bay leaves"
    ],
    "optDe": [
      "Kardamom, Ingwer, Zimt, Nelken und schwarzer Pfeffer",
      "Vanille, Chili und Muskat",
      "Kreuzkümmel und Knoblauch",
      "Dill und Lorbeer"
    ],
    "correct": 0,
    "expEn": "Simmering spices with full-fat milk and black tea creates comforting emulsified warmth.",
    "expDe": "In Milch ausgekochte Gewürze ergeben das wärmende Chai-Aroma."
  },
  {
    "id": "q_tea_18",
    "category": "tea",
    "questionEn": "Why is Cold Brew tea naturally sweeter than iced hot tea?",
    "questionDe": "Warum schmeckt Cold-Brew-Tee süßer und milder als abgekühlter Heißtee?",
    "optionsEn": [
      "Cold water extracts sweet amino acids while leaving bitter tannins trapped in leaves",
      "Refrigerators add sugar",
      "Cold destroys caffeine",
      "Acid evaporates in the fridge"
    ],
    "optionsDe": [
      "Kaltes Wasser löst süße Aminosäuren, während herbe Gerbstoffe im Blatt bleiben",
      "Kälte bildet Zucker",
      "Koffein wird zerstört",
      "Säure verdampft"
    ],
    "correctIndex": 0,
    "explanationEn": "Tannins require hot water to dissolve; cold extraction yields silky sweetness.",
    "explanationDe": "Gerbstoffe brauchen Hitze; im kalten Wasser diffundieren nur milde Aromen.",
    "qEn": "Why is Cold Brew tea naturally sweeter than iced hot tea?",
    "qDe": "Warum schmeckt Cold-Brew-Tee süßer und milder als abgekühlter Heißtee?",
    "optEn": [
      "Cold water extracts sweet amino acids while leaving bitter tannins trapped in leaves",
      "Refrigerators add sugar",
      "Cold destroys caffeine",
      "Acid evaporates in the fridge"
    ],
    "optDe": [
      "Kaltes Wasser löst süße Aminosäuren, während herbe Gerbstoffe im Blatt bleiben",
      "Kälte bildet Zucker",
      "Koffein wird zerstört",
      "Säure verdampft"
    ],
    "correct": 0,
    "expEn": "Tannins require hot water to dissolve; cold extraction yields silky sweetness.",
    "expDe": "Gerbstoffe brauchen Hitze; im kalten Wasser diffundieren nur milde Aromen."
  },
  {
    "id": "q_cof_01",
    "category": "coffee",
    "questionEn": "What defines authentic Italian espresso brewing parameters?",
    "questionDe": "Was sind die Richtwerte für klassischen italienischen Espresso (INIE)?",
    "optionsEn": [
      "25ml extracted in 25 seconds from 7g coffee at 9 bar pressure",
      "100ml in 1 minute from 20g",
      "50ml in 10 seconds at 2 bar",
      "Instant powder dissolved in boiling water"
    ],
    "optionsDe": [
      "25 ml Extraktion in 25 Sekunden aus 7g Mahlgut bei 9 bar Brühdruck",
      "100 ml in 1 Minute aus 20g",
      "50 ml in 10 Sekunden bei 2 bar",
      "Löslicher Kaffee mit kochendem Wasser"
    ],
    "correctIndex": 0,
    "explanationEn": "The Italian Espresso National Institute defines 25ml ± 2.5ml in 25 seconds at 9 bar and 88-92°C.",
    "explanationDe": "Das Istituto Nazionale Espresso Italiano definiert 25 ml in 25 Sekunden bei 9 bar Druck.",
    "qEn": "What defines authentic Italian espresso brewing parameters?",
    "qDe": "Was sind die Richtwerte für klassischen italienischen Espresso (INIE)?",
    "optEn": [
      "25ml extracted in 25 seconds from 7g coffee at 9 bar pressure",
      "100ml in 1 minute from 20g",
      "50ml in 10 seconds at 2 bar",
      "Instant powder dissolved in boiling water"
    ],
    "optDe": [
      "25 ml Extraktion in 25 Sekunden aus 7g Mahlgut bei 9 bar Brühdruck",
      "100 ml in 1 Minute aus 20g",
      "50 ml in 10 Sekunden bei 2 bar",
      "Löslicher Kaffee mit kochendem Wasser"
    ],
    "correct": 0,
    "expEn": "The Italian Espresso National Institute defines 25ml ± 2.5ml in 25 seconds at 9 bar and 88-92°C.",
    "expDe": "Das Istituto Nazionale Espresso Italiano definiert 25 ml in 25 Sekunden bei 9 bar Druck."
  },
  {
    "id": "q_cof_02",
    "category": "coffee",
    "questionEn": "What creates the golden crema layer on an espresso?",
    "questionDe": "Woraus besteht die goldbraune Crema auf einem Espresso?",
    "optionsEn": [
      "Carbon dioxide gas emulsified with coffee oils and microscopic solids under pressure",
      "Milk foam added on top",
      "Caramelized sugar syrup",
      "Chemical froth agents"
    ],
    "optionsDe": [
      "Unter Druck emulgierte Kaffeeöle und CO2-Gasbläschen mit Schwebstoffen",
      "Milchschaum",
      "Karamellisierter Zuckersirup",
      "Künstlicher Schaumbildner"
    ],
    "correctIndex": 0,
    "explanationEn": "High brewing pressure forces roasted CO2 and aromatic lipids into a velvety micro-foam emulsion.",
    "explanationDe": "Der Brühdruck emulgiert Röstgase (CO2) mit den Kaffeeölen zu feinstem Schaum.",
    "qEn": "What creates the golden crema layer on an espresso?",
    "qDe": "Woraus besteht die goldbraune Crema auf einem Espresso?",
    "optEn": [
      "Carbon dioxide gas emulsified with coffee oils and microscopic solids under pressure",
      "Milk foam added on top",
      "Caramelized sugar syrup",
      "Chemical froth agents"
    ],
    "optDe": [
      "Unter Druck emulgierte Kaffeeöle und CO2-Gasbläschen mit Schwebstoffen",
      "Milchschaum",
      "Karamellisierter Zuckersirup",
      "Künstlicher Schaumbildner"
    ],
    "correct": 0,
    "expEn": "High brewing pressure forces roasted CO2 and aromatic lipids into a velvety micro-foam emulsion.",
    "expDe": "Der Brühdruck emulgiert Röstgase (CO2) mit den Kaffeeölen zu feinstem Schaum."
  },
  {
    "id": "q_cof_03",
    "category": "coffee",
    "questionEn": "What distinguishes Arabica from Robusta coffee beans chemically?",
    "questionDe": "Was unterscheidet Arabica von Robusta-Kaffeebohnen chemisch?",
    "optionsEn": [
      "Arabica has more aromatic lipids and sucrose; Robusta has almost double caffeine and chlorogenic acids",
      "Arabica has zero caffeine",
      "Robusta has no crema",
      "Arabica is always roasted black"
    ],
    "optionsDe": [
      "Arabica besitzt mehr aromatische Öle und Zucker; Robusta hat fast doppelt so viel Koffein und Chlorogensäure",
      "Arabica hat kein Koffein",
      "Robusta bildet nie Crema",
      "Arabica wird nur dunkel geröstet"
    ],
    "correctIndex": 0,
    "explanationEn": "Arabica delivers complex acidity and sweetness; Robusta provides heavy body, crema stability, and caffeine punch.",
    "explanationDe": "Arabica glänzt durch feine Säuren und Süße; Robusta bringt kräftigen Körper, Crema und Bitterstoffe.",
    "qEn": "What distinguishes Arabica from Robusta coffee beans chemically?",
    "qDe": "Was unterscheidet Arabica von Robusta-Kaffeebohnen chemisch?",
    "optEn": [
      "Arabica has more aromatic lipids and sucrose; Robusta has almost double caffeine and chlorogenic acids",
      "Arabica has zero caffeine",
      "Robusta has no crema",
      "Arabica is always roasted black"
    ],
    "optDe": [
      "Arabica besitzt mehr aromatische Öle und Zucker; Robusta hat fast doppelt so viel Koffein und Chlorogensäure",
      "Arabica hat kein Koffein",
      "Robusta bildet nie Crema",
      "Arabica wird nur dunkel geröstet"
    ],
    "correct": 0,
    "expEn": "Arabica delivers complex acidity and sweetness; Robusta provides heavy body, crema stability, and caffeine punch.",
    "expDe": "Arabica glänzt durch feine Säuren und Süße; Robusta bringt kräftigen Körper, Crema und Bitterstoffe."
  },
  {
    "id": "q_cof_04",
    "category": "coffee",
    "questionEn": "What is an Espresso Doppio?",
    "questionDe": "Was ist ein Espresso Doppio?",
    "optionsEn": [
      "A double shot of espresso (approx. 50-60ml from 14-18g ground coffee)",
      "Espresso with double sugar",
      "Espresso with double milk foam",
      "Cold espresso over ice"
    ],
    "optionsDe": [
      "Ein doppelter Espresso (ca. 50–60 ml aus 14–18g gemahlenem Kaffee)",
      "Espresso mit doppeltem Zucker",
      "Espresso mit doppelter Milchhaube",
      "Kalter Espresso auf Eis"
    ],
    "correctIndex": 0,
    "explanationEn": "Doppio means double espresso extracted through a two-spout portafilter.",
    "explanationDe": "Ein Doppio ist ein doppelter Bezug mit doppelter Kaffeemehlmenge.",
    "qEn": "What is an Espresso Doppio?",
    "qDe": "Was ist ein Espresso Doppio?",
    "optEn": [
      "A double shot of espresso (approx. 50-60ml from 14-18g ground coffee)",
      "Espresso with double sugar",
      "Espresso with double milk foam",
      "Cold espresso over ice"
    ],
    "optDe": [
      "Ein doppelter Espresso (ca. 50–60 ml aus 14–18g gemahlenem Kaffee)",
      "Espresso mit doppeltem Zucker",
      "Espresso mit doppelter Milchhaube",
      "Kalter Espresso auf Eis"
    ],
    "correct": 0,
    "expEn": "Doppio means double espresso extracted through a two-spout portafilter.",
    "expDe": "Ein Doppio ist ein doppelter Bezug mit doppelter Kaffeemehlmenge."
  },
  {
    "id": "q_cof_05",
    "category": "coffee",
    "questionEn": "How does an Espresso Macchiato differ from a Cortado?",
    "questionDe": "Wie unterscheidet sich ein Espresso Macchiato von einem Cortado?",
    "optionsEn": [
      "Macchiato has just a dollop of textured milk foam; Cortado has equal parts espresso and warm steamed milk (1:1)",
      "Macchiato is made with chocolate",
      "Cortado has no caffeine",
      "Macchiato has cold water"
    ],
    "optionsDe": [
      "Macchiato erhält nur einen kleinen Tupfer Milchschaum ('gefleckt'); Cortado besteht zu 1:1 aus Espresso und warmer Milch",
      "Macchiato enthält Schokolade",
      "Cortado ist koffeinfrei",
      "Macchiato wird mit Wasser gestreckt"
    ],
    "correctIndex": 0,
    "explanationEn": "Macchiato translates to 'stained' or 'spotted' with micro-foam.",
    "explanationDe": "'Macchiato' bedeutet 'gefleckt'; der Cortado 'schneidet' den Espresso 1:1 mit Milch.",
    "qEn": "How does an Espresso Macchiato differ from a Cortado?",
    "qDe": "Wie unterscheidet sich ein Espresso Macchiato von einem Cortado?",
    "optEn": [
      "Macchiato has just a dollop of textured milk foam; Cortado has equal parts espresso and warm steamed milk (1:1)",
      "Macchiato is made with chocolate",
      "Cortado has no caffeine",
      "Macchiato has cold water"
    ],
    "optDe": [
      "Macchiato erhält nur einen kleinen Tupfer Milchschaum ('gefleckt'); Cortado besteht zu 1:1 aus Espresso und warmer Milch",
      "Macchiato enthält Schokolade",
      "Cortado ist koffeinfrei",
      "Macchiato wird mit Wasser gestreckt"
    ],
    "correct": 0,
    "expEn": "Macchiato translates to 'stained' or 'spotted' with micro-foam.",
    "expDe": "'Macchiato' bedeutet 'gefleckt'; der Cortado 'schneidet' den Espresso 1:1 mit Milch."
  },
  {
    "id": "q_cof_06",
    "category": "coffee",
    "questionEn": "How is traditional Turkish coffee brewed in a Cezve/Ibrik?",
    "questionDe": "Wie wird traditioneller türkischer Mokka in der Cezve zubereitet?",
    "optionsEn": [
      "Ultra-fine pulverized coffee and water simmered gently together without filtering",
      "Extracted through paper drip cone",
      "Pressed in a French press",
      "Steamed under 15 bar pressure"
    ],
    "optionsDe": [
      "Staubfein gemahlener Kaffee wird mit Wasser in der Cezve erhitzt und unfiltriert serviert",
      "Durch Papierfilter getropft",
      "In der Stempelkanne gepresst",
      "Mit 15 bar Dampfdruck gebrüht"
    ],
    "correctIndex": 0,
    "explanationEn": "Turkish coffee is unfiltered; grounds settle naturally at the bottom of the fincan cup.",
    "explanationDe": "Der Mokka wird unfiltriert getrunken; der Satz setzt sich am Tassenboden ab.",
    "qEn": "How is traditional Turkish coffee brewed in a Cezve/Ibrik?",
    "qDe": "Wie wird traditioneller türkischer Mokka in der Cezve zubereitet?",
    "optEn": [
      "Ultra-fine pulverized coffee and water simmered gently together without filtering",
      "Extracted through paper drip cone",
      "Pressed in a French press",
      "Steamed under 15 bar pressure"
    ],
    "optDe": [
      "Staubfein gemahlener Kaffee wird mit Wasser in der Cezve erhitzt und unfiltriert serviert",
      "Durch Papierfilter getropft",
      "In der Stempelkanne gepresst",
      "Mit 15 bar Dampfdruck gebrüht"
    ],
    "correct": 0,
    "expEn": "Turkish coffee is unfiltered; grounds settle naturally at the bottom of the fincan cup.",
    "expDe": "Der Mokka wird unfiltriert getrunken; der Satz setzt sich am Tassenboden ab."
  },
  {
    "id": "q_cof_07",
    "category": "coffee",
    "questionEn": "What makes Vietnamese Iced Coffee (Cà phê sữa đá) unique?",
    "questionDe": "Was macht vietnamesischen Cà phê sữa đá unverwechselbar?",
    "optionsEn": [
      "Dark roasted Robusta brewed through a metal Phin filter over sweetened condensed milk and ice",
      "Espresso with coconut water only",
      "Filtered Arabica with whipped butter",
      "Green raw coffee with mint"
    ],
    "optionsDe": [
      "Dunkler Robusta-Kaffee tropft durch einen Phin-Metallfilter auf gezuckerte Kondensmilch und Eis",
      "Espresso nur mit Kokoswasser",
      "Arabica mit geschlagener Butter",
      "Grüner Rohkaffee mit Minze"
    ],
    "correctIndex": 0,
    "explanationEn": "Sweet condensed milk cuts the intense, chocolatey bitterness of drip-brewed Robusta.",
    "explanationDe": "Gezuckerte Dickmilch puffert die schokoladige Bitterkeit des kräftigen Robusta perfekt ab.",
    "qEn": "What makes Vietnamese Iced Coffee (Cà phê sữa đá) unique?",
    "qDe": "Was macht vietnamesischen Cà phê sữa đá unverwechselbar?",
    "optEn": [
      "Dark roasted Robusta brewed through a metal Phin filter over sweetened condensed milk and ice",
      "Espresso with coconut water only",
      "Filtered Arabica with whipped butter",
      "Green raw coffee with mint"
    ],
    "optDe": [
      "Dunkler Robusta-Kaffee tropft durch einen Phin-Metallfilter auf gezuckerte Kondensmilch und Eis",
      "Espresso nur mit Kokoswasser",
      "Arabica mit geschlagener Butter",
      "Grüner Rohkaffee mit Minze"
    ],
    "correct": 0,
    "expEn": "Sweet condensed milk cuts the intense, chocolatey bitterness of drip-brewed Robusta.",
    "expDe": "Gezuckerte Dickmilch puffert die schokoladige Bitterkeit des kräftigen Robusta perfekt ab."
  },
  {
    "id": "q_cof_08",
    "category": "coffee",
    "questionEn": "What is the difference between a Flat White and a Cappuccino?",
    "questionDe": "Was unterscheidet einen Flat White von einem Cappuccino?",
    "optionsEn": [
      "Flat White uses double espresso (or ristretto) with silky microfoam poured flat; Cappuccino has airy dry foam crown",
      "Flat White has whipped cream",
      "Cappuccino has cinnamon only",
      "Flat White is served cold"
    ],
    "optionsDe": [
      "Flat White nutzt doppelten Ristretto mit samtigem Mikroschaum ohne dicke Schaumkrone",
      "Flat White enthält Schlagsahne",
      "Cappuccino darf keinen Espresso haben",
      "Flat White wird kalt serviert"
    ],
    "correctIndex": 0,
    "explanationEn": "Flat White focuses on integrated silky microfoam that blends seamlessly with the crema.",
    "explanationDe": "Der Mikroschaum des Flat White verschmilzt homogen mit dem Kaffee ohne trennende Schaumhaube.",
    "qEn": "What is the difference between a Flat White and a Cappuccino?",
    "qDe": "Was unterscheidet einen Flat White von einem Cappuccino?",
    "optEn": [
      "Flat White uses double espresso (or ristretto) with silky microfoam poured flat; Cappuccino has airy dry foam crown",
      "Flat White has whipped cream",
      "Cappuccino has cinnamon only",
      "Flat White is served cold"
    ],
    "optDe": [
      "Flat White nutzt doppelten Ristretto mit samtigem Mikroschaum ohne dicke Schaumkrone",
      "Flat White enthält Schlagsahne",
      "Cappuccino darf keinen Espresso haben",
      "Flat White wird kalt serviert"
    ],
    "correct": 0,
    "expEn": "Flat White focuses on integrated silky microfoam that blends seamlessly with the crema.",
    "expDe": "Der Mikroschaum des Flat White verschmilzt homogen mit dem Kaffee ohne trennende Schaumhaube."
  },
  {
    "id": "q_cof_09",
    "category": "coffee",
    "questionEn": "What happens during the 'First Crack' in coffee roasting?",
    "questionDe": "Was geschieht beim 'First Crack' während der Kaffeeröstung?",
    "optionsEn": [
      "Trapped moisture vaporizes, expanding the bean and cracking cellulose walls audibly",
      "Beans burn to charcoal",
      "Caffeine escapes as gas",
      "Beans turn white"
    ],
    "optionsDe": [
      "Verdampfendes Wasser und Gase sprengen hörbar die Zellstruktur der Bohne auf",
      "Bohnen verbrennen zu Asche",
      "Koffein entweicht als Gas",
      "Bohnen werden weiß"
    ],
    "correctIndex": 0,
    "explanationEn": "First crack signals light roast territory (Cinnamon/City roast) with developed fruit acids.",
    "explanationDe": "Der erste Knackpunkt markiert den Beginn der genießbaren Röststufen mit lebendigen Fruchtsäuren.",
    "qEn": "What happens during the 'First Crack' in coffee roasting?",
    "qDe": "Was geschieht beim 'First Crack' während der Kaffeeröstung?",
    "optEn": [
      "Trapped moisture vaporizes, expanding the bean and cracking cellulose walls audibly",
      "Beans burn to charcoal",
      "Caffeine escapes as gas",
      "Beans turn white"
    ],
    "optDe": [
      "Verdampfendes Wasser und Gase sprengen hörbar die Zellstruktur der Bohne auf",
      "Bohnen verbrennen zu Asche",
      "Koffein entweicht als Gas",
      "Bohnen werden weiß"
    ],
    "correct": 0,
    "expEn": "First crack signals light roast territory (Cinnamon/City roast) with developed fruit acids.",
    "expDe": "Der erste Knackpunkt markiert den Beginn der genießbaren Röststufen mit lebendigen Fruchtsäuren."
  },
  {
    "id": "q_cof_10",
    "category": "coffee",
    "questionEn": "What is an Americano compared to a Long Black?",
    "questionDe": "Was unterscheidet einen Americano von einem Long Black?",
    "optionsEn": [
      "Americano adds hot water to espresso; Long Black pours espresso over hot water preserving crema",
      "Americano has cold milk",
      "Long Black has brewed drip coffee",
      "Americano is decaf"
    ],
    "optionsDe": [
      "Beim Americano wird heißes Wasser auf Espresso gegossen; beim Long Black Espresso auf heißes Wasser (erhält Crema)",
      "Americano hat kalte Milch",
      "Long Black ist Filterkaffee",
      "Americano ist entkoffeiniert"
    ],
    "correctIndex": 0,
    "explanationEn": "Pouring espresso directly onto hot water maintains the unbroken golden crema layer in Australasia.",
    "explanationDe": "Beim Long Black bleibt die Crema unzerstört, da der Espresso auf das Wasser läuft.",
    "qEn": "What is an Americano compared to a Long Black?",
    "qDe": "Was unterscheidet einen Americano von einem Long Black?",
    "optEn": [
      "Americano adds hot water to espresso; Long Black pours espresso over hot water preserving crema",
      "Americano has cold milk",
      "Long Black has brewed drip coffee",
      "Americano is decaf"
    ],
    "optDe": [
      "Beim Americano wird heißes Wasser auf Espresso gegossen; beim Long Black Espresso auf heißes Wasser (erhält Crema)",
      "Americano hat kalte Milch",
      "Long Black ist Filterkaffee",
      "Americano ist entkoffeiniert"
    ],
    "correct": 0,
    "expEn": "Pouring espresso directly onto hot water maintains the unbroken golden crema layer in Australasia.",
    "expDe": "Beim Long Black bleibt die Crema unzerstört, da der Espresso auf das Wasser läuft."
  },
  {
    "id": "q_cof_11",
    "category": "coffee",
    "questionEn": "Why does Cold Brew coffee have lower perceived acidity than hot-brewed coffee?",
    "questionDe": "Warum hat Cold Brew Kaffee spürbar weniger Säure als heiß gebrühter Kaffee?",
    "optionsEn": [
      "Cold water extracts fewer volatile chlorogenic and quinic acids",
      "Cold brew has added baking soda",
      "Cold destroys caffeine",
      "Ice neutralizes all pH"
    ],
    "optionsDe": [
      "Kaltes Wasser löst weniger temperaturempfindliche Chlorogensäuren heraus",
      "Natron wird beigemischt",
      "Kälte baut Koffein ab",
      "Eis neutralisiert die Säure"
    ],
    "correctIndex": 0,
    "explanationEn": "Cold water steeping (12-24h) minimizes bitter and sour acids while highlighting chocolate notes.",
    "explanationDe": "Die Kaltwasser-Extraktion schont den Magen, da aggressive Frucht- und Röstsäuren im Mehl bleiben.",
    "qEn": "Why does Cold Brew coffee have lower perceived acidity than hot-brewed coffee?",
    "qDe": "Warum hat Cold Brew Kaffee spürbar weniger Säure als heiß gebrühter Kaffee?",
    "optEn": [
      "Cold water extracts fewer volatile chlorogenic and quinic acids",
      "Cold brew has added baking soda",
      "Cold destroys caffeine",
      "Ice neutralizes all pH"
    ],
    "optDe": [
      "Kaltes Wasser löst weniger temperaturempfindliche Chlorogensäuren heraus",
      "Natron wird beigemischt",
      "Kälte baut Koffein ab",
      "Eis neutralisiert die Säure"
    ],
    "correct": 0,
    "expEn": "Cold water steeping (12-24h) minimizes bitter and sour acids while highlighting chocolate notes.",
    "expDe": "Die Kaltwasser-Extraktion schont den Magen, da aggressive Frucht- und Röstsäuren im Mehl bleiben."
  },
  {
    "id": "q_cof_12",
    "category": "coffee",
    "questionEn": "What is a Ristretto?",
    "questionDe": "Was ist ein Ristretto?",
    "optionsEn": [
      "A short restricted espresso shot (approx. 15-20ml) extracting only early sweet aromatics",
      "Espresso with extra hot water",
      "Triple shot of espresso",
      "Espresso with lemon juice"
    ],
    "optionsDe": [
      "Ein verkürzter Espresso (ca. 15–20 ml), der vor allem die süßen Erstaromen löst",
      "Espresso mit viel Wasser",
      "Dreifacher Espressobezug",
      "Espresso mit Zitronensaft"
    ],
    "correctIndex": 0,
    "explanationEn": "Ristretto stops before bitter polyphenols and astringent compounds extract in the tail.",
    "explanationDe": "Ein Ristretto bricht den Bezug frühzeitig ab, um Bitterstoffe der Endphase zu vermeiden.",
    "qEn": "What is a Ristretto?",
    "qDe": "Was ist ein Ristretto?",
    "optEn": [
      "A short restricted espresso shot (approx. 15-20ml) extracting only early sweet aromatics",
      "Espresso with extra hot water",
      "Triple shot of espresso",
      "Espresso with lemon juice"
    ],
    "optDe": [
      "Ein verkürzter Espresso (ca. 15–20 ml), der vor allem die süßen Erstaromen löst",
      "Espresso mit viel Wasser",
      "Dreifacher Espressobezug",
      "Espresso mit Zitronensaft"
    ],
    "correct": 0,
    "expEn": "Ristretto stops before bitter polyphenols and astringent compounds extract in the tail.",
    "expDe": "Ein Ristretto bricht den Bezug frühzeitig ab, um Bitterstoffe der Endphase zu vermeiden."
  },
  {
    "id": "q_cof_13",
    "category": "coffee",
    "questionEn": "What does 'Washed Process' (wet process) highlight in coffee beans?",
    "questionDe": "Welches Geschmacksprofil betont die nasse Aufbereitung (Washed Coffee)?",
    "optionsEn": [
      "Clean, bright cup clarity with pronounced fruit acidity and floral notes",
      "Heavy earthy body and low acidity",
      "Fermented boozy fruit notes",
      "Burnt sugar notes"
    ],
    "optionsDe": [
      "Klare Tasse mit ausgeprägter, spritziger Säure und floralen Noten",
      "Erdiger, schwerer Körper ohne Säure",
      "Starke alkoholische Fermentnoten",
      "Verbrannter Zuckergeschmack"
    ],
    "correctIndex": 0,
    "explanationEn": "Removing fruit pulp before fermentation washes away sugar mucilage, accentuating pure terroir acids.",
    "explanationDe": "Das Entpulpen und Waschen vor dem Trocknen hebt die reine Sortensäure und Terroirtöne hervor.",
    "qEn": "What does 'Washed Process' (wet process) highlight in coffee beans?",
    "qDe": "Welches Geschmacksprofil betont die nasse Aufbereitung (Washed Coffee)?",
    "optEn": [
      "Clean, bright cup clarity with pronounced fruit acidity and floral notes",
      "Heavy earthy body and low acidity",
      "Fermented boozy fruit notes",
      "Burnt sugar notes"
    ],
    "optDe": [
      "Klare Tasse mit ausgeprägter, spritziger Säure und floralen Noten",
      "Erdiger, schwerer Körper ohne Säure",
      "Starke alkoholische Fermentnoten",
      "Verbrannter Zuckergeschmack"
    ],
    "correct": 0,
    "expEn": "Removing fruit pulp before fermentation washes away sugar mucilage, accentuating pure terroir acids.",
    "expDe": "Das Entpulpen und Waschen vor dem Trocknen hebt die reine Sortensäure und Terroirtöne hervor."
  },
  {
    "id": "q_cof_14",
    "category": "coffee",
    "questionEn": "What is 'Natural Process' (dry process) coffee?",
    "questionDe": "Was versteht man unter 'Natural Coffee' (trockener Aufbereitung)?",
    "optionsEn": [
      "Whole coffee cherries are sun-dried intact on raised beds, allowing pulp sugars to soak into beans",
      "Beans are washed with detergent",
      "Beans are dried in gas ovens",
      "Green coffee is roasted raw"
    ],
    "optionsDe": [
      "Ganze Kaffeekirschen werden mit Fruchtfleisch an der Sonne getrocknet; Fruchtzucker zieht in die Bohne",
      "Bohnen werden mit Lauge gewaschen",
      "Trocknung im Gasofen",
      "Rohkaffee wird ungeschält geröstet"
    ],
    "correctIndex": 0,
    "explanationEn": "Naturals yield heavy body, sweet tropical fruit notes, and berry jam aromatics.",
    "explanationDe": "Naturals entwickeln fruchtige, beerenartige Süße und üppigen Körper durch das getrocknete Fruchtfleisch.",
    "qEn": "What is 'Natural Process' (dry process) coffee?",
    "qDe": "Was versteht man unter 'Natural Coffee' (trockener Aufbereitung)?",
    "optEn": [
      "Whole coffee cherries are sun-dried intact on raised beds, allowing pulp sugars to soak into beans",
      "Beans are washed with detergent",
      "Beans are dried in gas ovens",
      "Green coffee is roasted raw"
    ],
    "optDe": [
      "Ganze Kaffeekirschen werden mit Fruchtfleisch an der Sonne getrocknet; Fruchtzucker zieht in die Bohne",
      "Bohnen werden mit Lauge gewaschen",
      "Trocknung im Gasofen",
      "Rohkaffee wird ungeschält geröstet"
    ],
    "correct": 0,
    "expEn": "Naturals yield heavy body, sweet tropical fruit notes, and berry jam aromatics.",
    "expDe": "Naturals entwickeln fruchtige, beerenartige Süße und üppigen Körper durch das getrocknete Fruchtfleisch."
  },
  {
    "id": "q_cof_15",
    "category": "coffee",
    "questionEn": "What is the optimum milk steaming temperature for latte art?",
    "questionDe": "Welche Milchtemperatur ist ideal beim Aufschäumen für Latte Art?",
    "optionsEn": [
      "60°C to 65°C (140°F to 150°F)",
      "85°C to 95°C",
      "30°C to 35°C",
      "100°C boiling point"
    ],
    "optionsDe": [
      "60°C bis 65°C",
      "85°C bis 95°C",
      "30°C bis 35°C",
      "100°C kochend"
    ],
    "correctIndex": 0,
    "explanationEn": "Above 70°C, whey proteins denature, lactose loses perceived sweetness, and milk develops a scalded taste.",
    "explanationDe": "Über 68°C gerinnt das Milcheiweiß, die natürliche Süße der Laktose leidet und der Schaum wird grob.",
    "qEn": "What is the optimum milk steaming temperature for latte art?",
    "qDe": "Welche Milchtemperatur ist ideal beim Aufschäumen für Latte Art?",
    "optEn": [
      "60°C to 65°C (140°F to 150°F)",
      "85°C to 95°C",
      "30°C to 35°C",
      "100°C boiling point"
    ],
    "optDe": [
      "60°C bis 65°C",
      "85°C bis 95°C",
      "30°C bis 35°C",
      "100°C kochend"
    ],
    "correct": 0,
    "expEn": "Above 70°C, whey proteins denature, lactose loses perceived sweetness, and milk develops a scalded taste.",
    "expDe": "Über 68°C gerinnt das Milcheiweiß, die natürliche Süße der Laktose leidet und der Schaum wird grob."
  },
  {
    "id": "q_cof_16",
    "category": "coffee",
    "questionEn": "What causes 'Channeling' during espresso extraction?",
    "questionDe": "Was versteht man unter 'Channeling' beim Espressobezug?",
    "optionsEn": [
      "Water finds paths of least resistance through cracks or uneven grounds, causing under- and over-extraction",
      "Water pipes leak",
      "Pump vibrates",
      "Grinder stops spinning"
    ],
    "optionsDe": [
      "Wasser sucht sich Risse im Kaffeepuck, schießt ungleichmäßig durch und extrahiert fehlerhaft",
      "Wasserrohre sind undicht",
      "Pumpe vibriert zu stark",
      "Mahlwerk blockiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Uneven tamping or clumping causes water jets, producing a watery, astringent, and bitter cup.",
    "explanationDe": "Ungleichmäßiges Tampen führt zu Rissen im Kaffeemehl, durch die Wasser zu schnell herausschießt.",
    "qEn": "What causes 'Channeling' during espresso extraction?",
    "qDe": "Was versteht man unter 'Channeling' beim Espressobezug?",
    "optEn": [
      "Water finds paths of least resistance through cracks or uneven grounds, causing under- and over-extraction",
      "Water pipes leak",
      "Pump vibrates",
      "Grinder stops spinning"
    ],
    "optDe": [
      "Wasser sucht sich Risse im Kaffeepuck, schießt ungleichmäßig durch und extrahiert fehlerhaft",
      "Wasserrohre sind undicht",
      "Pumpe vibriert zu stark",
      "Mahlwerk blockiert"
    ],
    "correct": 0,
    "expEn": "Uneven tamping or clumping causes water jets, producing a watery, astringent, and bitter cup.",
    "expDe": "Ungleichmäßiges Tampen führt zu Rissen im Kaffeemehl, durch die Wasser zu schnell herausschießt."
  },
  {
    "id": "q_cof_17",
    "category": "coffee",
    "questionEn": "Why must freshly roasted coffee beans rest for several days before espresso brewing?",
    "questionDe": "Warum müssen frisch geröstete Kaffeebohnen vor dem Espressobezug einige Tage ausgasen (degassen)?",
    "optionsEn": [
      "Excess carbon dioxide gas interferes with water contact, creating turbulent, bubbly, and bitter crema",
      "To absorb moisture from air",
      "To grow yeast cultures",
      "To turn dark brown"
    ],
    "optionsDe": [
      "Überschüssiges CO2-Röstgas stört den Wasserkontakt und lässt die Crema unruhig aufschäumen",
      "Um Luftfeuchte aufzunehmen",
      "Damit Hefe wächst",
      "Um dunkel zu werden"
    ],
    "correctIndex": 0,
    "explanationEn": "Coffee releases CO2 for 5-14 days; brewing too fresh produces gassy, sour, and unstable shots.",
    "explanationDe": "Frisch gerösteter Kaffee gast CO2 aus; ohne Ruhepause stören die Blasen die Extraktion massiv.",
    "qEn": "Why must freshly roasted coffee beans rest for several days before espresso brewing?",
    "qDe": "Warum müssen frisch geröstete Kaffeebohnen vor dem Espressobezug einige Tage ausgasen (degassen)?",
    "optEn": [
      "Excess carbon dioxide gas interferes with water contact, creating turbulent, bubbly, and bitter crema",
      "To absorb moisture from air",
      "To grow yeast cultures",
      "To turn dark brown"
    ],
    "optDe": [
      "Überschüssiges CO2-Röstgas stört den Wasserkontakt und lässt die Crema unruhig aufschäumen",
      "Um Luftfeuchte aufzunehmen",
      "Damit Hefe wächst",
      "Um dunkel zu werden"
    ],
    "correct": 0,
    "expEn": "Coffee releases CO2 for 5-14 days; brewing too fresh produces gassy, sour, and unstable shots.",
    "expDe": "Frisch gerösteter Kaffee gast CO2 aus; ohne Ruhepause stören die Blasen die Extraktion massiv."
  },
  {
    "id": "q_cof_18",
    "category": "coffee",
    "questionEn": "Which coffee brewing method uses total immersion followed by gentle air pressure?",
    "questionDe": "Welche Brühmethode kombiniert Vollimmersion mit sanftem manuellem Luftdruck?",
    "optionsEn": [
      "AeroPress",
      "V60 pour over",
      "Chemex",
      "Moka pot"
    ],
    "optionsDe": [
      "AeroPress",
      "V60 Handfilter",
      "Chemex",
      "Bialetti Espressokocher"
    ],
    "correctIndex": 0,
    "explanationEn": "The AeroPress steeps grounds completely before pressing through a paper or metal filter with a plunger.",
    "explanationDe": "Die AeroPress zieht wie eine French Press und wird dann mit einem Kolben sanft durchgedrückt.",
    "qEn": "Which coffee brewing method uses total immersion followed by gentle air pressure?",
    "qDe": "Welche Brühmethode kombiniert Vollimmersion mit sanftem manuellem Luftdruck?",
    "optEn": [
      "AeroPress",
      "V60 pour over",
      "Chemex",
      "Moka pot"
    ],
    "optDe": [
      "AeroPress",
      "V60 Handfilter",
      "Chemex",
      "Bialetti Espressokocher"
    ],
    "correct": 0,
    "expEn": "The AeroPress steeps grounds completely before pressing through a paper or metal filter with a plunger.",
    "expDe": "Die AeroPress zieht wie eine French Press und wird dann mit einem Kolben sanft durchgedrückt."
  },
  {
    "id": "q_pas_01",
    "category": "pasta_rice",
    "questionEn": "Why is bronze die extrusion ('trafilata al bronzo') prized for dry pasta?",
    "questionDe": "Warum wird Pasta, die durch Bronzeformen gezogen wurde ('trafilata al bronzo'), so geschätzt?",
    "optionsEn": [
      "Creates a rough, porous, chalky surface that clings tenaciously to sauces and emulsions",
      "Makes pasta cook in 1 minute",
      "Adds yellow food coloring",
      "Prevents pasta from breaking in box"
    ],
    "optionsDe": [
      "Erzeugt eine raue, poröse Oberfläche, an der Saucen und Emulsionen perfekt haften",
      "Lässt Pasta in 1 Minute gar werden",
      "Färbt die Pasta gelb",
      "Verhindert Bruch beim Transport"
    ],
    "correctIndex": 0,
    "explanationEn": "Teflon dies leave pasta slick and shiny; bronze dies create micro-ridges that hold sauce.",
    "explanationDe": "Teflonformen machen Nudeln glatt; Bronze hinterlässt eine raue Struktur, die Sauce bindet.",
    "qEn": "Why is bronze die extrusion ('trafilata al bronzo') prized for dry pasta?",
    "qDe": "Warum wird Pasta, die durch Bronzeformen gezogen wurde ('trafilata al bronzo'), so geschätzt?",
    "optEn": [
      "Creates a rough, porous, chalky surface that clings tenaciously to sauces and emulsions",
      "Makes pasta cook in 1 minute",
      "Adds yellow food coloring",
      "Prevents pasta from breaking in box"
    ],
    "optDe": [
      "Erzeugt eine raue, poröse Oberfläche, an der Saucen und Emulsionen perfekt haften",
      "Lässt Pasta in 1 Minute gar werden",
      "Färbt die Pasta gelb",
      "Verhindert Bruch beim Transport"
    ],
    "correct": 0,
    "expEn": "Teflon dies leave pasta slick and shiny; bronze dies create micro-ridges that hold sauce.",
    "expDe": "Teflonformen machen Nudeln glatt; Bronze hinterlässt eine raue Struktur, die Sauce bindet."
  },
  {
    "id": "q_pas_02",
    "category": "pasta_rice",
    "questionEn": "What does 'Al Dente' mean in culinary pasta preparation?",
    "questionDe": "Was bedeutet 'Al Dente' bei der Pastazubereitung genau?",
    "optionsEn": [
      "Firm to the tooth with a tiny ungelatinized starch core, offering chew resistance",
      "Completely soft and mushy",
      "Crunchy raw in the center",
      "Cooked until it sticks to the wall"
    ],
    "optionsDe": [
      "Fest im Biss mit einem winzigen, stärkehaltigen Kern, der angenehmen Widerstand leistet",
      "Vollständig weich gekocht",
      "Innen steinhart und roh",
      "So weich, dass sie an der Wand klebt"
    ],
    "correctIndex": 0,
    "explanationEn": "Al dente ensures a pleasant bite, slower glycemic absorption, and pasta that won't turn to mush in sauce.",
    "explanationDe": "Pasta mit Biss behält Struktur, lässt sich perfekt in der Pfanne fertig garen und sättigt länger.",
    "qEn": "What does 'Al Dente' mean in culinary pasta preparation?",
    "qDe": "Was bedeutet 'Al Dente' bei der Pastazubereitung genau?",
    "optEn": [
      "Firm to the tooth with a tiny ungelatinized starch core, offering chew resistance",
      "Completely soft and mushy",
      "Crunchy raw in the center",
      "Cooked until it sticks to the wall"
    ],
    "optDe": [
      "Fest im Biss mit einem winzigen, stärkehaltigen Kern, der angenehmen Widerstand leistet",
      "Vollständig weich gekocht",
      "Innen steinhart und roh",
      "So weich, dass sie an der Wand klebt"
    ],
    "correct": 0,
    "expEn": "Al dente ensures a pleasant bite, slower glycemic absorption, and pasta that won't turn to mush in sauce.",
    "expDe": "Pasta mit Biss behält Struktur, lässt sich perfekt in der Pfanne fertig garen und sättigt länger."
  },
  {
    "id": "q_pas_03",
    "category": "pasta_rice",
    "questionEn": "Why should pasta cooking water ('acqua di cottura') always be reserved for finishing sauce?",
    "questionDe": "Warum sollte man beim Abgießen von Nudeln immer Pastawasser aufbewahren?",
    "optionsEn": [
      "The suspended gelatinized starch and warm salt water bind fats and liquids into a glossy emulsion ('mantecatura')",
      "To wash the pan afterwards",
      "To cool the pasta down",
      "To drink as warm broth"
    ],
    "optionsDe": [
      "Die gelöste Stärke emulgiert Fette und Saucen zu einer sämigen, glänzenden Hülle (Mantecatura)",
      "Um den Topf zu spülen",
      "Um die Nudeln abzukühlen",
      "Als Brühe zum Trinken"
    ],
    "correctIndex": 0,
    "explanationEn": "Starchy water bridges oil/butter and cooking liquids, creating cohesive cling without added flour.",
    "explanationDe": "Die Stärke im Kochwasser bindet Fett und Wasser zu einer perfekten Emulsion ohne Mehlbindung.",
    "qEn": "Why should pasta cooking water ('acqua di cottura') always be reserved for finishing sauce?",
    "qDe": "Warum sollte man beim Abgießen von Nudeln immer Pastawasser aufbewahren?",
    "optEn": [
      "The suspended gelatinized starch and warm salt water bind fats and liquids into a glossy emulsion ('mantecatura')",
      "To wash the pan afterwards",
      "To cool the pasta down",
      "To drink as warm broth"
    ],
    "optDe": [
      "Die gelöste Stärke emulgiert Fette und Saucen zu einer sämigen, glänzenden Hülle (Mantecatura)",
      "Um den Topf zu spülen",
      "Um die Nudeln abzukühlen",
      "Als Brühe zum Trinken"
    ],
    "correct": 0,
    "expEn": "Starchy water bridges oil/butter and cooking liquids, creating cohesive cling without added flour.",
    "expDe": "Die Stärke im Kochwasser bindet Fett und Wasser zu einer perfekten Emulsion ohne Mehlbindung."
  },
  {
    "id": "q_pas_04",
    "category": "pasta_rice",
    "questionEn": "Which classic Roman pasta features Pecorino Romano and cracked black pepper exclusively?",
    "questionDe": "Welches klassische römische Pastagericht besteht ausschließlich aus Pecorino Romano und schwarzem Pfeffer?",
    "optionsEn": [
      "Cacio e Pepe",
      "Carbonara",
      "Amatriciana",
      "Pasta alla Gricia"
    ],
    "optionsDe": [
      "Cacio e Pepe",
      "Carbonara",
      "Amatriciana",
      "Pasta alla Gricia"
    ],
    "correctIndex": 0,
    "explanationEn": "Cacio e Pepe emulsifies finely grated sheep cheese with starchy water and toasted black peppercorns.",
    "explanationDe": "Cacio e Pepe bindet Pecorino und frisch gemahlenen Pfeffer allein durch stärkehaltiges Nudelwasser.",
    "qEn": "Which classic Roman pasta features Pecorino Romano and cracked black pepper exclusively?",
    "qDe": "Welches klassische römische Pastagericht besteht ausschließlich aus Pecorino Romano und schwarzem Pfeffer?",
    "optEn": [
      "Cacio e Pepe",
      "Carbonara",
      "Amatriciana",
      "Pasta alla Gricia"
    ],
    "optDe": [
      "Cacio e Pepe",
      "Carbonara",
      "Amatriciana",
      "Pasta alla Gricia"
    ],
    "correct": 0,
    "expEn": "Cacio e Pepe emulsifies finely grated sheep cheese with starchy water and toasted black peppercorns.",
    "expDe": "Cacio e Pepe bindet Pecorino und frisch gemahlenen Pfeffer allein durch stärkehaltiges Nudelwasser."
  },
  {
    "id": "q_pas_05",
    "category": "pasta_rice",
    "questionEn": "Which pasta shape is traditionally paired with Cime di Rapa in Puglia?",
    "questionDe": "Welche Pastaform wird in Apulien traditionell zu Stängelkohl (Cime di Rapa) gereicht?",
    "optionsEn": [
      "Orecchiette",
      "Spaghetti",
      "Penne",
      "Farfalle"
    ],
    "optionsDe": [
      "Orecchiette ('Öhrchen')",
      "Spaghetti",
      "Penne",
      "Farfalle"
    ],
    "correctIndex": 0,
    "explanationEn": "The concave dome of Orecchiette scoops up tender greens, anchovy, and crumbled sausage meat.",
    "explanationDe": "Die Wölbung der Orecchiette schaufelt bitteres Gemüse, Knoblauch und Salsiccia ideal auf.",
    "qEn": "Which pasta shape is traditionally paired with Cime di Rapa in Puglia?",
    "qDe": "Welche Pastaform wird in Apulien traditionell zu Stängelkohl (Cime di Rapa) gereicht?",
    "optEn": [
      "Orecchiette",
      "Spaghetti",
      "Penne",
      "Farfalle"
    ],
    "optDe": [
      "Orecchiette ('Öhrchen')",
      "Spaghetti",
      "Penne",
      "Farfalle"
    ],
    "correct": 0,
    "expEn": "The concave dome of Orecchiette scoops up tender greens, anchovy, and crumbled sausage meat.",
    "expDe": "Die Wölbung der Orecchiette schaufelt bitteres Gemüse, Knoblauch und Salsiccia ideal auf."
  },
  {
    "id": "q_pas_06",
    "category": "pasta_rice",
    "questionEn": "Why is Carnaroli often called the 'King of Risotto Rices' over Arborio?",
    "questionDe": "Warum gilt Carnaroli-Reis als der König für perfektes Risotto im Vergleich zu Arborio?",
    "optionsEn": [
      "Higher amylose content and firm grain structure yield creaminess while staying resiliently al dente",
      "Cooks in 5 minutes",
      "Sweetest rice grain",
      "Zero starch on exterior"
    ],
    "optionsDe": [
      "Höherer Amylosegehalt und fester Kornkern sorgen für sämigen Schmelz bei perfektem Kernbiss",
      "Gart in 5 Minuten",
      "Süßeste Reissorte",
      "Hat keine Stärke"
    ],
    "correctIndex": 0,
    "explanationEn": "Carnaroli releases surface amylopectin for creaminess without the grain breaking down or becoming soggy.",
    "explanationDe": "Carnaroli quillt cremig auf, behält aber im Kern seinen festen Biss und verkocht nicht.",
    "qEn": "Why is Carnaroli often called the 'King of Risotto Rices' over Arborio?",
    "qDe": "Warum gilt Carnaroli-Reis als der König für perfektes Risotto im Vergleich zu Arborio?",
    "optEn": [
      "Higher amylose content and firm grain structure yield creaminess while staying resiliently al dente",
      "Cooks in 5 minutes",
      "Sweetest rice grain",
      "Zero starch on exterior"
    ],
    "optDe": [
      "Höherer Amylosegehalt und fester Kornkern sorgen für sämigen Schmelz bei perfektem Kernbiss",
      "Gart in 5 Minuten",
      "Süßeste Reissorte",
      "Hat keine Stärke"
    ],
    "correct": 0,
    "expEn": "Carnaroli releases surface amylopectin for creaminess without the grain breaking down or becoming soggy.",
    "expDe": "Carnaroli quillt cremig auf, behält aber im Kern seinen festen Biss und verkocht nicht."
  },
  {
    "id": "q_pas_07",
    "category": "pasta_rice",
    "questionEn": "What gives Basmati rice its distinctive floral, nutty fragrance?",
    "questionDe": "Was verleiht echtem Basmati-Reis sein typisches blumig-nussiges Aroma?",
    "optionsEn": [
      "Natural compound 2-Acetyl-1-pyrroline (2AP) developed during Himalayan soil growth and aging",
      "Added rosewater perfume",
      "Toasting grains in sesame oil",
      "Artificial vanilla flavoring"
    ],
    "optionsDe": [
      "Die aromatische Verbindung 2-Acetyl-1-pyrrolin (2AP) sowie traditionelle Reifelagerung",
      "Zusatz von Rosenwasser",
      "Rösten in Sesamöl",
      "Künstliches Vanillin"
    ],
    "correctIndex": 0,
    "explanationEn": "Aged Basmati concentrates 2AP, which creates the celebrated popcorn/pandan aroma.",
    "explanationDe": "Echter Himalaya-Basmati lagert oft monatelang; die Reifung verstärkt das nussige Duftaroma.",
    "qEn": "What gives Basmati rice its distinctive floral, nutty fragrance?",
    "qDe": "Was verleiht echtem Basmati-Reis sein typisches blumig-nussiges Aroma?",
    "optEn": [
      "Natural compound 2-Acetyl-1-pyrroline (2AP) developed during Himalayan soil growth and aging",
      "Added rosewater perfume",
      "Toasting grains in sesame oil",
      "Artificial vanilla flavoring"
    ],
    "optDe": [
      "Die aromatische Verbindung 2-Acetyl-1-pyrrolin (2AP) sowie traditionelle Reifelagerung",
      "Zusatz von Rosenwasser",
      "Rösten in Sesamöl",
      "Künstliches Vanillin"
    ],
    "correct": 0,
    "expEn": "Aged Basmati concentrates 2AP, which creates the celebrated popcorn/pandan aroma.",
    "expDe": "Echter Himalaya-Basmati lagert oft monatelang; die Reifung verstärkt das nussige Duftaroma."
  },
  {
    "id": "q_pas_08",
    "category": "pasta_rice",
    "questionEn": "Why is Parboiled rice more nutritious than regular polished white rice?",
    "questionDe": "Warum enthält Parboiled Reis mehr Nährstoffe als geschliffener weißer Reis?",
    "optionsEn": [
      "Hydrothermal steam pressure forces vitamins and minerals from the bran into the endosperm before milling",
      "Enriched with synthetic vitamin powder",
      "Soaked in fruit juice",
      "Genetically modified"
    ],
    "optionsDe": [
      "Druckdampf presst vor dem Schleifen wasserlösliche Vitamine und Mineralstoffe aus der Schale ins Korn",
      "Mit synthetischem Vitaminpulver besprüht",
      "In Saft eingeweicht",
      "Gentechnisch verändert"
    ],
    "correctIndex": 0,
    "explanationEn": "Parboiling migrates B vitamins into the starchy kernel, gelatinizing starch for non-sticky grains.",
    "explanationDe": "Das Parboiling-Verfahren drückt wertvolle Nährstoffe aus dem Silberhäutchen ins Korninnere.",
    "qEn": "Why is Parboiled rice more nutritious than regular polished white rice?",
    "qDe": "Warum enthält Parboiled Reis mehr Nährstoffe als geschliffener weißer Reis?",
    "optEn": [
      "Hydrothermal steam pressure forces vitamins and minerals from the bran into the endosperm before milling",
      "Enriched with synthetic vitamin powder",
      "Soaked in fruit juice",
      "Genetically modified"
    ],
    "optDe": [
      "Druckdampf presst vor dem Schleifen wasserlösliche Vitamine und Mineralstoffe aus der Schale ins Korn",
      "Mit synthetischem Vitaminpulver besprüht",
      "In Saft eingeweicht",
      "Gentechnisch verändert"
    ],
    "correct": 0,
    "expEn": "Parboiling migrates B vitamins into the starchy kernel, gelatinizing starch for non-sticky grains.",
    "expDe": "Das Parboiling-Verfahren drückt wertvolle Nährstoffe aus dem Silberhäutchen ins Korninnere."
  },
  {
    "id": "q_pas_09",
    "category": "pasta_rice",
    "questionEn": "What distinguishes Jasmine rice from Basmati rice in texture?",
    "questionDe": "Wie unterscheidet sich Jasminreis in der Konsistenz von Basmatireis?",
    "optionsEn": [
      "Jasmine rice is higher in amylopectin, cooking slightly soft, moist, and gently sticky; Basmati cooks firm and separate",
      "Jasmine rice stays crunchy like gravel",
      "Basmati melts into porridge",
      "Jasmine rice has no aroma"
    ],
    "optionsDe": [
      "Jasminreis enthält mehr Amylopektin, wird weicher, feuchter und leicht klebrig; Basmati bleibt trocken-körnig",
      "Jasminreis bleibt steinhart",
      "Basmati wird Brei",
      "Jasminreis hat keinen Duft"
    ],
    "correctIndex": 0,
    "explanationEn": "Jasmine rice grains cling slightly, ideal for picking up with chopsticks or scooping curries.",
    "explanationDe": "Thailändischer Jasminreis haftet sanft zusammen und eignet sich perfekt für asiatische Currys.",
    "qEn": "What distinguishes Jasmine rice from Basmati rice in texture?",
    "qDe": "Wie unterscheidet sich Jasminreis in der Konsistenz von Basmatireis?",
    "optEn": [
      "Jasmine rice is higher in amylopectin, cooking slightly soft, moist, and gently sticky; Basmati cooks firm and separate",
      "Jasmine rice stays crunchy like gravel",
      "Basmati melts into porridge",
      "Jasmine rice has no aroma"
    ],
    "optDe": [
      "Jasminreis enthält mehr Amylopektin, wird weicher, feuchter und leicht klebrig; Basmati bleibt trocken-körnig",
      "Jasminreis bleibt steinhart",
      "Basmati wird Brei",
      "Jasminreis hat keinen Duft"
    ],
    "correct": 0,
    "expEn": "Jasmine rice grains cling slightly, ideal for picking up with chopsticks or scooping curries.",
    "expDe": "Thailändischer Jasminreis haftet sanft zusammen und eignet sich perfekt für asiatische Currys."
  },
  {
    "id": "q_pas_10",
    "category": "pasta_rice",
    "questionEn": "Which traditional rice is essential for Spanish Paella Valenciana?",
    "questionDe": "Welcher Reis ist unverzichtbar für eine authentische Paella Valenciana?",
    "optionsEn": [
      "Arroz Bomba (or Senia)",
      "Basmati",
      "Long grain Patna",
      "Jasmine"
    ],
    "optionsDe": [
      "Arroz Bomba (oder Senia)",
      "Basmati",
      "Langkornreis Patna",
      "Jasminreis"
    ],
    "correctIndex": 0,
    "explanationEn": "Bomba rice absorbs up to 3 times its volume in flavorful saffron broth without bursting.",
    "explanationDe": "Bomba-Reis saugt das Dreifache seines Volumens an Brühe auf, ohne seine Form zu verlieren.",
    "qEn": "Which traditional rice is essential for Spanish Paella Valenciana?",
    "qDe": "Welcher Reis ist unverzichtbar für eine authentische Paella Valenciana?",
    "optEn": [
      "Arroz Bomba (or Senia)",
      "Basmati",
      "Long grain Patna",
      "Jasmine"
    ],
    "optDe": [
      "Arroz Bomba (oder Senia)",
      "Basmati",
      "Langkornreis Patna",
      "Jasminreis"
    ],
    "correct": 0,
    "expEn": "Bomba rice absorbs up to 3 times its volume in flavorful saffron broth without bursting.",
    "expDe": "Bomba-Reis saugt das Dreifache seines Volumens an Brühe auf, ohne seine Form zu verlieren."
  },
  {
    "id": "q_pas_11",
    "category": "pasta_rice",
    "questionEn": "What is 'Socarrat' in authentic paella cooking?",
    "questionDe": "Was versteht man unter 'Socarrat' bei einer perfekten Paella?",
    "optionsEn": [
      "The crispy, deeply caramelized, golden-brown crust of rice formed at the bottom of the pan",
      "The raw chicken used",
      "The saffron broth",
      "The lemon wedge garnish"
    ],
    "optionsDe": [
      "Die knusprige, karamellisierte Reiskruste am flachen Boden der Paellapfanne",
      "Das rohe Fleisch",
      "Die Safransuppe",
      "Die Zitronenschnitze"
    ],
    "correctIndex": 0,
    "explanationEn": "Gentle rendering of olive oil and broth at the end crisps the bottom rice into a prize crunchy delicacy.",
    "explanationDe": "Das kurze Anrösten am Ende karamellisiert Stärke und Fett zu einer aromatischen Knusperschicht.",
    "qEn": "What is 'Socarrat' in authentic paella cooking?",
    "qDe": "Was versteht man unter 'Socarrat' bei einer perfekten Paella?",
    "optEn": [
      "The crispy, deeply caramelized, golden-brown crust of rice formed at the bottom of the pan",
      "The raw chicken used",
      "The saffron broth",
      "The lemon wedge garnish"
    ],
    "optDe": [
      "Die knusprige, karamellisierte Reiskruste am flachen Boden der Paellapfanne",
      "Das rohe Fleisch",
      "Die Safransuppe",
      "Die Zitronenschnitze"
    ],
    "correct": 0,
    "expEn": "Gentle rendering of olive oil and broth at the end crisps the bottom rice into a prize crunchy delicacy.",
    "expDe": "Das kurze Anrösten am Ende karamellisiert Stärke und Fett zu einer aromatischen Knusperschicht."
  },
  {
    "id": "q_pas_12",
    "category": "pasta_rice",
    "questionEn": "Why is short-grain Japonica rice used for Sushi (Koshihikari)?",
    "questionDe": "Warum wird für Sushi ausschließlich Rundkornreis (Japonica, z.B. Koshihikari) verwendet?",
    "optionsEn": [
      "High amylopectin content provides cohesion that holds shaped nigiri together while dissolving gently in mouth",
      "It is yellow naturally",
      "It cooks in 3 minutes",
      "It has zero carbohydrates"
    ],
    "optionsDe": [
      "Hoher Amylopektinanteil schenkt optimale Klebrigkeit für geformte Nigiri ohne zähen Matsch",
      "Er ist von Natur aus gelb",
      "Gart in 3 Minuten",
      "Hat keine Kohlenhydrate"
    ],
    "correctIndex": 0,
    "explanationEn": "Seasoned with rice vinegar, sugar, and salt, Japonica grains stick without needing heavy pressing.",
    "explanationDe": "Gewürzt mit Sushizu halten die Reiskörner zusammen, schmelzen aber am Gaumen locker auseinander.",
    "qEn": "Why is short-grain Japonica rice used for Sushi (Koshihikari)?",
    "qDe": "Warum wird für Sushi ausschließlich Rundkornreis (Japonica, z.B. Koshihikari) verwendet?",
    "optEn": [
      "High amylopectin content provides cohesion that holds shaped nigiri together while dissolving gently in mouth",
      "It is yellow naturally",
      "It cooks in 3 minutes",
      "It has zero carbohydrates"
    ],
    "optDe": [
      "Hoher Amylopektinanteil schenkt optimale Klebrigkeit für geformte Nigiri ohne zähen Matsch",
      "Er ist von Natur aus gelb",
      "Gart in 3 Minuten",
      "Hat keine Kohlenhydrate"
    ],
    "correct": 0,
    "expEn": "Seasoned with rice vinegar, sugar, and salt, Japonica grains stick without needing heavy pressing.",
    "expDe": "Gewürzt mit Sushizu halten die Reiskörner zusammen, schmelzen aber am Gaumen locker auseinander."
  },
  {
    "id": "q_pas_13",
    "category": "pasta_rice",
    "questionEn": "What is Wild Rice botanically?",
    "questionDe": "Was ist Wildreis aus botanischer Sicht?",
    "optionsEn": [
      "The aquatic seed of North American water grass (Zizania palustris), not a true Oryza rice",
      "Charred black Asian rice",
      "Wild wheat grain",
      "Artificially dyed rice"
    ],
    "optionsDe": [
      "Samen eines nordamerikanischen Süßgrases (Zizania palustris), kein echter Reis",
      "Verkohlter Basmatireis",
      "Wilder Urweizen",
      "Eingefärbter Reis"
    ],
    "correctIndex": 0,
    "explanationEn": "Wild rice is an aquatic marsh grass seed celebrated for its firm chew and smoky tea-like aroma.",
    "explanationDe": "Wildreis ist ein Wassergras mit festem Biss und nussig-erdigem, rauchigem Geschmack.",
    "qEn": "What is Wild Rice botanically?",
    "qDe": "Was ist Wildreis aus botanischer Sicht?",
    "optEn": [
      "The aquatic seed of North American water grass (Zizania palustris), not a true Oryza rice",
      "Charred black Asian rice",
      "Wild wheat grain",
      "Artificially dyed rice"
    ],
    "optDe": [
      "Samen eines nordamerikanischen Süßgrases (Zizania palustris), kein echter Reis",
      "Verkohlter Basmatireis",
      "Wilder Urweizen",
      "Eingefärbter Reis"
    ],
    "correct": 0,
    "expEn": "Wild rice is an aquatic marsh grass seed celebrated for its firm chew and smoky tea-like aroma.",
    "expDe": "Wildreis ist ein Wassergras mit festem Biss und nussig-erdigem, rauchigem Geschmack."
  },
  {
    "id": "q_pas_14",
    "category": "pasta_rice",
    "questionEn": "Why is rinsing white rice prior to cooking recommended?",
    "questionDe": "Warum sollte weißer Reis vor dem Kochen gründlich gewaschen werden?",
    "optionsEn": [
      "Removes excess surface flour and loose starch granules, preventing a gluey, gummy texture",
      "Kills bacteria",
      "Adds water weight",
      "Extracts salt"
    ],
    "optionsDe": [
      "Spült lose Oberflächenstärke ab, damit die Körner beim Kochen nicht klebrig verkleistern",
      "Tötet Bakterien ab",
      "Macht ihn schwerer",
      "Entzieht Salz"
    ],
    "correctIndex": 0,
    "explanationEn": "Rinsing until the water runs clear ensures fluffy, distinct, and individual grains.",
    "explanationDe": "Das Waschen bis zum klaren Ablauf verhindert, dass freie Stärke den Reis in Brei verwandelt.",
    "qEn": "Why is rinsing white rice prior to cooking recommended?",
    "qDe": "Warum sollte weißer Reis vor dem Kochen gründlich gewaschen werden?",
    "optEn": [
      "Removes excess surface flour and loose starch granules, preventing a gluey, gummy texture",
      "Kills bacteria",
      "Adds water weight",
      "Extracts salt"
    ],
    "optDe": [
      "Spült lose Oberflächenstärke ab, damit die Körner beim Kochen nicht klebrig verkleistern",
      "Tötet Bakterien ab",
      "Macht ihn schwerer",
      "Entzieht Salz"
    ],
    "correct": 0,
    "expEn": "Rinsing until the water runs clear ensures fluffy, distinct, and individual grains.",
    "expDe": "Das Waschen bis zum klaren Ablauf verhindert, dass freie Stärke den Reis in Brei verwandelt."
  },
  {
    "id": "q_pas_15",
    "category": "pasta_rice",
    "questionEn": "Which sauce style pairs best with broad ribbon Tagliatelle / Pappardelle?",
    "questionDe": "Welche Sauce harmoniert ideal mit breiten Bandnudeln (Tagliatelle, Pappardelle)?",
    "optionsEn": [
      "Rich meat ragùs, wild boar, and braised mushroom sauces",
      "Light olive oil and garlic",
      "Clear consommé",
      "Melted fruit jelly"
    ],
    "optionsDe": [
      "Reichhaltige Fleischragùs (Bolognese, Wildschwein) und dichte Pilzsaucen",
      "Dünnes Knoblauchöl",
      "Klare Brühe",
      "Fruchtgelee"
    ],
    "correctIndex": 0,
    "explanationEn": "Broad rough egg ribbons provide the surface area required to suspend heavy meat pieces and emulsified braises.",
    "explanationDe": "Breite Nudeln bieten die nötige Tragfläche für stückige Fleischsaucen und Pilzragùs.",
    "qEn": "Which sauce style pairs best with broad ribbon Tagliatelle / Pappardelle?",
    "qDe": "Welche Sauce harmoniert ideal mit breiten Bandnudeln (Tagliatelle, Pappardelle)?",
    "optEn": [
      "Rich meat ragùs, wild boar, and braised mushroom sauces",
      "Light olive oil and garlic",
      "Clear consommé",
      "Melted fruit jelly"
    ],
    "optDe": [
      "Reichhaltige Fleischragùs (Bolognese, Wildschwein) und dichte Pilzsaucen",
      "Dünnes Knoblauchöl",
      "Klare Brühe",
      "Fruchtgelee"
    ],
    "correct": 0,
    "expEn": "Broad rough egg ribbons provide the surface area required to suspend heavy meat pieces and emulsified braises.",
    "expDe": "Breite Nudeln bieten die nötige Tragfläche für stückige Fleischsaucen und Pilzragùs."
  },
  {
    "id": "q_pas_16",
    "category": "pasta_rice",
    "questionEn": "What is the defining meat in authentic Carbonara and Amatriciana?",
    "questionDe": "Welches Fleischstück ist Pflicht für echte Carbonara und Amatriciana?",
    "optionsEn": [
      "Guanciale (cured pork jowl / cheek)",
      "Pancetta (pork belly)",
      "Cooked ham",
      "Smoked bacon strips"
    ],
    "optionsDe": [
      "Guanciale (luftgetrocknete Schweinebacke)",
      "Pancetta (Bauchspeck)",
      "Kochschinken",
      "Geräucherter Speck"
    ],
    "correctIndex": 0,
    "explanationEn": "Guanciale contains rich intramuscular fat and peppery curing spices, rendering clear, savory liquid gold.",
    "explanationDe": "Schweinebacke schmilzt zart, hat ein feines Aroma und liefert das unersetzliche Schmalz.",
    "qEn": "What is the defining meat in authentic Carbonara and Amatriciana?",
    "qDe": "Welches Fleischstück ist Pflicht für echte Carbonara und Amatriciana?",
    "optEn": [
      "Guanciale (cured pork jowl / cheek)",
      "Pancetta (pork belly)",
      "Cooked ham",
      "Smoked bacon strips"
    ],
    "optDe": [
      "Guanciale (luftgetrocknete Schweinebacke)",
      "Pancetta (Bauchspeck)",
      "Kochschinken",
      "Geräucherter Speck"
    ],
    "correct": 0,
    "expEn": "Guanciale contains rich intramuscular fat and peppery curing spices, rendering clear, savory liquid gold.",
    "expDe": "Schweinebacke schmilzt zart, hat ein feines Aroma und liefert das unersetzliche Schmalz."
  },
  {
    "id": "q_pas_17",
    "category": "pasta_rice",
    "questionEn": "Why should freshly made egg pasta (Pasta Fresca) never be rinsed with cold water after boiling?",
    "questionDe": "Warum darf frische Eierteigware nach dem Kochen keinesfalls mit kaltem Wasser abgeschreckt werden?",
    "optionsEn": [
      "Cold water washes away starchy surface film and causes temperature shock, preventing sauce binding",
      "Pasta turns toxic",
      "Pasta melts completely",
      "Eggs coagulate into leather"
    ],
    "optionsDe": [
      "Abschrecken spült den Stärkefilm ab und kühlt die Nudel ab, wodurch keine Sauce mehr haftet",
      "Nudeln werden giftig",
      "Sie lösen sich auf",
      "Das Ei wird zäh"
    ],
    "correctIndex": 0,
    "explanationEn": "Rinsing removes the microscopic starch coating that forms a velvet emulsion with sauce.",
    "explanationDe": "Nudeln niemals abschrecken; sie müssen dampfend heiß direkt in die heiße Sauce wandern.",
    "qEn": "Why should freshly made egg pasta (Pasta Fresca) never be rinsed with cold water after boiling?",
    "qDe": "Warum darf frische Eierteigware nach dem Kochen keinesfalls mit kaltem Wasser abgeschreckt werden?",
    "optEn": [
      "Cold water washes away starchy surface film and causes temperature shock, preventing sauce binding",
      "Pasta turns toxic",
      "Pasta melts completely",
      "Eggs coagulate into leather"
    ],
    "optDe": [
      "Abschrecken spült den Stärkefilm ab und kühlt die Nudel ab, wodurch keine Sauce mehr haftet",
      "Nudeln werden giftig",
      "Sie lösen sich auf",
      "Das Ei wird zäh"
    ],
    "correct": 0,
    "expEn": "Rinsing removes the microscopic starch coating that forms a velvet emulsion with sauce.",
    "expDe": "Nudeln niemals abschrecken; sie müssen dampfend heiß direkt in die heiße Sauce wandern."
  },
  {
    "id": "q_pas_18",
    "category": "pasta_rice",
    "questionEn": "What distinguishes Rigatoni from Penne?",
    "questionDe": "Was unterscheidet Rigatoni von Penne Rigate?",
    "optionsEn": [
      "Rigatoni are straight cut with wide round cylinder openings; Penne are cut diagonally with pointed quills",
      "Rigatoni have no ridges",
      "Penne are made of potatoes",
      "Rigatoni are stuffed"
    ],
    "optionsDe": [
      "Rigatoni sind gerade geschnitten mit weiter Öffnung; Penne sind schräg angespitzt ('Federkiel')",
      "Rigatoni haben keine Rillen",
      "Penne bestehen aus Kartoffeln",
      "Rigatoni sind gefüllt"
    ],
    "correctIndex": 0,
    "explanationEn": "Rigatoni ('ridged') have straight cut ends and a wide tube that captures sausage and peas inside.",
    "explanationDe": "Penne sind wie antike Schreibfedern schräg gekappt; Rigatoni fangen Saucenstückchen im Hohlraum ein.",
    "qEn": "What distinguishes Rigatoni from Penne?",
    "qDe": "Was unterscheidet Rigatoni von Penne Rigate?",
    "optEn": [
      "Rigatoni are straight cut with wide round cylinder openings; Penne are cut diagonally with pointed quills",
      "Rigatoni have no ridges",
      "Penne are made of potatoes",
      "Rigatoni are stuffed"
    ],
    "optDe": [
      "Rigatoni sind gerade geschnitten mit weiter Öffnung; Penne sind schräg angespitzt ('Federkiel')",
      "Rigatoni haben keine Rillen",
      "Penne bestehen aus Kartoffeln",
      "Rigatoni sind gefüllt"
    ],
    "correct": 0,
    "expEn": "Rigatoni ('ridged') have straight cut ends and a wide tube that captures sausage and peas inside.",
    "expDe": "Penne sind wie antike Schreibfedern schräg gekappt; Rigatoni fangen Saucenstückchen im Hohlraum ein."
  },
  {
    "id": "q_sau_01",
    "category": "sauces_condiments",
    "questionEn": "What type of chemical emulsion is real Mayonnaise?",
    "questionDe": "Welche Art von chemischer Emulsion ist echte Mayonnaise?",
    "optionsEn": [
      "Oil-in-water emulsion stabilized by egg yolk lecithin",
      "Water-in-oil emulsion",
      "Gas emulsion",
      "Suspension of solid fats"
    ],
    "optionsDe": [
      "Öl-in-Wasser-Emulsion, stabilisiert durch Eidotter-Lecithin",
      "Wasser-in-Öl-Emulsion",
      "Gasemulsion",
      "Suspension fester Fette"
    ],
    "correctIndex": 0,
    "explanationEn": "Lecithin in egg yolk coats dispersed oil micro-droplets, preventing them from coalescing into oil slicks.",
    "explanationDe": "Lecithin im Eigelb bindet die feinen Öltröpfchen im Wasseranteil zu einer stabilen Creme.",
    "qEn": "What type of chemical emulsion is real Mayonnaise?",
    "qDe": "Welche Art von chemischer Emulsion ist echte Mayonnaise?",
    "optEn": [
      "Oil-in-water emulsion stabilized by egg yolk lecithin",
      "Water-in-oil emulsion",
      "Gas emulsion",
      "Suspension of solid fats"
    ],
    "optDe": [
      "Öl-in-Wasser-Emulsion, stabilisiert durch Eidotter-Lecithin",
      "Wasser-in-Öl-Emulsion",
      "Gasemulsion",
      "Suspension fester Fette"
    ],
    "correct": 0,
    "expEn": "Lecithin in egg yolk coats dispersed oil micro-droplets, preventing them from coalescing into oil slicks.",
    "expDe": "Lecithin im Eigelb bindet die feinen Öltröpfchen im Wasseranteil zu einer stabilen Creme."
  },
  {
    "id": "q_sau_02",
    "category": "sauces_condiments",
    "questionEn": "What gives Japanese Kewpie Mayonnaise its richer taste and velvety texture?",
    "questionDe": "Was verleiht japanischer Kewpie-Mayonnaise ihren reicheren Geschmack und Schmelz?",
    "optionsEn": [
      "Uses only egg yolks (no whites), rice vinegar, and monosodium glutamate (MSG)",
      "Uses olive oil exclusively",
      "Contains sweet cream",
      "Is cooked like custard"
    ],
    "optionsDe": [
      "Verwendet nur reines Eigelb (kein Eiklar), milden Reisessig und einen Hauch MSG",
      "Basiert nur auf Olivenöl",
      "Enthält flüssige Sahne",
      "Wird wie Pudding gekocht"
    ],
    "correctIndex": 0,
    "explanationEn": "Using exclusively egg yolks doubles phospholipid density, yielding deeper yellow color and umami depth.",
    "explanationDe": "Das ausschließliche Eigelb sorgt für samtigen Schmelz und typischen Umami-Körper.",
    "qEn": "What gives Japanese Kewpie Mayonnaise its richer taste and velvety texture?",
    "qDe": "Was verleiht japanischer Kewpie-Mayonnaise ihren reicheren Geschmack und Schmelz?",
    "optEn": [
      "Uses only egg yolks (no whites), rice vinegar, and monosodium glutamate (MSG)",
      "Uses olive oil exclusively",
      "Contains sweet cream",
      "Is cooked like custard"
    ],
    "optDe": [
      "Verwendet nur reines Eigelb (kein Eiklar), milden Reisessig und einen Hauch MSG",
      "Basiert nur auf Olivenöl",
      "Enthält flüssige Sahne",
      "Wird wie Pudding gekocht"
    ],
    "correct": 0,
    "expEn": "Using exclusively egg yolks doubles phospholipid density, yielding deeper yellow color and umami depth.",
    "expDe": "Das ausschließliche Eigelb sorgt für samtigen Schmelz und typischen Umami-Körper."
  },
  {
    "id": "q_sau_03",
    "category": "sauces_condiments",
    "questionEn": "At what temperature does Sauce Hollandaise break (curdle) if overheated?",
    "questionDe": "Bei welcher Temperatur gerinnt Sauce Hollandaise, wenn sie zu heiß geschlagen wird?",
    "optionsEn": [
      "Above 68°C to 70°C (155°F - 158°F)",
      "Above 100°C",
      "Above 45°C",
      "At 30°C"
    ],
    "optionsDe": [
      "Ab ca. 68°C bis 70°C",
      "Erst über 100°C",
      "Bereits ab 45°C",
      "Bei 30°C"
    ],
    "correctIndex": 0,
    "explanationEn": "Egg proteins coagulate above 68°C, squeezing out bound butter fat into an oily curdled mess.",
    "explanationDe": "Ab 68°C stockt das Eigelb unumkehrbar; die Fett-Wasser-Bindung bricht schlagartig zusammen.",
    "qEn": "At what temperature does Sauce Hollandaise break (curdle) if overheated?",
    "qDe": "Bei welcher Temperatur gerinnt Sauce Hollandaise, wenn sie zu heiß geschlagen wird?",
    "optEn": [
      "Above 68°C to 70°C (155°F - 158°F)",
      "Above 100°C",
      "Above 45°C",
      "At 30°C"
    ],
    "optDe": [
      "Ab ca. 68°C bis 70°C",
      "Erst über 100°C",
      "Bereits ab 45°C",
      "Bei 30°C"
    ],
    "correct": 0,
    "expEn": "Egg proteins coagulate above 68°C, squeezing out bound butter fat into an oily curdled mess.",
    "expDe": "Ab 68°C stockt das Eigelb unumkehrbar; die Fett-Wasser-Bindung bricht schlagartig zusammen."
  },
  {
    "id": "q_sau_04",
    "category": "sauces_condiments",
    "questionEn": "What liquid base is traditionally used in authentic French Dijon Mustard instead of plain vinegar?",
    "questionDe": "Welche traditionelle Flüssigkeit wird für echten Dijonsenf statt billigem Essig verwendet?",
    "optionsEn": [
      "Verjus (unripe green grape juice) or white wine",
      "Apple cider",
      "Distilled malt vinegar",
      "Lemon water"
    ],
    "optionsDe": [
      "Verjus (Säuresaft unreifer Trauben) oder trockener Weißwein",
      "Apfelmost",
      "Malzessig",
      "Zitronenwasser"
    ],
    "correctIndex": 0,
    "explanationEn": "Brown Brassica juncea seeds soaked in sour verjus create Dijon's clean, piercing sinus heat.",
    "explanationDe": "Verjus oder Weißwein verleiht Dijonsenf seine scharfe, feine und ungesüßte Frische.",
    "qEn": "What liquid base is traditionally used in authentic French Dijon Mustard instead of plain vinegar?",
    "qDe": "Welche traditionelle Flüssigkeit wird für echten Dijonsenf statt billigem Essig verwendet?",
    "optEn": [
      "Verjus (unripe green grape juice) or white wine",
      "Apple cider",
      "Distilled malt vinegar",
      "Lemon water"
    ],
    "optDe": [
      "Verjus (Säuresaft unreifer Trauben) oder trockener Weißwein",
      "Apfelmost",
      "Malzessig",
      "Zitronenwasser"
    ],
    "correct": 0,
    "expEn": "Brown Brassica juncea seeds soaked in sour verjus create Dijon's clean, piercing sinus heat.",
    "expDe": "Verjus oder Weißwein verleiht Dijonsenf seine scharfe, feine und ungesüßte Frische."
  },
  {
    "id": "q_sau_05",
    "category": "sauces_condiments",
    "questionEn": "What imparts the distinctive sweet-spicy character to Bavarian Sweet Mustard (Weißwurstsenf)?",
    "questionDe": "Was verleiht bayerischem süßem Senf (Weißwurstsenf) seinen typischen Charakter?",
    "optionsEn": [
      "Coarsely crushed yellow and brown seeds, caramelized brown sugar, and apple sauce/spices",
      "Honey and chili flakes",
      "Molasses and tomato paste",
      "Sweet milk"
    ],
    "optionsDe": [
      "Grob geschrotete Senfsaat, karamellisierter Zucker und feine Gewürze",
      "Reiner Bienenhonig und Chili",
      "Melasse und Tomatenmark",
      "Süße Milch"
    ],
    "correctIndex": 0,
    "explanationEn": "Traditional Weißwurstsenf balances coarse crunch with caramelized sugar syrup and mild vinegar.",
    "explanationDe": "Der karamellisierte Zucker puffert die Schärfe der Senfkörner harmonisch zur Weißwurst ab.",
    "qEn": "What imparts the distinctive sweet-spicy character to Bavarian Sweet Mustard (Weißwurstsenf)?",
    "qDe": "Was verleiht bayerischem süßem Senf (Weißwurstsenf) seinen typischen Charakter?",
    "optEn": [
      "Coarsely crushed yellow and brown seeds, caramelized brown sugar, and apple sauce/spices",
      "Honey and chili flakes",
      "Molasses and tomato paste",
      "Sweet milk"
    ],
    "optDe": [
      "Grob geschrotete Senfsaat, karamellisierter Zucker und feine Gewürze",
      "Reiner Bienenhonig und Chili",
      "Melasse und Tomatenmark",
      "Süße Milch"
    ],
    "correct": 0,
    "expEn": "Traditional Weißwurstsenf balances coarse crunch with caramelized sugar syrup and mild vinegar.",
    "expDe": "Der karamellisierte Zucker puffert die Schärfe der Senfkörner harmonisch zur Weißwurst ab."
  },
  {
    "id": "q_sau_06",
    "category": "sauces_condiments",
    "questionEn": "How is authentic McIlhenny Tabasco sauce aged?",
    "questionDe": "Wie reift originale Tabasco Pepper Sauce?",
    "optionsEn": [
      "Tabasco chili mash is salted and aged for up to 3 years in white oak whiskey barrels",
      "Boiled in steel tanks with vinegar",
      "Sun-dried in clay pots",
      "Fermented under water"
    ],
    "optionsDe": [
      "Chili-Maische reift bis zu 3 Jahre mit Salz in ausgebrannten Eichenfässern",
      "In Stahltanks gekocht",
      "In Tonkrügen getrocknet",
      "Unter Wasser vergoren"
    ],
    "correctIndex": 0,
    "explanationEn": "Three years of oak barrel aging develop complex fermented fruity acids before vinegar blending.",
    "explanationDe": "Die dreijährige Holzfassreife erzeugt das unverwechselbare fermentierte Holzaroma.",
    "qEn": "How is authentic McIlhenny Tabasco sauce aged?",
    "qDe": "Wie reift originale Tabasco Pepper Sauce?",
    "optEn": [
      "Tabasco chili mash is salted and aged for up to 3 years in white oak whiskey barrels",
      "Boiled in steel tanks with vinegar",
      "Sun-dried in clay pots",
      "Fermented under water"
    ],
    "optDe": [
      "Chili-Maische reift bis zu 3 Jahre mit Salz in ausgebrannten Eichenfässern",
      "In Stahltanks gekocht",
      "In Tonkrügen getrocknet",
      "Unter Wasser vergoren"
    ],
    "correct": 0,
    "expEn": "Three years of oak barrel aging develop complex fermented fruity acids before vinegar blending.",
    "expDe": "Die dreijährige Holzfassreife erzeugt das unverwechselbare fermentierte Holzaroma."
  },
  {
    "id": "q_sau_07",
    "category": "sauces_condiments",
    "questionEn": "What key ingredients define classic Thai Sriracha sauce?",
    "questionDe": "Welche Kernzutaten prägen originale Sriracha Chilisauce?",
    "optionsEn": [
      "Sun-ripened red jalapeño chilis, fresh garlic, vinegar, sugar, and salt",
      "Habanero and mango",
      "Dried chipotle and chocolate",
      "Black pepper and soy sauce"
    ],
    "optionsDe": [
      "Rote reife Jalapeño-Chilis, frischer Knoblauch, Essig, Zucker und Salz",
      "Habanero und Mango",
      "Chipotle und Schokolade",
      "Schwarzer Pfeffer und Sojasauce"
    ],
    "correctIndex": 0,
    "explanationEn": "Sriracha balances fermented garlic tang with sweet heat, originating in Si Racha, Thailand.",
    "explanationDe": "Die Balance aus frischem Knoblauch, feiner Säure und Chilisüße macht Sriracha weltberühmt.",
    "qEn": "What key ingredients define classic Thai Sriracha sauce?",
    "qDe": "Welche Kernzutaten prägen originale Sriracha Chilisauce?",
    "optEn": [
      "Sun-ripened red jalapeño chilis, fresh garlic, vinegar, sugar, and salt",
      "Habanero and mango",
      "Dried chipotle and chocolate",
      "Black pepper and soy sauce"
    ],
    "optDe": [
      "Rote reife Jalapeño-Chilis, frischer Knoblauch, Essig, Zucker und Salz",
      "Habanero und Mango",
      "Chipotle und Schokolade",
      "Schwarzer Pfeffer und Sojasauce"
    ],
    "correct": 0,
    "expEn": "Sriracha balances fermented garlic tang with sweet heat, originating in Si Racha, Thailand.",
    "expDe": "Die Balance aus frischem Knoblauch, feiner Säure und Chilisüße macht Sriracha weltberühmt."
  },
  {
    "id": "q_sau_08",
    "category": "sauces_condiments",
    "questionEn": "What ingredients characterize Kansas City-style Barbecue sauce?",
    "questionDe": "Was zeichnet Barbecue-Sauce im Kansas City-Stil aus?",
    "optionsEn": [
      "Thick tomato/ketchup base, dark molasses or brown sugar, apple cider vinegar, and liquid smoke",
      "Pure yellow mustard and vinegar",
      "White mayonnaise base",
      "Soy sauce and mirin"
    ],
    "optionsDe": [
      "Dicke Tomatenbasis, dunkle Melasse oder brauner Zucker, Apfelessig und Rauchnote",
      "Reiner Senf und Essig",
      "Weiße Mayonnaisebasis",
      "Sojasauce und Mirin"
    ],
    "correctIndex": 0,
    "explanationEn": "Kansas City BBQ sauce is sweet, sticky, and smoky, clinging to smoked ribs and brisket.",
    "explanationDe": "Süß, rauchig und dickflüssig: Melasse und Tomate karamellisieren perfekt auf Rippchen.",
    "qEn": "What ingredients characterize Kansas City-style Barbecue sauce?",
    "qDe": "Was zeichnet Barbecue-Sauce im Kansas City-Stil aus?",
    "optEn": [
      "Thick tomato/ketchup base, dark molasses or brown sugar, apple cider vinegar, and liquid smoke",
      "Pure yellow mustard and vinegar",
      "White mayonnaise base",
      "Soy sauce and mirin"
    ],
    "optDe": [
      "Dicke Tomatenbasis, dunkle Melasse oder brauner Zucker, Apfelessig und Rauchnote",
      "Reiner Senf und Essig",
      "Weiße Mayonnaisebasis",
      "Sojasauce und Mirin"
    ],
    "correct": 0,
    "expEn": "Kansas City BBQ sauce is sweet, sticky, and smoky, clinging to smoked ribs and brisket.",
    "expDe": "Süß, rauchig und dickflüssig: Melasse und Tomate karamellisieren perfekt auf Rippchen."
  },
  {
    "id": "q_sau_09",
    "category": "sauces_condiments",
    "questionEn": "What distinguishes Mexican Salsa Verde from Salsa Roja?",
    "questionDe": "Was unterscheidet mexikanische Salsa Verde grundlegend von Salsa Roja?",
    "optionsEn": [
      "Salsa Verde uses tart green Tomatillos (Physalis philadelphica); Salsa Roja uses ripe red tomatoes",
      "Salsa Verde is colored with spinach",
      "Salsa Verde has no chilis",
      "Salsa Roja uses red wine"
    ],
    "optionsDe": [
      "Salsa Verde basiert auf säuerlichen grünen Tomatillos; Salsa Roja auf reifen roten Tomaten",
      "Salsa Verde wird mit Spinat gefärbt",
      "Salsa Verde hat keine Chilis",
      "Salsa Roja enthält Rotwein"
    ],
    "correctIndex": 0,
    "explanationEn": "Tomatillos are husked tart nightshades providing herbal citrus tang unlike sweeter red tomatoes.",
    "explanationDe": "Tomatillos besitzen eine spritzige Fruchtsäure und verleihen Salsa Verde ihren herben Kick.",
    "qEn": "What distinguishes Mexican Salsa Verde from Salsa Roja?",
    "qDe": "Was unterscheidet mexikanische Salsa Verde grundlegend von Salsa Roja?",
    "optEn": [
      "Salsa Verde uses tart green Tomatillos (Physalis philadelphica); Salsa Roja uses ripe red tomatoes",
      "Salsa Verde is colored with spinach",
      "Salsa Verde has no chilis",
      "Salsa Roja uses red wine"
    ],
    "optDe": [
      "Salsa Verde basiert auf säuerlichen grünen Tomatillos; Salsa Roja auf reifen roten Tomaten",
      "Salsa Verde wird mit Spinat gefärbt",
      "Salsa Verde hat keine Chilis",
      "Salsa Roja enthält Rotwein"
    ],
    "correct": 0,
    "expEn": "Tomatillos are husked tart nightshades providing herbal citrus tang unlike sweeter red tomatoes.",
    "expDe": "Tomatillos besitzen eine spritzige Fruchtsäure und verleihen Salsa Verde ihren herben Kick."
  },
  {
    "id": "q_sau_10",
    "category": "sauces_condiments",
    "questionEn": "What is the classic culinary ratio for a French Vinaigrette?",
    "questionDe": "Was ist das klassische Grundverhältnis für eine französische Vinaigrette?",
    "optionsEn": [
      "3 parts oil to 1 part vinegar (or acid)",
      "1 part oil to 3 parts vinegar",
      "Equal parts oil and vinegar (1:1)",
      "5 parts vinegar to 1 part oil"
    ],
    "optionsDe": [
      "3 Teile Öl auf 1 Teil Essig (oder Säure)",
      "1 Teil Öl auf 3 Teile Essig",
      "Zu gleichen Teilen (1:1)",
      "5 Teile Essig auf 1 Teil Öl"
    ],
    "correctIndex": 0,
    "explanationEn": "The 3:1 ratio provides enough fat to coat salad leaves without overpowering tart acidity.",
    "explanationDe": "Drei Teile Öl binden einen Teil Säure zu einer harmonischen, mundfüllenden Salatsauce.",
    "qEn": "What is the classic culinary ratio for a French Vinaigrette?",
    "qDe": "Was ist das klassische Grundverhältnis für eine französische Vinaigrette?",
    "optEn": [
      "3 parts oil to 1 part vinegar (or acid)",
      "1 part oil to 3 parts vinegar",
      "Equal parts oil and vinegar (1:1)",
      "5 parts vinegar to 1 part oil"
    ],
    "optDe": [
      "3 Teile Öl auf 1 Teil Essig (oder Säure)",
      "1 Teil Öl auf 3 Teile Essig",
      "Zu gleichen Teilen (1:1)",
      "5 Teile Essig auf 1 Teil Öl"
    ],
    "correct": 0,
    "expEn": "The 3:1 ratio provides enough fat to coat salad leaves without overpowering tart acidity.",
    "expDe": "Drei Teile Öl binden einen Teil Säure zu einer harmonischen, mundfüllenden Salatsauce."
  },
  {
    "id": "q_sau_11",
    "category": "sauces_condiments",
    "questionEn": "Which essential ingredients create the iconic Caesar Dressing emulsification?",
    "questionDe": "Welche Zutaten sind unverzichtbar für ein authentisches Caesar Dressing?",
    "optionsEn": [
      "Egg yolk, salted anchovies, garlic, Parmesan, lemon juice, Dijon mustard, and Worcestershire sauce",
      "Yogurt, dill, and cucumber",
      "Tomato paste and paprika",
      "Sour cream and sugar"
    ],
    "optionsDe": [
      "Eigelb, Sardellenfilets, Knoblauch, Parmesan, Zitronensaft, Dijon und Worcestershire-Sauce",
      "Joghurt, Dill und Gurke",
      "Tomatenmark und Paprika",
      "Schmand und Zucker"
    ],
    "correctIndex": 0,
    "explanationEn": "Anchovies and aged Parmigiano-Reggiano provide the powerful natural glutamates (umami).",
    "explanationDe": "Sardellen und Parmesan liefern das typische, dichte Umami auf knackigem Römersalat.",
    "qEn": "Which essential ingredients create the iconic Caesar Dressing emulsification?",
    "qDe": "Welche Zutaten sind unverzichtbar für ein authentisches Caesar Dressing?",
    "optEn": [
      "Egg yolk, salted anchovies, garlic, Parmesan, lemon juice, Dijon mustard, and Worcestershire sauce",
      "Yogurt, dill, and cucumber",
      "Tomato paste and paprika",
      "Sour cream and sugar"
    ],
    "optDe": [
      "Eigelb, Sardellenfilets, Knoblauch, Parmesan, Zitronensaft, Dijon und Worcestershire-Sauce",
      "Joghurt, Dill und Gurke",
      "Tomatenmark und Paprika",
      "Schmand und Zucker"
    ],
    "correct": 0,
    "expEn": "Anchovies and aged Parmigiano-Reggiano provide the powerful natural glutamates (umami).",
    "expDe": "Sardellen und Parmesan liefern das typische, dichte Umami auf knackigem Römersalat."
  },
  {
    "id": "q_sau_12",
    "category": "sauces_condiments",
    "questionEn": "What is the base of authentic Italian Basil Pesto alla Genovese DOP?",
    "questionDe": "Woraus besteht echtes Pesto alla Genovese DOP?",
    "optionsEn": [
      "Fresh Genovese basil, pine nuts, garlic, Parmigiano, Pecorino Fiore Sardo, and extra virgin olive oil",
      "Parsley, walnuts, butter, and cream",
      "Coriander, cashews, and canola oil",
      "Basil, heavy cream, and cheddar"
    ],
    "optionsDe": [
      "Basilikum Genovese DOP, Pinienkerne, Knoblauch, Parmesan, Pecorino Sardo und Olivenöl",
      "Petersilie, Walnüsse und Sahne",
      "Koriander, Cashews und Rapsöl",
      "Basilikum, Sahne und Gouda"
    ],
    "correctIndex": 0,
    "explanationEn": "Traditionally pounded with a marble mortar and wooden pestle without friction heat.",
    "explanationDe": "Im Mörser zerstoßen bleiben ätherische Öle leuchtend grün und intensiv aromatisch.",
    "qEn": "What is the base of authentic Italian Basil Pesto alla Genovese DOP?",
    "qDe": "Woraus besteht echtes Pesto alla Genovese DOP?",
    "optEn": [
      "Fresh Genovese basil, pine nuts, garlic, Parmigiano, Pecorino Fiore Sardo, and extra virgin olive oil",
      "Parsley, walnuts, butter, and cream",
      "Coriander, cashews, and canola oil",
      "Basil, heavy cream, and cheddar"
    ],
    "optDe": [
      "Basilikum Genovese DOP, Pinienkerne, Knoblauch, Parmesan, Pecorino Sardo und Olivenöl",
      "Petersilie, Walnüsse und Sahne",
      "Koriander, Cashews und Rapsöl",
      "Basilikum, Sahne und Gouda"
    ],
    "correct": 0,
    "expEn": "Traditionally pounded with a marble mortar and wooden pestle without friction heat.",
    "expDe": "Im Mörser zerstoßen bleiben ätherische Öle leuchtend grün und intensiv aromatisch."
  },
  {
    "id": "q_sau_13",
    "category": "sauces_condiments",
    "questionEn": "Why does freshly made Bearnaise Sauce feature tarragon and chervil?",
    "questionDe": "Was unterscheidet Sauce Béarnaise geschmacklich von Sauce Hollandaise?",
    "optionsEn": [
      "Béarnaise incorporates a tarragon, chervil, shallot, and white wine vinegar reduction",
      "Béarnaise contains tomato paste",
      "Béarnaise contains curry powder",
      "Béarnaise uses olive oil"
    ],
    "optionsDe": [
      "Béarnaise enthält eine Reduktion aus Estragon, Kerbel, Schalotten und Weißweinessig",
      "Béarnaise enthält Tomatenmark",
      "Béarnaise wird mit Curry gewürzt",
      "Béarnaise basiert auf Olivenöl"
    ],
    "correctIndex": 0,
    "explanationEn": "The anise-herbal note of tarragon pairs exquisitely with grilled steak and tournedos.",
    "explanationDe": "Die Estragon-Kerbel-Reduktion schenkt der warmen Buttersauce ihre feine Frische.",
    "qEn": "Why does freshly made Bearnaise Sauce feature tarragon and chervil?",
    "qDe": "Was unterscheidet Sauce Béarnaise geschmacklich von Sauce Hollandaise?",
    "optEn": [
      "Béarnaise incorporates a tarragon, chervil, shallot, and white wine vinegar reduction",
      "Béarnaise contains tomato paste",
      "Béarnaise contains curry powder",
      "Béarnaise uses olive oil"
    ],
    "optDe": [
      "Béarnaise enthält eine Reduktion aus Estragon, Kerbel, Schalotten und Weißweinessig",
      "Béarnaise enthält Tomatenmark",
      "Béarnaise wird mit Curry gewürzt",
      "Béarnaise basiert auf Olivenöl"
    ],
    "correct": 0,
    "expEn": "The anise-herbal note of tarragon pairs exquisitely with grilled steak and tournedos.",
    "expDe": "Die Estragon-Kerbel-Reduktion schenkt der warmen Buttersauce ihre feine Frische."
  },
  {
    "id": "q_sau_14",
    "category": "sauces_condiments",
    "questionEn": "What is the defining umami ingredient in Worcestershire Sauce?",
    "questionDe": "Was ist der entscheidende Umami-Bringer in echter Worcestershire-Sauce?",
    "optionsEn": [
      "Fermented whole anchovies aged in vinegar and molasses casks",
      "MSG crystals",
      "Mushroom extract",
      "Beef bouillon"
    ],
    "optionsDe": [
      "Fermentierte ganze Sardellen, die jahrelang in Holzfässern mit Essig und Melasse reifen",
      "Künstliches Glutamat",
      "Pilzextrakt",
      "Rinderbrühe"
    ],
    "correctIndex": 0,
    "explanationEn": "Lea & Perrins ages anchovies for 18 months, creating deep savory depth.",
    "explanationDe": "Fassgereifte Sardellen schenken der Sauce ihre unvergleichliche Würztiefe.",
    "qEn": "What is the defining umami ingredient in Worcestershire Sauce?",
    "qDe": "Was ist der entscheidende Umami-Bringer in echter Worcestershire-Sauce?",
    "optEn": [
      "Fermented whole anchovies aged in vinegar and molasses casks",
      "MSG crystals",
      "Mushroom extract",
      "Beef bouillon"
    ],
    "optDe": [
      "Fermentierte ganze Sardellen, die jahrelang in Holzfässern mit Essig und Melasse reifen",
      "Künstliches Glutamat",
      "Pilzextrakt",
      "Rinderbrühe"
    ],
    "correct": 0,
    "expEn": "Lea & Perrins ages anchovies for 18 months, creating deep savory depth.",
    "expDe": "Fassgereifte Sardellen schenken der Sauce ihre unvergleichliche Würztiefe."
  },
  {
    "id": "q_sau_15",
    "category": "sauces_condiments",
    "questionEn": "What is French Remoulade sauce?",
    "questionDe": "Was ist eine klassische französische Remouladensauce?",
    "optionsEn": [
      "Mayonnaise blended with capers, chopped gherkins, fresh herbs, and anchovy essence",
      "Warm tomato sauce",
      "Sour cream with horseradish",
      "Hollandaise with red wine"
    ],
    "optionsDe": [
      "Mayonnaise verfeinert mit gehackten Kapern, Essiggurken, Kräutern und Sardellenpaste",
      "Warme Tomatensauce",
      "Sauerrahm mit Kren",
      "Hollandaise mit Rotwein"
    ],
    "correctIndex": 0,
    "explanationEn": "Remoulade provides piquant acid and herbal crunch, pairing traditionally with cold roast beef or fried fish.",
    "explanationDe": "Kapern und Cornichons bringen Säure und Textur zu Roastbeef oder Backfisch.",
    "qEn": "What is French Remoulade sauce?",
    "qDe": "Was ist eine klassische französische Remouladensauce?",
    "optEn": [
      "Mayonnaise blended with capers, chopped gherkins, fresh herbs, and anchovy essence",
      "Warm tomato sauce",
      "Sour cream with horseradish",
      "Hollandaise with red wine"
    ],
    "optDe": [
      "Mayonnaise verfeinert mit gehackten Kapern, Essiggurken, Kräutern und Sardellenpaste",
      "Warme Tomatensauce",
      "Sauerrahm mit Kren",
      "Hollandaise mit Rotwein"
    ],
    "correct": 0,
    "expEn": "Remoulade provides piquant acid and herbal crunch, pairing traditionally with cold roast beef or fried fish.",
    "expDe": "Kapern und Cornichons bringen Säure und Textur zu Roastbeef oder Backfisch."
  },
  {
    "id": "q_sau_16",
    "category": "sauces_condiments",
    "questionEn": "How is authentic Argentine Chimichurri prepared?",
    "questionDe": "Wie wird authentisches argentinisches Chimichurri zubereitet?",
    "optionsEn": [
      "Finely chopped flat-leaf parsley, garlic, oregano, red pepper flakes, olive oil, and red wine vinegar",
      "Cooked tomato and beef gravy",
      "Pureed avocado with lime",
      "Cilantro and coconut milk"
    ],
    "optionsDe": [
      "Gehackte glatte Petersilie, Knoblauch, Oregano, Chiliflocken, Olivenöl und Rotweinessig",
      "Gekochte Bratensauce",
      "Avocado-Püree mit Limette",
      "Koriander mit Kokosmilch"
    ],
    "correctIndex": 0,
    "explanationEn": "Chimichurri is a raw, tangy herb sauce that cuts through fatty Asado grilled meats.",
    "explanationDe": "Die frische Kräutersäure des Chimichurri durchbricht das reichhaltige Fett gegrillten Rindfleischs.",
    "qEn": "How is authentic Argentine Chimichurri prepared?",
    "qDe": "Wie wird authentisches argentinisches Chimichurri zubereitet?",
    "optEn": [
      "Finely chopped flat-leaf parsley, garlic, oregano, red pepper flakes, olive oil, and red wine vinegar",
      "Cooked tomato and beef gravy",
      "Pureed avocado with lime",
      "Cilantro and coconut milk"
    ],
    "optDe": [
      "Gehackte glatte Petersilie, Knoblauch, Oregano, Chiliflocken, Olivenöl und Rotweinessig",
      "Gekochte Bratensauce",
      "Avocado-Püree mit Limette",
      "Koriander mit Kokosmilch"
    ],
    "correct": 0,
    "expEn": "Chimichurri is a raw, tangy herb sauce that cuts through fatty Asado grilled meats.",
    "expDe": "Die frische Kräutersäure des Chimichurri durchbricht das reichhaltige Fett gegrillten Rindfleischs."
  },
  {
    "id": "q_sau_17",
    "category": "sauces_condiments",
    "questionEn": "What gives English Colman's Mustard its fiery nostril punch?",
    "questionDe": "Was erzeugt die stechende Nasenschärfe in englischem Colman's Senf?",
    "optionsEn": [
      "Enzyme myrosinase converting glucosinolates into volatile allyl isothiocyanate upon mixing with water",
      "Added capsaicin from chili",
      "Black pepper oil",
      "Concentrated vinegar"
    ],
    "optionsDe": [
      "Das Enzym Myrosinase spaltet Senfölglykoside beim Anrühren mit Wasser in Allylisothiocyanat",
      "Zusatz von reinem Chili-Capsaicin",
      "Schwarzer Pfefferextrakt",
      "Konzentrierte Essigsäure"
    ],
    "correctIndex": 0,
    "explanationEn": "Allyl isothiocyanate is volatile, rising into nasal passages similarly to wasabi.",
    "explanationDe": "Flüchtiges Senföl steigt sofort in die Nebenhöhlen und sorgt für intensive Schärfe.",
    "qEn": "What gives English Colman's Mustard its fiery nostril punch?",
    "qDe": "Was erzeugt die stechende Nasenschärfe in englischem Colman's Senf?",
    "optEn": [
      "Enzyme myrosinase converting glucosinolates into volatile allyl isothiocyanate upon mixing with water",
      "Added capsaicin from chili",
      "Black pepper oil",
      "Concentrated vinegar"
    ],
    "optDe": [
      "Das Enzym Myrosinase spaltet Senfölglykoside beim Anrühren mit Wasser in Allylisothiocyanat",
      "Zusatz von reinem Chili-Capsaicin",
      "Schwarzer Pfefferextrakt",
      "Konzentrierte Essigsäure"
    ],
    "correct": 0,
    "expEn": "Allyl isothiocyanate is volatile, rising into nasal passages similarly to wasabi.",
    "expDe": "Flüchtiges Senföl steigt sofort in die Nebenhöhlen und sorgt für intensive Schärfe."
  },
  {
    "id": "q_sau_18",
    "category": "sauces_condiments",
    "questionEn": "Why is Honey-Mustard dressing so stable compared to plain oil-and-vinegar?",
    "questionDe": "Warum ist Honig-Senf-Dressing stabiler als reine Essig-Öl-Mischungen?",
    "optionsEn": [
      "Mustard mucilage and honey sugars act as natural emulsifiers, preventing oil droplet coalescence",
      "Honey freezes the dressing",
      "Vinegar boils the oil",
      "Salt dissolves all fat"
    ],
    "optionsDe": [
      "Schleimstoffe im Senf und zähe Honigzucker wirken als natürliche Emulgatoren",
      "Honig lässt das Dressing gefrieren",
      "Essig kocht das Öl auf",
      "Salz löst Fett auf"
    ],
    "correctIndex": 0,
    "explanationEn": "Polysaccharides in mustard coat oil globules, maintaining a silky, creamy emulsion.",
    "explanationDe": "Senfschleimstoffe stabilisieren die Tröpfchen und verhindern das Entmischen.",
    "qEn": "Why is Honey-Mustard dressing so stable compared to plain oil-and-vinegar?",
    "qDe": "Warum ist Honig-Senf-Dressing stabiler als reine Essig-Öl-Mischungen?",
    "optEn": [
      "Mustard mucilage and honey sugars act as natural emulsifiers, preventing oil droplet coalescence",
      "Honey freezes the dressing",
      "Vinegar boils the oil",
      "Salt dissolves all fat"
    ],
    "optDe": [
      "Schleimstoffe im Senf und zähe Honigzucker wirken als natürliche Emulgatoren",
      "Honig lässt das Dressing gefrieren",
      "Essig kocht das Öl auf",
      "Salz löst Fett auf"
    ],
    "correct": 0,
    "expEn": "Polysaccharides in mustard coat oil globules, maintaining a silky, creamy emulsion.",
    "expDe": "Senfschleimstoffe stabilisieren die Tröpfchen und verhindern das Entmischen."
  },
  {
    "id": "q_sft_01",
    "category": "soft_drinks",
    "questionEn": "Which bitter alkaloid defines authentic Tonic Water?",
    "questionDe": "Welches Bitteralkaloid kennzeichnet echtes Tonic Water?",
    "optionsEn": [
      "Quinine extracted from Cinchona bark",
      "Caffeine",
      "Theobromine",
      "Capsaicin"
    ],
    "optionsDe": [
      "Chinin aus der Rinde des Chinarindenbaums",
      "Koffein",
      "Theobromin",
      "Capsaicin"
    ],
    "correctIndex": 0,
    "explanationEn": "Quinine was originally taken by British officers against malaria; it fluoresces bright blue under UV light.",
    "explanationDe": "Chinin stammt aus der Chinarinde und leuchtet unter ultraviolettem Schwarzlicht bläulich.",
    "qEn": "Which bitter alkaloid defines authentic Tonic Water?",
    "qDe": "Welches Bitteralkaloid kennzeichnet echtes Tonic Water?",
    "optEn": [
      "Quinine extracted from Cinchona bark",
      "Caffeine",
      "Theobromine",
      "Capsaicin"
    ],
    "optDe": [
      "Chinin aus der Rinde des Chinarindenbaums",
      "Koffein",
      "Theobromin",
      "Capsaicin"
    ],
    "correct": 0,
    "expEn": "Quinine was originally taken by British officers against malaria; it fluoresces bright blue under UV light.",
    "expDe": "Chinin stammt aus der Chinarinde und leuchtet unter ultraviolettem Schwarzlicht bläulich."
  },
  {
    "id": "q_sft_02",
    "category": "soft_drinks",
    "questionEn": "Why does Tonic Water fluoresce bright blue under ultraviolet blacklight?",
    "questionDe": "Warum leuchtet Tonic Water unter UV-Schwarzlicht bläulich?",
    "optionsEn": [
      "Quinine molecules absorb UV photons and re-emit visible blue light (fluorescence)",
      "Artificial blue food dye",
      "Dissolved carbon dioxide bubbles",
      "Sugar crystallization"
    ],
    "optionsDe": [
      "Chininmoleküle absorbieren UV-Strahlung und emittieren blaues Licht (Fluoreszenz)",
      "Blauer Lebensmittelfarbstoff",
      "Gelöste CO2-Bläschen",
      "Zuckerkristalle"
    ],
    "correctIndex": 0,
    "explanationEn": "Quinine contains a quinoline ring that naturally fluoresces at 450nm.",
    "explanationDe": "Die Molekülstruktur des Chinins regt natürliche Fluoreszenz bei UV-Licht an.",
    "qEn": "Why does Tonic Water fluoresce bright blue under ultraviolet blacklight?",
    "qDe": "Warum leuchtet Tonic Water unter UV-Schwarzlicht bläulich?",
    "optEn": [
      "Quinine molecules absorb UV photons and re-emit visible blue light (fluorescence)",
      "Artificial blue food dye",
      "Dissolved carbon dioxide bubbles",
      "Sugar crystallization"
    ],
    "optDe": [
      "Chininmoleküle absorbieren UV-Strahlung und emittieren blaues Licht (Fluoreszenz)",
      "Blauer Lebensmittelfarbstoff",
      "Gelöste CO2-Bläschen",
      "Zuckerkristalle"
    ],
    "correct": 0,
    "expEn": "Quinine contains a quinoline ring that naturally fluoresces at 450nm.",
    "expDe": "Die Molekülstruktur des Chinins regt natürliche Fluoreszenz bei UV-Licht an."
  },
  {
    "id": "q_sft_03",
    "category": "soft_drinks",
    "questionEn": "What is the difference between Ginger Ale and Ginger Beer?",
    "questionDe": "Was unterscheidet Ginger Ale von echtem Ginger Beer?",
    "optionsEn": [
      "Ginger Beer is brewed and fermented with real ginger roots (cloudy, spicy heat); Ginger Ale is carbonated sweet ginger soda",
      "Ginger Ale contains 10% alcohol",
      "Ginger Beer contains hops",
      "Ginger Ale is black"
    ],
    "optionsDe": [
      "Ginger Beer wird aus Ingwerwurzel fermentiert (trüb, scharf); Ginger Ale ist eine milde, klare Ingwer-Limonade",
      "Ginger Ale enthält Alkohol",
      "Ginger Beer enthält Hopfen",
      "Ginger Ale ist dunkel wie Cola"
    ],
    "correctIndex": 0,
    "explanationEn": "Ginger Beer provides the sharp, fiery kick required for Moscow Mules and Dark 'n Stormy cocktails.",
    "explanationDe": "Echtes Ginger Beer bringt authentische Ingwerschärfe und feine Trübung ins Glas.",
    "qEn": "What is the difference between Ginger Ale and Ginger Beer?",
    "qDe": "Was unterscheidet Ginger Ale von echtem Ginger Beer?",
    "optEn": [
      "Ginger Beer is brewed and fermented with real ginger roots (cloudy, spicy heat); Ginger Ale is carbonated sweet ginger soda",
      "Ginger Ale contains 10% alcohol",
      "Ginger Beer contains hops",
      "Ginger Ale is black"
    ],
    "optDe": [
      "Ginger Beer wird aus Ingwerwurzel fermentiert (trüb, scharf); Ginger Ale ist eine milde, klare Ingwer-Limonade",
      "Ginger Ale enthält Alkohol",
      "Ginger Beer enthält Hopfen",
      "Ginger Ale ist dunkel wie Cola"
    ],
    "correct": 0,
    "expEn": "Ginger Beer provides the sharp, fiery kick required for Moscow Mules and Dark 'n Stormy cocktails.",
    "expDe": "Echtes Ginger Beer bringt authentische Ingwerschärfe und feine Trübung ins Glas."
  },
  {
    "id": "q_sft_04",
    "category": "soft_drinks",
    "questionEn": "What plant seed gave original Cola drinks their name and caffeine?",
    "questionDe": "Welcher afrikanische Baumsamen gab Cola-Getränken ihren Namen und Koffein?",
    "optionsEn": [
      "Kola nut (Cola acuminata)",
      "Cocoa bean",
      "Coffee cherry",
      "Nutmeg"
    ],
    "optionsDe": [
      "Kolanuss (Cola acuminata)",
      "Kakaobohne",
      "Kaffeekirsche",
      "Muskatnuss"
    ],
    "correctIndex": 0,
    "explanationEn": "Kola nuts contain caffeine and theobromine, traditionally chewed in West Africa.",
    "explanationDe": "Die afrikanische Kolanuss lieferte das ursprüngliche Koffein für Cola-Sirup.",
    "qEn": "What plant seed gave original Cola drinks their name and caffeine?",
    "qDe": "Welcher afrikanische Baumsamen gab Cola-Getränken ihren Namen und Koffein?",
    "optEn": [
      "Kola nut (Cola acuminata)",
      "Cocoa bean",
      "Coffee cherry",
      "Nutmeg"
    ],
    "optDe": [
      "Kolanuss (Cola acuminata)",
      "Kakaobohne",
      "Kaffeekirsche",
      "Muskatnuss"
    ],
    "correct": 0,
    "expEn": "Kola nuts contain caffeine and theobromine, traditionally chewed in West Africa.",
    "expDe": "Die afrikanische Kolanuss lieferte das ursprüngliche Koffein für Cola-Sirup."
  },
  {
    "id": "q_sft_05",
    "category": "soft_drinks",
    "questionEn": "What amino acid is standard in modern Energy Drinks?",
    "questionDe": "Welche Aminosulfonsäure ist ein Standardbestandteil in Energy Drinks?",
    "optionsEn": [
      "Taurine (2-aminoethanesulfonic acid)",
      "Creatine",
      "Lysine",
      "Glutamine"
    ],
    "optionsDe": [
      "Taurin (2-Aminoethansulfonsäure)",
      "Kreatin",
      "Lysin",
      "Glutamin"
    ],
    "correctIndex": 0,
    "explanationEn": "Taurine supports bile acid conjugation and membrane stabilization in metabolic pathways.",
    "explanationDe": "Taurin reguliert den Flüssigkeitshaushalt und stärkt die Wirkung von Koffein.",
    "qEn": "What amino acid is standard in modern Energy Drinks?",
    "qDe": "Welche Aminosulfonsäure ist ein Standardbestandteil in Energy Drinks?",
    "optEn": [
      "Taurine (2-aminoethanesulfonic acid)",
      "Creatine",
      "Lysine",
      "Glutamine"
    ],
    "optDe": [
      "Taurin (2-Aminoethansulfonsäure)",
      "Kreatin",
      "Lysin",
      "Glutamin"
    ],
    "correct": 0,
    "expEn": "Taurine supports bile acid conjugation and membrane stabilization in metabolic pathways.",
    "expDe": "Taurin reguliert den Flüssigkeitshaushalt und stärkt die Wirkung von Koffein."
  },
  {
    "id": "q_sft_06",
    "category": "soft_drinks",
    "questionEn": "What is Club Soda compared to Seltzer Water?",
    "questionDe": "Was unterscheidet Club Soda von reinem Seltzer-Wasser?",
    "optionsEn": [
      "Club Soda contains added mineral salts (potassium bicarbonate, sodium chloride) for clean crispness; Seltzer is plain carbonated water",
      "Club Soda has alcohol",
      "Seltzer contains lemon juice",
      "Club Soda is sweetened with honey"
    ],
    "optionsDe": [
      "Club Soda enthält zugesetzte Mineralsalze für weichen Geschmack; Seltzer ist reines Sprudelwasser",
      "Club Soda hat Alkohol",
      "Seltzer hat Zitronensaft",
      "Club Soda ist gesüßt"
    ],
    "correctIndex": 0,
    "explanationEn": "Mineral salts replicate natural spring water taste and buffer acidity in cocktails.",
    "explanationDe": "Mineralien im Club Soda puffern die Säure von Spirituosen und Zitrusfrüchten ab.",
    "qEn": "What is Club Soda compared to Seltzer Water?",
    "qDe": "Was unterscheidet Club Soda von reinem Seltzer-Wasser?",
    "optEn": [
      "Club Soda contains added mineral salts (potassium bicarbonate, sodium chloride) for clean crispness; Seltzer is plain carbonated water",
      "Club Soda has alcohol",
      "Seltzer contains lemon juice",
      "Club Soda is sweetened with honey"
    ],
    "optDe": [
      "Club Soda enthält zugesetzte Mineralsalze für weichen Geschmack; Seltzer ist reines Sprudelwasser",
      "Club Soda hat Alkohol",
      "Seltzer hat Zitronensaft",
      "Club Soda ist gesüßt"
    ],
    "correct": 0,
    "expEn": "Mineral salts replicate natural spring water taste and buffer acidity in cocktails.",
    "expDe": "Mineralien im Club Soda puffern die Säure von Spirituosen und Zitrusfrüchten ab."
  },
  {
    "id": "q_sft_07",
    "category": "soft_drinks",
    "questionEn": "What acid provides the characteristic sharp bite in dark Cola beverages?",
    "questionDe": "Welche Säure erzeugt den typischen herben Biss in dunklen Cola-Getränken?",
    "optionsEn": [
      "Phosphoric acid (H3PO4)",
      "Citric acid only",
      "Acetic acid",
      "Lactic acid"
    ],
    "optionsDe": [
      "Phosphorsäure (H3PO4)",
      "Reine Zitronensäure",
      "Essigsäure",
      "Milchsäure"
    ],
    "correctIndex": 0,
    "explanationEn": "Phosphoric acid delivers an astringent tartness that cuts through heavy sugar sweetness.",
    "explanationDe": "Phosphorsäure verleiht Cola ihre typische trockene Säure und verhindert klebrigen Nachgeschmack.",
    "qEn": "What acid provides the characteristic sharp bite in dark Cola beverages?",
    "qDe": "Welche Säure erzeugt den typischen herben Biss in dunklen Cola-Getränken?",
    "optEn": [
      "Phosphoric acid (H3PO4)",
      "Citric acid only",
      "Acetic acid",
      "Lactic acid"
    ],
    "optDe": [
      "Phosphorsäure (H3PO4)",
      "Reine Zitronensäure",
      "Essigsäure",
      "Milchsäure"
    ],
    "correct": 0,
    "expEn": "Phosphoric acid delivers an astringent tartness that cuts through heavy sugar sweetness.",
    "expDe": "Phosphorsäure verleiht Cola ihre typische trockene Säure und verhindert klebrigen Nachgeschmack."
  },
  {
    "id": "q_sft_08",
    "category": "soft_drinks",
    "questionEn": "What is Bitter Lemon?",
    "questionDe": "Was ist Bitter Lemon?",
    "optionsEn": [
      "A carbonated soft drink combining tart lemon juice with bitter quinine",
      "Unsweetened squeezed lemon",
      "Limoncello liqueur",
      "Fermented lime juice"
    ],
    "optionsDe": [
      "Ein kohlensäurehaltiges Erfrischungsgetränk aus Zitronensaft und bitterem Chinin",
      "Ungesüßter Zitronensaft",
      "Limoncello-Likör",
      "Vergorener Limettensaft"
    ],
    "correctIndex": 0,
    "explanationEn": "The contrast between citric tartness and chinine bitterness makes it a classic highball mixer.",
    "explanationDe": "Die Liaison aus saurer Zitrone und bitterem Chinin macht Bitter Lemon zum Bar-Klassiker.",
    "qEn": "What is Bitter Lemon?",
    "qDe": "Was ist Bitter Lemon?",
    "optEn": [
      "A carbonated soft drink combining tart lemon juice with bitter quinine",
      "Unsweetened squeezed lemon",
      "Limoncello liqueur",
      "Fermented lime juice"
    ],
    "optDe": [
      "Ein kohlensäurehaltiges Erfrischungsgetränk aus Zitronensaft und bitterem Chinin",
      "Ungesüßter Zitronensaft",
      "Limoncello-Likör",
      "Vergorener Limettensaft"
    ],
    "correct": 0,
    "expEn": "The contrast between citric tartness and chinine bitterness makes it a classic highball mixer.",
    "expDe": "Die Liaison aus saurer Zitrone und bitterem Chinin macht Bitter Lemon zum Bar-Klassiker."
  },
  {
    "id": "q_sft_09",
    "category": "soft_drinks",
    "questionEn": "What tree bark extract provides the foamy head on Root Beer?",
    "questionDe": "Welcher pflanzliche Extrakt erzeugte traditionell den stabilen Schaum auf Root Beer?",
    "optionsEn": [
      "Sarsaparilla root or Sassafras bark (and yucca extract)",
      "Oak bark",
      "Willow bark",
      "Pine needles"
    ],
    "optionsDe": [
      "Sarsaparilla-Wurzel oder Sassafras-Rinde (sowie Yucca-Extrakt)",
      "Eichenrinde",
      "Weidenrinde",
      "Kiefernnadeln"
    ],
    "correctIndex": 0,
    "explanationEn": "Saponins in sarsaparilla and yucca froth into thick, creamy root beer foam.",
    "explanationDe": "Saponine in Wurzelkräutern schäumen cremig auf und duften nach Wintergrün.",
    "qEn": "What tree bark extract provides the foamy head on Root Beer?",
    "qDe": "Welcher pflanzliche Extrakt erzeugte traditionell den stabilen Schaum auf Root Beer?",
    "optEn": [
      "Sarsaparilla root or Sassafras bark (and yucca extract)",
      "Oak bark",
      "Willow bark",
      "Pine needles"
    ],
    "optDe": [
      "Sarsaparilla-Wurzel oder Sassafras-Rinde (sowie Yucca-Extrakt)",
      "Eichenrinde",
      "Weidenrinde",
      "Kiefernnadeln"
    ],
    "correct": 0,
    "expEn": "Saponins in sarsaparilla and yucca froth into thick, creamy root beer foam.",
    "expDe": "Saponine in Wurzelkräutern schäumen cremig auf und duften nach Wintergrün."
  },
  {
    "id": "q_sft_08b",
    "category": "soft_drinks",
    "questionEn": "What is Mexican Coke celebrated for among beverage connoisseurs?",
    "questionDe": "Wofür wird mexikanische Coca-Cola von Kennern geschätzt?",
    "optionsEn": [
      "Sweetened with 100% natural cane sugar instead of High Fructose Corn Syrup (HFCS)",
      "Contains real cocaine",
      "Contains green lime juice",
      "Is triple carbonated"
    ],
    "optionsDe": [
      "Mit 100% echtem Rohrzucker gesüßt statt mit Maisstärkesirup (HFCS)",
      "Enthält echtes Kokain",
      "Enthält Limettensaft",
      "Ist dreifach kohlensäurehaltig"
    ],
    "correctIndex": 0,
    "explanationEn": "Pure cane sugar provides a cleaner mouthfeel and crisper finish without cloying corn syrup viscosity.",
    "explanationDe": "Echter Rohrzucker sorgt für ein klares Mundgefühl ohne klebrigen Nachgeschmack.",
    "qEn": "What is Mexican Coke celebrated for among beverage connoisseurs?",
    "qDe": "Wofür wird mexikanische Coca-Cola von Kennern geschätzt?",
    "optEn": [
      "Sweetened with 100% natural cane sugar instead of High Fructose Corn Syrup (HFCS)",
      "Contains real cocaine",
      "Contains green lime juice",
      "Is triple carbonated"
    ],
    "optDe": [
      "Mit 100% echtem Rohrzucker gesüßt statt mit Maisstärkesirup (HFCS)",
      "Enthält echtes Kokain",
      "Enthält Limettensaft",
      "Ist dreifach kohlensäurehaltig"
    ],
    "correct": 0,
    "expEn": "Pure cane sugar provides a cleaner mouthfeel and crisper finish without cloying corn syrup viscosity.",
    "expDe": "Echter Rohrzucker sorgt für ein klares Mundgefühl ohne klebrigen Nachgeschmack."
  },
  {
    "id": "q_sft_11",
    "category": "soft_drinks",
    "questionEn": "What gives San Pellegrino Aranciata Rossa its color and flavor?",
    "questionDe": "Was verleiht italienischer Aranciata Rossa ihr Aroma?",
    "optionsEn": [
      "Blood orange juice (Moro, Tarocco, or Sanguinello from Sicily)",
      "Red food dye #40",
      "Beet juice extract only",
      "Cherry syrup"
    ],
    "optionsDe": [
      "Sizilianischer Blutorangensaft (Moro, Tarocco oder Sanguinello)",
      "Roter synthetischer Farbstoff",
      "Rote-Bete-Saft",
      "Kirschsirup"
    ],
    "correctIndex": 0,
    "explanationEn": "Anthocyanin pigments in Sicilian blood oranges deliver raspberry-citrus complexity.",
    "explanationDe": "Sizilianische Blutorangen enthalten Anthocyane mit herbsüßem Beerenaroma.",
    "qEn": "What gives San Pellegrino Aranciata Rossa its color and flavor?",
    "qDe": "Was verleiht italienischer Aranciata Rossa ihr Aroma?",
    "optEn": [
      "Blood orange juice (Moro, Tarocco, or Sanguinello from Sicily)",
      "Red food dye #40",
      "Beet juice extract only",
      "Cherry syrup"
    ],
    "optDe": [
      "Sizilianischer Blutorangensaft (Moro, Tarocco oder Sanguinello)",
      "Roter synthetischer Farbstoff",
      "Rote-Bete-Saft",
      "Kirschsirup"
    ],
    "correct": 0,
    "expEn": "Anthocyanin pigments in Sicilian blood oranges deliver raspberry-citrus complexity.",
    "expDe": "Sizilianische Blutorangen enthalten Anthocyane mit herbsüßem Beerenaroma."
  },
  {
    "id": "q_sft_12",
    "category": "soft_drinks",
    "questionEn": "What is Kombucha biologically?",
    "questionDe": "Was ist Kombucha aus biologischer Sicht?",
    "optionsEn": [
      "A fermented sweet tea drink cultured with a symbiotic culture of bacteria and yeast (SCOBY)",
      "Distilled herbal wine",
      "Pasteurized green tea soda",
      "Mushroom tea without sugar"
    ],
    "optionsDe": [
      "Ein fermentierter süßer Tee, vergoren mit einer Kultur aus Bakterien und Hefen (SCOBY)",
      "Destillierter Kräuterwein",
      "Pasteurisierte Grüntee-Limo",
      "Pilztee ohne Zucker"
    ],
    "correctIndex": 0,
    "explanationEn": "Yeasts produce ethanol; acetic acid bacteria convert it to tart gluconic and acetic acids.",
    "explanationDe": "Die Lebensgemeinschaft aus Hefen und Essigsäurebakterien erzeugt prickelnde Säure.",
    "qEn": "What is Kombucha biologically?",
    "qDe": "Was ist Kombucha aus biologischer Sicht?",
    "optEn": [
      "A fermented sweet tea drink cultured with a symbiotic culture of bacteria and yeast (SCOBY)",
      "Distilled herbal wine",
      "Pasteurized green tea soda",
      "Mushroom tea without sugar"
    ],
    "optDe": [
      "Ein fermentierter süßer Tee, vergoren mit einer Kultur aus Bakterien und Hefen (SCOBY)",
      "Destillierter Kräuterwein",
      "Pasteurisierte Grüntee-Limo",
      "Pilztee ohne Zucker"
    ],
    "correct": 0,
    "expEn": "Yeasts produce ethanol; acetic acid bacteria convert it to tart gluconic and acetic acids.",
    "expDe": "Die Lebensgemeinschaft aus Hefen und Essigsäurebakterien erzeugt prickelnde Säure."
  },
  {
    "id": "q_sft_13",
    "category": "soft_drinks",
    "questionEn": "What gives Chinotto, the Italian bittersweet soda, its dark color and herbal flavor?",
    "questionDe": "Woraus wird die italienische Kult-Kräuterlimonade Chinotto gewonnen?",
    "optionsEn": [
      "Extract of small, bitter myrtle-leaved orange fruit (Citrus myrtifolia)",
      "Dark roasted malt",
      "Black licorice root",
      "Caramelized onions"
    ],
    "optionsDe": [
      "Extrakt der kleinen, herben Bitterorange Chinotto (Citrus myrtifolia)",
      "Dunkles Röstmalz",
      "Schwarze Lakritzwurzel",
      "Karamellisierte Zwiebeln"
    ],
    "correctIndex": 0,
    "explanationEn": "Chinotto delivers complex alpine herbs and bitter orange zest flavors.",
    "explanationDe": "Die bitteren Zwergorangen aus Ligurien schmecken feinherb, krautig und erfrischend.",
    "qEn": "What gives Chinotto, the Italian bittersweet soda, its dark color and herbal flavor?",
    "qDe": "Woraus wird die italienische Kult-Kräuterlimonade Chinotto gewonnen?",
    "optEn": [
      "Extract of small, bitter myrtle-leaved orange fruit (Citrus myrtifolia)",
      "Dark roasted malt",
      "Black licorice root",
      "Caramelized onions"
    ],
    "optDe": [
      "Extrakt der kleinen, herben Bitterorange Chinotto (Citrus myrtifolia)",
      "Dunkles Röstmalz",
      "Schwarze Lakritzwurzel",
      "Karamellisierte Zwiebeln"
    ],
    "correct": 0,
    "expEn": "Chinotto delivers complex alpine herbs and bitter orange zest flavors.",
    "expDe": "Die bitteren Zwergorangen aus Ligurien schmecken feinherb, krautig und erfrischend."
  },
  {
    "id": "q_sft_14",
    "category": "soft_drinks",
    "questionEn": "Why does soda lose carbonation faster when warm than when chilled?",
    "questionDe": "Warum perlt warme Limonade viel schneller aus als eisgekühlte?",
    "optionsEn": [
      "Carbon dioxide solubility in water decreases as liquid temperature rises",
      "Heat destroys the CO2 molecule",
      "Warm cans have holes",
      "Sugar turns gas into syrup"
    ],
    "optionsDe": [
      "Die Löslichkeit von Kohlendioxid in Wasser sinkt mit steigender Temperatur drastisch",
      "Hitze zerstört Kohlensäure",
      "Warme Dosen sind undicht",
      "Zucker schluckt das Gas"
    ],
    "correctIndex": 0,
    "explanationEn": "Cold water molecules pack tighter, trapping gaseous CO2 in hydrated liquid solution.",
    "explanationDe": "Kaltes Wasser kann deutlich mehr CO2 physikalisch binden als warme Flüssigkeit.",
    "qEn": "Why does soda lose carbonation faster when warm than when chilled?",
    "qDe": "Warum perlt warme Limonade viel schneller aus als eisgekühlte?",
    "optEn": [
      "Carbon dioxide solubility in water decreases as liquid temperature rises",
      "Heat destroys the CO2 molecule",
      "Warm cans have holes",
      "Sugar turns gas into syrup"
    ],
    "optDe": [
      "Die Löslichkeit von Kohlendioxid in Wasser sinkt mit steigender Temperatur drastisch",
      "Hitze zerstört Kohlensäure",
      "Warme Dosen sind undicht",
      "Zucker schluckt das Gas"
    ],
    "correct": 0,
    "expEn": "Cold water molecules pack tighter, trapping gaseous CO2 in hydrated liquid solution.",
    "expDe": "Kaltes Wasser kann deutlich mehr CO2 physikalisch binden als warme Flüssigkeit."
  },
  {
    "id": "q_sft_15",
    "category": "soft_drinks",
    "questionEn": "What is an Italian 'Aperitivo Soda' (e.g. Sanbittèr, Crodino)?",
    "questionDe": "Was zeichnet alkoholfreie italienische Bitter-Sodas (Sanbittèr, Crodino) aus?",
    "optionsEn": [
      "Bittersweet sparkling infusion of gentian root, orange peel, and botanical herbs",
      "Pure grapefruit juice",
      "Red sparkling wine with alcohol removed",
      "Sweet cherry soda"
    ],
    "optionsDe": [
      "Feinherbe, kohlensäurehaltige Kräuterauszüge aus Enzian, Bitterorange und Kräutern",
      "Reiner Grapefruitsaft",
      "Alkoholfreier Schaumwein",
      "Süße Kirschlimonade"
    ],
    "correctIndex": 0,
    "explanationEn": "Designed to stimulate stomach gastric juices before a meal without any alcohol.",
    "explanationDe": "Die enthaltenen Bitterstoffe regen Appetit und Magensaftproduktion ideal an.",
    "qEn": "What is an Italian 'Aperitivo Soda' (e.g. Sanbittèr, Crodino)?",
    "qDe": "Was zeichnet alkoholfreie italienische Bitter-Sodas (Sanbittèr, Crodino) aus?",
    "optEn": [
      "Bittersweet sparkling infusion of gentian root, orange peel, and botanical herbs",
      "Pure grapefruit juice",
      "Red sparkling wine with alcohol removed",
      "Sweet cherry soda"
    ],
    "optDe": [
      "Feinherbe, kohlensäurehaltige Kräuterauszüge aus Enzian, Bitterorange und Kräutern",
      "Reiner Grapefruitsaft",
      "Alkoholfreier Schaumwein",
      "Süße Kirschlimonade"
    ],
    "correct": 0,
    "expEn": "Designed to stimulate stomach gastric juices before a meal without any alcohol.",
    "expDe": "Die enthaltenen Bitterstoffe regen Appetit und Magensaftproduktion ideal an."
  },
  {
    "id": "q_sft_16",
    "category": "soft_drinks",
    "questionEn": "What flavor profile defines Horchata de Chufa in Valencia?",
    "questionDe": "Was prägt die spanische Horchata de Chufa aus Valencia?",
    "optionsEn": [
      "Creamy, nutty plant milk made from soaked tiger nuts (chufa tubers), water, and sugar",
      "Rice and cinnamon milk",
      "Almond marzipan drink",
      "Coconut milk shake"
    ],
    "optionsDe": [
      "Cremige Erdmandelmilch aus Chufa-Knollen, Wasser und feinem Zucker",
      "Reis-Zimt-Milch",
      "Mandelmarzipantrank",
      "Kokosnuss-Shake"
    ],
    "correctIndex": 0,
    "explanationEn": "Tiger nuts (Cyperus esculentus) yield rich, naturally sweet plant lipids without dairy.",
    "explanationDe": "Chufas sind Erdmandeln und liefern eine nussige, erfrischende Pflanzenmilch.",
    "qEn": "What flavor profile defines Horchata de Chufa in Valencia?",
    "qDe": "Was prägt die spanische Horchata de Chufa aus Valencia?",
    "optEn": [
      "Creamy, nutty plant milk made from soaked tiger nuts (chufa tubers), water, and sugar",
      "Rice and cinnamon milk",
      "Almond marzipan drink",
      "Coconut milk shake"
    ],
    "optDe": [
      "Cremige Erdmandelmilch aus Chufa-Knollen, Wasser und feinem Zucker",
      "Reis-Zimt-Milch",
      "Mandelmarzipantrank",
      "Kokosnuss-Shake"
    ],
    "correct": 0,
    "expEn": "Tiger nuts (Cyperus esculentus) yield rich, naturally sweet plant lipids without dairy.",
    "expDe": "Chufas sind Erdmandeln und liefern eine nussige, erfrischende Pflanzenmilch."
  },
  {
    "id": "q_sft_17",
    "category": "soft_drinks",
    "questionEn": "What gives cream soda its distinctive mouthfeel and dessert aroma?",
    "questionDe": "Was verleiht Cream Soda sein typisches Dessertaroma und weiches Mundgefühl?",
    "optionsEn": [
      "Natural vanilla extract and smooth micro-carbonation",
      "Heavy whipping cream",
      "Butter solids",
      "Egg white meringue"
    ],
    "optionsDe": [
      "Natürliches Vanille-Aroma und feinperlige Kohlensäure",
      "Reine flüssige Sahne",
      "Geschmolzene Butter",
      "Eischnee"
    ],
    "correctIndex": 0,
    "explanationEn": "Vanilla aroma simulates melted ice cream notes without requiring dairy fats.",
    "explanationDe": "Vanillearomen erwecken die Assoziation von cremigem Vanilleeis.",
    "qEn": "What gives cream soda its distinctive mouthfeel and dessert aroma?",
    "qDe": "Was verleiht Cream Soda sein typisches Dessertaroma und weiches Mundgefühl?",
    "optEn": [
      "Natural vanilla extract and smooth micro-carbonation",
      "Heavy whipping cream",
      "Butter solids",
      "Egg white meringue"
    ],
    "optDe": [
      "Natürliches Vanille-Aroma und feinperlige Kohlensäure",
      "Reine flüssige Sahne",
      "Geschmolzene Butter",
      "Eischnee"
    ],
    "correct": 0,
    "expEn": "Vanilla aroma simulates melted ice cream notes without requiring dairy fats.",
    "expDe": "Vanillearomen erwecken die Assoziation von cremigem Vanilleeis."
  },
  {
    "id": "q_sft_18",
    "category": "soft_drinks",
    "questionEn": "What natural plant pigment creates the ruby hue in Hibiscus Iced Tea (Karkadeh)?",
    "questionDe": "Welcher Pflanzenfarbstoff färbt Hibiskustee (Karkadeh) leuchtend rubinrot?",
    "optionsEn": [
      "Anthocyanins in dried Hibiscus sabdariffa calyces",
      "Carotene",
      "Chlorophyll",
      "Lycopene"
    ],
    "optionsDe": [
      "Anthocyane in den getrockneten Blütenkelchen von Hibiscus sabdariffa",
      "Carotin",
      "Chlorophyll",
      "Lycopin"
    ],
    "correctIndex": 0,
    "explanationEn": "Anthocyanins provide cranberry-like tartness and stunning natural crimson color.",
    "explanationDe": "Die Blütenkelche enthalten fruchtige Fruchtsäuren und natürliche rote Pflanzenpigmente.",
    "qEn": "What natural plant pigment creates the ruby hue in Hibiscus Iced Tea (Karkadeh)?",
    "qDe": "Welcher Pflanzenfarbstoff färbt Hibiskustee (Karkadeh) leuchtend rubinrot?",
    "optEn": [
      "Anthocyanins in dried Hibiscus sabdariffa calyces",
      "Carotene",
      "Chlorophyll",
      "Lycopene"
    ],
    "optDe": [
      "Anthocyane in den getrockneten Blütenkelchen von Hibiscus sabdariffa",
      "Carotin",
      "Chlorophyll",
      "Lycopin"
    ],
    "correct": 0,
    "expEn": "Anthocyanins provide cranberry-like tartness and stunning natural crimson color.",
    "expDe": "Die Blütenkelche enthalten fruchtige Fruchtsäuren und natürliche rote Pflanzenpigmente."
  },
  {
    "id": "q_dai_01",
    "category": "dairy",
    "questionEn": "What is the legal minimum milk fat content of German 'Vollmilch' (whole milk)?",
    "questionDe": "Wie hoch ist der gesetzliche Mindestfettgehalt für Vollmilch in Deutschland?",
    "optionsEn": [
      "3.5% fat (or natural fat content typically 3.8-4.2%)",
      "1.5% fat",
      "0.3% fat",
      "10% fat"
    ],
    "optionsDe": [
      "Mindestens 3,5% Fett (bzw. natürlicher Fettgehalt 3,8–4,2%)",
      "1,5% Fett",
      "0,3% Fett",
      "10% Fett"
    ],
    "correctIndex": 0,
    "explanationEn": "Standardized whole milk is adjusted to 3.5% milk fat; raw milk contains 3.8-4.2%.",
    "explanationDe": "Standardisierte Vollmilch enthält 3,5% Fett; fettarme Milch liegt bei 1,5–1,8%.",
    "qEn": "What is the legal minimum milk fat content of German 'Vollmilch' (whole milk)?",
    "qDe": "Wie hoch ist der gesetzliche Mindestfettgehalt für Vollmilch in Deutschland?",
    "optEn": [
      "3.5% fat (or natural fat content typically 3.8-4.2%)",
      "1.5% fat",
      "0.3% fat",
      "10% fat"
    ],
    "optDe": [
      "Mindestens 3,5% Fett (bzw. natürlicher Fettgehalt 3,8–4,2%)",
      "1,5% Fett",
      "0,3% Fett",
      "10% Fett"
    ],
    "correct": 0,
    "expEn": "Standardized whole milk is adjusted to 3.5% milk fat; raw milk contains 3.8-4.2%.",
    "expDe": "Standardisierte Vollmilch enthält 3,5% Fett; fettarme Milch liegt bei 1,5–1,8%."
  },
  {
    "id": "q_dai_02",
    "category": "dairy",
    "questionEn": "What happens during milk homogenization?",
    "questionDe": "Was geschieht bei der Homogenisierung von Milch?",
    "optionsEn": [
      "Milk is forced through tiny nozzles under 200 bar pressure, shattering fat globules so cream doesn't separate",
      "Milk is boiled for 2 hours",
      "Fat is removed completely",
      "Sugar is added"
    ],
    "optionsDe": [
      "Milch wird unter hohem Druck (ca. 200 bar) durch feine Düsen gepresst; Fettkügelchen zerteilen sich",
      "Milch wird 2 Stunden gekocht",
      "Fett wird abzentrifugiert",
      "Milchzucker wird zugefügt"
    ],
    "correctIndex": 0,
    "explanationEn": "Micro-sized fat globules stay suspended evenly, preventing a cream plug from rising to the surface.",
    "explanationDe": "Durch das Zerkleinern der Fettkügelchen rahmt die Milch in der Flasche nicht mehr auf.",
    "qEn": "What happens during milk homogenization?",
    "qDe": "Was geschieht bei der Homogenisierung von Milch?",
    "optEn": [
      "Milk is forced through tiny nozzles under 200 bar pressure, shattering fat globules so cream doesn't separate",
      "Milk is boiled for 2 hours",
      "Fat is removed completely",
      "Sugar is added"
    ],
    "optDe": [
      "Milch wird unter hohem Druck (ca. 200 bar) durch feine Düsen gepresst; Fettkügelchen zerteilen sich",
      "Milch wird 2 Stunden gekocht",
      "Fett wird abzentrifugiert",
      "Milchzucker wird zugefügt"
    ],
    "correct": 0,
    "expEn": "Micro-sized fat globules stay suspended evenly, preventing a cream plug from rising to the surface.",
    "expDe": "Durch das Zerkleinern der Fettkügelchen rahmt die Milch in der Flasche nicht mehr auf."
  },
  {
    "id": "q_dai_03",
    "category": "dairy",
    "questionEn": "What defines UHT (Ultra-High Temperature) milk processing?",
    "questionDe": "Was zeichnet H-Milch (Ultrahocherhitzung) verfahrenstechnisch aus?",
    "optionsEn": [
      "Heated to 135°C–150°C for 2–4 seconds to destroy all microorganisms and bacterial spores",
      "Boiled at 100°C for 30 minutes",
      "Frozen to -40°C",
      "Filtered through paper"
    ],
    "optionsDe": [
      "Erhitzung auf 135°C bis 150°C für 2 bis 4 Sekunden zur Sterilisation",
      "Kochen bei 100°C für 30 Minuten",
      "Einfrieren auf -40°C",
      "Kaltfiltration"
    ],
    "correctIndex": 0,
    "explanationEn": "Aseptic packaging allows unopened UHT milk to be stored unrefrigerated for months.",
    "explanationDe": "Das Blitz-Erhitzen tötet alle Keime und Sporen ab; die Milch ist ungekühlt haltbar.",
    "qEn": "What defines UHT (Ultra-High Temperature) milk processing?",
    "qDe": "Was zeichnet H-Milch (Ultrahocherhitzung) verfahrenstechnisch aus?",
    "optEn": [
      "Heated to 135°C–150°C for 2–4 seconds to destroy all microorganisms and bacterial spores",
      "Boiled at 100°C for 30 minutes",
      "Frozen to -40°C",
      "Filtered through paper"
    ],
    "optDe": [
      "Erhitzung auf 135°C bis 150°C für 2 bis 4 Sekunden zur Sterilisation",
      "Kochen bei 100°C für 30 Minuten",
      "Einfrieren auf -40°C",
      "Kaltfiltration"
    ],
    "correct": 0,
    "expEn": "Aseptic packaging allows unopened UHT milk to be stored unrefrigerated for months.",
    "expDe": "Das Blitz-Erhitzen tötet alle Keime und Sporen ab; die Milch ist ungekühlt haltbar."
  },
  {
    "id": "q_dai_04",
    "category": "dairy",
    "questionEn": "What sugar is unique to mammal milk and causes lactose intolerance in some adults?",
    "questionDe": "Welcher Zweifachzucker kommt nur in Milch vor und verursacht bei manchen Laktoseintoleranz?",
    "optionsEn": [
      "Lactose (glucose + galactose)",
      "Fructose",
      "Sucrose",
      "Maltose"
    ],
    "optionsDe": [
      "Laktose (Milchzucker aus Glukose und Galaktose)",
      "Fruktose",
      "Saccharose",
      "Maltose"
    ],
    "correctIndex": 0,
    "explanationEn": "Insufficient lactase enzyme in the small intestine leaves lactose unabsorbed, causing fermentation.",
    "explanationDe": "Fehlt das körpereigene Enzym Laktase, kann der Milchzucker im Dünndarm nicht gespalten werden.",
    "qEn": "What sugar is unique to mammal milk and causes lactose intolerance in some adults?",
    "qDe": "Welcher Zweifachzucker kommt nur in Milch vor und verursacht bei manchen Laktoseintoleranz?",
    "optEn": [
      "Lactose (glucose + galactose)",
      "Fructose",
      "Sucrose",
      "Maltose"
    ],
    "optDe": [
      "Laktose (Milchzucker aus Glukose und Galaktose)",
      "Fruktose",
      "Saccharose",
      "Maltose"
    ],
    "correct": 0,
    "expEn": "Insufficient lactase enzyme in the small intestine leaves lactose unabsorbed, causing fermentation.",
    "expDe": "Fehlt das körpereigene Enzym Laktase, kann der Milchzucker im Dünndarm nicht gespalten werden."
  },
  {
    "id": "q_dai_05",
    "category": "dairy",
    "questionEn": "What is the primary protein family making up 80% of cow milk proteins?",
    "questionDe": "Welche Proteinfamilie stellt rund 80% des Gesamteiweißes in Kuhmilch?",
    "optionsEn": [
      "Caseins (alpha, beta, and kappa caseins)",
      "Whey albumins",
      "Gluten",
      "Collagen"
    ],
    "optionsDe": [
      "Kaseine (Alpha-, Beta- und Kappa-Kasein)",
      "Molkenalbumine",
      "Gluten",
      "Kollagen"
    ],
    "correctIndex": 0,
    "explanationEn": "Casein micelles coagulate when rennet or acid is added, forming solid cheese curds.",
    "explanationDe": "Kaseine bilden Micellen, die bei Säure oder Lab gerinnen und die Basis für Käse bilden.",
    "qEn": "What is the primary protein family making up 80% of cow milk proteins?",
    "qDe": "Welche Proteinfamilie stellt rund 80% des Gesamteiweißes in Kuhmilch?",
    "optEn": [
      "Caseins (alpha, beta, and kappa caseins)",
      "Whey albumins",
      "Gluten",
      "Collagen"
    ],
    "optDe": [
      "Kaseine (Alpha-, Beta- und Kappa-Kasein)",
      "Molkenalbumine",
      "Gluten",
      "Kollagen"
    ],
    "correct": 0,
    "expEn": "Casein micelles coagulate when rennet or acid is added, forming solid cheese curds.",
    "expDe": "Kaseine bilden Micellen, die bei Säure oder Lab gerinnen und die Basis für Käse bilden."
  },
  {
    "id": "q_dai_06",
    "category": "dairy",
    "questionEn": "What is Ghee in traditional Indian culinary science?",
    "questionDe": "Was ist Ghee aus lebensmittelchemischer Sicht?",
    "optionsEn": [
      "Clarified butterfat simmered until milk solids brown and all water evaporates (100% pure butterfat)",
      "Whipped salted butter",
      "Fermented goat milk",
      "Margarine made of palm oil"
    ],
    "optionsDe": [
      "Reines Butterfett, bei dem Wasser verdampft und Milcheiweiße nussig gebräunt und abgeseiht wurden",
      "Geschlagene Salzkäsebutter",
      "Vergorene Ziegenmilch",
      "Pflanzenmargarine"
    ],
    "correctIndex": 0,
    "explanationEn": "Ghee has a smoke point of 250°C (482°F) and keeps indefinitely without refrigeration.",
    "explanationDe": "Ghee enthält weder Wasser noch Eiweiß; es verbrennt erst bei 250°C und hält ungekühlt.",
    "qEn": "What is Ghee in traditional Indian culinary science?",
    "qDe": "Was ist Ghee aus lebensmittelchemischer Sicht?",
    "optEn": [
      "Clarified butterfat simmered until milk solids brown and all water evaporates (100% pure butterfat)",
      "Whipped salted butter",
      "Fermented goat milk",
      "Margarine made of palm oil"
    ],
    "optDe": [
      "Reines Butterfett, bei dem Wasser verdampft und Milcheiweiße nussig gebräunt und abgeseiht wurden",
      "Geschlagene Salzkäsebutter",
      "Vergorene Ziegenmilch",
      "Pflanzenmargarine"
    ],
    "correct": 0,
    "expEn": "Ghee has a smoke point of 250°C (482°F) and keeps indefinitely without refrigeration.",
    "expDe": "Ghee enthält weder Wasser noch Eiweiß; es verbrennt erst bei 250°C und hält ungekühlt."
  },
  {
    "id": "q_dai_07",
    "category": "dairy",
    "questionEn": "What distinguishes French Crème Fraîche from regular heavy cream?",
    "questionDe": "Was unterscheidet Crème fraîche von süßer Schlagsahne?",
    "optionsEn": [
      "Cultured with lactic acid bacteria (min. 30% fat), slightly acidic, and won't curdle when boiled",
      "Contains 10% sugar",
      "Is whipped into foam",
      "Made of skimmed milk"
    ],
    "optionsDe": [
      "Mit Milchsäurebakterien gesäuert (mind. 30% Fett); gerinnt beim Kochen nicht",
      "Enthält 10% Zucker",
      "Ist fertig aufgeschlagen",
      "Besteht aus Magermilch"
    ],
    "correctIndex": 0,
    "explanationEn": "High fat content and low protein prevent curdling, making Crème Fraîche ideal for hot pan reductions.",
    "explanationDe": "Dank hohem Fettgehalt und Säuerung flockt Crème fraîche in heißen Saucen nicht aus.",
    "qEn": "What distinguishes French Crème Fraîche from regular heavy cream?",
    "qDe": "Was unterscheidet Crème fraîche von süßer Schlagsahne?",
    "optEn": [
      "Cultured with lactic acid bacteria (min. 30% fat), slightly acidic, and won't curdle when boiled",
      "Contains 10% sugar",
      "Is whipped into foam",
      "Made of skimmed milk"
    ],
    "optDe": [
      "Mit Milchsäurebakterien gesäuert (mind. 30% Fett); gerinnt beim Kochen nicht",
      "Enthält 10% Zucker",
      "Ist fertig aufgeschlagen",
      "Besteht aus Magermilch"
    ],
    "correct": 0,
    "expEn": "High fat content and low protein prevent curdling, making Crème Fraîche ideal for hot pan reductions.",
    "expDe": "Dank hohem Fettgehalt und Säuerung flockt Crème fraîche in heißen Saucen nicht aus."
  },
  {
    "id": "q_dai_08",
    "category": "dairy",
    "questionEn": "What gives cultured Butter its rich hazelnut aroma compared to sweet cream butter?",
    "questionDe": "Was erzeugt das nussige Aroma in Sauerrahmbutter im Vergleich zu Süßrahmbutter?",
    "optionsEn": [
      "Diacetyl produced by lactic bacterial fermentation of citrate",
      "Added roasted hazelnuts",
      "Smoke aroma",
      "Caramelized lactose"
    ],
    "optionsDe": [
      "Diacetyl, gebildet durch Milchsäurebakterien bei der Reifung des Rahms",
      "Zusatz von Haselnussöl",
      "Raucharoma",
      "Karamellisierter Zucker"
    ],
    "correctIndex": 0,
    "explanationEn": "Fermentation of citric acid by Leuconostoc bacteria yields rich buttery diacetyl.",
    "explanationDe": "Reifungskulturen wandeln Zitronensäure in aromatisches Diacetyl um.",
    "qEn": "What gives cultured Butter its rich hazelnut aroma compared to sweet cream butter?",
    "qDe": "Was erzeugt das nussige Aroma in Sauerrahmbutter im Vergleich zu Süßrahmbutter?",
    "optEn": [
      "Diacetyl produced by lactic bacterial fermentation of citrate",
      "Added roasted hazelnuts",
      "Smoke aroma",
      "Caramelized lactose"
    ],
    "optDe": [
      "Diacetyl, gebildet durch Milchsäurebakterien bei der Reifung des Rahms",
      "Zusatz von Haselnussöl",
      "Raucharoma",
      "Karamellisierter Zucker"
    ],
    "correct": 0,
    "expEn": "Fermentation of citric acid by Leuconostoc bacteria yields rich buttery diacetyl.",
    "expDe": "Reifungskulturen wandeln Zitronensäure in aromatisches Diacetyl um."
  },
  {
    "id": "q_dai_09",
    "category": "dairy",
    "questionEn": "What is Buttermilk (echte reine Buttermilch) traditionally?",
    "questionDe": "Was ist echte reine Buttermilch im traditionellen Sinn?",
    "optionsEn": [
      "The tart, low-fat liquid remaining after churning cultured cream into solid butter",
      "Milk mixed with lemon juice",
      "Melted butter in water",
      "Thick yogurt shake"
    ],
    "optionsDe": [
      "Die säuerliche, fettarme Flüssigkeit, die beim Buttern von gereiftem Rahm abfließt",
      "Milch mit Zitronensaft",
      "Geschmolzene Butter in Wasser",
      "Dickflüssiger Joghurt"
    ],
    "correctIndex": 0,
    "explanationEn": "True buttermilk has under 1% fat, high natural lecithin, and refreshing lactic tartness.",
    "explanationDe": "Reine Buttermilch ist fast fettfrei, reich an Lecithin und herrlich erfrischend.",
    "qEn": "What is Buttermilk (echte reine Buttermilch) traditionally?",
    "qDe": "Was ist echte reine Buttermilch im traditionellen Sinn?",
    "optEn": [
      "The tart, low-fat liquid remaining after churning cultured cream into solid butter",
      "Milk mixed with lemon juice",
      "Melted butter in water",
      "Thick yogurt shake"
    ],
    "optDe": [
      "Die säuerliche, fettarme Flüssigkeit, die beim Buttern von gereiftem Rahm abfließt",
      "Milch mit Zitronensaft",
      "Geschmolzene Butter in Wasser",
      "Dickflüssiger Joghurt"
    ],
    "correct": 0,
    "expEn": "True buttermilk has under 1% fat, high natural lecithin, and refreshing lactic tartness.",
    "expDe": "Reine Buttermilch ist fast fettfrei, reich an Lecithin und herrlich erfrischend."
  },
  {
    "id": "q_dai_10",
    "category": "dairy",
    "questionEn": "What live bacterial cultures are legally required in authentic Yogurt?",
    "questionDe": "Welche Bakterienkulturen sind für echten Joghurt gesetzlich vorgeschrieben?",
    "optionsEn": [
      "Lactobacillus bulgaricus and Streptococcus thermophilus",
      "Bakers yeast and mold",
      "Acetobacter and brettanomyces",
      "Penicillium roqueforti"
    ],
    "optionsDe": [
      "Lactobacillus bulgaricus und Streptococcus thermophilus",
      "Bäckerhefe und Schimmel",
      "Essigsäurebakterien",
      "Edelschimmelpilze"
    ],
    "correctIndex": 0,
    "explanationEn": "These two thermophilic bacteria work in symbiosis, fermenting lactose into soothing lactic acid.",
    "explanationDe": "Beide Stämme wandeln Laktose bei 40–42°C in Milchsäure um und lassen das Eiweiß stocken.",
    "qEn": "What live bacterial cultures are legally required in authentic Yogurt?",
    "qDe": "Welche Bakterienkulturen sind für echten Joghurt gesetzlich vorgeschrieben?",
    "optEn": [
      "Lactobacillus bulgaricus and Streptococcus thermophilus",
      "Bakers yeast and mold",
      "Acetobacter and brettanomyces",
      "Penicillium roqueforti"
    ],
    "optDe": [
      "Lactobacillus bulgaricus und Streptococcus thermophilus",
      "Bäckerhefe und Schimmel",
      "Essigsäurebakterien",
      "Edelschimmelpilze"
    ],
    "correct": 0,
    "expEn": "These two thermophilic bacteria work in symbiosis, fermenting lactose into soothing lactic acid.",
    "expDe": "Beide Stämme wandeln Laktose bei 40–42°C in Milchsäure um und lassen das Eiweiß stocken."
  },
  {
    "id": "q_dai_11",
    "category": "dairy",
    "questionEn": "How is thick Greek Yogurt traditionally made?",
    "questionDe": "Wie wird traditioneller griechischer Joghurt hergestellt?",
    "optionsEn": [
      "Strained through fine cloth to drain off watery whey, concentrating protein and fat",
      "Thickened with gelatin",
      "Boiled with cornstarch",
      "Frozen solid"
    ],
    "optionsDe": [
      "Geseiht durch Tücher, um wässrige Molke abzutrennen; Proteine und Fette konzentrieren sich",
      "Mit Gelatine angedickt",
      "Mit Speisestärke gekocht",
      "Gefroren"
    ],
    "correctIndex": 0,
    "explanationEn": "Straining yields three times the protein per spoon and a dense, velvet spoonable texture.",
    "explanationDe": "Das Abtropfen der Molke verdreifacht den Eiweißgehalt und schenkt sahnige Festigkeit.",
    "qEn": "How is thick Greek Yogurt traditionally made?",
    "qDe": "Wie wird traditioneller griechischer Joghurt hergestellt?",
    "optEn": [
      "Strained through fine cloth to drain off watery whey, concentrating protein and fat",
      "Thickened with gelatin",
      "Boiled with cornstarch",
      "Frozen solid"
    ],
    "optDe": [
      "Geseiht durch Tücher, um wässrige Molke abzutrennen; Proteine und Fette konzentrieren sich",
      "Mit Gelatine angedickt",
      "Mit Speisestärke gekocht",
      "Gefroren"
    ],
    "correct": 0,
    "expEn": "Straining yields three times the protein per spoon and a dense, velvet spoonable texture.",
    "expDe": "Das Abtropfen der Molke verdreifacht den Eiweißgehalt und schenkt sahnige Festigkeit."
  },
  {
    "id": "q_dai_12",
    "category": "dairy",
    "questionEn": "What is Kefir and what is the 'Kefir Grain'?",
    "questionDe": "Was ist Kefir und woraus bestehen 'Kefirknollen'?",
    "optionsEn": [
      "A symbiotic grain colony of yeasts and lactic bacteria producing mild alcohol and fizz",
      "A cereal grain like wheat",
      "A chemical tablet",
      "A freeze-dried powder"
    ],
    "optionsDe": [
      "Eine gallertige Symbiose aus Hefen und Milchsäurebakterien, die Prickeln und Minialkohol erzeugt",
      "Ein Getreidekorn wie Roggen",
      "Eine Brausetablette",
      "Gefriergetrocknetes Mehl"
    ],
    "correctIndex": 0,
    "explanationEn": "Yeasts produce CO2 and trace ethanol (0.5%); bacteria produce lactic acid and polysaccharides.",
    "explanationDe": "Hefen und Bakterien bilden Kohlensäure, Vitamine und einen Hauch Gärungsalkohol.",
    "qEn": "What is Kefir and what is the 'Kefir Grain'?",
    "qDe": "Was ist Kefir und woraus bestehen 'Kefirknollen'?",
    "optEn": [
      "A symbiotic grain colony of yeasts and lactic bacteria producing mild alcohol and fizz",
      "A cereal grain like wheat",
      "A chemical tablet",
      "A freeze-dried powder"
    ],
    "optDe": [
      "Eine gallertige Symbiose aus Hefen und Milchsäurebakterien, die Prickeln und Minialkohol erzeugt",
      "Ein Getreidekorn wie Roggen",
      "Eine Brausetablette",
      "Gefriergetrocknetes Mehl"
    ],
    "correct": 0,
    "expEn": "Yeasts produce CO2 and trace ethanol (0.5%); bacteria produce lactic acid and polysaccharides.",
    "expDe": "Hefen und Bakterien bilden Kohlensäure, Vitamine und einen Hauch Gärungsalkohol."
  },
  {
    "id": "q_dai_13",
    "category": "dairy",
    "questionEn": "Why does milk foam during coffee steaming?",
    "questionDe": "Warum lässt sich Milch zu stabilem Milchschaum aufschlagen?",
    "optionsEn": [
      "Whey proteins unfold and encapsulate injected air bubbles, stabilized by milk fats below 65°C",
      "Lactose boils into caramel",
      "Water evaporates",
      "Fat melts into oil"
    ],
    "optionsDe": [
      "Molkeneiweiße entfalten sich und umhüllen Luftbläschen; Fett stabilisiert die Wandungen",
      "Milchzucker karamellisiert",
      "Wasser verdampft",
      "Fett verbrennt"
    ],
    "correctIndex": 0,
    "explanationEn": "Denaturing whey proteins form an elastic film around micro-bubbles; excess heat collapses them.",
    "explanationDe": "Die Eiweiße bilden elastische Hüllen um die Luftblasen; zu viel Hitze lässt sie platzen.",
    "qEn": "Why does milk foam during coffee steaming?",
    "qDe": "Warum lässt sich Milch zu stabilem Milchschaum aufschlagen?",
    "optEn": [
      "Whey proteins unfold and encapsulate injected air bubbles, stabilized by milk fats below 65°C",
      "Lactose boils into caramel",
      "Water evaporates",
      "Fat melts into oil"
    ],
    "optDe": [
      "Molkeneiweiße entfalten sich und umhüllen Luftbläschen; Fett stabilisiert die Wandungen",
      "Milchzucker karamellisiert",
      "Wasser verdampft",
      "Fett verbrennt"
    ],
    "correct": 0,
    "expEn": "Denaturing whey proteins form an elastic film around micro-bubbles; excess heat collapses them.",
    "expDe": "Die Eiweiße bilden elastische Hüllen um die Luftblasen; zu viel Hitze lässt sie platzen."
  },
  {
    "id": "q_dai_14",
    "category": "dairy",
    "questionEn": "What is Condensed Milk (gezuckerte Kondensmilch)?",
    "questionDe": "Was ist gezuckerte Kondensmilch?",
    "optionsEn": [
      "Cow milk reduced by 60% water evaporation and preserved with 40-45% added sugar",
      "Powdered milk dissolved in water",
      "Cream boiled with flour",
      "Soy milk syrup"
    ],
    "optionsDe": [
      "Eingedickte Milch, der ca. 60% Wasser entzogen und reichlich Zucker zugesetzt wurde",
      "Milchpulver in Wasser",
      "Rahm mit Mehl",
      "Sojasirup"
    ],
    "correctIndex": 0,
    "explanationEn": "High osmotic pressure from sugar inhibits bacterial growth without refrigeration.",
    "explanationDe": "Der hohe Zuckergehalt bindet Wasser osmotisch und konserviert die dicke Milch dauerhaft.",
    "qEn": "What is Condensed Milk (gezuckerte Kondensmilch)?",
    "qDe": "Was ist gezuckerte Kondensmilch?",
    "optEn": [
      "Cow milk reduced by 60% water evaporation and preserved with 40-45% added sugar",
      "Powdered milk dissolved in water",
      "Cream boiled with flour",
      "Soy milk syrup"
    ],
    "optDe": [
      "Eingedickte Milch, der ca. 60% Wasser entzogen und reichlich Zucker zugesetzt wurde",
      "Milchpulver in Wasser",
      "Rahm mit Mehl",
      "Sojasirup"
    ],
    "correct": 0,
    "expEn": "High osmotic pressure from sugar inhibits bacterial growth without refrigeration.",
    "expDe": "Der hohe Zuckergehalt bindet Wasser osmotisch und konserviert die dicke Milch dauerhaft."
  },
  {
    "id": "q_dai_15",
    "category": "dairy",
    "questionEn": "What causes the rich brown color and nutty flavor in Beurre Noisette (brown butter)?",
    "questionDe": "Was erzeugt die nussige Bräune in 'Beurre Noisette' (Nussbutter)?",
    "optionsEn": [
      "Maillard reaction between milk proteins (casein) and lactose sugars when water boils off at 120-130°C",
      "Added hazelnut syrup",
      "Wood smoke",
      "Caramel color dye"
    ],
    "optionsDe": [
      "Maillard-Reaktion zwischen Milcheiweiß und Milchzucker nach dem Verdampfen des Wassers",
      "Zusatz von Haselnussmus",
      "Holzrauch",
      "Zuckerkulör"
    ],
    "correctIndex": 0,
    "explanationEn": "Once the water sputters away, milk solids toast in pure butterfat, releasing nutty aromas.",
    "explanationDe": "Sobald das Wasser verdampft ist, rösten die Eiweißflöckchen im Butterfett goldbraun.",
    "qEn": "What causes the rich brown color and nutty flavor in Beurre Noisette (brown butter)?",
    "qDe": "Was erzeugt die nussige Bräune in 'Beurre Noisette' (Nussbutter)?",
    "optEn": [
      "Maillard reaction between milk proteins (casein) and lactose sugars when water boils off at 120-130°C",
      "Added hazelnut syrup",
      "Wood smoke",
      "Caramel color dye"
    ],
    "optDe": [
      "Maillard-Reaktion zwischen Milcheiweiß und Milchzucker nach dem Verdampfen des Wassers",
      "Zusatz von Haselnussmus",
      "Holzrauch",
      "Zuckerkulör"
    ],
    "correct": 0,
    "expEn": "Once the water sputters away, milk solids toast in pure butterfat, releasing nutty aromas.",
    "expDe": "Sobald das Wasser verdampft ist, rösten die Eiweißflöckchen im Butterfett goldbraun."
  },
  {
    "id": "q_dai_16",
    "category": "dairy",
    "questionEn": "What is Skyr in Nordic dairy tradition?",
    "questionDe": "Was ist traditioneller isländischer Skyr?",
    "optionsEn": [
      "A cultured fresh sour-milk cheese strained to high-protein, zero-fat creaminess",
      "A sweet dessert pudding",
      "Salted sheep butter",
      "Fermented whale fat"
    ],
    "optionsDe": [
      "Ein traditionell gereifter Sauermilchkäse mit extrem hohem Proteingehalt und kaum Fett",
      "Ein süßer Sahnepudding",
      "Gesalzene Schafbutter",
      "Vergorenes Walfett"
    ],
    "correctIndex": 0,
    "explanationEn": "Skyr is legally a fresh curd cheese made with skimmed milk, offering massive protein density.",
    "explanationDe": "Skyr ist eigentlich ein fettfreier Frischkäse mit fester Konsistenz und feiner Säure.",
    "qEn": "What is Skyr in Nordic dairy tradition?",
    "qDe": "Was ist traditioneller isländischer Skyr?",
    "optEn": [
      "A cultured fresh sour-milk cheese strained to high-protein, zero-fat creaminess",
      "A sweet dessert pudding",
      "Salted sheep butter",
      "Fermented whale fat"
    ],
    "optDe": [
      "Ein traditionell gereifter Sauermilchkäse mit extrem hohem Proteingehalt und kaum Fett",
      "Ein süßer Sahnepudding",
      "Gesalzene Schafbutter",
      "Vergorenes Walfett"
    ],
    "correct": 0,
    "expEn": "Skyr is legally a fresh curd cheese made with skimmed milk, offering massive protein density.",
    "expDe": "Skyr ist eigentlich ein fettfreier Frischkäse mit fester Konsistenz und feiner Säure."
  },
  {
    "id": "q_dai_17",
    "category": "dairy",
    "questionEn": "Why does cold cream whip into stiff peaks while warm cream turns into greasy soup?",
    "questionDe": "Warum lässt sich kalte Sahne steif schlagen, warme Sahne hingegen nicht?",
    "optionsEn": [
      "Milk fat globule membranes must remain solid and crystalline to form a rigid structural lattice around air bubbles",
      "Cold cream has more sugar",
      "Warm cream loses protein",
      "Cold cream attracts nitrogen"
    ],
    "optionsDe": [
      "Fettkügelchen müssen fest kristallisiert sein, um ein stabiles Gerüst um Luftbläschen zu bilden",
      "Kalte Sahne hat mehr Zucker",
      "Warme Sahne verliert Eiweiß",
      "Kälte bindet Stickstoff"
    ],
    "correctIndex": 0,
    "explanationEn": "Above 15°C, butterfat melts into liquid oil, which defoams and collapses whipped air bubbles.",
    "explanationDe": "Flüssiges Fett zerstört den Schaum; nur feste Fettkristalle stützen die Luftbläschen.",
    "qEn": "Why does cold cream whip into stiff peaks while warm cream turns into greasy soup?",
    "qDe": "Warum lässt sich kalte Sahne steif schlagen, warme Sahne hingegen nicht?",
    "optEn": [
      "Milk fat globule membranes must remain solid and crystalline to form a rigid structural lattice around air bubbles",
      "Cold cream has more sugar",
      "Warm cream loses protein",
      "Cold cream attracts nitrogen"
    ],
    "optDe": [
      "Fettkügelchen müssen fest kristallisiert sein, um ein stabiles Gerüst um Luftbläschen zu bilden",
      "Kalte Sahne hat mehr Zucker",
      "Warme Sahne verliert Eiweiß",
      "Kälte bindet Stickstoff"
    ],
    "correct": 0,
    "expEn": "Above 15°C, butterfat melts into liquid oil, which defoams and collapses whipped air bubbles.",
    "expDe": "Flüssiges Fett zerstört den Schaum; nur feste Fettkristalle stützen die Luftbläschen."
  },
  {
    "id": "q_dai_18",
    "category": "dairy",
    "questionEn": "What is Quark (Topfen) in Central European gastronomy?",
    "questionDe": "Was ist Quark bzw. Topfen in der Küchenpraxis?",
    "optionsEn": [
      "A fresh acid-set curd cheese made by coagulating pasteurized skimmed milk with lactic cultures",
      "A hard mountain cheese",
      "Fermented butter",
      "Whipped cream cheese with salt"
    ],
    "optionsDe": [
      "Ein Frischkäse, hergestellt durch Milchsäuerung und sanfte Dicklegung von Magermilch",
      "Ein gereifter Bergkäse",
      "Fermentierte Butter",
      "Gesalzener Rahmfrischkäse"
    ],
    "correctIndex": 0,
    "explanationEn": "Quark separates curds from acid whey, versatile for German cheesecake (Käsekuchen) or herb dips.",
    "explanationDe": "Topfen ist das gestockte Kasein der Sauermilch, ideal für Strudel, Mehlspeisen und Kräuterdips.",
    "qEn": "What is Quark (Topfen) in Central European gastronomy?",
    "qDe": "Was ist Quark bzw. Topfen in der Küchenpraxis?",
    "optEn": [
      "A fresh acid-set curd cheese made by coagulating pasteurized skimmed milk with lactic cultures",
      "A hard mountain cheese",
      "Fermented butter",
      "Whipped cream cheese with salt"
    ],
    "optDe": [
      "Ein Frischkäse, hergestellt durch Milchsäuerung und sanfte Dicklegung von Magermilch",
      "Ein gereifter Bergkäse",
      "Fermentierte Butter",
      "Gesalzener Rahmfrischkäse"
    ],
    "correct": 0,
    "expEn": "Quark separates curds from acid whey, versatile for German cheesecake (Käsekuchen) or herb dips.",
    "expDe": "Topfen ist das gestockte Kasein der Sauermilch, ideal für Strudel, Mehlspeisen und Kräuterdips."
  },
  {
    "id": "q_che_01",
    "category": "cheese",
    "questionEn": "What is the legal minimum aging time for Parmigiano Reggiano DOP?",
    "questionDe": "Wie lange muss Parmigiano Reggiano DOP mindestens reifen?",
    "optionsEn": [
      "12 months (typically 24 to 36 months)",
      "3 months",
      "6 weeks",
      "5 years"
    ],
    "optionsDe": [
      "Mindestens 12 Monate (klassisch 24 bis 36 Monate)",
      "3 Monate",
      "6 Wochen",
      "Mindestens 5 Jahre"
    ],
    "correctIndex": 0,
    "explanationEn": "Parmigiano Reggiano is inspected at 12 months with a silver hammer before receiving fire-branded certification.",
    "explanationDe": "Nach 12 Monaten prüft das Konsortium jeden Laib mit dem Klöppel auf Risse und Hohlräume.",
    "qEn": "What is the legal minimum aging time for Parmigiano Reggiano DOP?",
    "qDe": "Wie lange muss Parmigiano Reggiano DOP mindestens reifen?",
    "optEn": [
      "12 months (typically 24 to 36 months)",
      "3 months",
      "6 weeks",
      "5 years"
    ],
    "optDe": [
      "Mindestens 12 Monate (klassisch 24 bis 36 Monate)",
      "3 Monate",
      "6 Wochen",
      "Mindestens 5 Jahre"
    ],
    "correct": 0,
    "expEn": "Parmigiano Reggiano is inspected at 12 months with a silver hammer before receiving fire-branded certification.",
    "expDe": "Nach 12 Monaten prüft das Konsortium jeden Laib mit dem Klöppel auf Risse und Hohlräume."
  },
  {
    "id": "q_che_02",
    "category": "cheese",
    "questionEn": "What are the crunchy white crystals found in well-aged cheese (e.g. 36-month Parmesan or vintage Gouda)?",
    "questionDe": "Was sind die feinen Knusperkristalle in reifem Parmesan oder altem Gouda?",
    "optionsEn": [
      "Crystallized calcium lactate and tyrosine amino acid crystals",
      "Table salt (NaCl) grains",
      "Bone fragments",
      "Sugar crystals"
    ],
    "optionsDe": [
      "Ausgefallene Aminosäure-Kristalle (Tyrosin) und Calciumlactat",
      "Eingestreute Kochsalzkörner",
      "Kalkreste",
      "Rohrzuckerkristalle"
    ],
    "correctIndex": 0,
    "explanationEn": "Proteolysis breaks casein into free amino acids; insoluble tyrosine precipitates into crunchy gems.",
    "explanationDe": "Der Eiweißabbau setzt Tyrosin frei; diese Aminosäuren kristallisieren zu edlem Umami-Biss.",
    "qEn": "What are the crunchy white crystals found in well-aged cheese (e.g. 36-month Parmesan or vintage Gouda)?",
    "qDe": "Was sind die feinen Knusperkristalle in reifem Parmesan oder altem Gouda?",
    "optEn": [
      "Crystallized calcium lactate and tyrosine amino acid crystals",
      "Table salt (NaCl) grains",
      "Bone fragments",
      "Sugar crystals"
    ],
    "optDe": [
      "Ausgefallene Aminosäure-Kristalle (Tyrosin) und Calciumlactat",
      "Eingestreute Kochsalzkörner",
      "Kalkreste",
      "Rohrzuckerkristalle"
    ],
    "correct": 0,
    "expEn": "Proteolysis breaks casein into free amino acids; insoluble tyrosine precipitates into crunchy gems.",
    "expDe": "Der Eiweißabbau setzt Tyrosin frei; diese Aminosäuren kristallisieren zu edlem Umami-Biss."
  },
  {
    "id": "q_che_03",
    "category": "cheese",
    "questionEn": "What noble mold strain creates the blue veins in Roquefort and Gorgonzola?",
    "questionDe": "Welcher Edelschimmelpilz erzeugt die blauen Adern in Roquefort und Gorgonzola?",
    "optionsEn": [
      "Penicillium roqueforti",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Saccharomyces cerevisiae"
    ],
    "optionsDe": [
      "Penicillium roqueforti",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Bäckerhefe"
    ],
    "correctIndex": 0,
    "explanationEn": "Penicillium roqueforti breaks down butterfat into methyl ketones, creating spicy piquancy.",
    "explanationDe": "Der Schimmel spaltet Fette in Ketone, was den typisch pikant-würzigen Blauschimmelgeschmack erzeugt.",
    "qEn": "What noble mold strain creates the blue veins in Roquefort and Gorgonzola?",
    "qDe": "Welcher Edelschimmelpilz erzeugt die blauen Adern in Roquefort und Gorgonzola?",
    "optEn": [
      "Penicillium roqueforti",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Saccharomyces cerevisiae"
    ],
    "optDe": [
      "Penicillium roqueforti",
      "Aspergillus oryzae",
      "Penicillium camemberti",
      "Bäckerhefe"
    ],
    "correct": 0,
    "expEn": "Penicillium roqueforti breaks down butterfat into methyl ketones, creating spicy piquancy.",
    "expDe": "Der Schimmel spaltet Fette in Ketone, was den typisch pikant-würzigen Blauschimmelgeschmack erzeugt."
  },
  {
    "id": "q_che_04",
    "category": "cheese",
    "questionEn": "What milk is strictly used for authentic Mozzarella di Bufala Campana DOP?",
    "questionDe": "Welche Milch ist für echte Mozzarella di Bufala Campana DOP vorgeschrieben?",
    "optionsEn": [
      "Whole raw or pasteurized water buffalo milk (Bubalus bubalis)",
      "Cow milk only",
      "Goat milk",
      "Sheep milk"
    ],
    "optionsDe": [
      "Reine Wasserbüffelmilch (Bubalus bubalis)",
      "Kuhmilch",
      "Ziegenmilch",
      "Schafsmilch"
    ],
    "correctIndex": 0,
    "explanationEn": "Water buffalo milk contains almost double the fat and protein of cow milk, yielding porcelain creaminess.",
    "explanationDe": "Büffelmilch hat ca. 8% Fett und verleiht der Mozzarella ihren saftigen, süßlich-säuerlichen Schmelz.",
    "qEn": "What milk is strictly used for authentic Mozzarella di Bufala Campana DOP?",
    "qDe": "Welche Milch ist für echte Mozzarella di Bufala Campana DOP vorgeschrieben?",
    "optEn": [
      "Whole raw or pasteurized water buffalo milk (Bubalus bubalis)",
      "Cow milk only",
      "Goat milk",
      "Sheep milk"
    ],
    "optDe": [
      "Reine Wasserbüffelmilch (Bubalus bubalis)",
      "Kuhmilch",
      "Ziegenmilch",
      "Schafsmilch"
    ],
    "correct": 0,
    "expEn": "Water buffalo milk contains almost double the fat and protein of cow milk, yielding porcelain creaminess.",
    "expDe": "Büffelmilch hat ca. 8% Fett und verleiht der Mozzarella ihren saftigen, süßlich-säuerlichen Schmelz."
  },
  {
    "id": "q_che_05",
    "category": "cheese",
    "questionEn": "What gives French Camembert and Brie their velvety white blooming rind?",
    "questionDe": "Was bildet die samtig weiße Edelschimmelrinde auf Camembert und Brie?",
    "optionsEn": [
      "Penicillium camemberti (or Penicillium candidum)",
      "Flour dust",
      "Chalk powder",
      "Baking soda"
    ],
    "optionsDe": [
      "Penicillium camemberti (auch Penicillium candidum genannt)",
      "Mehlstaub",
      "Kalküberzug",
      "Backpulver"
    ],
    "correctIndex": 0,
    "explanationEn": "Surface mold secretes enzymes that break down curd from outside inward, softening cheese into a molten core.",
    "explanationDe": "Der weiße Schimmelpilz baut das Kasein von der Rinde nach innen ab, bis der Teig fließt.",
    "qEn": "What gives French Camembert and Brie their velvety white blooming rind?",
    "qDe": "Was bildet die samtig weiße Edelschimmelrinde auf Camembert und Brie?",
    "optEn": [
      "Penicillium camemberti (or Penicillium candidum)",
      "Flour dust",
      "Chalk powder",
      "Baking soda"
    ],
    "optDe": [
      "Penicillium camemberti (auch Penicillium candidum genannt)",
      "Mehlstaub",
      "Kalküberzug",
      "Backpulver"
    ],
    "correct": 0,
    "expEn": "Surface mold secretes enzymes that break down curd from outside inward, softening cheese into a molten core.",
    "expDe": "Der weiße Schimmelpilz baut das Kasein von der Rinde nach innen ab, bis der Teig fließt."
  },
  {
    "id": "q_che_06",
    "category": "cheese",
    "questionEn": "What creates the famous round holes ('eyes') in Swiss Emmentaler AOP?",
    "questionDe": "Was verursacht die typischen großen Löcher im Schweizer Emmentaler AOP?",
    "optionsEn": [
      "Propionic acid bacteria (Propionibacterium freudenreichii) producing carbon dioxide gas bubbles",
      "Gas bubbles from boiling milk",
      "Mechanical drills",
      "Worms in aging cellar"
    ],
    "optionsDe": [
      "Propionsäurebakterien bilden Kohlendioxidgas, das im festen Teig nicht entweichen kann",
      "Kochende Blasen",
      "Mechanische Bohrer",
      "Käsemaden"
    ],
    "correctIndex": 0,
    "explanationEn": "Bacteria consume lactic acid, producing nutty propionic acid, acetic acid, and CO2 pockets.",
    "explanationDe": "Propionsäurebakterien erzeugen nussiges Aroma und Kohlendioxidgas, das die Löcher aufbläht.",
    "qEn": "What creates the famous round holes ('eyes') in Swiss Emmentaler AOP?",
    "qDe": "Was verursacht die typischen großen Löcher im Schweizer Emmentaler AOP?",
    "optEn": [
      "Propionic acid bacteria (Propionibacterium freudenreichii) producing carbon dioxide gas bubbles",
      "Gas bubbles from boiling milk",
      "Mechanical drills",
      "Worms in aging cellar"
    ],
    "optDe": [
      "Propionsäurebakterien bilden Kohlendioxidgas, das im festen Teig nicht entweichen kann",
      "Kochende Blasen",
      "Mechanische Bohrer",
      "Käsemaden"
    ],
    "correct": 0,
    "expEn": "Bacteria consume lactic acid, producing nutty propionic acid, acetic acid, and CO2 pockets.",
    "expDe": "Propionsäurebakterien erzeugen nussiges Aroma und Kohlendioxidgas, das die Löcher aufbläht."
  },
  {
    "id": "q_che_07",
    "category": "cheese",
    "questionEn": "What distinguishes authentic Feta g.U. (PDO) from generic salad cheese?",
    "questionDe": "Was unterscheidet echten griechischen Feta g.U. von herkömmlichem Hirtenkäse?",
    "optionsEn": [
      "Must be produced in Greece from sheep milk (min. 70%) and goat milk (max. 30%) aged in brine",
      "Made from cow milk with palm oil",
      "Made in Denmark from skim milk",
      "Contains cheddar scraps"
    ],
    "optionsDe": [
      "Traditionell in Griechenland aus Schafsmilch (mind. 70%) und Ziegenmilch gereift in Salzlake",
      "Aus Kuhmilch mit Palmöl",
      "Aus dänischer Magermilch",
      "Aus Rinderfett"
    ],
    "correctIndex": 0,
    "explanationEn": "EU PDO rules protect Greek terroir; cow milk imitations must be labelled 'salad block' or 'white cheese'.",
    "explanationDe": "Feta darf nur aus Schafs- und Ziegenmilch in Griechenland stammen; Kuhmilchprodukte sind Imitate.",
    "qEn": "What distinguishes authentic Feta g.U. (PDO) from generic salad cheese?",
    "qDe": "Was unterscheidet echten griechischen Feta g.U. von herkömmlichem Hirtenkäse?",
    "optEn": [
      "Must be produced in Greece from sheep milk (min. 70%) and goat milk (max. 30%) aged in brine",
      "Made from cow milk with palm oil",
      "Made in Denmark from skim milk",
      "Contains cheddar scraps"
    ],
    "optDe": [
      "Traditionell in Griechenland aus Schafsmilch (mind. 70%) und Ziegenmilch gereift in Salzlake",
      "Aus Kuhmilch mit Palmöl",
      "Aus dänischer Magermilch",
      "Aus Rinderfett"
    ],
    "correct": 0,
    "expEn": "EU PDO rules protect Greek terroir; cow milk imitations must be labelled 'salad block' or 'white cheese'.",
    "expDe": "Feta darf nur aus Schafs- und Ziegenmilch in Griechenland stammen; Kuhmilchprodukte sind Imitate."
  },
  {
    "id": "q_che_08",
    "category": "cheese",
    "questionEn": "Why is Raclette du Valais AOP the supreme melting cheese?",
    "questionDe": "Warum schmilzt echter Walliser Raclette AOP so außergewöhnlich cremig?",
    "optionsEn": [
      "Unpasteurized mountain milk with balanced calcium-to-protein ratio and fat, melting smoothly without oil separation",
      "Contains added emulsifier salts",
      "Is pre-melted in factory",
      "Contains flour"
    ],
    "optionsDe": [
      "Rohmilch mit idealem Calcium-Kasein-Gleichgewicht; schmilzt homogen ohne Fettabsonderung",
      "Enthält Schmelzsalze",
      "Ist vorgekocht",
      "Enthält Mehl"
    ],
    "correctIndex": 0,
    "explanationEn": "Ages 3-6 months with washed rind; optimal pH (5.2-5.4) allows protein strings to slide gracefully.",
    "explanationDe": "Der optimale Säure- und Fettgehalt sorgt dafür, dass das Kaseingerüst zart fließt ohne zu ölen.",
    "qEn": "Why is Raclette du Valais AOP the supreme melting cheese?",
    "qDe": "Warum schmilzt echter Walliser Raclette AOP so außergewöhnlich cremig?",
    "optEn": [
      "Unpasteurized mountain milk with balanced calcium-to-protein ratio and fat, melting smoothly without oil separation",
      "Contains added emulsifier salts",
      "Is pre-melted in factory",
      "Contains flour"
    ],
    "optDe": [
      "Rohmilch mit idealem Calcium-Kasein-Gleichgewicht; schmilzt homogen ohne Fettabsonderung",
      "Enthält Schmelzsalze",
      "Ist vorgekocht",
      "Enthält Mehl"
    ],
    "correct": 0,
    "expEn": "Ages 3-6 months with washed rind; optimal pH (5.2-5.4) allows protein strings to slide gracefully.",
    "expDe": "Der optimale Säure- und Fettgehalt sorgt dafür, dass das Kaseingerüst zart fließt ohne zu ölen."
  },
  {
    "id": "q_che_09",
    "category": "cheese",
    "questionEn": "What is Pecorino Romano made from?",
    "questionDe": "Aus welcher Milch wird echter Pecorino Romano hergestellt?",
    "optionsEn": [
      "100% sheep milk (pecora = sheep in Italian)",
      "Goat milk",
      "Cow milk",
      "Water buffalo milk"
    ],
    "optionsDe": [
      "100% Schafsmilch ('pecora' = Schaf auf Italienisch)",
      "Ziegenmilch",
      "Kuhmilch",
      "Büffelmilch"
    ],
    "correctIndex": 0,
    "explanationEn": "Dry-salted sheep curd yields sharp, pungent, savory salinity indispensable in Carbonara and Amatriciana.",
    "explanationDe": "Schafsmilch und kräftiges Trockensalzen verleihen dem Pecorino seinen pikanten, salzigen Biss.",
    "qEn": "What is Pecorino Romano made from?",
    "qDe": "Aus welcher Milch wird echter Pecorino Romano hergestellt?",
    "optEn": [
      "100% sheep milk (pecora = sheep in Italian)",
      "Goat milk",
      "Cow milk",
      "Water buffalo milk"
    ],
    "optDe": [
      "100% Schafsmilch ('pecora' = Schaf auf Italienisch)",
      "Ziegenmilch",
      "Kuhmilch",
      "Büffelmilch"
    ],
    "correct": 0,
    "expEn": "Dry-salted sheep curd yields sharp, pungent, savory salinity indispensable in Carbonara and Amatriciana.",
    "expDe": "Schafsmilch und kräftiges Trockensalzen verleihen dem Pecorino seinen pikanten, salzigen Biss."
  },
  {
    "id": "q_che_10",
    "category": "cheese",
    "questionEn": "How is French Comté AOP classified by the Juragruyère consortium?",
    "questionDe": "Wie wird französischer Comté AOP im Reifekeller beurteilt?",
    "optionsEn": [
      "Graded on a 20-point scale for rind, texture, and flavor; scores above 15 receive the green Comté Clochette band",
      "Tested by boiling",
      "Weighed on scales only",
      "Priced by color"
    ],
    "optionsDe": [
      "Auf einer 20-Punkte-Skala; Käse mit 15+ Punkten erhalten die grüne Banderole 'Comté Clochette'",
      "Wird gekocht",
      "Nur nach Gewicht",
      "Nur nach Farbe"
    ],
    "correctIndex": 0,
    "explanationEn": "Wheels scoring 12-14 points receive a brown band; flawed wheels are disqualified from the AOP label.",
    "explanationDe": "Nur Spitzenlaibe aus bester Montbéliarde-Kuhmilch mit komplexem Aroma erhalten das grüne Gütesiegel.",
    "qEn": "How is French Comté AOP classified by the Juragruyère consortium?",
    "qDe": "Wie wird französischer Comté AOP im Reifekeller beurteilt?",
    "optEn": [
      "Graded on a 20-point scale for rind, texture, and flavor; scores above 15 receive the green Comté Clochette band",
      "Tested by boiling",
      "Weighed on scales only",
      "Priced by color"
    ],
    "optDe": [
      "Auf einer 20-Punkte-Skala; Käse mit 15+ Punkten erhalten die grüne Banderole 'Comté Clochette'",
      "Wird gekocht",
      "Nur nach Gewicht",
      "Nur nach Farbe"
    ],
    "correct": 0,
    "expEn": "Wheels scoring 12-14 points receive a brown band; flawed wheels are disqualified from the AOP label.",
    "expDe": "Nur Spitzenlaibe aus bester Montbéliarde-Kuhmilch mit komplexem Aroma erhalten das grüne Gütesiegel."
  },
  {
    "id": "q_che_11",
    "category": "cheese",
    "questionEn": "What is the function of animal or microbial Rennet (Lab) in cheese making?",
    "questionDe": "Welche Funktion hat Lab (Chymosin) bei der Käseherstellung?",
    "optionsEn": [
      "Enzymatically cleaves kappa-casein, causing milk proteins to precipitate into firm curd",
      "Sweetens the milk",
      "Colors the curd yellow",
      "Kills all bacteria"
    ],
    "optionsDe": [
      "Spaltet Kappa-Kasein enzymatisch, sodass die Micellen zu festem Bruch gerinnen",
      "Süßt die Milch",
      "Färbt den Bruch gelb",
      "Sterilisiert die Milch"
    ],
    "correctIndex": 0,
    "explanationEn": "Cleaving protective hair-like kappa-casein destabilizes micelles, joining them into a solid gel net.",
    "explanationDe": "Das Enzym bricht die Schutzhülle der Kaseinteilchen auf; die Milch dickt ohne Säuerung ein.",
    "qEn": "What is the function of animal or microbial Rennet (Lab) in cheese making?",
    "qDe": "Welche Funktion hat Lab (Chymosin) bei der Käseherstellung?",
    "optEn": [
      "Enzymatically cleaves kappa-casein, causing milk proteins to precipitate into firm curd",
      "Sweetens the milk",
      "Colors the curd yellow",
      "Kills all bacteria"
    ],
    "optDe": [
      "Spaltet Kappa-Kasein enzymatisch, sodass die Micellen zu festem Bruch gerinnen",
      "Süßt die Milch",
      "Färbt den Bruch gelb",
      "Sterilisiert die Milch"
    ],
    "correct": 0,
    "expEn": "Cleaving protective hair-like kappa-casein destabilizes micelles, joining them into a solid gel net.",
    "expDe": "Das Enzym bricht die Schutzhülle der Kaseinteilchen auf; die Milch dickt ohne Säuerung ein."
  },
  {
    "id": "q_che_12",
    "category": "cheese",
    "questionEn": "What defines an authentic Dutch Gouda Noord-Hollandse BOB?",
    "questionDe": "Was zeichnet echten nordholländischen Gouda BOB aus?",
    "optionsEn": [
      "Made from coastal pasture cow milk, washed curd to reduce lactose, and coated with protective paraffin wax",
      "Made with sheep milk in caves",
      "Smoked with peat",
      "Injected with beer"
    ],
    "optionsDe": [
      "Aus Weidemilch der Küstenpolder; der Bruch wird mit Wasser gewaschen, um Säure zu mildern",
      "Aus Schafsmilch in Höhlen",
      "Mit Torf geräuchert",
      "Mit Bier geimpft"
    ],
    "correctIndex": 0,
    "explanationEn": "Washing curd flushes away excess lactose, preventing harsh sourness and fostering butterscotch sweetness.",
    "explanationDe": "Das Waschen des Bruchs senkt den Milchzucker und sorgt für den mild-karamelligen Charakter.",
    "qEn": "What defines an authentic Dutch Gouda Noord-Hollandse BOB?",
    "qDe": "Was zeichnet echten nordholländischen Gouda BOB aus?",
    "optEn": [
      "Made from coastal pasture cow milk, washed curd to reduce lactose, and coated with protective paraffin wax",
      "Made with sheep milk in caves",
      "Smoked with peat",
      "Injected with beer"
    ],
    "optDe": [
      "Aus Weidemilch der Küstenpolder; der Bruch wird mit Wasser gewaschen, um Säure zu mildern",
      "Aus Schafsmilch in Höhlen",
      "Mit Torf geräuchert",
      "Mit Bier geimpft"
    ],
    "correct": 0,
    "expEn": "Washing curd flushes away excess lactose, preventing harsh sourness and fostering butterscotch sweetness.",
    "expDe": "Das Waschen des Bruchs senkt den Milchzucker und sorgt für den mild-karamelligen Charakter."
  },
  {
    "id": "q_che_13",
    "category": "cheese",
    "questionEn": "What is Ricotta technically in the dairy lexicon?",
    "questionDe": "Was ist Ricotta aus lebensmitteltechnischer Sicht?",
    "optionsEn": [
      "A whey cheese ('re-cooked' whey proteins albumin and globulin), not a true curd cheese",
      "A hard sheep cheese",
      "Fermented butterfat",
      "A blue mold cheese"
    ],
    "optionsDe": [
      "Ein Molkeneiweißkäse ('wiedergekochte' Albumin- und Globulinproteine der Molke)",
      "Ein Hartkäse",
      "Fermentiertes Butterfett",
      "Ein Blauschimmelkäse"
    ],
    "correctIndex": 0,
    "explanationEn": "Heating leftover sweet cheese whey to 85-90°C precipitates albumin into delicate fluffy white flakes.",
    "explanationDe": "Ricotta entsteht durch Erhitzen der Restmolke; die feinen Molkenproteine gerinnen als Schaum.",
    "qEn": "What is Ricotta technically in the dairy lexicon?",
    "qDe": "Was ist Ricotta aus lebensmitteltechnischer Sicht?",
    "optEn": [
      "A whey cheese ('re-cooked' whey proteins albumin and globulin), not a true curd cheese",
      "A hard sheep cheese",
      "Fermented butterfat",
      "A blue mold cheese"
    ],
    "optDe": [
      "Ein Molkeneiweißkäse ('wiedergekochte' Albumin- und Globulinproteine der Molke)",
      "Ein Hartkäse",
      "Fermentiertes Butterfett",
      "Ein Blauschimmelkäse"
    ],
    "correct": 0,
    "expEn": "Heating leftover sweet cheese whey to 85-90°C precipitates albumin into delicate fluffy white flakes.",
    "expDe": "Ricotta entsteht durch Erhitzen der Restmolke; die feinen Molkenproteine gerinnen als Schaum."
  },
  {
    "id": "q_che_14",
    "category": "cheese",
    "questionEn": "Why does Cheddar undergo the labor-intensive 'Cheddaring' process?",
    "questionDe": "Warum durchläuft echter Cheddar das aufwendige 'Cheddaring'-Verfahren?",
    "optionsEn": [
      "Curd slabs are cut, stacked, and turned repeatedly to expel whey and stretch curd into dense fibers",
      "Curd is boiled in copper kettles",
      "Cheese is smoked over oak",
      "Wheels are soaked in wine"
    ],
    "optionsDe": [
      "Bruchblöcke werden gestapelt, gepresst und gewendet, um Molke auszutreiben und Struktur zu verdichten",
      "Bruch wird gekocht",
      "Über Eichenholz geräuchert",
      "In Wein gebadet"
    ],
    "correctIndex": 0,
    "explanationEn": "Acid buildup and warm gravity pressing fuse curd grains into a distinct crumbly-chewy melt.",
    "explanationDe": "Das Stapeln und Wenden säuert den Bruch an und schenkt traditionellem Farmhouse Cheddar seinen Biss.",
    "qEn": "Why does Cheddar undergo the labor-intensive 'Cheddaring' process?",
    "qDe": "Warum durchläuft echter Cheddar das aufwendige 'Cheddaring'-Verfahren?",
    "optEn": [
      "Curd slabs are cut, stacked, and turned repeatedly to expel whey and stretch curd into dense fibers",
      "Curd is boiled in copper kettles",
      "Cheese is smoked over oak",
      "Wheels are soaked in wine"
    ],
    "optDe": [
      "Bruchblöcke werden gestapelt, gepresst und gewendet, um Molke auszutreiben und Struktur zu verdichten",
      "Bruch wird gekocht",
      "Über Eichenholz geräuchert",
      "In Wein gebadet"
    ],
    "correct": 0,
    "expEn": "Acid buildup and warm gravity pressing fuse curd grains into a distinct crumbly-chewy melt.",
    "expDe": "Das Stapeln und Wenden säuert den Bruch an und schenkt traditionellem Farmhouse Cheddar seinen Biss."
  },
  {
    "id": "q_che_15",
    "category": "cheese",
    "questionEn": "What imparts the orange-red rind and pungent barnyard aroma to Munster or Taleggio?",
    "questionDe": "Was erzeugt die orangerote Schmiere und den kräftigen Duft bei Münster oder Taleggio?",
    "optionsEn": [
      "Brevibacterium linens (red smear bacteria) washed periodically with salt water brine",
      "Paprika powder dusting",
      "Carrot juice bath",
      "Synthetic red color"
    ],
    "optionsDe": [
      "Rotschmiere-Bakterien (Brevibacterium linens), gefördert durch Waschen mit Salzlake",
      "Paprikapulver",
      "Karottensaftbad",
      "Künstlicher Farbstoff"
    ],
    "correctIndex": 0,
    "explanationEn": "B. linens thrives in alkaline, moist salt conditions, digesting proteins into savory sulfurous aromatics.",
    "explanationDe": "Die Rotschmiere baut Eiweiß intensiv ab; der Käse duftet streng, schmeckt aber sahnig-mild.",
    "qEn": "What imparts the orange-red rind and pungent barnyard aroma to Munster or Taleggio?",
    "qDe": "Was erzeugt die orangerote Schmiere und den kräftigen Duft bei Münster oder Taleggio?",
    "optEn": [
      "Brevibacterium linens (red smear bacteria) washed periodically with salt water brine",
      "Paprika powder dusting",
      "Carrot juice bath",
      "Synthetic red color"
    ],
    "optDe": [
      "Rotschmiere-Bakterien (Brevibacterium linens), gefördert durch Waschen mit Salzlake",
      "Paprikapulver",
      "Karottensaftbad",
      "Künstlicher Farbstoff"
    ],
    "correct": 0,
    "expEn": "B. linens thrives in alkaline, moist salt conditions, digesting proteins into savory sulfurous aromatics.",
    "expDe": "Die Rotschmiere baut Eiweiß intensiv ab; der Käse duftet streng, schmeckt aber sahnig-mild."
  },
  {
    "id": "q_che_16",
    "category": "cheese",
    "questionEn": "What plant gives English Gloucester and Red Leicester cheeses their vibrant orange color?",
    "questionDe": "Welcher natürliche Pflanzenfarbstoff färbt englischen Red Leicester oder Cheddar leuchtend orange?",
    "optionsEn": [
      "Annatto seed extract (Bixa orellana)",
      "Turmeric",
      "Saffron",
      "Beetroot juice"
    ],
    "optionsDe": [
      "Annatto-Samenextrakt (Bixa orellana)",
      "Kurkuma",
      "Safran",
      "Rote-Bete-Saft"
    ],
    "correctIndex": 0,
    "explanationEn": "South American achiote tree seeds provide natural bixin carotenoids without altering flavor.",
    "explanationDe": "Annatto ist ein geschmacksneutraler Pflanzensamen aus den Tropen mit sonnengelbem Carotinoid.",
    "qEn": "What plant gives English Gloucester and Red Leicester cheeses their vibrant orange color?",
    "qDe": "Welcher natürliche Pflanzenfarbstoff färbt englischen Red Leicester oder Cheddar leuchtend orange?",
    "optEn": [
      "Annatto seed extract (Bixa orellana)",
      "Turmeric",
      "Saffron",
      "Beetroot juice"
    ],
    "optDe": [
      "Annatto-Samenextrakt (Bixa orellana)",
      "Kurkuma",
      "Safran",
      "Rote-Bete-Saft"
    ],
    "correct": 0,
    "expEn": "South American achiote tree seeds provide natural bixin carotenoids without altering flavor.",
    "expDe": "Annatto ist ein geschmacksneutraler Pflanzensamen aus den Tropen mit sonnengelbem Carotinoid."
  },
  {
    "id": "q_che_17",
    "category": "cheese",
    "questionEn": "What is the primary difference between Parmigiano Reggiano and Grana Padano?",
    "questionDe": "Was ist der Hauptunterschied zwischen Parmigiano Reggiano und Grana Padano?",
    "optionsEn": [
      "Parmigiano cows are fed strictly fresh grass and hay (zero silage); Grana Padano permits controlled corn silage and lysozyme",
      "Grana Padano is made from sheep milk",
      "Parmigiano is made in Germany",
      "Grana is never aged"
    ],
    "optionsDe": [
      "Parmigiano-Kühe fressen ausschließlich Gras und Heu (keine Silage); Grana erlaubt Silagefutter",
      "Grana Padano ist aus Schafsmilch",
      "Parmigiano kommt aus Deutschland",
      "Grana reift nie"
    ],
    "correctIndex": 0,
    "explanationEn": "Parmigiano forbids silage and preservatives; Grana Padano uses egg white lysozyme to inhibit late gas blowing.",
    "explanationDe": "Der Verzicht auf Gärfutter (Silage) ist das strikte Qualitätsgeheimnis des Parmigiano Reggiano.",
    "qEn": "What is the primary difference between Parmigiano Reggiano and Grana Padano?",
    "qDe": "Was ist der Hauptunterschied zwischen Parmigiano Reggiano und Grana Padano?",
    "optEn": [
      "Parmigiano cows are fed strictly fresh grass and hay (zero silage); Grana Padano permits controlled corn silage and lysozyme",
      "Grana Padano is made from sheep milk",
      "Parmigiano is made in Germany",
      "Grana is never aged"
    ],
    "optDe": [
      "Parmigiano-Kühe fressen ausschließlich Gras und Heu (keine Silage); Grana erlaubt Silagefutter",
      "Grana Padano ist aus Schafsmilch",
      "Parmigiano kommt aus Deutschland",
      "Grana reift nie"
    ],
    "correct": 0,
    "expEn": "Parmigiano forbids silage and preservatives; Grana Padano uses egg white lysozyme to inhibit late gas blowing.",
    "expDe": "Der Verzicht auf Gärfutter (Silage) ist das strikte Qualitätsgeheimnis des Parmigiano Reggiano."
  },
  {
    "id": "q_che_18",
    "category": "cheese",
    "questionEn": "Why should cheese be removed from the refrigerator 1 hour before serving?",
    "questionDe": "Warum sollte Käse mindestens 1 Stunde vor dem Verzehr temperiert werden?",
    "optionsEn": [
      "Chilled butterfat is hard and masks volatile aroma esters; room temp (18-20°C) softens fat and releases bouquet",
      "Cheese spoils if eaten cold",
      "To kill bacteria with air",
      "To dry out the rind"
    ],
    "optionsDe": [
      "Kaltes Milchfett ist starr und sperrt Aromen ein; bei Raumtemperatur (18–20°C) schmilzt das Bouquet auf",
      "Kalter Käse ist giftig",
      "Um Keime an der Luft zu töten",
      "Damit die Rinde austrocknet"
    ],
    "correctIndex": 0,
    "explanationEn": "Cold anesthetizes tongue receptors; ambient warmth allows lipophilic aromatic molecules to volatilize.",
    "explanationDe": "Erst bei Zimmertemperatur verflüssigen sich die Aromastoffe und entfalten ihr volles Spektrum.",
    "qEn": "Why should cheese be removed from the refrigerator 1 hour before serving?",
    "qDe": "Warum sollte Käse mindestens 1 Stunde vor dem Verzehr temperiert werden?",
    "optEn": [
      "Chilled butterfat is hard and masks volatile aroma esters; room temp (18-20°C) softens fat and releases bouquet",
      "Cheese spoils if eaten cold",
      "To kill bacteria with air",
      "To dry out the rind"
    ],
    "optDe": [
      "Kaltes Milchfett ist starr und sperrt Aromen ein; bei Raumtemperatur (18–20°C) schmilzt das Bouquet auf",
      "Kalter Käse ist giftig",
      "Um Keime an der Luft zu töten",
      "Damit die Rinde austrocknet"
    ],
    "correct": 0,
    "expEn": "Cold anesthetizes tongue receptors; ambient warmth allows lipophilic aromatic molecules to volatilize.",
    "expDe": "Erst bei Zimmertemperatur verflüssigen sich die Aromastoffe und entfalten ihr volles Spektrum."
  },
  {
    "id": "q_egg_01",
    "category": "eggs",
    "questionEn": "At what temperature does egg yolk coagulate versus egg white?",
    "questionDe": "Bei welcher Temperatur stockt Eigelb im Vergleich zu Eiklar?",
    "optionsEn": [
      "White starts at 62-65°C; yolk sets firmly between 65-70°C",
      "Both set at 100°C",
      "Yolk sets at 40°C",
      "White sets at 85°C"
    ],
    "optionsDe": [
      "Eiklar beginnt bei 62–65°C zu stocken; Eigelb bindet cremig zwischen 65–70°C",
      "Beide stocken erst bei 100°C",
      "Eigelb stockt bei 40°C",
      "Eiklar stockt erst bei 85°C"
    ],
    "correctIndex": 0,
    "explanationEn": "Ovalbumin in white begins setting lower, but yolk proteins denature completely above 68°C.",
    "explanationDe": "Eiklar gerinnt ab 62°C; Eigelb bindet zwischen 65°C und 70°C cremig für Sous-vide-Eier.",
    "qEn": "At what temperature does egg yolk coagulate versus egg white?",
    "qDe": "Bei welcher Temperatur stockt Eigelb im Vergleich zu Eiklar?",
    "optEn": [
      "White starts at 62-65°C; yolk sets firmly between 65-70°C",
      "Both set at 100°C",
      "Yolk sets at 40°C",
      "White sets at 85°C"
    ],
    "optDe": [
      "Eiklar beginnt bei 62–65°C zu stocken; Eigelb bindet cremig zwischen 65–70°C",
      "Beide stocken erst bei 100°C",
      "Eigelb stockt bei 40°C",
      "Eiklar stockt erst bei 85°C"
    ],
    "correct": 0,
    "expEn": "Ovalbumin in white begins setting lower, but yolk proteins denature completely above 68°C.",
    "expDe": "Eiklar gerinnt ab 62°C; Eigelb bindet zwischen 65°C und 70°C cremig für Sous-vide-Eier."
  },
  {
    "id": "q_egg_02",
    "category": "eggs",
    "questionEn": "What causes the green-grey ring around the yolk in hard-boiled eggs?",
    "questionDe": "Was verursacht den grün-grauen Rand um das Eigelb bei zu lange gekochten Eiern?",
    "optionsEn": [
      "Ferrous sulfide (FeS) formed when sulfur in the white reacts with iron in the yolk",
      "Bacterial mold",
      "Copper pollution",
      "Chlorine in tap water"
    ],
    "optionsDe": [
      "Eisensulfid (FeS), gebildet durch Schwefelwasserstoff aus dem Eiklar und Eisen im Eidotter",
      "Schimmelbefall",
      "Kupferrückstände",
      "Chlor im Kochwasser"
    ],
    "correctIndex": 0,
    "explanationEn": "Prolonged heat releases hydrogen sulfide from ovalbumin, which migrates inward and reacts with yolk iron.",
    "explanationDe": "Langes Kochen treibt Schwefel zum Dotter, wo er mit Eisen zu unschädlichem grauem Eisensulfid reagiert.",
    "qEn": "What causes the green-grey ring around the yolk in hard-boiled eggs?",
    "qDe": "Was verursacht den grün-grauen Rand um das Eigelb bei zu lange gekochten Eiern?",
    "optEn": [
      "Ferrous sulfide (FeS) formed when sulfur in the white reacts with iron in the yolk",
      "Bacterial mold",
      "Copper pollution",
      "Chlorine in tap water"
    ],
    "optDe": [
      "Eisensulfid (FeS), gebildet durch Schwefelwasserstoff aus dem Eiklar und Eisen im Eidotter",
      "Schimmelbefall",
      "Kupferrückstände",
      "Chlor im Kochwasser"
    ],
    "correct": 0,
    "expEn": "Prolonged heat releases hydrogen sulfide from ovalbumin, which migrates inward and reacts with yolk iron.",
    "expDe": "Langes Kochen treibt Schwefel zum Dotter, wo er mit Eisen zu unschädlichem grauem Eisensulfid reagiert."
  },
  {
    "id": "q_egg_03",
    "category": "eggs",
    "questionEn": "Why does an older egg float in a bowl of cold water?",
    "questionDe": "Warum schwimmt ein altes Ei in einem Glas kaltem Wasser oben?",
    "optionsEn": [
      "Water evaporates through porous shell pores and the internal air cell expands",
      "It fills with helium",
      "The shell becomes thicker",
      "The yolk turns into oil"
    ],
    "optionsDe": [
      "Wasser verdunstet durch die poröse Kalkschale und die Luftkammer vergrößert sich",
      "Es bildet sich Helium",
      "Die Schale wird dicker",
      "Der Dotter wird zu Öl"
    ],
    "correctIndex": 0,
    "explanationEn": "Fresh eggs have a tiny air pocket and sink; moisture loss increases buoyancy over weeks.",
    "explanationDe": "Frische Eier sinken flach zu Boden; mit zunehmendem Alter verliert das Ei Wasser und steigt auf.",
    "qEn": "Why does an older egg float in a bowl of cold water?",
    "qDe": "Warum schwimmt ein altes Ei in einem Glas kaltem Wasser oben?",
    "optEn": [
      "Water evaporates through porous shell pores and the internal air cell expands",
      "It fills with helium",
      "The shell becomes thicker",
      "The yolk turns into oil"
    ],
    "optDe": [
      "Wasser verdunstet durch die poröse Kalkschale und die Luftkammer vergrößert sich",
      "Es bildet sich Helium",
      "Die Schale wird dicker",
      "Der Dotter wird zu Öl"
    ],
    "correct": 0,
    "expEn": "Fresh eggs have a tiny air pocket and sink; moisture loss increases buoyancy over weeks.",
    "expDe": "Frische Eier sinken flach zu Boden; mit zunehmendem Alter verliert das Ei Wasser und steigt auf."
  },
  {
    "id": "q_egg_04",
    "category": "eggs",
    "questionEn": "What is the purpose of adding a splash of vinegar when poaching eggs?",
    "questionDe": "Warum gibt man einen Schuss Essig ins Wasser beim Pochieren von Eiern?",
    "optionsEn": [
      "Lowers water pH, accelerating egg white protein coagulation so it wraps neatly without dispersing",
      "Kills salmonella",
      "Bleaches the shell",
      "Adds lemon flavor"
    ],
    "optionsDe": [
      "Senkt den pH-Wert und beschleunigt das Gerinnen des Eiklars, damit es nicht zerfasert",
      "Tötet Salmonellen ab",
      "Bleicht die Eier",
      "Gibt Zitronengeschmack"
    ],
    "correctIndex": 0,
    "explanationEn": "Mild acidity neutralizes negative charges on proteins, fostering rapid firm bonding in simmering water.",
    "explanationDe": "Säure lässt die Proteine des Eiklars schlagartig fest werden, bevor sie im Wasser verwehen.",
    "qEn": "What is the purpose of adding a splash of vinegar when poaching eggs?",
    "qDe": "Warum gibt man einen Schuss Essig ins Wasser beim Pochieren von Eiern?",
    "optEn": [
      "Lowers water pH, accelerating egg white protein coagulation so it wraps neatly without dispersing",
      "Kills salmonella",
      "Bleaches the shell",
      "Adds lemon flavor"
    ],
    "optDe": [
      "Senkt den pH-Wert und beschleunigt das Gerinnen des Eiklars, damit es nicht zerfasert",
      "Tötet Salmonellen ab",
      "Bleicht die Eier",
      "Gibt Zitronengeschmack"
    ],
    "correct": 0,
    "expEn": "Mild acidity neutralizes negative charges on proteins, fostering rapid firm bonding in simmering water.",
    "expDe": "Säure lässt die Proteine des Eiklars schlagartig fest werden, bevor sie im Wasser verwehen."
  },
  {
    "id": "q_egg_05",
    "category": "eggs",
    "questionEn": "What are the Chalazae (Hagelschnüre) inside a raw egg?",
    "questionDe": "Welche Funktion haben die Hagelschnüre (Chalazae) im rohen Ei?",
    "optionsEn": [
      "Twisted protein strands that suspend the yolk centered in the albumen",
      "Embryo veins",
      "Parasites",
      "Fat ligaments"
    ],
    "optionsDe": [
      "Gedrehte Eiweißstränge, die den Dotter mittig im schützenden Eiklar verankern",
      "Adern des Kükens",
      "Parasiten",
      "Fettbänder"
    ],
    "correctIndex": 0,
    "explanationEn": "Prominent, thick chalazae indicate high egg freshness and firm albumen viscosity.",
    "explanationDe": "Ausgeprägte Hagelschnüre sind ein Qualitätsmerkmal für absolute Frische des Eies.",
    "qEn": "What are the Chalazae (Hagelschnüre) inside a raw egg?",
    "qDe": "Welche Funktion haben die Hagelschnüre (Chalazae) im rohen Ei?",
    "optEn": [
      "Twisted protein strands that suspend the yolk centered in the albumen",
      "Embryo veins",
      "Parasites",
      "Fat ligaments"
    ],
    "optDe": [
      "Gedrehte Eiweißstränge, die den Dotter mittig im schützenden Eiklar verankern",
      "Adern des Kükens",
      "Parasiten",
      "Fettbänder"
    ],
    "correct": 0,
    "expEn": "Prominent, thick chalazae indicate high egg freshness and firm albumen viscosity.",
    "expDe": "Ausgeprägte Hagelschnüre sind ein Qualitätsmerkmal für absolute Frische des Eies."
  },
  {
    "id": "q_egg_06",
    "category": "eggs",
    "questionEn": "What defines an authentic French rolled omelette?",
    "questionDe": "Was zeichnet ein klassisches französisches Omelette aus?",
    "optionsEn": [
      "Pale buttery exterior without browning, rolled cylinder, creamy baveuse molten interior",
      "Crispy brown crust with cheese",
      "Deep-fried egg pancake",
      "Baked in high oven"
    ],
    "optionsDe": [
      "Goldgelb ohne Bräunung, glatte Zylinderform, innen cremig-flüssig ('baveuse')",
      "Knusprig braun gebraten",
      "Frittierter Eierkuchen",
      "Im Ofen souffliert"
    ],
    "correctIndex": 0,
    "explanationEn": "High heat with constant vigorous stirring and cold butter folding produces a silky custard center.",
    "explanationDe": "Gleichmäßiges Rühren in schäumender Butter verhindert Bräunung und hält den Kern cremig.",
    "qEn": "What defines an authentic French rolled omelette?",
    "qDe": "Was zeichnet ein klassisches französisches Omelette aus?",
    "optEn": [
      "Pale buttery exterior without browning, rolled cylinder, creamy baveuse molten interior",
      "Crispy brown crust with cheese",
      "Deep-fried egg pancake",
      "Baked in high oven"
    ],
    "optDe": [
      "Goldgelb ohne Bräunung, glatte Zylinderform, innen cremig-flüssig ('baveuse')",
      "Knusprig braun gebraten",
      "Frittierter Eierkuchen",
      "Im Ofen souffliert"
    ],
    "correct": 0,
    "expEn": "High heat with constant vigorous stirring and cold butter folding produces a silky custard center.",
    "expDe": "Gleichmäßiges Rühren in schäumender Butter verhindert Bräunung und hält den Kern cremig."
  },
  {
    "id": "q_egg_07",
    "category": "eggs",
    "questionEn": "What does egg stamp code '0-DE-...' signify in the EU?",
    "questionDe": "Was bedeutet die Ziffer '0' auf dem EU-Ei-Erzeugerstempel (z.B. 0-DE-12345)?",
    "optionsEn": [
      "Ecological / Organic farming (Ökologische Erzeugung / Bio)",
      "Free range (Freilandhaltung)",
      "Barn housing (Bodenhaltung)",
      "Caged hens"
    ],
    "optionsDe": [
      "Ökologische Erzeugung / Bio-Haltung",
      "Freilandhaltung",
      "Bodenhaltung",
      "Käfighaltung"
    ],
    "correctIndex": 0,
    "explanationEn": "0 = Bio/Organic; 1 = Freiland/Free range; 2 = Bodenhaltung/Barn; 3 = Käfighaltung/Cage.",
    "explanationDe": "0 steht für Bio-Eier mit Auslauf und Ökofutter; 1 für Freiland; 2 für Bodenhaltung.",
    "qEn": "What does egg stamp code '0-DE-...' signify in the EU?",
    "qDe": "Was bedeutet die Ziffer '0' auf dem EU-Ei-Erzeugerstempel (z.B. 0-DE-12345)?",
    "optEn": [
      "Ecological / Organic farming (Ökologische Erzeugung / Bio)",
      "Free range (Freilandhaltung)",
      "Barn housing (Bodenhaltung)",
      "Caged hens"
    ],
    "optDe": [
      "Ökologische Erzeugung / Bio-Haltung",
      "Freilandhaltung",
      "Bodenhaltung",
      "Käfighaltung"
    ],
    "correct": 0,
    "expEn": "0 = Bio/Organic; 1 = Freiland/Free range; 2 = Bodenhaltung/Barn; 3 = Käfighaltung/Cage.",
    "expDe": "0 steht für Bio-Eier mit Auslauf und Ökofutter; 1 für Freiland; 2 für Bodenhaltung."
  },
  {
    "id": "q_egg_08",
    "category": "eggs",
    "questionEn": "Why does egg white whip into voluminous foam but fails if a drop of yolk is present?",
    "questionDe": "Warum schlägt Eiklar zu festem Eischnee, versagt aber völlig bei einem Tropfen Eigelb?",
    "optionsEn": [
      "Fats in yolk compete with albumen proteins at the air-water interface, breaking surface tension bubbles",
      "Yolk cools the bowl",
      "Yolk has too much salt",
      "Yolk absorbs air"
    ],
    "optionsDe": [
      "Fette im Eidotter stören die Proteinvernetzung an der Luft-Wasser-Grenze; Blasen kollabieren",
      "Dotter kühlt die Schüssel ab",
      "Dotter enthält zu viel Salz",
      "Dotter saugt die Luft auf"
    ],
    "correctIndex": 0,
    "explanationEn": "Lipids disrupt the hydrophobic-hydrophilic protein network required to trap air bubbles.",
    "explanationDe": "Schon Spuren von Fett verhindern, dass die Proteine ein stabiles Gerüst um Luftbläschen spannen.",
    "qEn": "Why does egg white whip into voluminous foam but fails if a drop of yolk is present?",
    "qDe": "Warum schlägt Eiklar zu festem Eischnee, versagt aber völlig bei einem Tropfen Eigelb?",
    "optEn": [
      "Fats in yolk compete with albumen proteins at the air-water interface, breaking surface tension bubbles",
      "Yolk cools the bowl",
      "Yolk has too much salt",
      "Yolk absorbs air"
    ],
    "optDe": [
      "Fette im Eidotter stören die Proteinvernetzung an der Luft-Wasser-Grenze; Blasen kollabieren",
      "Dotter kühlt die Schüssel ab",
      "Dotter enthält zu viel Salz",
      "Dotter saugt die Luft auf"
    ],
    "correct": 0,
    "expEn": "Lipids disrupt the hydrophobic-hydrophilic protein network required to trap air bubbles.",
    "expDe": "Schon Spuren von Fett verhindern, dass die Proteine ein stabiles Gerüst um Luftbläschen spannen."
  },
  {
    "id": "q_egg_09",
    "category": "eggs",
    "questionEn": "What is an Onsen Tamago in Japanese hot spring culinary tradition?",
    "questionDe": "Was ist ein traditionelles japanisches Onsen-Ei (Onsen Tamago)?",
    "optionsEn": [
      "Egg slow-cooked in 65-68°C mineral waters, yielding firm silky yolk and custard-soft white",
      "Boiled egg with soy sauce",
      "Raw egg over hot rice",
      "Scrambled egg soup"
    ],
    "optionsDe": [
      "Bei konstanter Quelltemperatur (65–68°C) gegart: Dotter ist cremig-fest, Eiklar samtig-weich",
      "In Sojasauce hartgekochtes Ei",
      "Rohes Ei auf Reis",
      "Rühreisuppe"
    ],
    "correctIndex": 0,
    "explanationEn": "Since yolk sets around 65°C and white sets fully at 80°C, low temp creates a reverse-texture egg.",
    "explanationDe": "Weil Eigelb vor dem Eiklar seine Cremigkeit bindet, ist der Dotter fester als das Eiklar.",
    "qEn": "What is an Onsen Tamago in Japanese hot spring culinary tradition?",
    "qDe": "Was ist ein traditionelles japanisches Onsen-Ei (Onsen Tamago)?",
    "optEn": [
      "Egg slow-cooked in 65-68°C mineral waters, yielding firm silky yolk and custard-soft white",
      "Boiled egg with soy sauce",
      "Raw egg over hot rice",
      "Scrambled egg soup"
    ],
    "optDe": [
      "Bei konstanter Quelltemperatur (65–68°C) gegart: Dotter ist cremig-fest, Eiklar samtig-weich",
      "In Sojasauce hartgekochtes Ei",
      "Rohes Ei auf Reis",
      "Rühreisuppe"
    ],
    "correct": 0,
    "expEn": "Since yolk sets around 65°C and white sets fully at 80°C, low temp creates a reverse-texture egg.",
    "expDe": "Weil Eigelb vor dem Eiklar seine Cremigkeit bindet, ist der Dotter fester als das Eiklar."
  },
  {
    "id": "q_egg_10",
    "category": "eggs",
    "questionEn": "What is an Egg Benedict?",
    "questionDe": "Woraus besteht ein klassisches Egg Benedict?",
    "optionsEn": [
      "Toasted English muffin, Canadian bacon/ham, poached egg, and warm Hollandaise sauce",
      "Fried egg on sourdough with ketchup",
      "Scrambled eggs with salmon",
      "Boiled egg in salad"
    ],
    "optionsDe": [
      "Getoasteter English Muffin, Schinken, pochiertes Ei und warme Sauce Hollandaise",
      "Spiegelei auf Brot mit Ketchup",
      "Rührei mit Lachs",
      "Gekochtes Ei im Salat"
    ],
    "correctIndex": 0,
    "explanationEn": "Invented in New York; the molten yolk combines with velvety butter Hollandaise.",
    "explanationDe": "Der flüssige warme Eidotter verschmilzt mit Buttersauce, Schinken und knusprigem Muffin.",
    "qEn": "What is an Egg Benedict?",
    "qDe": "Woraus besteht ein klassisches Egg Benedict?",
    "optEn": [
      "Toasted English muffin, Canadian bacon/ham, poached egg, and warm Hollandaise sauce",
      "Fried egg on sourdough with ketchup",
      "Scrambled eggs with salmon",
      "Boiled egg in salad"
    ],
    "optDe": [
      "Getoasteter English Muffin, Schinken, pochiertes Ei und warme Sauce Hollandaise",
      "Spiegelei auf Brot mit Ketchup",
      "Rührei mit Lachs",
      "Gekochtes Ei im Salat"
    ],
    "correct": 0,
    "expEn": "Invented in New York; the molten yolk combines with velvety butter Hollandaise.",
    "expDe": "Der flüssige warme Eidotter verschmilzt mit Buttersauce, Schinken und knusprigem Muffin."
  },
  {
    "id": "q_egg_11",
    "category": "eggs",
    "questionEn": "Why do scrambled eggs become watery if cooked on high heat or held on a buffet too long?",
    "questionDe": "Warum wässern Rühreier (Synerese), wenn sie zu heiß gegart oder warmgehalten werden?",
    "optionsEn": [
      "Protein strands over-coagulate and contract tightly, squeezing out trapped water like a sponge",
      "Water condenses from kitchen air",
      "Butter melts into water",
      "Salt dissolves the eggs"
    ],
    "optionsDe": [
      "Proteine vernetzen sich zu dicht und pressen gebundenes Wasser wie ein Schwamm heraus",
      "Luftfeuchtigkeit kondensiert",
      "Butter wird zu Wasser",
      "Salz löst das Ei auf"
    ],
    "correctIndex": 0,
    "explanationEn": "Syneresis occurs when tight protein matrices squeeze out liquid, leaving rubbery curds in liquid.",
    "explanationDe": "Zu starke Hitze zieht das Eiweißgitter zusammen; die eingeschlossene Flüssigkeit tritt aus.",
    "qEn": "Why do scrambled eggs become watery if cooked on high heat or held on a buffet too long?",
    "qDe": "Warum wässern Rühreier (Synerese), wenn sie zu heiß gegart oder warmgehalten werden?",
    "optEn": [
      "Protein strands over-coagulate and contract tightly, squeezing out trapped water like a sponge",
      "Water condenses from kitchen air",
      "Butter melts into water",
      "Salt dissolves the eggs"
    ],
    "optDe": [
      "Proteine vernetzen sich zu dicht und pressen gebundenes Wasser wie ein Schwamm heraus",
      "Luftfeuchtigkeit kondensiert",
      "Butter wird zu Wasser",
      "Salz löst das Ei auf"
    ],
    "correct": 0,
    "expEn": "Syneresis occurs when tight protein matrices squeeze out liquid, leaving rubbery curds in liquid.",
    "expDe": "Zu starke Hitze zieht das Eiweißgitter zusammen; die eingeschlossene Flüssigkeit tritt aus."
  },
  {
    "id": "q_egg_12",
    "category": "eggs",
    "questionEn": "What is Century Egg (Pidan) in Chinese cuisine?",
    "questionDe": "Was ist das chinesische 'Tausendjährige Ei' (Pidan)?",
    "optionsEn": [
      "Duck egg preserved in clay, ash, salt, lime, and tea for months, turning white into amber jelly and yolk dark green",
      "An egg 1000 years old",
      "Fossilized dinosaur egg",
      "Egg soaked in vinegar for a week"
    ],
    "optionsDe": [
      "In Lehm, Asche, Kalk und Salz gereiftes Entenei; Eiklar geliert bernsteinfarben, Dotter wird cremig-grün",
      "Ein 1000 Jahre altes Ei",
      "Versteinertes Vogelei",
      "In Essig eingelegtes Hühnerei"
    ],
    "correctIndex": 0,
    "explanationEn": "Alkaline curing raises pH to 9-12, breaking proteins into savory peptides without heat.",
    "explanationDe": "Durch basische Reifung denaturieren die Proteine kalt; es entstehen komplexe Umami-Noten.",
    "qEn": "What is Century Egg (Pidan) in Chinese cuisine?",
    "qDe": "Was ist das chinesische 'Tausendjährige Ei' (Pidan)?",
    "optEn": [
      "Duck egg preserved in clay, ash, salt, lime, and tea for months, turning white into amber jelly and yolk dark green",
      "An egg 1000 years old",
      "Fossilized dinosaur egg",
      "Egg soaked in vinegar for a week"
    ],
    "optDe": [
      "In Lehm, Asche, Kalk und Salz gereiftes Entenei; Eiklar geliert bernsteinfarben, Dotter wird cremig-grün",
      "Ein 1000 Jahre altes Ei",
      "Versteinertes Vogelei",
      "In Essig eingelegtes Hühnerei"
    ],
    "correct": 0,
    "expEn": "Alkaline curing raises pH to 9-12, breaking proteins into savory peptides without heat.",
    "expDe": "Durch basische Reifung denaturieren die Proteine kalt; es entstehen komplexe Umami-Noten."
  },
  {
    "id": "q_egg_13",
    "category": "eggs",
    "questionEn": "What determines the shell color of a chicken egg (white vs. brown)?",
    "questionDe": "Wodurch wird die Schalenfarbe eines Hühnereis (weiß oder braun) bestimmt?",
    "optionsEn": [
      "The chicken's genetic breed and earlobe color (brown pigments come from protoporphyrin)",
      "The color of feed grain (corn vs. wheat)",
      "Sunlight exposure",
      "Feather washing"
    ],
    "optionsDe": [
      "Die Genetik der Hühnerrasse (erkennbar an der Farbe der Ohrscheiben)",
      "Das Futter (Mais vs. Weizen)",
      "Sonnenlicht im Hühnerstall",
      "Reinigung der Federn"
    ],
    "correctIndex": 0,
    "explanationEn": "Ear lobe color correlates with pigment glands in the oviduct; feed affects only yolk hue, not shell.",
    "explanationDe": "Weiße Ohrscheiben legen meist weiße Eier; die Schalenfarbe hat keinen Einfluss auf Geschmack.",
    "qEn": "What determines the shell color of a chicken egg (white vs. brown)?",
    "qDe": "Wodurch wird die Schalenfarbe eines Hühnereis (weiß oder braun) bestimmt?",
    "optEn": [
      "The chicken's genetic breed and earlobe color (brown pigments come from protoporphyrin)",
      "The color of feed grain (corn vs. wheat)",
      "Sunlight exposure",
      "Feather washing"
    ],
    "optDe": [
      "Die Genetik der Hühnerrasse (erkennbar an der Farbe der Ohrscheiben)",
      "Das Futter (Mais vs. Weizen)",
      "Sonnenlicht im Hühnerstall",
      "Reinigung der Federn"
    ],
    "correct": 0,
    "expEn": "Ear lobe color correlates with pigment glands in the oviduct; feed affects only yolk hue, not shell.",
    "expDe": "Weiße Ohrscheiben legen meist weiße Eier; die Schalenfarbe hat keinen Einfluss auf Geschmack."
  },
  {
    "id": "q_egg_14",
    "category": "eggs",
    "questionEn": "What causes deep orange yolk color in free-range eggs?",
    "questionDe": "Was erzeugt die tief orange Dotterfarbe bei Weidehühnern?",
    "optionsEn": [
      "Carotenoids (lutein and zeaxanthin) from green grasses, marigold petals, or paprika",
      "Excess blood in yolk",
      "Chemical dyes",
      "High cholesterol content"
    ],
    "optionsDe": [
      "Carotinoide (Lutein, Zeaxanthin) aus frischem Wiesengrün, Ringelblumen oder Paprika",
      "Blutbestandteile",
      "Künstliche Farbstoffe",
      "Hoher Cholesteringehalt"
    ],
    "correctIndex": 0,
    "explanationEn": "Carotenoids are lipophilic pigments deposited directly from diet into developing yolks.",
    "explanationDe": "Hühner lagern Carotinoide aus Klee, Gras und Kräutern im fettreichen Eidotter ein.",
    "qEn": "What causes deep orange yolk color in free-range eggs?",
    "qDe": "Was erzeugt die tief orange Dotterfarbe bei Weidehühnern?",
    "optEn": [
      "Carotenoids (lutein and zeaxanthin) from green grasses, marigold petals, or paprika",
      "Excess blood in yolk",
      "Chemical dyes",
      "High cholesterol content"
    ],
    "optDe": [
      "Carotinoide (Lutein, Zeaxanthin) aus frischem Wiesengrün, Ringelblumen oder Paprika",
      "Blutbestandteile",
      "Künstliche Farbstoffe",
      "Hoher Cholesteringehalt"
    ],
    "correct": 0,
    "expEn": "Carotenoids are lipophilic pigments deposited directly from diet into developing yolks.",
    "expDe": "Hühner lagern Carotinoide aus Klee, Gras und Kräutern im fettreichen Eidotter ein."
  },
  {
    "id": "q_egg_15",
    "category": "eggs",
    "questionEn": "What is an Italian Frittata compared to a French omelette?",
    "questionDe": "Was unterscheidet eine italienische Frittata von einem französischen Omelette?",
    "optionsEn": [
      "Ingredients are whisked directly into eggs, cooked slowly flat in a skillet, and browned on both sides or broiled",
      "Frittata is rolled with raw cheese",
      "Frittata contains flour",
      "Frittata is deep-fried"
    ],
    "optionsDe": [
      "Zutaten werden direkt mit den Eiern verquirlt, langsam dick gestockt und gewendet oder überbacken",
      "Frittata wird gerollt",
      "Frittata ist ein Hefekuchen",
      "Frittata wird frittiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Frittata resembles an open-faced Spanish tortilla without folding, served warm or at room temp.",
    "explanationDe": "Die Frittata wird flach gegart und in Kuchenstücke geschnitten, ideal für Buffets.",
    "qEn": "What is an Italian Frittata compared to a French omelette?",
    "qDe": "Was unterscheidet eine italienische Frittata von einem französischen Omelette?",
    "optEn": [
      "Ingredients are whisked directly into eggs, cooked slowly flat in a skillet, and browned on both sides or broiled",
      "Frittata is rolled with raw cheese",
      "Frittata contains flour",
      "Frittata is deep-fried"
    ],
    "optDe": [
      "Zutaten werden direkt mit den Eiern verquirlt, langsam dick gestockt und gewendet oder überbacken",
      "Frittata wird gerollt",
      "Frittata ist ein Hefekuchen",
      "Frittata wird frittiert"
    ],
    "correct": 0,
    "expEn": "Frittata resembles an open-faced Spanish tortilla without folding, served warm or at room temp.",
    "expDe": "Die Frittata wird flach gegart und in Kuchenstücke geschnitten, ideal für Buffets."
  },
  {
    "id": "q_egg_16",
    "category": "eggs",
    "questionEn": "What is the primary role of egg yolk in baking and pastry creams?",
    "questionDe": "Welche Funktion hat Eigelb in Cremes und Teigen in der Patisserie?",
    "optionsEn": [
      "Provides rich emulsification, silky mouthfeel, golden color, and velvety tender crumb",
      "Acts as yeast rising agent",
      "Dries out dough",
      "Adds crisp sugar crunch"
    ],
    "optionsDe": [
      "Liefert Emulgatoren (Lecithin), sahnigen Schmelz, Farbe und zarte Krumenstruktur",
      "Treibt wie Backhefe",
      "Trocknet Teige aus",
      "Macht Baiser knusprig"
    ],
    "correctIndex": 0,
    "explanationEn": "Yolk fat shortens gluten strands and binds fat-water phases in custards and brioches.",
    "explanationDe": "Fett und Lecithin machen Hefegebäck mürbe und binden Vanillesaucen samtig ab.",
    "qEn": "What is the primary role of egg yolk in baking and pastry creams?",
    "qDe": "Welche Funktion hat Eigelb in Cremes und Teigen in der Patisserie?",
    "optEn": [
      "Provides rich emulsification, silky mouthfeel, golden color, and velvety tender crumb",
      "Acts as yeast rising agent",
      "Dries out dough",
      "Adds crisp sugar crunch"
    ],
    "optDe": [
      "Liefert Emulgatoren (Lecithin), sahnigen Schmelz, Farbe und zarte Krumenstruktur",
      "Treibt wie Backhefe",
      "Trocknet Teige aus",
      "Macht Baiser knusprig"
    ],
    "correct": 0,
    "expEn": "Yolk fat shortens gluten strands and binds fat-water phases in custards and brioches.",
    "expDe": "Fett und Lecithin machen Hefegebäck mürbe und binden Vanillesaucen samtig ab."
  },
  {
    "id": "q_egg_17",
    "category": "eggs",
    "questionEn": "What is an Egg Florentine?",
    "questionDe": "Was kennzeichnet Eier Florentiner Art (Eggs Florentine)?",
    "optionsEn": [
      "Poached eggs served on a bed of buttered cooked spinach with Mornay or Hollandaise sauce",
      "Eggs with tomato sauce",
      "Raw eggs with Parmesan",
      "Fried eggs on steak"
    ],
    "optionsDe": [
      "Pochierte Eier auf gedünstetem Blattspinat, überzogen mit Mornay- oder Hollandaisesauce",
      "Spiegeleier mit Tomatensauce",
      "Rohe Eier mit Parmesan",
      "Eier auf Rindersteak"
    ],
    "correctIndex": 0,
    "explanationEn": "'Florentine' in classical French cuisine denotes dishes served with spinach.",
    "explanationDe": "In der klassischen Küche steht der Zusatz 'Florentiner Art' für Gerichte mit Spinat.",
    "qEn": "What is an Egg Florentine?",
    "qDe": "Was kennzeichnet Eier Florentiner Art (Eggs Florentine)?",
    "optEn": [
      "Poached eggs served on a bed of buttered cooked spinach with Mornay or Hollandaise sauce",
      "Eggs with tomato sauce",
      "Raw eggs with Parmesan",
      "Fried eggs on steak"
    ],
    "optDe": [
      "Pochierte Eier auf gedünstetem Blattspinat, überzogen mit Mornay- oder Hollandaisesauce",
      "Spiegeleier mit Tomatensauce",
      "Rohe Eier mit Parmesan",
      "Eier auf Rindersteak"
    ],
    "correct": 0,
    "expEn": "'Florentine' in classical French cuisine denotes dishes served with spinach.",
    "expDe": "In der klassischen Küche steht der Zusatz 'Florentiner Art' für Gerichte mit Spinat."
  },
  {
    "id": "q_egg_18",
    "category": "eggs",
    "questionEn": "Why does beating cold eggs take longer to emulsify than room-temperature eggs?",
    "questionDe": "Warum lassen sich zimmertemperierte Eier besser aufschlagen und emulgieren als kühlschrankkalte Eier?",
    "optionsEn": [
      "Warm egg proteins have lower surface viscosity and stretch more easily, trapping micro-air bubbles",
      "Cold eggs curdle instantly",
      "Warm eggs lose water",
      "Cold eggs are too sweet"
    ],
    "optionsDe": [
      "Zimmertemperierte Proteine haben eine geringere Viskosität und bilden schneller elastische Schaumhäute",
      "Kühlschrankeier gerinnen sofort",
      "Warme Eier verlieren Wasser",
      "Kälte macht Eier süß"
    ],
    "correctIndex": 0,
    "explanationEn": "Room temp (20°C) allows albumen and yolk lipids to blend and expand rapidly without curdling.",
    "explanationDe": "Bei Raumtemperatur binden Eier Emulsionen wie Mayonnaise oder Biskuitteig deutlich stabiler.",
    "qEn": "Why does beating cold eggs take longer to emulsify than room-temperature eggs?",
    "qDe": "Warum lassen sich zimmertemperierte Eier besser aufschlagen und emulgieren als kühlschrankkalte Eier?",
    "optEn": [
      "Warm egg proteins have lower surface viscosity and stretch more easily, trapping micro-air bubbles",
      "Cold eggs curdle instantly",
      "Warm eggs lose water",
      "Cold eggs are too sweet"
    ],
    "optDe": [
      "Zimmertemperierte Proteine haben eine geringere Viskosität und bilden schneller elastische Schaumhäute",
      "Kühlschrankeier gerinnen sofort",
      "Warme Eier verlieren Wasser",
      "Kälte macht Eier süß"
    ],
    "correct": 0,
    "expEn": "Room temp (20°C) allows albumen and yolk lipids to blend and expand rapidly without curdling.",
    "expDe": "Bei Raumtemperatur binden Eier Emulsionen wie Mayonnaise oder Biskuitteig deutlich stabiler."
  },
  {
    "id": "q_veg_01",
    "category": "vegetables",
    "questionEn": "What culinary compound makes Black Truffles (Tuber melanosporum) uniquely fragrant?",
    "questionDe": "Welche Duftstoffe prägen den Périgord-Schwarztruffel (Tuber melanosporum)?",
    "optionsEn": [
      "Volatile sulfur compounds like dimethyl sulfide and 2-methylbutanal",
      "Menthol",
      "Linalool",
      "Vanillin"
    ],
    "optionsDe": [
      "Flüchtige Schwefelverbindungen (Dimethylsulfid) und erdig-würzige Aldehyde",
      "Menthol",
      "Linalool",
      "Vanillin"
    ],
    "correctIndex": 0,
    "explanationEn": "Sulfur molecules evoke damp forest soil, musk, and dried mushrooms.",
    "explanationDe": "Schwefelhaltige Terpene erzeugen das typische, tief-erdige Aroma des Edelpilzes.",
    "qEn": "What culinary compound makes Black Truffles (Tuber melanosporum) uniquely fragrant?",
    "qDe": "Welche Duftstoffe prägen den Périgord-Schwarztruffel (Tuber melanosporum)?",
    "optEn": [
      "Volatile sulfur compounds like dimethyl sulfide and 2-methylbutanal",
      "Menthol",
      "Linalool",
      "Vanillin"
    ],
    "optDe": [
      "Flüchtige Schwefelverbindungen (Dimethylsulfid) und erdig-würzige Aldehyde",
      "Menthol",
      "Linalool",
      "Vanillin"
    ],
    "correct": 0,
    "expEn": "Sulfur molecules evoke damp forest soil, musk, and dried mushrooms.",
    "expDe": "Schwefelhaltige Terpene erzeugen das typische, tief-erdige Aroma des Edelpilzes."
  },
  {
    "id": "q_veg_02",
    "category": "vegetables",
    "questionEn": "Why should Chanterelle mushrooms (Pfifferlinge) never be washed in a sink of water?",
    "questionDe": "Warum sollte man frische Pfifferlinge niemals im Wasserbad waschen?",
    "optionsEn": [
      "Spongy gills soak up water like a sponge, turning rubbery and boiling in their own juice in the pan",
      "Water makes them poisonous",
      "Caps dissolve in water",
      "Color washes off completely"
    ],
    "optionsDe": [
      "Das poröse Schwammgewebe saugt Wasser auf; in der Pfanne kochen sie im Saft und werden zäh",
      "Wasser macht sie giftig",
      "Die Hüte lösen sich auf",
      "Die gelbe Farbe wäscht sich ab"
    ],
    "correctIndex": 0,
    "explanationEn": "Dry brush or trim chanterelles; wet mushrooms cannot sear properly at high frying heat.",
    "explanationDe": "Pilze nur trocken abbürsten; nasse Pilze braten nicht an, sondern dünsten zäh aus.",
    "qEn": "Why should Chanterelle mushrooms (Pfifferlinge) never be washed in a sink of water?",
    "qDe": "Warum sollte man frische Pfifferlinge niemals im Wasserbad waschen?",
    "optEn": [
      "Spongy gills soak up water like a sponge, turning rubbery and boiling in their own juice in the pan",
      "Water makes them poisonous",
      "Caps dissolve in water",
      "Color washes off completely"
    ],
    "optDe": [
      "Das poröse Schwammgewebe saugt Wasser auf; in der Pfanne kochen sie im Saft und werden zäh",
      "Wasser macht sie giftig",
      "Die Hüte lösen sich auf",
      "Die gelbe Farbe wäscht sich ab"
    ],
    "correct": 0,
    "expEn": "Dry brush or trim chanterelles; wet mushrooms cannot sear properly at high frying heat.",
    "expDe": "Pilze nur trocken abbürsten; nasse Pilze braten nicht an, sondern dünsten zäh aus."
  },
  {
    "id": "q_veg_03",
    "category": "vegetables",
    "questionEn": "What is the secret of French Caramelized Onions (Oignons caramélisés)?",
    "questionDe": "Was ist das Geheimnis für echte französische karamellisierte Zwiebeln?",
    "optionsEn": [
      "Slow cooking for 45-60 minutes, allowing cell walls to break down and sugars to caramelize slowly via Maillard reactions",
      "Adding two cups of white sugar",
      "Frying at 250°C for 2 minutes",
      "Boiling in vinegar"
    ],
    "optionsDe": [
      "Langsames Dünsten über 45–60 Minuten; zelleigene Zucker karamellisieren durch Maillard-Reaktion",
      "Zugabe von Kristallzucker",
      "Frittieren bei 250°C",
      "Kochen in Essig"
    ],
    "correctIndex": 0,
    "explanationEn": "Gentle heat concentrates natural fructose without scorching bitter sulfur compounds.",
    "explanationDe": "Langsames Rösten wandelt scharfe schweflige Zwiebelstoffe in tiefsüßes Umami um.",
    "qEn": "What is the secret of French Caramelized Onions (Oignons caramélisés)?",
    "qDe": "Was ist das Geheimnis für echte französische karamellisierte Zwiebeln?",
    "optEn": [
      "Slow cooking for 45-60 minutes, allowing cell walls to break down and sugars to caramelize slowly via Maillard reactions",
      "Adding two cups of white sugar",
      "Frying at 250°C for 2 minutes",
      "Boiling in vinegar"
    ],
    "optDe": [
      "Langsames Dünsten über 45–60 Minuten; zelleigene Zucker karamellisieren durch Maillard-Reaktion",
      "Zugabe von Kristallzucker",
      "Frittieren bei 250°C",
      "Kochen in Essig"
    ],
    "correct": 0,
    "expEn": "Gentle heat concentrates natural fructose without scorching bitter sulfur compounds.",
    "expDe": "Langsames Rösten wandelt scharfe schweflige Zwiebelstoffe in tiefsüßes Umami um."
  },
  {
    "id": "q_veg_04",
    "category": "vegetables",
    "questionEn": "Why is white asparagus (Spargel) grown buried under dark earthen mounds?",
    "questionDe": "Warum wächst weißer Stangenspargel unter aufgeschütteten Erddämmen?",
    "optionsEn": [
      "Lack of sunlight prevents photosynthesis and chlorophyll formation, keeping stalks snowy white and tender",
      "To protect from wind",
      "To grow faster",
      "To absorb fertilizer better"
    ],
    "optionsDe": [
      "Lichtentzug verhindert Photosynthese und Chlorophyllbildung; die Stangen bleiben weiß und zart",
      "Schutz vor Wind",
      "Damit er schneller wächst",
      "Um Dünger aufzunehmen"
    ],
    "correctIndex": 0,
    "explanationEn": "Exposure to daylight turns the tips violet or green, triggering bitter compound synthesis.",
    "explanationDe": "Sobald Spargelspitzen die Erde durchbrechen, färben sie sich durch Sonnenlicht violett.",
    "qEn": "Why is white asparagus (Spargel) grown buried under dark earthen mounds?",
    "qDe": "Warum wächst weißer Stangenspargel unter aufgeschütteten Erddämmen?",
    "optEn": [
      "Lack of sunlight prevents photosynthesis and chlorophyll formation, keeping stalks snowy white and tender",
      "To protect from wind",
      "To grow faster",
      "To absorb fertilizer better"
    ],
    "optDe": [
      "Lichtentzug verhindert Photosynthese und Chlorophyllbildung; die Stangen bleiben weiß und zart",
      "Schutz vor Wind",
      "Damit er schneller wächst",
      "Um Dünger aufzunehmen"
    ],
    "correct": 0,
    "expEn": "Exposure to daylight turns the tips violet or green, triggering bitter compound synthesis.",
    "expDe": "Sobald Spargelspitzen die Erde durchbrechen, färben sie sich durch Sonnenlicht violett."
  },
  {
    "id": "q_veg_05",
    "category": "vegetables",
    "questionEn": "What gives Porcini mushrooms (Steinpilze / Boletus edulis) their celebrated savory umami?",
    "questionDe": "Was verleiht getrockneten Steinpilzen (Boletus edulis) ihr intensives Umami-Aroma?",
    "optionsEn": [
      "High natural concentrations of free glutamic acid and ribonucleotide guanylate",
      "Added MSG powder",
      "Wood ash",
      "Sugar crystals"
    ],
    "optionsDe": [
      "Extrem hohe Konzentration an natürlicher freier Glutaminsäure und Guanylat",
      "Zugesetztes Glutamat",
      "Holzasche",
      "Zuckerkristalle"
    ],
    "correctIndex": 0,
    "explanationEn": "Drying concentrates glutamates exponentially, making porcini soaking water liquid gold for sauces.",
    "explanationDe": "Beim Trocknen potenziert sich die Glutaminsäure; Steinpilzwasser ist die beste Naturbouillon.",
    "qEn": "What gives Porcini mushrooms (Steinpilze / Boletus edulis) their celebrated savory umami?",
    "qDe": "Was verleiht getrockneten Steinpilzen (Boletus edulis) ihr intensives Umami-Aroma?",
    "optEn": [
      "High natural concentrations of free glutamic acid and ribonucleotide guanylate",
      "Added MSG powder",
      "Wood ash",
      "Sugar crystals"
    ],
    "optDe": [
      "Extrem hohe Konzentration an natürlicher freier Glutaminsäure und Guanylat",
      "Zugesetztes Glutamat",
      "Holzasche",
      "Zuckerkristalle"
    ],
    "correct": 0,
    "expEn": "Drying concentrates glutamates exponentially, making porcini soaking water liquid gold for sauces.",
    "expDe": "Beim Trocknen potenziert sich die Glutaminsäure; Steinpilzwasser ist die beste Naturbouillon."
  },
  {
    "id": "q_veg_06",
    "category": "vegetables",
    "questionEn": "What enzyme reaction turns garlic pungent only after crushing or slicing?",
    "questionDe": "Welche enzymatische Reaktion erzeugt die typische Knoblauchschärfe erst beim Schneiden?",
    "optionsEn": [
      "Alliin is cleaved by alliinase enzyme when plant cells rupture, generating pungent allicin",
      "Garlic absorbs air oxygen",
      "Garlic heats up from knife friction",
      "Garlic releases vinegar"
    ],
    "optionsDe": [
      "Alliin wird beim Zerstören der Zellen durch Alliinase enzymatisch in scharfes Allicin gespalten",
      "Knoblauch bindet Luftsauerstoff",
      "Messerreibung erhitzt den Knoblauch",
      "Knoblauch scheidet Essig aus"
    ],
    "correctIndex": 0,
    "explanationEn": "Intact garlic cloves are mild; cell damage triggers the defensive allicin cascade.",
    "explanationDe": "Ganze Zehen riechen kaum; erst durch Quetschen oder Schneiden entsteht stechendes Allicin.",
    "qEn": "What enzyme reaction turns garlic pungent only after crushing or slicing?",
    "qDe": "Welche enzymatische Reaktion erzeugt die typische Knoblauchschärfe erst beim Schneiden?",
    "optEn": [
      "Alliin is cleaved by alliinase enzyme when plant cells rupture, generating pungent allicin",
      "Garlic absorbs air oxygen",
      "Garlic heats up from knife friction",
      "Garlic releases vinegar"
    ],
    "optDe": [
      "Alliin wird beim Zerstören der Zellen durch Alliinase enzymatisch in scharfes Allicin gespalten",
      "Knoblauch bindet Luftsauerstoff",
      "Messerreibung erhitzt den Knoblauch",
      "Knoblauch scheidet Essig aus"
    ],
    "correct": 0,
    "expEn": "Intact garlic cloves are mild; cell damage triggers the defensive allicin cascade.",
    "expDe": "Ganze Zehen riechen kaum; erst durch Quetschen oder Schneiden entsteht stechendes Allicin."
  },
  {
    "id": "q_veg_07",
    "category": "vegetables",
    "questionEn": "Why should tomatoes never be stored below 10°C in the refrigerator?",
    "questionDe": "Warum sollten aromatische Tomaten niemals im Kühlschrank unter 10°C gelagert werden?",
    "optionsEn": [
      "Cold permanently shuts down volatile aroma-producing enzymes and breaks down cell walls into mealy texture",
      "Tomatoes turn poisonous",
      "Tomatoes freeze into ice",
      "Seeds germinate inside"
    ],
    "optionsDe": [
      "Kälte deaktiviert die Enzyme für flüchtige Aromastoffe irreversibel und macht das Fleisch mehlig",
      "Tomaten werden giftig",
      "Tomaten gefrieren sofort",
      "Kerne keimen im Fruchtfleisch"
    ],
    "correctIndex": 0,
    "explanationEn": "Chilling suppresses linalool and geranial esters; store at room temperature for maximum bouquet.",
    "explanationDe": "Kälte zerstört das Aromagerüst; Raumtemperatur bewahrt Duft und saftige Festigkeit.",
    "qEn": "Why should tomatoes never be stored below 10°C in the refrigerator?",
    "qDe": "Warum sollten aromatische Tomaten niemals im Kühlschrank unter 10°C gelagert werden?",
    "optEn": [
      "Cold permanently shuts down volatile aroma-producing enzymes and breaks down cell walls into mealy texture",
      "Tomatoes turn poisonous",
      "Tomatoes freeze into ice",
      "Seeds germinate inside"
    ],
    "optDe": [
      "Kälte deaktiviert die Enzyme für flüchtige Aromastoffe irreversibel und macht das Fleisch mehlig",
      "Tomaten werden giftig",
      "Tomaten gefrieren sofort",
      "Kerne keimen im Fruchtfleisch"
    ],
    "correct": 0,
    "expEn": "Chilling suppresses linalool and geranial esters; store at room temperature for maximum bouquet.",
    "expDe": "Kälte zerstört das Aromagerüst; Raumtemperatur bewahrt Duft und saftige Festigkeit."
  },
  {
    "id": "q_veg_08",
    "category": "vegetables",
    "questionEn": "What is Romanesco botanically and aesthetically?",
    "questionDe": "Was ist Romanesco aus botanischer Sicht?",
    "optionsEn": [
      "A variant of Brassica oleracea with natural fractal logarithmic spiral florets",
      "A cross between carrot and potato",
      "A genetically modified fern",
      "An artificially carved cabbage"
    ],
    "optionsDe": [
      "Eine Blumenkohlvariante (Brassica oleracea) mit fraktaler, mathematisch perfekter Spiralstruktur",
      "Kreuzung aus Möhre und Kohl",
      "Gentechnischer Farn",
      "Künstlich geschnitzter Kohl"
    ],
    "correctIndex": 0,
    "explanationEn": "Each bud consists of a series of smaller identical spiral cones (Fibonacci sequence).",
    "explanationDe": "Romanesco schmeckt milder und nussiger als Blumenkohl und begeistert durch seine Fraktale.",
    "qEn": "What is Romanesco botanically and aesthetically?",
    "qDe": "Was ist Romanesco aus botanischer Sicht?",
    "optEn": [
      "A variant of Brassica oleracea with natural fractal logarithmic spiral florets",
      "A cross between carrot and potato",
      "A genetically modified fern",
      "An artificially carved cabbage"
    ],
    "optDe": [
      "Eine Blumenkohlvariante (Brassica oleracea) mit fraktaler, mathematisch perfekter Spiralstruktur",
      "Kreuzung aus Möhre und Kohl",
      "Gentechnischer Farn",
      "Künstlich geschnitzter Kohl"
    ],
    "correct": 0,
    "expEn": "Each bud consists of a series of smaller identical spiral cones (Fibonacci sequence).",
    "expDe": "Romanesco schmeckt milder und nussiger als Blumenkohl und begeistert durch seine Fraktale."
  },
  {
    "id": "q_veg_09",
    "category": "vegetables",
    "questionEn": "What causes the tears when cutting raw yellow onions?",
    "questionDe": "Warum weint man beim Schneiden von Küchenzwiebeln?",
    "optionsEn": [
      "Syn-propanethial-S-oxide, a volatile sulfur gas that contacts eye moisture to form mild sulfuric acid",
      "Onion dust particles",
      "Cold vapor",
      "Acidic juice squirts"
    ],
    "optionsDe": [
      "Syn-Propanthial-S-oxid, ein flüchtiges Gas, das mit Tränenflüssigkeit zu verdünnter Schwefelsäure reagiert",
      "Zwiebelstaub",
      "Kalter Dampf",
      "Saurer Spritzsaft"
    ],
    "correctIndex": 0,
    "explanationEn": "Lachrymatory factor synthase releases volatile sulfenic acids that irritate corneal nerves.",
    "explanationDe": "Das freigesetzte Gas reizt die Nerven der Hornhaut, die reflexartig Tränenfluss anregen.",
    "qEn": "What causes the tears when cutting raw yellow onions?",
    "qDe": "Warum weint man beim Schneiden von Küchenzwiebeln?",
    "optEn": [
      "Syn-propanethial-S-oxide, a volatile sulfur gas that contacts eye moisture to form mild sulfuric acid",
      "Onion dust particles",
      "Cold vapor",
      "Acidic juice squirts"
    ],
    "optDe": [
      "Syn-Propanthial-S-oxid, ein flüchtiges Gas, das mit Tränenflüssigkeit zu verdünnter Schwefelsäure reagiert",
      "Zwiebelstaub",
      "Kalter Dampf",
      "Saurer Spritzsaft"
    ],
    "correct": 0,
    "expEn": "Lachrymatory factor synthase releases volatile sulfenic acids that irritate corneal nerves.",
    "expDe": "Das freigesetzte Gas reizt die Nerven der Hornhaut, die reflexartig Tränenfluss anregen."
  },
  {
    "id": "q_veg_10",
    "category": "vegetables",
    "questionEn": "Why is blanching green vegetables in boiling salted water and ice-shocking essential?",
    "questionDe": "Warum ist Blanchieren in Salzwasser mit anschließendem Eiswasser-Schockieren so wichtig?",
    "optionsEn": [
      "Halts heat quickly, preserving bright chlorophyll and retaining crisp cellular crunch",
      "Kills root hairs",
      "Removes all vitamins",
      "Melts the skin"
    ],
    "optionsDe": [
      "Stoppt den Garprozess sofort, fixiert leuchtendes Blattchlorophyll und bewahrt Bissfestigkeit",
      "Tötet Wurzeln",
      "Schwemmt Vitamine aus",
      "Löst die Schale auf"
    ],
    "correctIndex": 0,
    "explanationEn": "Heat denatures chlorophyllase enzymes; ice water prevents residual cooking from turning greens dull brown.",
    "explanationDe": "Der Kälteschock verhindert das Nachgaren und bewahrt die strahlend grüne Farbe von Bohnen und Erbsen.",
    "qEn": "Why is blanching green vegetables in boiling salted water and ice-shocking essential?",
    "qDe": "Warum ist Blanchieren in Salzwasser mit anschließendem Eiswasser-Schockieren so wichtig?",
    "optEn": [
      "Halts heat quickly, preserving bright chlorophyll and retaining crisp cellular crunch",
      "Kills root hairs",
      "Removes all vitamins",
      "Melts the skin"
    ],
    "optDe": [
      "Stoppt den Garprozess sofort, fixiert leuchtendes Blattchlorophyll und bewahrt Bissfestigkeit",
      "Tötet Wurzeln",
      "Schwemmt Vitamine aus",
      "Löst die Schale auf"
    ],
    "correct": 0,
    "expEn": "Heat denatures chlorophyllase enzymes; ice water prevents residual cooking from turning greens dull brown.",
    "expDe": "Der Kälteschock verhindert das Nachgaren und bewahrt die strahlend grüne Farbe von Bohnen und Erbsen."
  },
  {
    "id": "q_veg_11",
    "category": "vegetables",
    "questionEn": "What is Belgian Endive (Chicorée) forced to grow in dark cellars for?",
    "questionDe": "Warum wird Chicorée in lichtdichten Dunkelräumen gezogen?",
    "optionsEn": [
      "Darkness prevents chlorophyll formation, keeping leaves pale yellow and mildly bitter rather than unpalatably harsh",
      "To prevent leaf insects",
      "To grow faster than weeds",
      "To stay warm"
    ],
    "optionsDe": [
      "Lichtentzug verhindert die Bildung von Chlorophyll und extremer Bitterkeit (Lactucin)",
      "Schutz vor Insekten",
      "Wächst schneller",
      "Bleibt wärmer"
    ],
    "correctIndex": 0,
    "explanationEn": "Light exposure produces intense bitter sesquiterpene lactones and dark green coloring.",
    "explanationDe": "Unter Licht bildet Chicorée Bitterstoffe aus; im Dunkeln bleibt er mild und knackig.",
    "qEn": "What is Belgian Endive (Chicorée) forced to grow in dark cellars for?",
    "qDe": "Warum wird Chicorée in lichtdichten Dunkelräumen gezogen?",
    "optEn": [
      "Darkness prevents chlorophyll formation, keeping leaves pale yellow and mildly bitter rather than unpalatably harsh",
      "To prevent leaf insects",
      "To grow faster than weeds",
      "To stay warm"
    ],
    "optDe": [
      "Lichtentzug verhindert die Bildung von Chlorophyll und extremer Bitterkeit (Lactucin)",
      "Schutz vor Insekten",
      "Wächst schneller",
      "Bleibt wärmer"
    ],
    "correct": 0,
    "expEn": "Light exposure produces intense bitter sesquiterpene lactones and dark green coloring.",
    "expDe": "Unter Licht bildet Chicorée Bitterstoffe aus; im Dunkeln bleibt er mild und knackig."
  },
  {
    "id": "q_veg_12",
    "category": "vegetables",
    "questionEn": "What is the defining aroma compound in truffles that trained pigs and dogs detect?",
    "questionDe": "Welcher Duftstoff im Trüffel wird von Trüffelschweinen und Hunden gewittert?",
    "optionsEn": [
      "Dimethyl sulfide and androstenol (sex pheromone mimic)",
      "Capsaicin",
      "Caffeine",
      "Vanillin"
    ],
    "optionsDe": [
      "Dimethylsulfid und Androstenol (Pheromon-Äquivalent)",
      "Capsaicin",
      "Koffein",
      "Vanillin"
    ],
    "correctIndex": 0,
    "explanationEn": "Androstenol is chemically identical to male boar sex pheromone, driving wild pigs wild.",
    "explanationDe": "Dieser Duftstoff ähnelt dem Pheromon des Ebers, weshalb Säue instinktiv danach graben.",
    "qEn": "What is the defining aroma compound in truffles that trained pigs and dogs detect?",
    "qDe": "Welcher Duftstoff im Trüffel wird von Trüffelschweinen und Hunden gewittert?",
    "optEn": [
      "Dimethyl sulfide and androstenol (sex pheromone mimic)",
      "Capsaicin",
      "Caffeine",
      "Vanillin"
    ],
    "optDe": [
      "Dimethylsulfid und Androstenol (Pheromon-Äquivalent)",
      "Capsaicin",
      "Koffein",
      "Vanillin"
    ],
    "correct": 0,
    "expEn": "Androstenol is chemically identical to male boar sex pheromone, driving wild pigs wild.",
    "expDe": "Dieser Duftstoff ähnelt dem Pheromon des Ebers, weshalb Säue instinktiv danach graben."
  },
  {
    "id": "q_veg_13",
    "category": "vegetables",
    "questionEn": "What culinary advantage do Charlotte or Nicola waxy potatoes (festkochend) offer?",
    "questionDe": "Welchen Vorteil bieten festkochende Kartoffelsorten (z.B. Sieglinde, Nicola) in der Küche?",
    "optionsEn": [
      "Higher moisture and lower amylose starch keep slices firm and uncrumbled in potato salads or gratins",
      "Cooks in 2 minutes",
      "Turns instantly into puree",
      "Contains zero calories"
    ],
    "optionsDe": [
      "Hoher Feuchtigkeits- und geringer Stärkegehalt halten Scheiben beim Kochen fest in Form",
      "Gart in 2 Minuten",
      "Zerfällt sofort zu Brei",
      "Hat keine Kalorien"
    ],
    "correctIndex": 0,
    "explanationEn": "Waxy potatoes hold their geometry cleanly when tossed with warm vinaigrette or baked in dauphinoise.",
    "explanationDe": "Festkochende Sorten zerfallen nicht und nehmen Dressings für Kartoffelsalat perfekt auf.",
    "qEn": "What culinary advantage do Charlotte or Nicola waxy potatoes (festkochend) offer?",
    "qDe": "Welchen Vorteil bieten festkochende Kartoffelsorten (z.B. Sieglinde, Nicola) in der Küche?",
    "optEn": [
      "Higher moisture and lower amylose starch keep slices firm and uncrumbled in potato salads or gratins",
      "Cooks in 2 minutes",
      "Turns instantly into puree",
      "Contains zero calories"
    ],
    "optDe": [
      "Hoher Feuchtigkeits- und geringer Stärkegehalt halten Scheiben beim Kochen fest in Form",
      "Gart in 2 Minuten",
      "Zerfällt sofort zu Brei",
      "Hat keine Kalorien"
    ],
    "correct": 0,
    "expEn": "Waxy potatoes hold their geometry cleanly when tossed with warm vinaigrette or baked in dauphinoise.",
    "expDe": "Festkochende Sorten zerfallen nicht und nehmen Dressings für Kartoffelsalat perfekt auf."
  },
  {
    "id": "q_veg_14",
    "category": "vegetables",
    "questionEn": "Why is raw aubergine (eggplant) salted before frying?",
    "questionDe": "Warum salzt man geschnittene Auberginen traditionell vor dem Braten?",
    "optionsEn": [
      "Draws out bitter juices through osmosis and collapses spongy air pockets so it absorbs less frying oil",
      "To preserve for months",
      "To cook it raw",
      "To turn it yellow"
    ],
    "optionsDe": [
      "Zieht bitteren Saft osmotisch heraus und verdichtet das Schwammgewebe, sodass weniger Fett aufgesaugt wird",
      "Konserviert monatelang",
      "Macht sie roh essbar",
      "Färbt sie gelb"
    ],
    "correctIndex": 0,
    "explanationEn": "Collapsing intercellular air spaces prevents the vegetable from behaving like an oil sponge.",
    "explanationDe": "Salzen entzieht Wasser und verdichtet die Poren; die Aubergine brät knusprig statt fettig.",
    "qEn": "Why is raw aubergine (eggplant) salted before frying?",
    "qDe": "Warum salzt man geschnittene Auberginen traditionell vor dem Braten?",
    "optEn": [
      "Draws out bitter juices through osmosis and collapses spongy air pockets so it absorbs less frying oil",
      "To preserve for months",
      "To cook it raw",
      "To turn it yellow"
    ],
    "optDe": [
      "Zieht bitteren Saft osmotisch heraus und verdichtet das Schwammgewebe, sodass weniger Fett aufgesaugt wird",
      "Konserviert monatelang",
      "Macht sie roh essbar",
      "Färbt sie gelb"
    ],
    "correct": 0,
    "expEn": "Collapsing intercellular air spaces prevents the vegetable from behaving like an oil sponge.",
    "expDe": "Salzen entzieht Wasser und verdichtet die Poren; die Aubergine brät knusprig statt fettig."
  },
  {
    "id": "q_veg_15",
    "category": "vegetables",
    "questionEn": "What makes Morel mushrooms (Morcheln) toxic if eaten raw?",
    "questionDe": "Warum sind Speisemorcheln roh giftig und müssen gründlich erhitzt oder getrocknet werden?",
    "optionsEn": [
      "Contain hydrazine toxins (like gyromitrin) and hemolysins that destroy red blood cells, destroyed only by heat (>70°C)",
      "Contain nerve venom",
      "Contain cyanide",
      "Contain heavy mercury"
    ],
    "optionsDe": [
      "Enthalten hitzelabile Gifte (Hämolysine), die rote Blutkörperchen zersetzen und erst ab 70°C zerfallen",
      "Enthalten Nervengift",
      "Enthalten Blausäure",
      "Enthalten Quecksilber"
    ],
    "correctIndex": 0,
    "explanationEn": "Always cook morels for at least 15-20 minutes; drying and heat neutralize hemolysin toxins completely.",
    "explanationDe": "Morcheln niemals roh verzehren; erst durch ausreichendes Garen oder Trocknen werden sie bekömmlich.",
    "qEn": "What makes Morel mushrooms (Morcheln) toxic if eaten raw?",
    "qDe": "Warum sind Speisemorcheln roh giftig und müssen gründlich erhitzt oder getrocknet werden?",
    "optEn": [
      "Contain hydrazine toxins (like gyromitrin) and hemolysins that destroy red blood cells, destroyed only by heat (>70°C)",
      "Contain nerve venom",
      "Contain cyanide",
      "Contain heavy mercury"
    ],
    "optDe": [
      "Enthalten hitzelabile Gifte (Hämolysine), die rote Blutkörperchen zersetzen und erst ab 70°C zerfallen",
      "Enthalten Nervengift",
      "Enthalten Blausäure",
      "Enthalten Quecksilber"
    ],
    "correct": 0,
    "expEn": "Always cook morels for at least 15-20 minutes; drying and heat neutralize hemolysin toxins completely.",
    "expDe": "Morcheln niemals roh verzehren; erst durch ausreichendes Garen oder Trocknen werden sie bekömmlich."
  },
  {
    "id": "q_veg_16",
    "category": "vegetables",
    "questionEn": "What is Mirepoix in classical French stock making?",
    "questionDe": "Was ist ein klassisches französisches Mirepoix?",
    "optionsEn": [
      "A diced aromatic vegetable base of 2 parts onion, 1 part carrot, and 1 part celery",
      "Garlic, ginger, and chili",
      "Mushrooms, tomatoes, and leek",
      "Potatoes and peas"
    ],
    "optionsDe": [
      "Röstgemüse-Basis aus 2 Teilen Zwiebeln, 1 Teil Möhren und 1 Teil Knollensellerie",
      "Knoblauch, Ingwer und Chili",
      "Pilze, Tomaten und Lauch",
      "Kartoffeln und Erbsen"
    ],
    "correctIndex": 0,
    "explanationEn": "Gently sweated in fat, Mirepoix provides the foundational savory backbone for stocks and braises.",
    "explanationDe": "Mirepoix bildet das aromatische Fundament für Fonds, Schmorgerichte und Saucen.",
    "qEn": "What is Mirepoix in classical French stock making?",
    "qDe": "Was ist ein klassisches französisches Mirepoix?",
    "optEn": [
      "A diced aromatic vegetable base of 2 parts onion, 1 part carrot, and 1 part celery",
      "Garlic, ginger, and chili",
      "Mushrooms, tomatoes, and leek",
      "Potatoes and peas"
    ],
    "optDe": [
      "Röstgemüse-Basis aus 2 Teilen Zwiebeln, 1 Teil Möhren und 1 Teil Knollensellerie",
      "Knoblauch, Ingwer und Chili",
      "Pilze, Tomaten und Lauch",
      "Kartoffeln und Erbsen"
    ],
    "correct": 0,
    "expEn": "Gently sweated in fat, Mirepoix provides the foundational savory backbone for stocks and braises.",
    "expDe": "Mirepoix bildet das aromatische Fundament für Fonds, Schmorgerichte und Saucen."
  },
  {
    "id": "q_veg_17",
    "category": "vegetables",
    "questionEn": "Why are Jerusalem Artichokes (Topinambur) sweet yet cause digestive gas in some people?",
    "questionDe": "Warum schmecken Topinambur-Knollen süßlich, können aber Blähungen verursachen?",
    "optionsEn": [
      "Rich in inulin, a prebiotic fructose polymer indigestible by human enzymes but fermented by gut bacteria",
      "Contain table sugar",
      "Contain sulfur crystals",
      "Contain alcohol"
    ],
    "optionsDe": [
      "Enthalten Inulin, ein Fruktose-Polysaccharid, das erst im Dickdarm von Bakterien vergoren wird",
      "Enthalten Haushaltszucker",
      "Bestehen aus Schwefel",
      "Enthalten Gärungsalkohol"
    ],
    "correctIndex": 0,
    "explanationEn": "Inulin is non-glycemic and diabetic-friendly, but intestinal fermentation produces carbon dioxide gas.",
    "explanationDe": "Inulin lässt den Blutzucker nicht ansteigen, fordert aber die Darmflora durch Fermentation heraus.",
    "qEn": "Why are Jerusalem Artichokes (Topinambur) sweet yet cause digestive gas in some people?",
    "qDe": "Warum schmecken Topinambur-Knollen süßlich, können aber Blähungen verursachen?",
    "optEn": [
      "Rich in inulin, a prebiotic fructose polymer indigestible by human enzymes but fermented by gut bacteria",
      "Contain table sugar",
      "Contain sulfur crystals",
      "Contain alcohol"
    ],
    "optDe": [
      "Enthalten Inulin, ein Fruktose-Polysaccharid, das erst im Dickdarm von Bakterien vergoren wird",
      "Enthalten Haushaltszucker",
      "Bestehen aus Schwefel",
      "Enthalten Gärungsalkohol"
    ],
    "correct": 0,
    "expEn": "Inulin is non-glycemic and diabetic-friendly, but intestinal fermentation produces carbon dioxide gas.",
    "expDe": "Inulin lässt den Blutzucker nicht ansteigen, fordert aber die Darmflora durch Fermentation heraus."
  },
  {
    "id": "q_veg_18",
    "category": "vegetables",
    "questionEn": "What gives red cabbage (Rotkohl) its changing color from blue to ruby red?",
    "questionDe": "Was steuert die Farbe von Rotkohl zwischen violettblau und rubinrot?",
    "optionsEn": [
      "Anthocyanin pigments act as natural pH indicators: turning red with acid (vinegar/apple) and blue in alkaline water",
      "Iron content in pot",
      "Amount of salt",
      "Cooking time in oven"
    ],
    "optionsDe": [
      "Anthocyane wirken als natürlicher pH-Indikator: sauer (Essig/Äpfel) = rubinrot; basisch = blauviolett",
      "Eisengehalt im Kochtopf",
      "Salzmenge",
      "Garzeit im Ofen"
    ],
    "correctIndex": 0,
    "explanationEn": "Adding vinegar or tart apples shifts anthocyanins into their protonated vibrant scarlet-red state.",
    "explanationDe": "Säurezugabe zaubert das leuchtende Rot; ohne Säure kocht der Kohl stumpf blauviolett.",
    "qEn": "What gives red cabbage (Rotkohl) its changing color from blue to ruby red?",
    "qDe": "Was steuert die Farbe von Rotkohl zwischen violettblau und rubinrot?",
    "optEn": [
      "Anthocyanin pigments act as natural pH indicators: turning red with acid (vinegar/apple) and blue in alkaline water",
      "Iron content in pot",
      "Amount of salt",
      "Cooking time in oven"
    ],
    "optDe": [
      "Anthocyane wirken als natürlicher pH-Indikator: sauer (Essig/Äpfel) = rubinrot; basisch = blauviolett",
      "Eisengehalt im Kochtopf",
      "Salzmenge",
      "Garzeit im Ofen"
    ],
    "correct": 0,
    "expEn": "Adding vinegar or tart apples shifts anthocyanins into their protonated vibrant scarlet-red state.",
    "expDe": "Säurezugabe zaubert das leuchtende Rot; ohne Säure kocht der Kohl stumpf blauviolett."
  },
  {
    "id": "q_fru_01",
    "category": "fruits",
    "questionEn": "What causes a green banana or avocado to ripen rapidly in a brown paper bag with an apple?",
    "questionDe": "Warum reifen Avocados oder Bananen in einer Papiertüte zusammen mit einem Apfel schneller nach?",
    "optionsEn": [
      "Apples release ethylene gas (C2H4), a natural plant hormone that triggers ripening enzymes",
      "Paper bags heat up to 40°C",
      "Apples absorb all moisture",
      "Apples release carbon monoxide"
    ],
    "optionsDe": [
      "Äpfel strömen Ethylen aus, ein natürliches Phytohormon, das Fruchtreife-Enzyme stimuliert",
      "Papiertüten heizen sich auf 40°C auf",
      "Äpfel entziehen Feuchtigkeit",
      "Äpfel strömen Kohlenmonoxid aus"
    ],
    "correctIndex": 0,
    "explanationEn": "Climacteric fruits respond to gaseous ethylene, converting starches into sweet sugars rapidly.",
    "explanationDe": "Klimakterische Früchte reagieren auf Ethylengas und bauen Stärke in aromatischen Fruchtzucker um.",
    "qEn": "What causes a green banana or avocado to ripen rapidly in a brown paper bag with an apple?",
    "qDe": "Warum reifen Avocados oder Bananen in einer Papiertüte zusammen mit einem Apfel schneller nach?",
    "optEn": [
      "Apples release ethylene gas (C2H4), a natural plant hormone that triggers ripening enzymes",
      "Paper bags heat up to 40°C",
      "Apples absorb all moisture",
      "Apples release carbon monoxide"
    ],
    "optDe": [
      "Äpfel strömen Ethylen aus, ein natürliches Phytohormon, das Fruchtreife-Enzyme stimuliert",
      "Papiertüten heizen sich auf 40°C auf",
      "Äpfel entziehen Feuchtigkeit",
      "Äpfel strömen Kohlenmonoxid aus"
    ],
    "correct": 0,
    "expEn": "Climacteric fruits respond to gaseous ethylene, converting starches into sweet sugars rapidly.",
    "expDe": "Klimakterische Früchte reagieren auf Ethylengas und bauen Stärke in aromatischen Fruchtzucker um."
  },
  {
    "id": "q_fru_02",
    "category": "fruits",
    "questionEn": "Why does freshly squeezed lemon juice prevent sliced apples and pears from browning?",
    "questionDe": "Warum verhindert Zitronensaft das Braunwerden von geschnittenen Äpfeln?",
    "optionsEn": [
      "Ascorbic acid (Vitamin C) acts as an antioxidant and citric acid lowers pH, inactivating polyphenol oxidase",
      "Lemon juice freezes fruit cells",
      "Sugar in lemon covers fruit",
      "Lemon kills yeast"
    ],
    "optionsDe": [
      "Ascorbinsäure (Vitamin C) wirkt als Antioxidans und der niedrige pH hemmt Polyphenoloxidase",
      "Zitronensaft gefriert Fruchtzellen",
      "Zucker bildet eine Schutzschicht",
      "Zitrone tötet Hefen ab"
    ],
    "correctIndex": 0,
    "explanationEn": "Low pH below 4 and antioxidant vitamin C block enzymatic oxidation of phenolic compounds into brown melanins.",
    "explanationDe": "Zitronensäure und Vitamin C unterbinden die enzymatische Bräunung des Fruchtfleisches an der Luft.",
    "qEn": "Why does freshly squeezed lemon juice prevent sliced apples and pears from browning?",
    "qDe": "Warum verhindert Zitronensaft das Braunwerden von geschnittenen Äpfeln?",
    "optEn": [
      "Ascorbic acid (Vitamin C) acts as an antioxidant and citric acid lowers pH, inactivating polyphenol oxidase",
      "Lemon juice freezes fruit cells",
      "Sugar in lemon covers fruit",
      "Lemon kills yeast"
    ],
    "optDe": [
      "Ascorbinsäure (Vitamin C) wirkt als Antioxidans und der niedrige pH hemmt Polyphenoloxidase",
      "Zitronensaft gefriert Fruchtzellen",
      "Zucker bildet eine Schutzschicht",
      "Zitrone tötet Hefen ab"
    ],
    "correct": 0,
    "expEn": "Low pH below 4 and antioxidant vitamin C block enzymatic oxidation of phenolic compounds into brown melanins.",
    "expDe": "Zitronensäure und Vitamin C unterbinden die enzymatische Bräunung des Fruchtfleisches an der Luft."
  },
  {
    "id": "q_fru_03",
    "category": "fruits",
    "questionEn": "What enzyme in raw pineapple and kiwi prevents gelatin from setting?",
    "questionDe": "Welches Enzym in frischer Ananas und Kiwi verhindert das Gelieren von Gelatinespeisen?",
    "optionsEn": [
      "Bromelain (in pineapple) and actinidin (in kiwi) proteases, which digest gelatin collagen into liquid peptides",
      "Amylase",
      "Lipase",
      "Lactase"
    ],
    "optionsDe": [
      "Proteasen (Bromelain in Ananas, Actinidin in Kiwi) spalten die Gelatine-Kollagene enzymatisch",
      "Amylase",
      "Lipase",
      "Laktase"
    ],
    "correctIndex": 0,
    "explanationEn": "Raw bromelain chops collagen protein chains; brief boiling denatures the enzyme, allowing gelatin to set.",
    "explanationDe": "Frische Ananas zersetzt Gelatine; erst kurzes Einkochen inaktiviert das eiweißspaltende Enzym.",
    "qEn": "What enzyme in raw pineapple and kiwi prevents gelatin from setting?",
    "qDe": "Welches Enzym in frischer Ananas und Kiwi verhindert das Gelieren von Gelatinespeisen?",
    "optEn": [
      "Bromelain (in pineapple) and actinidin (in kiwi) proteases, which digest gelatin collagen into liquid peptides",
      "Amylase",
      "Lipase",
      "Lactase"
    ],
    "optDe": [
      "Proteasen (Bromelain in Ananas, Actinidin in Kiwi) spalten die Gelatine-Kollagene enzymatisch",
      "Amylase",
      "Lipase",
      "Laktase"
    ],
    "correct": 0,
    "expEn": "Raw bromelain chops collagen protein chains; brief boiling denatures the enzyme, allowing gelatin to set.",
    "expDe": "Frische Ananas zersetzt Gelatine; erst kurzes Einkochen inaktiviert das eiweißspaltende Enzym."
  },
  {
    "id": "q_fru_04",
    "category": "fruits",
    "questionEn": "What defines an authentic Sicilian Blood Orange (Arancia Rossa di Sicilia IGP)?",
    "questionDe": "Was zeichnet sizilianische Blutorangen (Arancia Rossa IGP) aus?",
    "optionsEn": [
      "Volcanic Etna terroir and extreme diurnal temperature swings trigger deep anthocyanin red pigmentation",
      "Injected with pomegranate juice",
      "Grown in dark greenhouses",
      "Dyed with beet syrup"
    ],
    "optionsDe": [
      "Temperaturwechsel am Ätna stimulieren die Synthese von rubinroten Anthocyan-Antioxidantien",
      "Mit Granatapfelsaft geimpft",
      "Im Dunkeln gezogen",
      "Mit Rote-Bete-Sirup gefärbt"
    ],
    "correctIndex": 0,
    "explanationEn": "Cold night temperatures (under 5°C) contrast with warm Sicilian days, synthesizing antioxidant anthocyanins.",
    "explanationDe": "Kalte Nächte am Fuße des Ätna aktivieren die Bildung der rubinroten, beerenartigen Pflanzenfarbstoffe.",
    "qEn": "What defines an authentic Sicilian Blood Orange (Arancia Rossa di Sicilia IGP)?",
    "qDe": "Was zeichnet sizilianische Blutorangen (Arancia Rossa IGP) aus?",
    "optEn": [
      "Volcanic Etna terroir and extreme diurnal temperature swings trigger deep anthocyanin red pigmentation",
      "Injected with pomegranate juice",
      "Grown in dark greenhouses",
      "Dyed with beet syrup"
    ],
    "optDe": [
      "Temperaturwechsel am Ätna stimulieren die Synthese von rubinroten Anthocyan-Antioxidantien",
      "Mit Granatapfelsaft geimpft",
      "Im Dunkeln gezogen",
      "Mit Rote-Bete-Sirup gefärbt"
    ],
    "correct": 0,
    "expEn": "Cold night temperatures (under 5°C) contrast with warm Sicilian days, synthesizing antioxidant anthocyanins.",
    "expDe": "Kalte Nächte am Fuße des Ätna aktivieren die Bildung der rubinroten, beerenartigen Pflanzenfarbstoffe."
  },
  {
    "id": "q_fru_05",
    "category": "fruits",
    "questionEn": "What is the difference between a Meyer Lemon and a standard Eureka lemon?",
    "questionDe": "Was unterscheidet eine Meyer-Zitrone von einer herkömmlichen Zitrone?",
    "optionsEn": [
      "Meyer lemon is a natural hybrid of lemon and sweet orange/mandarin, featuring thin skin, lower acid, and floral sweetness",
      "Meyer lemon has green pulp",
      "Meyer lemon has zero juice",
      "Meyer lemon is spicy like pepper"
    ],
    "optionsDe": [
      "Meyer-Zitrone ist eine Naturkreuzung aus Zitrone und Mandarine/Orange mit dünner Schale und floraler Milde",
      "Hat grünes Fruchtfleisch",
      "Besitzt keinen Saft",
      "Ist scharf wie Pfeffer"
    ],
    "correctIndex": 0,
    "explanationEn": "Lower acidity and fragrant bergamot-like peel make Meyer lemons beloved in fine desserts.",
    "explanationDe": "Die feine Süße und dünne Schale machen sie zum Liebling der gehobenen Patisserie.",
    "qEn": "What is the difference between a Meyer Lemon and a standard Eureka lemon?",
    "qDe": "Was unterscheidet eine Meyer-Zitrone von einer herkömmlichen Zitrone?",
    "optEn": [
      "Meyer lemon is a natural hybrid of lemon and sweet orange/mandarin, featuring thin skin, lower acid, and floral sweetness",
      "Meyer lemon has green pulp",
      "Meyer lemon has zero juice",
      "Meyer lemon is spicy like pepper"
    ],
    "optDe": [
      "Meyer-Zitrone ist eine Naturkreuzung aus Zitrone und Mandarine/Orange mit dünner Schale und floraler Milde",
      "Hat grünes Fruchtfleisch",
      "Besitzt keinen Saft",
      "Ist scharf wie Pfeffer"
    ],
    "correct": 0,
    "expEn": "Lower acidity and fragrant bergamot-like peel make Meyer lemons beloved in fine desserts.",
    "expDe": "Die feine Süße und dünne Schale machen sie zum Liebling der gehobenen Patisserie."
  },
  {
    "id": "q_fru_06",
    "category": "fruits",
    "questionEn": "What gives fresh raspberries and strawberries their mouthwatering aroma?",
    "questionDe": "Welcher Aromastoff prägt das intensive Bouquet von Wald-Himbeeren?",
    "optionsEn": [
      "Raspberry ketone (4-(4-hydroxyphenyl)butan-2-one) and volatile esters",
      "Pure vanillin",
      "Acetic acid",
      "Menthol"
    ],
    "optionsDe": [
      "Himbeerketon (4-(4-Hydroxyphenyl)butan-2-on) und fruchtige Ester",
      "Reines Vanillin",
      "Essigsäure",
      "Menthol"
    ],
    "correctIndex": 0,
    "explanationEn": "Raspberry ketone delivers signature ripe berry perfume detectable in parts-per-billion.",
    "explanationDe": "Himbeerketon und Fruchtester sorgen für das berauschende, feine Sommerbeeren-Aroma.",
    "qEn": "What gives fresh raspberries and strawberries their mouthwatering aroma?",
    "qDe": "Welcher Aromastoff prägt das intensive Bouquet von Wald-Himbeeren?",
    "optEn": [
      "Raspberry ketone (4-(4-hydroxyphenyl)butan-2-one) and volatile esters",
      "Pure vanillin",
      "Acetic acid",
      "Menthol"
    ],
    "optDe": [
      "Himbeerketon (4-(4-Hydroxyphenyl)butan-2-on) und fruchtige Ester",
      "Reines Vanillin",
      "Essigsäure",
      "Menthol"
    ],
    "correct": 0,
    "expEn": "Raspberry ketone delivers signature ripe berry perfume detectable in parts-per-billion.",
    "expDe": "Himbeerketon und Fruchtester sorgen für das berauschende, feine Sommerbeeren-Aroma."
  },
  {
    "id": "q_fru_07",
    "category": "fruits",
    "questionEn": "Why are Quinces (Quitten) almost never eaten raw in European gastronomy?",
    "questionDe": "Warum werden Quitten in der europäischen Küche fast nie roh verzehrt?",
    "optionsEn": [
      "Rock-hard woody stone cells, high astringent tannins, and raw bitterness soften into fragrant pink jelly only when cooked",
      "Raw quinces are toxic",
      "Skin is covered in poison",
      "Raw quinces taste salty"
    ],
    "optionsDe": [
      "Steinzellen und herbe Gerbstoffe werden erst durch Kochen weich, rosarot und betörend duftend",
      "Rohe Quitten sind giftig",
      "Die Schale ist giftig",
      "Rohe Quitten sind salzig"
    ],
    "correctIndex": 0,
    "explanationEn": "Gentle poaching breaks down insoluble pectins and converts leucoanthocyanins into ruby-colored jewel jelly.",
    "explanationDe": "Langes Kochen spaltet die harten Pektine und färbt das Fruchtfleisch appetitlich rubinrosa.",
    "qEn": "Why are Quinces (Quitten) almost never eaten raw in European gastronomy?",
    "qDe": "Warum werden Quitten in der europäischen Küche fast nie roh verzehrt?",
    "optEn": [
      "Rock-hard woody stone cells, high astringent tannins, and raw bitterness soften into fragrant pink jelly only when cooked",
      "Raw quinces are toxic",
      "Skin is covered in poison",
      "Raw quinces taste salty"
    ],
    "optDe": [
      "Steinzellen und herbe Gerbstoffe werden erst durch Kochen weich, rosarot und betörend duftend",
      "Rohe Quitten sind giftig",
      "Die Schale ist giftig",
      "Rohe Quitten sind salzig"
    ],
    "correct": 0,
    "expEn": "Gentle poaching breaks down insoluble pectins and converts leucoanthocyanins into ruby-colored jewel jelly.",
    "expDe": "Langes Kochen spaltet die harten Pektine und färbt das Fruchtfleisch appetitlich rubinrosa."
  },
  {
    "id": "q_fru_08",
    "category": "fruits",
    "questionEn": "What is Pectin and where is it concentrated in fruits like apples and citrus?",
    "questionDe": "Was ist Pektin und wo ist es bei Zitrusfrüchten und Äpfeln am stärksten konzentriert?",
    "optionsEn": [
      "A structural plant polysaccharide concentrated in peels, cores, and white pith (albedo), forming fruit jam gels with sugar and acid",
      "A protein found in seeds",
      "Fruit fat",
      "A type of yeast"
    ],
    "optionsDe": [
      "Ein pflanzliches Polysaccharid in Schalen, Kerngehäusen und weißem Albedo, das Gelees festigt",
      "Ein Eiweiß in Kernen",
      "Fruchteigenes Fett",
      "Ein Hefepilz"
    ],
    "correctIndex": 0,
    "explanationEn": "Pectin forms a three-dimensional gel network in the presence of 60% sugar and acid (pH ~3.2).",
    "explanationDe": "Pektin geliert Marmeladen; es sitzt vor allem im weißen Schalengewebe und Kernhaus.",
    "qEn": "What is Pectin and where is it concentrated in fruits like apples and citrus?",
    "qDe": "Was ist Pektin und wo ist es bei Zitrusfrüchten und Äpfeln am stärksten konzentriert?",
    "optEn": [
      "A structural plant polysaccharide concentrated in peels, cores, and white pith (albedo), forming fruit jam gels with sugar and acid",
      "A protein found in seeds",
      "Fruit fat",
      "A type of yeast"
    ],
    "optDe": [
      "Ein pflanzliches Polysaccharid in Schalen, Kerngehäusen und weißem Albedo, das Gelees festigt",
      "Ein Eiweiß in Kernen",
      "Fruchteigenes Fett",
      "Ein Hefepilz"
    ],
    "correct": 0,
    "expEn": "Pectin forms a three-dimensional gel network in the presence of 60% sugar and acid (pH ~3.2).",
    "expDe": "Pektin geliert Marmeladen; es sitzt vor allem im weißen Schalengewebe und Kernhaus."
  },
  {
    "id": "q_fru_09",
    "category": "fruits",
    "questionEn": "What gives Japanese Yuzu citrus fruit its culinary fame?",
    "questionDe": "Was macht die japanische Yuzu-Zitrusfrucht in der Spitzengastronomie so begehrt?",
    "optionsEn": [
      "Complex aroma blending green mandarin, grapefruit, and floral lime with tart high-acid juice",
      "It is sweet like ripe mango",
      "Contains zero seeds",
      "Has purple skin"
    ],
    "optionsDe": [
      "Komplexes Bouquet aus Mandarine, Grapefruit und Bergamotte mit intensiv-aromatischer Säure",
      "Schmeckt süß wie Mango",
      "Hat keine Kerne",
      "Ist violett"
    ],
    "correctIndex": 0,
    "explanationEn": "Yuzu rind contains rare terpene oils that elevate sashimi dressings, ponzu, and sorbets.",
    "explanationDe": "Yuzu besitzt ätherische Öle, die selbst bei sparsamster Dosierung betörend frisch duften.",
    "qEn": "What gives Japanese Yuzu citrus fruit its culinary fame?",
    "qDe": "Was macht die japanische Yuzu-Zitrusfrucht in der Spitzengastronomie so begehrt?",
    "optEn": [
      "Complex aroma blending green mandarin, grapefruit, and floral lime with tart high-acid juice",
      "It is sweet like ripe mango",
      "Contains zero seeds",
      "Has purple skin"
    ],
    "optDe": [
      "Komplexes Bouquet aus Mandarine, Grapefruit und Bergamotte mit intensiv-aromatischer Säure",
      "Schmeckt süß wie Mango",
      "Hat keine Kerne",
      "Ist violett"
    ],
    "correct": 0,
    "expEn": "Yuzu rind contains rare terpene oils that elevate sashimi dressings, ponzu, and sorbets.",
    "expDe": "Yuzu besitzt ätherische Öle, die selbst bei sparsamster Dosierung betörend frisch duften."
  },
  {
    "id": "q_fru_10",
    "category": "fruits",
    "questionEn": "What defines authentic French Marrons Glacés?",
    "questionDe": "Was sind echte französische Marrons Glacés?",
    "optionsEn": [
      "Candied sweet chestnuts slowly poached over days in vanilla sugar syrup and glazed",
      "Roasted chestnuts in butter",
      "Chestnut ice cream",
      "Chestnut puree with salt"
    ],
    "optionsDe": [
      "Über Tage hinweg schonend mit Bourbon-Vanillesirup kandierte und glasierte Edelkastanien",
      "In Butter geröstete Maroni",
      "Kastanieneis",
      "Salziges Kastanienmus"
    ],
    "correctIndex": 0,
    "explanationEn": "Days of osmotic syrup bathing replace internal water with sugar crystal velvet.",
    "explanationDe": "Das tagelange, behutsame Kandieren verleiht den Edelkastanien ihre zart schmelzende Textur.",
    "qEn": "What defines authentic French Marrons Glacés?",
    "qDe": "Was sind echte französische Marrons Glacés?",
    "optEn": [
      "Candied sweet chestnuts slowly poached over days in vanilla sugar syrup and glazed",
      "Roasted chestnuts in butter",
      "Chestnut ice cream",
      "Chestnut puree with salt"
    ],
    "optDe": [
      "Über Tage hinweg schonend mit Bourbon-Vanillesirup kandierte und glasierte Edelkastanien",
      "In Butter geröstete Maroni",
      "Kastanieneis",
      "Salziges Kastanienmus"
    ],
    "correct": 0,
    "expEn": "Days of osmotic syrup bathing replace internal water with sugar crystal velvet.",
    "expDe": "Das tagelange, behutsame Kandieren verleiht den Edelkastanien ihre zart schmelzende Textur."
  },
  {
    "id": "q_fru_11",
    "category": "fruits",
    "questionEn": "Why are Figs (Feigen) technically not single fruits botanically?",
    "questionDe": "Warum sind Feigen aus botanischer Sicht keine einfachen Einzelfrüchte?",
    "optionsEn": [
      "They are an inverted flower inflorescence ('Syconium') containing hundreds of tiny internal fruits",
      "They are underground mushrooms",
      "They are tree roots",
      "They are sea algae"
    ],
    "optionsDe": [
      "Sie sind ein nach innen gestülpter Blütenstand (Syconium) mit hunderten winzigen Steinfrüchten",
      "Sie sind Baumpilze",
      "Sie sind Wurzelknollen",
      "Sie sind Algen"
    ],
    "correctIndex": 0,
    "explanationEn": "Fig wasps pollinate internal flowers through the eye opening; each crunch is a microscopic seed fruit.",
    "explanationDe": "Die Feige ist eine Scheinblüte, in deren Innerem hunderte Miniatur-Steinfrüchte heranreifen.",
    "qEn": "Why are Figs (Feigen) technically not single fruits botanically?",
    "qDe": "Warum sind Feigen aus botanischer Sicht keine einfachen Einzelfrüchte?",
    "optEn": [
      "They are an inverted flower inflorescence ('Syconium') containing hundreds of tiny internal fruits",
      "They are underground mushrooms",
      "They are tree roots",
      "They are sea algae"
    ],
    "optDe": [
      "Sie sind ein nach innen gestülpter Blütenstand (Syconium) mit hunderten winzigen Steinfrüchten",
      "Sie sind Baumpilze",
      "Sie sind Wurzelknollen",
      "Sie sind Algen"
    ],
    "correct": 0,
    "expEn": "Fig wasps pollinate internal flowers through the eye opening; each crunch is a microscopic seed fruit.",
    "expDe": "Die Feige ist eine Scheinblüte, in deren Innerem hunderte Miniatur-Steinfrüchte heranreifen."
  },
  {
    "id": "q_fru_12",
    "category": "fruits",
    "questionEn": "What is Passion Fruit (Maracuja) praised for in confectionery?",
    "questionDe": "Was zeichnet Passionsfrucht (Maracuja) in Desserts und Sorbets aus?",
    "optionsEn": [
      "Electrifying tropical acidity and volatile sulfur-ester aromatics that cut through heavy chocolates and creams",
      "Extremely mild bland sweetness",
      "High fat content",
      "Vanilla flavor"
    ],
    "optionsDe": [
      "Elektrisierende tropische Säure und exotische Schwefelfruchtester, die schwere Cremes beleben",
      "Milde neutrale Süße",
      "Hoher Fettgehalt",
      "Vanillegeschmack"
    ],
    "correctIndex": 0,
    "explanationEn": "Maracuja provides razor-sharp citric acid and exotic aromatics to balance chocolate and caramel.",
    "explanationDe": "Die knackige Fruchtsäure der Maracuja ist der perfekte Kontrapunkt zu süßer Schokolade.",
    "qEn": "What is Passion Fruit (Maracuja) praised for in confectionery?",
    "qDe": "Was zeichnet Passionsfrucht (Maracuja) in Desserts und Sorbets aus?",
    "optEn": [
      "Electrifying tropical acidity and volatile sulfur-ester aromatics that cut through heavy chocolates and creams",
      "Extremely mild bland sweetness",
      "High fat content",
      "Vanilla flavor"
    ],
    "optDe": [
      "Elektrisierende tropische Säure und exotische Schwefelfruchtester, die schwere Cremes beleben",
      "Milde neutrale Süße",
      "Hoher Fettgehalt",
      "Vanillegeschmack"
    ],
    "correct": 0,
    "expEn": "Maracuja provides razor-sharp citric acid and exotic aromatics to balance chocolate and caramel.",
    "expDe": "Die knackige Fruchtsäure der Maracuja ist der perfekte Kontrapunkt zu süßer Schokolade."
  },
  {
    "id": "q_fru_13",
    "category": "fruits",
    "questionEn": "What distinguishes sweet cherries from sour cherries (Sauerkirschen / Morellen)?",
    "questionDe": "Was unterscheidet Sauerkirschen (Schattenmorellen) von Süßkirschen in der Küche?",
    "optionsEn": [
      "Higher malic acid, lower sugar, and intense tart anthocyanin pigment, holding shape brilliantly when baked",
      "Sour cherries have no stone",
      "Sweet cherries are yellow only",
      "Sour cherries cannot be cooked"
    ],
    "optionsDe": [
      "Höherer Äpfelsäuregehalt, herbere Tannine und intensive Farbe; ideal für Kuchen und Kompott",
      "Sauerkirschen haben keine Steine",
      "Süßkirschen sind gelb",
      "Sauerkirschen zerkochen sofort"
    ],
    "correctIndex": 0,
    "explanationEn": "Sour cherries retain fruit sharpness and deep crimson color in Black Forest Gateau (Schwarzwälder Kirschtorte).",
    "explanationDe": "Schattenmorellen behalten beim Backen Biss und belebende Säure gegen schwere Schlagsahne.",
    "qEn": "What distinguishes sweet cherries from sour cherries (Sauerkirschen / Morellen)?",
    "qDe": "Was unterscheidet Sauerkirschen (Schattenmorellen) von Süßkirschen in der Küche?",
    "optEn": [
      "Higher malic acid, lower sugar, and intense tart anthocyanin pigment, holding shape brilliantly when baked",
      "Sour cherries have no stone",
      "Sweet cherries are yellow only",
      "Sour cherries cannot be cooked"
    ],
    "optDe": [
      "Höherer Äpfelsäuregehalt, herbere Tannine und intensive Farbe; ideal für Kuchen und Kompott",
      "Sauerkirschen haben keine Steine",
      "Süßkirschen sind gelb",
      "Sauerkirschen zerkochen sofort"
    ],
    "correct": 0,
    "expEn": "Sour cherries retain fruit sharpness and deep crimson color in Black Forest Gateau (Schwarzwälder Kirschtorte).",
    "expDe": "Schattenmorellen behalten beim Backen Biss und belebende Säure gegen schwere Schlagsahne."
  },
  {
    "id": "q_fru_14",
    "category": "fruits",
    "questionEn": "What makes Mango 'Alphonso' from Ratnagiri, India the queen of mangoes?",
    "questionDe": "Warum gilt die indische Alphonso-Mango als Königin aller Mangos?",
    "optionsEn": [
      "Saffron-golden fiberless pulp with intense floral aroma, honey sweetness, and velvety texture",
      "It stays green and crunchy",
      "Has five stones inside",
      "Has bitter grapefruit flavor"
    ],
    "optionsDe": [
      "Faserfreies, safrangelbes Fruchtfleisch mit intensivem floralem Bukett und zartem Schmelz",
      "Bleibt grün und hart",
      "Enthält 5 Kerne",
      "Schmeckt bitter"
    ],
    "correctIndex": 0,
    "explanationEn": "Volatile monoterpenes and absence of stringy fibers make Alphonso the gold standard for purees and lassis.",
    "explanationDe": "Das cremig-faserfreie Fleisch und die Aromafülle sind weltweit unerreicht für Mango Lassi.",
    "qEn": "What makes Mango 'Alphonso' from Ratnagiri, India the queen of mangoes?",
    "qDe": "Warum gilt die indische Alphonso-Mango als Königin aller Mangos?",
    "optEn": [
      "Saffron-golden fiberless pulp with intense floral aroma, honey sweetness, and velvety texture",
      "It stays green and crunchy",
      "Has five stones inside",
      "Has bitter grapefruit flavor"
    ],
    "optDe": [
      "Faserfreies, safrangelbes Fruchtfleisch mit intensivem floralem Bukett und zartem Schmelz",
      "Bleibt grün und hart",
      "Enthält 5 Kerne",
      "Schmeckt bitter"
    ],
    "correct": 0,
    "expEn": "Volatile monoterpenes and absence of stringy fibers make Alphonso the gold standard for purees and lassis.",
    "expDe": "Das cremig-faserfreie Fleisch und die Aromafülle sind weltweit unerreicht für Mango Lassi."
  },
  {
    "id": "q_fru_15",
    "category": "fruits",
    "questionEn": "What compound gives Rhubarb (Rhabarber) its teeth-coating astringency?",
    "questionDe": "Welche Säure erzeugt das pelzige Gefühl auf den Zähnen beim Essen von Rhabarber?",
    "optionsEn": [
      "Oxalic acid, which precipitates calcium from saliva onto tooth enamel",
      "Citric acid only",
      "Acetic acid",
      "Lactic acid"
    ],
    "optionsDe": [
      "Oxalsäure, die mit Speichel-Calcium zu unlöslichem Calciumoxalat auf dem Zahnschmelz reagiert",
      "Reine Zitronensäure",
      "Essigsäure",
      "Milchsäure"
    ],
    "correctIndex": 0,
    "explanationEn": "Oxalic acid forms microscopic calcium oxalate crystals; peeling and cooking with dairy buffers the sensation.",
    "explanationDe": "Oxalsäure bindet Calcium; Milchprodukte oder Schälen puffern den adstringierenden Belag ab.",
    "qEn": "What compound gives Rhubarb (Rhabarber) its teeth-coating astringency?",
    "qDe": "Welche Säure erzeugt das pelzige Gefühl auf den Zähnen beim Essen von Rhabarber?",
    "optEn": [
      "Oxalic acid, which precipitates calcium from saliva onto tooth enamel",
      "Citric acid only",
      "Acetic acid",
      "Lactic acid"
    ],
    "optDe": [
      "Oxalsäure, die mit Speichel-Calcium zu unlöslichem Calciumoxalat auf dem Zahnschmelz reagiert",
      "Reine Zitronensäure",
      "Essigsäure",
      "Milchsäure"
    ],
    "correct": 0,
    "expEn": "Oxalic acid forms microscopic calcium oxalate crystals; peeling and cooking with dairy buffers the sensation.",
    "expDe": "Oxalsäure bindet Calcium; Milchprodukte oder Schälen puffern den adstringierenden Belag ab."
  },
  {
    "id": "q_fru_16",
    "category": "fruits",
    "questionEn": "What is Bergamot orange (Citrus bergamia) primarily cultivated for?",
    "questionDe": "Wofür wird die kalabrische Bergamotte (Citrus bergamia) fast ausschließlich angebaut?",
    "optionsEn": [
      "Cold-pressed aromatic peel oil for Earl Grey tea, perfumery, and liqueurs (juice is too intensely bitter/sour)",
      "Fresh fruit consumption like clementines",
      "Feeding livestock",
      "Producing sweet table wine"
    ],
    "optionsDe": [
      "Kaltgepresstes ätherisches Schalenöl für Earl Grey, Parfums und Liköre (Fruchtfleisch zu sauer-bitter)",
      "Als Tafelfrucht zum Schälen",
      "Als Tierfutter",
      "Zur Weinkelterung"
    ],
    "correctIndex": 0,
    "explanationEn": "90% of global Bergamot comes from Calabria; its peel is packed with linalyl acetate and linalool.",
    "explanationDe": "Das edle Öl aus der Schale kalabrischer Bergamotten ist weltberühmt für Earl Grey und Eau de Cologne.",
    "qEn": "What is Bergamot orange (Citrus bergamia) primarily cultivated for?",
    "qDe": "Wofür wird die kalabrische Bergamotte (Citrus bergamia) fast ausschließlich angebaut?",
    "optEn": [
      "Cold-pressed aromatic peel oil for Earl Grey tea, perfumery, and liqueurs (juice is too intensely bitter/sour)",
      "Fresh fruit consumption like clementines",
      "Feeding livestock",
      "Producing sweet table wine"
    ],
    "optDe": [
      "Kaltgepresstes ätherisches Schalenöl für Earl Grey, Parfums und Liköre (Fruchtfleisch zu sauer-bitter)",
      "Als Tafelfrucht zum Schälen",
      "Als Tierfutter",
      "Zur Weinkelterung"
    ],
    "correct": 0,
    "expEn": "90% of global Bergamot comes from Calabria; its peel is packed with linalyl acetate and linalool.",
    "expDe": "Das edle Öl aus der Schale kalabrischer Bergamotten ist weltberühmt für Earl Grey und Eau de Cologne."
  },
  {
    "id": "q_fru_17",
    "category": "fruits",
    "questionEn": "Why do Pomegranates (Granatäpfel) contain hundreds of juicy arils?",
    "questionDe": "Was isst man bei einem Granatapfel aus botanischer Sicht?",
    "optionsEn": [
      "The jewel-like fleshy edible seed coats (Arils), bursting with sweet-tart ruby juice",
      "The bitter white spongy pith",
      "The outer woody rind",
      "The flower petals"
    ],
    "optionsDe": [
      "Die saftigen Samenmäntel (Arillen), die die Kerne mit rubinrotem Fruchtsaft umhüllen",
      "Das bittere weiße Schwammgewebe",
      "Die ledrige Außenschale",
      "Die Blütenblätter"
    ],
    "correctIndex": 0,
    "explanationEn": "Pomegranate juice is rich in punicalagins, providing deep berry tartness and tannic complexity.",
    "explanationDe": "Die roten Arillen liefern knackigen Saftbissen mit feinen Gerbstoffen für Salate und Fleischglasuren.",
    "qEn": "Why do Pomegranates (Granatäpfel) contain hundreds of juicy arils?",
    "qDe": "Was isst man bei einem Granatapfel aus botanischer Sicht?",
    "optEn": [
      "The jewel-like fleshy edible seed coats (Arils), bursting with sweet-tart ruby juice",
      "The bitter white spongy pith",
      "The outer woody rind",
      "The flower petals"
    ],
    "optDe": [
      "Die saftigen Samenmäntel (Arillen), die die Kerne mit rubinrotem Fruchtsaft umhüllen",
      "Das bittere weiße Schwammgewebe",
      "Die ledrige Außenschale",
      "Die Blütenblätter"
    ],
    "correct": 0,
    "expEn": "Pomegranate juice is rich in punicalagins, providing deep berry tartness and tannic complexity.",
    "expDe": "Die roten Arillen liefern knackigen Saftbissen mit feinen Gerbstoffen für Salate und Fleischglasuren."
  },
  {
    "id": "q_fru_18",
    "category": "fruits",
    "questionEn": "What is the botanical difference between wild blueberries (Waldheidelbeeren) and cultivated blueberries (Kulturheidelbeeren)?",
    "questionDe": "Was unterscheidet echte Waldheidelbeeren von Kulturheidelbeeren?",
    "optionsEn": [
      "Wild berries are dark purple through and through with red staining juice; cultivated berries have pale translucent white flesh",
      "Cultivated berries are bitter",
      "Wild berries grow on palm trees",
      "Cultivated berries have thorns"
    ],
    "optionsDe": [
      "Waldheidelbeeren sind durchgefärbt blau mit färbendem Saft; Kulturheidelbeeren haben weißes Fruchtfleisch",
      "Kulturheidelbeeren sind bitter",
      "Waldbeeren wachsen auf Palmen",
      "Kulturbeeren haben Dornen"
    ],
    "correctIndex": 0,
    "explanationEn": "Wild Vaccinium myrtillus contains anthocyanins in the flesh; cultivated Vaccinium corymbosum only in the skin.",
    "explanationDe": "Echte Waldheidelbeeren färben Zunge und Zähne tiefblau, Kulturheidelbeeren sind innen hell.",
    "qEn": "What is the botanical difference between wild blueberries (Waldheidelbeeren) and cultivated blueberries (Kulturheidelbeeren)?",
    "qDe": "Was unterscheidet echte Waldheidelbeeren von Kulturheidelbeeren?",
    "optEn": [
      "Wild berries are dark purple through and through with red staining juice; cultivated berries have pale translucent white flesh",
      "Cultivated berries are bitter",
      "Wild berries grow on palm trees",
      "Cultivated berries have thorns"
    ],
    "optDe": [
      "Waldheidelbeeren sind durchgefärbt blau mit färbendem Saft; Kulturheidelbeeren haben weißes Fruchtfleisch",
      "Kulturheidelbeeren sind bitter",
      "Waldbeeren wachsen auf Palmen",
      "Kulturbeeren haben Dornen"
    ],
    "correct": 0,
    "expEn": "Wild Vaccinium myrtillus contains anthocyanins in the flesh; cultivated Vaccinium corymbosum only in the skin.",
    "expDe": "Echte Waldheidelbeeren färben Zunge und Zähne tiefblau, Kulturheidelbeeren sind innen hell."
  },
  {
    "id": "q_nut_01",
    "category": "nuts",
    "questionEn": "What makes Pistacchio Verde di Bronte DOP from Sicily world-renowned?",
    "questionDe": "Was macht die grüne Pistazie aus Bronte DOP (Sizilien) weltberühmt?",
    "optionsEn": [
      "Grown on volcanic lava slopes of Mount Etna, hand-harvested biennially, with emerald green color and intense sweet resinous aroma",
      "Dyed with spinach",
      "Grown under water",
      "Naturally salted on tree"
    ],
    "optionsDe": [
      "Wächst auf erkalteter Ätna-Lava, wird nur alle 2 Jahre geerntet und besitzt smaragdgrünes, harzig-süßes Aroma",
      "Wird mit Spinat gefärbt",
      "Wächst unter Wasser",
      "Ist von Natur aus gesalzen"
    ],
    "correctIndex": 0,
    "explanationEn": "Volcanic minerals and biennial harvesting concentrate aroma and chlorophyll into vibrant green gems.",
    "explanationDe": "Die sizilianische Vulkanerde schenkt der Pistazie ihre unvergleichliche Farbe und aromatische Tiefe.",
    "qEn": "What makes Pistacchio Verde di Bronte DOP from Sicily world-renowned?",
    "qDe": "Was macht die grüne Pistazie aus Bronte DOP (Sizilien) weltberühmt?",
    "optEn": [
      "Grown on volcanic lava slopes of Mount Etna, hand-harvested biennially, with emerald green color and intense sweet resinous aroma",
      "Dyed with spinach",
      "Grown under water",
      "Naturally salted on tree"
    ],
    "optDe": [
      "Wächst auf erkalteter Ätna-Lava, wird nur alle 2 Jahre geerntet und besitzt smaragdgrünes, harzig-süßes Aroma",
      "Wird mit Spinat gefärbt",
      "Wächst unter Wasser",
      "Ist von Natur aus gesalzen"
    ],
    "correct": 0,
    "expEn": "Volcanic minerals and biennial harvesting concentrate aroma and chlorophyll into vibrant green gems.",
    "expDe": "Die sizilianische Vulkanerde schenkt der Pistazie ihre unvergleichliche Farbe und aromatische Tiefe."
  },
  {
    "id": "q_nut_02",
    "category": "nuts",
    "questionEn": "Why must Piedmontese Hazelnuts (Nocciola del Piemonte IGP) be gently roasted?",
    "questionDe": "Warum werden Piemonteser Haselnüsse (Nocciola del Piemonte IGP) schonend geröstet?",
    "optionsEn": [
      "Roasting peels papery bitter skins and triggers Maillard reactions, releasing hazelnut pyrazines for gianduja chocolate",
      "Kills poison",
      "Makes them soft as butter",
      "Bleaches them white"
    ],
    "optionsDe": [
      "Entfernt die herbe Fruchthaut und bildet Röstpyrazine für feinstes Nougat- und Gianduja-Aroma",
      "Tötet Gift ab",
      "Macht sie weich wie Butter",
      "Färbt sie weiß"
    ],
    "correctIndex": 0,
    "explanationEn": "The spherical Tonda Gentile Trilobata hazelnut is the undisputed pinnacle for chocolate confectionery.",
    "explanationDe": "Die Tonda Gentile besitzt nach dem Rösten den vollkommensten Schmelz für Nusscremes und Pralinen.",
    "qEn": "Why must Piedmontese Hazelnuts (Nocciola del Piemonte IGP) be gently roasted?",
    "qDe": "Warum werden Piemonteser Haselnüsse (Nocciola del Piemonte IGP) schonend geröstet?",
    "optEn": [
      "Roasting peels papery bitter skins and triggers Maillard reactions, releasing hazelnut pyrazines for gianduja chocolate",
      "Kills poison",
      "Makes them soft as butter",
      "Bleaches them white"
    ],
    "optDe": [
      "Entfernt die herbe Fruchthaut und bildet Röstpyrazine für feinstes Nougat- und Gianduja-Aroma",
      "Tötet Gift ab",
      "Macht sie weich wie Butter",
      "Färbt sie weiß"
    ],
    "correct": 0,
    "expEn": "The spherical Tonda Gentile Trilobata hazelnut is the undisputed pinnacle for chocolate confectionery.",
    "expDe": "Die Tonda Gentile besitzt nach dem Rösten den vollkommensten Schmelz für Nusscremes und Pralinen."
  },
  {
    "id": "q_nut_03",
    "category": "nuts",
    "questionEn": "What is the toxic compound in raw Bitter Almonds that is absent in sweet almonds?",
    "questionDe": "Welcher Giftstoff steckt in rohen Bittermandeln im Gegensatz zu süßen Mandeln?",
    "optionsEn": [
      "Amygdalin, which breaks down into deadly hydrogen cyanide (HCN) and benzaldehyde when crushed",
      "Arsenic",
      "Mercury",
      "Strychnine"
    ],
    "optionsDe": [
      "Amygdalin, das bei Kontakt mit Speichel hochgiftige Blausäure (HCN) freisetzt",
      "Arsen",
      "Quecksilber",
      "Strychnin"
    ],
    "correctIndex": 0,
    "explanationEn": "As few as 5-10 raw bitter almonds can be fatal to children; heat or distillation safely strips toxicity.",
    "explanationDe": "Bittermandeln dürfen nur entgiftet verwendet werden; das Spaltprodukt Benzaldehyd liefert Marzipanduft.",
    "qEn": "What is the toxic compound in raw Bitter Almonds that is absent in sweet almonds?",
    "qDe": "Welcher Giftstoff steckt in rohen Bittermandeln im Gegensatz zu süßen Mandeln?",
    "optEn": [
      "Amygdalin, which breaks down into deadly hydrogen cyanide (HCN) and benzaldehyde when crushed",
      "Arsenic",
      "Mercury",
      "Strychnine"
    ],
    "optDe": [
      "Amygdalin, das bei Kontakt mit Speichel hochgiftige Blausäure (HCN) freisetzt",
      "Arsen",
      "Quecksilber",
      "Strychnin"
    ],
    "correct": 0,
    "expEn": "As few as 5-10 raw bitter almonds can be fatal to children; heat or distillation safely strips toxicity.",
    "expDe": "Bittermandeln dürfen nur entgiftet verwendet werden; das Spaltprodukt Benzaldehyd liefert Marzipanduft."
  },
  {
    "id": "q_nut_04",
    "category": "nuts",
    "questionEn": "What is Tahini in Middle Eastern culinary science?",
    "questionDe": "Woraus besteht echtes orientalisches Tahini (Tahin)?",
    "optionsEn": [
      "100% smooth ground toasted hulled sesame seeds (rich in sesamin and healthy fats)",
      "Peanut butter with lemon",
      "Chickpea flour paste",
      "Sunflower oil paste"
    ],
    "optionsDe": [
      "Feinst vermahlene Paste aus gerösteten Sesamsamen ohne Zusätze",
      "Erdnussbutter mit Zitrone",
      "Kichererbsenmehlpaste",
      "Sonnenblumenkernpaste"
    ],
    "correctIndex": 0,
    "explanationEn": "Tahini is rich in calcium and natural emulsifiers, essential for creamy Hummus and Baba Ghanoush.",
    "explanationDe": "Sesampaste schenkt Hummus seine nussige Bindung und samtige Cremigkeit.",
    "qEn": "What is Tahini in Middle Eastern culinary science?",
    "qDe": "Woraus besteht echtes orientalisches Tahini (Tahin)?",
    "optEn": [
      "100% smooth ground toasted hulled sesame seeds (rich in sesamin and healthy fats)",
      "Peanut butter with lemon",
      "Chickpea flour paste",
      "Sunflower oil paste"
    ],
    "optDe": [
      "Feinst vermahlene Paste aus gerösteten Sesamsamen ohne Zusätze",
      "Erdnussbutter mit Zitrone",
      "Kichererbsenmehlpaste",
      "Sonnenblumenkernpaste"
    ],
    "correct": 0,
    "expEn": "Tahini is rich in calcium and natural emulsifiers, essential for creamy Hummus and Baba Ghanoush.",
    "expDe": "Sesampaste schenkt Hummus seine nussige Bindung und samtige Cremigkeit."
  },
  {
    "id": "q_nut_05",
    "category": "nuts",
    "questionEn": "Why are Walnuts (Walnüsse) prone to turning rancid quickly if stored warm?",
    "questionDe": "Warum werden Walnüsse bei warmer Lagerung so schnell ranzig?",
    "optionsEn": [
      "Exceptionally high in delicate polyunsaturated omega-3 alpha-linolenic fatty acids that oxidize rapidly in air",
      "They have high sugar",
      "Moisture dissolves nuts",
      "Salt attracts oxygen"
    ],
    "optionsDe": [
      "Sehr hoher Gehalt an empfindlichen mehrfach ungesättigten Omega-3-Fettsäuren, die an der Luft oxidieren",
      "Haben zu viel Zucker",
      "Feuchtigkeit löst sie auf",
      "Salz zieht Sauerstoff an"
    ],
    "correctIndex": 0,
    "explanationEn": "Store shelled walnuts in airtight jars in the refrigerator or freezer to prevent lipid peroxidation.",
    "explanationDe": "Das wertvolle Walnussöl oxidiert bei Wärme rasch; Lagerung im Kühlschrank schützt den nussigen Geschmack.",
    "qEn": "Why are Walnuts (Walnüsse) prone to turning rancid quickly if stored warm?",
    "qDe": "Warum werden Walnüsse bei warmer Lagerung so schnell ranzig?",
    "optEn": [
      "Exceptionally high in delicate polyunsaturated omega-3 alpha-linolenic fatty acids that oxidize rapidly in air",
      "They have high sugar",
      "Moisture dissolves nuts",
      "Salt attracts oxygen"
    ],
    "optDe": [
      "Sehr hoher Gehalt an empfindlichen mehrfach ungesättigten Omega-3-Fettsäuren, die an der Luft oxidieren",
      "Haben zu viel Zucker",
      "Feuchtigkeit löst sie auf",
      "Salz zieht Sauerstoff an"
    ],
    "correct": 0,
    "expEn": "Store shelled walnuts in airtight jars in the refrigerator or freezer to prevent lipid peroxidation.",
    "expDe": "Das wertvolle Walnussöl oxidiert bei Wärme rasch; Lagerung im Kühlschrank schützt den nussigen Geschmack."
  },
  {
    "id": "q_nut_06",
    "category": "nuts",
    "questionEn": "What is the Cashew nut botanically and why is it never sold in its raw shell?",
    "questionDe": "Was ist die Cashewnuss botanisch und warum wird sie nie in der Rohschale verkauft?",
    "optionsEn": [
      "The seed of the Cashew Apple; the shell contains caustic urushiol resin (poison ivy toxin) destroyed only by roasting",
      "A root tuber",
      "A cereal grain",
      "A sea shell"
    ],
    "optionsDe": [
      "Der Samen des Cashew-Apfels; die Schale enthält ätzendes Urushiol-Öl, das erst durch Rösten verbrennt",
      "Eine Wurzelknolle",
      "Ein Getreidekorn",
      "Eine Muschel"
    ],
    "correctIndex": 0,
    "explanationEn": "Urushiol causes severe skin chemical burns; cashews are steamed and shelled under strict safety standards.",
    "explanationDe": "Das Schalenöl ist hochgradig ätzend; erst Dämpfen und Rösten machen den milden Cashewkern genießbar.",
    "qEn": "What is the Cashew nut botanically and why is it never sold in its raw shell?",
    "qDe": "Was ist die Cashewnuss botanisch und warum wird sie nie in der Rohschale verkauft?",
    "optEn": [
      "The seed of the Cashew Apple; the shell contains caustic urushiol resin (poison ivy toxin) destroyed only by roasting",
      "A root tuber",
      "A cereal grain",
      "A sea shell"
    ],
    "optDe": [
      "Der Samen des Cashew-Apfels; die Schale enthält ätzendes Urushiol-Öl, das erst durch Rösten verbrennt",
      "Eine Wurzelknolle",
      "Ein Getreidekorn",
      "Eine Muschel"
    ],
    "correct": 0,
    "expEn": "Urushiol causes severe skin chemical burns; cashews are steamed and shelled under strict safety standards.",
    "expDe": "Das Schalenöl ist hochgradig ätzend; erst Dämpfen und Rösten machen den milden Cashewkern genießbar."
  },
  {
    "id": "q_nut_07",
    "category": "nuts",
    "questionEn": "What makes Mediterranean Pine Nuts (Pinoli) so prized compared to Siberian cedar nuts?",
    "questionDe": "Was unterscheidet echte Mittelmeer-Pinienkerne (Pinus pinea) von asiatischen Zedernüssen?",
    "optionsEn": [
      "Slender ivory shape, delicate creamy-resinous aroma, and absence of the metallic 'pine mouth' taste defect",
      "They are crunchy like rocks",
      "They taste like sweet sugar",
      "They are dyed green"
    ],
    "optionsDe": [
      "Schlanke Elfenbeinform, cremig-harziger Schmelz und kein Risiko des metallischen 'Pinienmund'-Syndroms",
      "Sind steinhart",
      "Schmecken wie Zucker",
      "Sind grün gefärbt"
    ],
    "correctIndex": 0,
    "explanationEn": "True Italian pinoli from stone pines are the heart of Pesto Genovese; cheaper cedar nuts can cause dysgeusia.",
    "explanationDe": "Pinus pinea liefert den unverfälschten Buttergeschmack für Pesto ohne metallischen Nachgeschmack.",
    "qEn": "What makes Mediterranean Pine Nuts (Pinoli) so prized compared to Siberian cedar nuts?",
    "qDe": "Was unterscheidet echte Mittelmeer-Pinienkerne (Pinus pinea) von asiatischen Zedernüssen?",
    "optEn": [
      "Slender ivory shape, delicate creamy-resinous aroma, and absence of the metallic 'pine mouth' taste defect",
      "They are crunchy like rocks",
      "They taste like sweet sugar",
      "They are dyed green"
    ],
    "optDe": [
      "Schlanke Elfenbeinform, cremig-harziger Schmelz und kein Risiko des metallischen 'Pinienmund'-Syndroms",
      "Sind steinhart",
      "Schmecken wie Zucker",
      "Sind grün gefärbt"
    ],
    "correct": 0,
    "expEn": "True Italian pinoli from stone pines are the heart of Pesto Genovese; cheaper cedar nuts can cause dysgeusia.",
    "expDe": "Pinus pinea liefert den unverfälschten Buttergeschmack für Pesto ohne metallischen Nachgeschmack."
  },
  {
    "id": "q_nut_08",
    "category": "nuts",
    "questionEn": "Why are Peanuts botanically classified as legumes rather than true tree nuts?",
    "questionDe": "Warum sind Erdnüsse botanisch Hülsenfrüchte und keine echten Nüsse?",
    "optionsEn": [
      "They grow in pods underground (Arachis hypogaea) like beans and peas, with nitrogen-fixing roots",
      "They grow on palm trees",
      "They are cereal seeds",
      "They are mushrooms"
    ],
    "optionsDe": [
      "Sie reifen als unterirdische Hülsenfrüchte an den Wurzeln wie Erbsen und Bohnen",
      "Sie wachsen auf Palmen",
      "Sie sind Getreidekörner",
      "Sie sind Pilze"
    ],
    "correctIndex": 0,
    "explanationEn": "After flowering above ground, flower stalks bend down and bury themselves to mature pods in the soil.",
    "explanationDe": "Nach der Blüte senkt sich der Trieb in die Erde, wo die Erdnuss wie eine Bohne heranreift.",
    "qEn": "Why are Peanuts botanically classified as legumes rather than true tree nuts?",
    "qDe": "Warum sind Erdnüsse botanisch Hülsenfrüchte und keine echten Nüsse?",
    "optEn": [
      "They grow in pods underground (Arachis hypogaea) like beans and peas, with nitrogen-fixing roots",
      "They grow on palm trees",
      "They are cereal seeds",
      "They are mushrooms"
    ],
    "optDe": [
      "Sie reifen als unterirdische Hülsenfrüchte an den Wurzeln wie Erbsen und Bohnen",
      "Sie wachsen auf Palmen",
      "Sie sind Getreidekörner",
      "Sie sind Pilze"
    ],
    "correct": 0,
    "expEn": "After flowering above ground, flower stalks bend down and bury themselves to mature pods in the soil.",
    "expDe": "Nach der Blüte senkt sich der Trieb in die Erde, wo die Erdnuss wie eine Bohne heranreift."
  },
  {
    "id": "q_nut_09",
    "category": "nuts",
    "questionEn": "What gives Marzipan its legally defined quality grades in Germany?",
    "questionDe": "Was bestimmt die Qualitätsstufen von echtem Lübecker Marzipan?",
    "optionsEn": [
      "The ratio of pure almond paste (Marzipanrohmasse) to added sugar (max 10% sugar added for Edelmarzipan)",
      "Amount of flour added",
      "Amount of butter added",
      "Egg white content"
    ],
    "optionsDe": [
      "Das Verhältnis von Marzipanrohmasse zu zugesetztem Zucker (Edelmarzipan: max. 30% Zuckerzusatz)",
      "Mehlzusatz",
      "Buttergehalt",
      "Eiweißanteil"
    ],
    "correctIndex": 0,
    "explanationEn": "Lübecker Marzipan has PGI protection; high almond content ensures rich, unctuous mouthfeel.",
    "explanationDe": "Viel Mandeln und wenig Zucker garantieren das edle, feuchte Marzipanerlebnis aus Lübeck.",
    "qEn": "What gives Marzipan its legally defined quality grades in Germany?",
    "qDe": "Was bestimmt die Qualitätsstufen von echtem Lübecker Marzipan?",
    "optEn": [
      "The ratio of pure almond paste (Marzipanrohmasse) to added sugar (max 10% sugar added for Edelmarzipan)",
      "Amount of flour added",
      "Amount of butter added",
      "Egg white content"
    ],
    "optDe": [
      "Das Verhältnis von Marzipanrohmasse zu zugesetztem Zucker (Edelmarzipan: max. 30% Zuckerzusatz)",
      "Mehlzusatz",
      "Buttergehalt",
      "Eiweißanteil"
    ],
    "correct": 0,
    "expEn": "Lübecker Marzipan has PGI protection; high almond content ensures rich, unctuous mouthfeel.",
    "expDe": "Viel Mandeln und wenig Zucker garantieren das edle, feuchte Marzipanerlebnis aus Lübeck."
  },
  {
    "id": "q_nut_09b",
    "category": "nuts",
    "questionEn": "What are Chia seeds valued for in culinary suspensions and puddings?",
    "questionDe": "Warum quellen Chiasamen in Flüssigkeiten zu einem geleeartigen Pudding auf?",
    "optionsEn": [
      "High soluble mucilage fiber in seed coats forms a thick hydrophilic hydrogel absorbing 10x its weight in water",
      "Starch boils instantly",
      "Gluten binds water",
      "Yeast ferments water"
    ],
    "optionsDe": [
      "Lösliche Schleimstoffe in der Samenschale bilden ein Hydrogel, das das Zehnfache an Wasser bindet",
      "Stärke quillt auf",
      "Gluten geliert",
      "Hefe fermentiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Chia gel mimics egg or fat emulsions in vegan baking and creates soothing breakfast puddings.",
    "explanationDe": "Die pflanzlichen Quellstoffe binden Flüssigkeit ohne Kochen zu samtiger Geltextur.",
    "qEn": "What are Chia seeds valued for in culinary suspensions and puddings?",
    "qDe": "Warum quellen Chiasamen in Flüssigkeiten zu einem geleeartigen Pudding auf?",
    "optEn": [
      "High soluble mucilage fiber in seed coats forms a thick hydrophilic hydrogel absorbing 10x its weight in water",
      "Starch boils instantly",
      "Gluten binds water",
      "Yeast ferments water"
    ],
    "optDe": [
      "Lösliche Schleimstoffe in der Samenschale bilden ein Hydrogel, das das Zehnfache an Wasser bindet",
      "Stärke quillt auf",
      "Gluten geliert",
      "Hefe fermentiert"
    ],
    "correct": 0,
    "expEn": "Chia gel mimics egg or fat emulsions in vegan baking and creates soothing breakfast puddings.",
    "expDe": "Die pflanzlichen Quellstoffe binden Flüssigkeit ohne Kochen zu samtiger Geltextur."
  },
  {
    "id": "q_nut_11",
    "category": "nuts",
    "questionEn": "Where does the Macadamia nut originate and why is its shell notoriously difficult to crack?",
    "questionDe": "Wo stammt die Macadamianuss her und warum ist ihre Schale so steinhart?",
    "optionsEn": [
      "Indigenous to rainforests of eastern Australia; spherical dense lignified shell withstands 300 psi of pressure",
      "Originated in Germany",
      "Originated in Alaska",
      "Originated in Egypt"
    ],
    "optionsDe": [
      "Aus den Regenwäldern Ostaustraliens; die verholzte Steinschale hält über 20 bar Druck stand",
      "Aus Deutschland",
      "Aus Alaska",
      "Aus Ägypten"
    ],
    "correctIndex": 0,
    "explanationEn": "Known as the Queen of Nuts; requires specialized tungsten steel notched crackers to release buttery kernel.",
    "explanationDe": "Die extrem harte Schale schützt die fettreichste und cremigste Nuss der Welt.",
    "qEn": "Where does the Macadamia nut originate and why is its shell notoriously difficult to crack?",
    "qDe": "Wo stammt die Macadamianuss her und warum ist ihre Schale so steinhart?",
    "optEn": [
      "Indigenous to rainforests of eastern Australia; spherical dense lignified shell withstands 300 psi of pressure",
      "Originated in Germany",
      "Originated in Alaska",
      "Originated in Egypt"
    ],
    "optDe": [
      "Aus den Regenwäldern Ostaustraliens; die verholzte Steinschale hält über 20 bar Druck stand",
      "Aus Deutschland",
      "Aus Alaska",
      "Aus Ägypten"
    ],
    "correct": 0,
    "expEn": "Known as the Queen of Nuts; requires specialized tungsten steel notched crackers to release buttery kernel.",
    "expDe": "Die extrem harte Schale schützt die fettreichste und cremigste Nuss der Welt."
  },
  {
    "id": "q_nut_12",
    "category": "nuts",
    "questionEn": "What is Gomasio in Japanese macrobiotic seasoning?",
    "questionDe": "Was ist japanisches Gomasio?",
    "optionsEn": [
      "Toasted whole sesame seeds crushed with sea salt in a Suribachi mortar (approx. 10:1 ratio)",
      "Soy sauce powder",
      "Wasabi salt",
      "Dried fish flakes"
    ],
    "optionsDe": [
      "Im Mörser zerstoßener gerösteter Sesam vermengt mit feinem Meersalz (ca. 10:1)",
      "Sojasaucenpulver",
      "Wasabisalz",
      "Fischflocken"
    ],
    "correctIndex": 0,
    "explanationEn": "Sesame oil coats salt grains, reducing required sodium while imparting deep roasty umami to rice.",
    "explanationDe": "Das Sesamöl umhüllt die Salzkörner; man salzt sparsamer und genießt nussige Röstaromen.",
    "qEn": "What is Gomasio in Japanese macrobiotic seasoning?",
    "qDe": "Was ist japanisches Gomasio?",
    "optEn": [
      "Toasted whole sesame seeds crushed with sea salt in a Suribachi mortar (approx. 10:1 ratio)",
      "Soy sauce powder",
      "Wasabi salt",
      "Dried fish flakes"
    ],
    "optDe": [
      "Im Mörser zerstoßener gerösteter Sesam vermengt mit feinem Meersalz (ca. 10:1)",
      "Sojasaucenpulver",
      "Wasabisalz",
      "Fischflocken"
    ],
    "correct": 0,
    "expEn": "Sesame oil coats salt grains, reducing required sodium while imparting deep roasty umami to rice.",
    "expDe": "Das Sesamöl umhüllt die Salzkörner; man salzt sparsamer und genießt nussige Röstaromen."
  },
  {
    "id": "q_nut_13",
    "category": "nuts",
    "questionEn": "Why are Pecans favored over walnuts in American Southern pies?",
    "questionDe": "Warum werden Pekannüsse für klassischen Pecan Pie gegenüber Walnüssen bevorzugt?",
    "optionsEn": [
      "Higher fat, lower astringent tannins, and rich maple-butter sweetness that caramelizes with corn syrup/molasses",
      "Pecans never burn",
      "Pecans have zero calories",
      "Pecans are salty"
    ],
    "optionsDe": [
      "Höherer Fettgehalt, kaum herbe Gerbstoffe und süßliches Ahornaroma, das wunderbar karamellisiert",
      "Brennen nie an",
      "Haben keine Kalorien",
      "Sind salzig"
    ],
    "correctIndex": 0,
    "explanationEn": "Thin, smooth shells and sweet lipids lack the bitter tannic skin bite of walnuts.",
    "explanationDe": "Pekannüsse schmecken süß-buttrig ohne herben Beigeschmack und karamellisieren grandios.",
    "qEn": "Why are Pecans favored over walnuts in American Southern pies?",
    "qDe": "Warum werden Pekannüsse für klassischen Pecan Pie gegenüber Walnüssen bevorzugt?",
    "optEn": [
      "Higher fat, lower astringent tannins, and rich maple-butter sweetness that caramelizes with corn syrup/molasses",
      "Pecans never burn",
      "Pecans have zero calories",
      "Pecans are salty"
    ],
    "optDe": [
      "Höherer Fettgehalt, kaum herbe Gerbstoffe und süßliches Ahornaroma, das wunderbar karamellisiert",
      "Brennen nie an",
      "Haben keine Kalorien",
      "Sind salzig"
    ],
    "correct": 0,
    "expEn": "Thin, smooth shells and sweet lipids lack the bitter tannic skin bite of walnuts.",
    "expDe": "Pekannüsse schmecken süß-buttrig ohne herben Beigeschmack und karamellisieren grandios."
  },
  {
    "id": "q_nut_14",
    "category": "nuts",
    "questionEn": "What are Pumpkin Seeds (Steirische Kürbiskerne g.g.A.) known for?",
    "questionDe": "Was zeichnet Steirische Kürbiskerne g.g.A. botanisch aus?",
    "optionsEn": [
      "Mutation yielding hull-less soft dark green seeds packed with chlorophyll, nutty fats, and zinc",
      "Thick white shells",
      "Red color",
      "Sweet fruit pulp"
    ],
    "optionsDe": [
      "Schalenlose weiche, dunkelgrüne Kerne mit hohem Chlorophyll- und nussigem Ölgehalt",
      "Dicke weiße Schale",
      "Rote Farbe",
      "Süßes Fruchtfleisch"
    ],
    "correctIndex": 0,
    "explanationEn": "Mutated Cucurbita pepo var. styriaca grows seed without woody husks, pressed into emerald pumpkin seed oil.",
    "explanationDe": "Die schalenlos gewachsenen Kerne werden direkt zu dunklem, nussigem Steirischem Kürbiskernöl geröstet.",
    "qEn": "What are Pumpkin Seeds (Steirische Kürbiskerne g.g.A.) known for?",
    "qDe": "Was zeichnet Steirische Kürbiskerne g.g.A. botanisch aus?",
    "optEn": [
      "Mutation yielding hull-less soft dark green seeds packed with chlorophyll, nutty fats, and zinc",
      "Thick white shells",
      "Red color",
      "Sweet fruit pulp"
    ],
    "optDe": [
      "Schalenlose weiche, dunkelgrüne Kerne mit hohem Chlorophyll- und nussigem Ölgehalt",
      "Dicke weiße Schale",
      "Rote Farbe",
      "Süßes Fruchtfleisch"
    ],
    "correct": 0,
    "expEn": "Mutated Cucurbita pepo var. styriaca grows seed without woody husks, pressed into emerald pumpkin seed oil.",
    "expDe": "Die schalenlos gewachsenen Kerne werden direkt zu dunklem, nussigem Steirischem Kürbiskernöl geröstet."
  },
  {
    "id": "q_nut_15",
    "category": "nuts",
    "questionEn": "What culinary seed provides the base for French Dijon mustard and curry powders?",
    "questionDe": "Welcher Samen bildet das Fundament für Senf und viele Currymischungen?",
    "optionsEn": [
      "Mustard seeds (Sinapis alba, Brassica juncea, and Brassica nigra)",
      "Cumin seeds",
      "Fennel seeds",
      "Coriander seeds"
    ],
    "optionsDe": [
      "Senfsaat (Gelber, Brauner und Schwarzer Senf)",
      "Kreuzkümmelsamen",
      "Fenchelsamen",
      "Koriandersamen"
    ],
    "correctIndex": 0,
    "explanationEn": "Cruciferous mustard seeds contain sinigrin and sinalbin, unlocking fiery pungency upon contact with liquid.",
    "explanationDe": "Senfkörner enthalten Glukosinolate, die erst durch Wasser Schärfe freisetzen.",
    "qEn": "What culinary seed provides the base for French Dijon mustard and curry powders?",
    "qDe": "Welcher Samen bildet das Fundament für Senf und viele Currymischungen?",
    "optEn": [
      "Mustard seeds (Sinapis alba, Brassica juncea, and Brassica nigra)",
      "Cumin seeds",
      "Fennel seeds",
      "Coriander seeds"
    ],
    "optDe": [
      "Senfsaat (Gelber, Brauner und Schwarzer Senf)",
      "Kreuzkümmelsamen",
      "Fenchelsamen",
      "Koriandersamen"
    ],
    "correct": 0,
    "expEn": "Cruciferous mustard seeds contain sinigrin and sinalbin, unlocking fiery pungency upon contact with liquid.",
    "expDe": "Senfkörner enthalten Glukosinolate, die erst durch Wasser Schärfe freisetzen."
  },
  {
    "id": "q_nut_16",
    "category": "nuts",
    "questionEn": "Why are Brazil Nuts (Paranüsse) prized for thyroid health?",
    "questionDe": "Warum gelten Paranüsse als die reichste natürliche Quelle für Selen?",
    "optionsEn": [
      "Trees in deep Amazonian soils accumulate massive concentrations of trace mineral Selenium",
      "They contain iodine",
      "They contain synthetic tablets",
      "They have thyroid hormones"
    ],
    "optionsDe": [
      "Tiefwurzelnde Urwaldriesen im Amazonas reichern das Spurenelement Selen extrem an",
      "Enthalten Jod",
      "Enthalten synthetische Stoffe",
      "Enthalten Schilddrüsenhormone"
    ],
    "correctIndex": 0,
    "explanationEn": "Just 1 to 2 Brazil nuts per day cover 100% of the adult human selenium requirement.",
    "explanationDe": "Bereits ein bis zwei Paranüsse täglich decken den menschlichen Selenbedarf vollständig.",
    "qEn": "Why are Brazil Nuts (Paranüsse) prized for thyroid health?",
    "qDe": "Warum gelten Paranüsse als die reichste natürliche Quelle für Selen?",
    "optEn": [
      "Trees in deep Amazonian soils accumulate massive concentrations of trace mineral Selenium",
      "They contain iodine",
      "They contain synthetic tablets",
      "They have thyroid hormones"
    ],
    "optDe": [
      "Tiefwurzelnde Urwaldriesen im Amazonas reichern das Spurenelement Selen extrem an",
      "Enthalten Jod",
      "Enthalten synthetische Stoffe",
      "Enthalten Schilddrüsenhormone"
    ],
    "correct": 0,
    "expEn": "Just 1 to 2 Brazil nuts per day cover 100% of the adult human selenium requirement.",
    "expDe": "Bereits ein bis zwei Paranüsse täglich decken den menschlichen Selenbedarf vollständig."
  },
  {
    "id": "q_nut_17",
    "category": "nuts",
    "questionEn": "What is Poppy Seed filling (Mohnback) in Central European strudels and cakes?",
    "questionDe": "Wie wird Mohnsaat für Mohnstrudel verarbeitet, damit sie ihr Aroma entfaltet?",
    "optionsEn": [
      "Seeds must be crushed or ground in a poppy mill to crack hard seed coats and release fragrant milk oils",
      "Soaked in vinegar",
      "Fried in beef fat",
      "Eaten whole unground"
    ],
    "optionsDe": [
      "Blaumohn muss gequetscht oder gemahlen werden, um die harten Schalen zu brechen und Aromaöle freizusetzen",
      "In Essig eingelegt",
      "In Rinderfett gebraten",
      "Unzerkleinert gegessen"
    ],
    "correctIndex": 0,
    "explanationEn": "Whole poppy seeds pass through undigested; grinding releases rich, nutty, blue-black oil paste.",
    "explanationDe": "Erst gemahlen entfaltet Blaumohn seinen samtigen, nussig-herben Geschmack in Strudel und Kuchen.",
    "qEn": "What is Poppy Seed filling (Mohnback) in Central European strudels and cakes?",
    "qDe": "Wie wird Mohnsaat für Mohnstrudel verarbeitet, damit sie ihr Aroma entfaltet?",
    "optEn": [
      "Seeds must be crushed or ground in a poppy mill to crack hard seed coats and release fragrant milk oils",
      "Soaked in vinegar",
      "Fried in beef fat",
      "Eaten whole unground"
    ],
    "optDe": [
      "Blaumohn muss gequetscht oder gemahlen werden, um die harten Schalen zu brechen und Aromaöle freizusetzen",
      "In Essig eingelegt",
      "In Rinderfett gebraten",
      "Unzerkleinert gegessen"
    ],
    "correct": 0,
    "expEn": "Whole poppy seeds pass through undigested; grinding releases rich, nutty, blue-black oil paste.",
    "expDe": "Erst gemahlen entfaltet Blaumohn seinen samtigen, nussig-herben Geschmack in Strudel und Kuchen."
  },
  {
    "id": "q_nut_18",
    "category": "nuts",
    "questionEn": "What makes Pine Nut mouth (Pine Mouth syndrome) occur from inferior imports?",
    "questionDe": "Was löst das gefürchtete 'Pinienmund-Syndrom' bei minderwertigen Importen aus?",
    "optionsEn": [
      "Consuming non-culinary wild pine species (Pinus armandii) causing intense metallic bitter taste lasting 2 weeks",
      "Allergic shock",
      "Tooth decay",
      "Food poisoning from salmonella"
    ],
    "optionsDe": [
      "Verzehr ungeeigneter Wildkiefern (Pinus armandii); erzeugt tagelang anhaltenden metallischen Bittergeschmack",
      "Allergischer Schock",
      "Karies",
      "Salmonellen"
    ],
    "correctIndex": 0,
    "explanationEn": "Armand's pine nuts induce reversible trigeminal taste distortion; always purchase authentic Pinus pinea.",
    "explanationDe": "Minderwertige chinesische Kiefernnüsse können für Wochen jeden Bissen metallisch-bitter schmecken lassen.",
    "qEn": "What makes Pine Nut mouth (Pine Mouth syndrome) occur from inferior imports?",
    "qDe": "Was löst das gefürchtete 'Pinienmund-Syndrom' bei minderwertigen Importen aus?",
    "optEn": [
      "Consuming non-culinary wild pine species (Pinus armandii) causing intense metallic bitter taste lasting 2 weeks",
      "Allergic shock",
      "Tooth decay",
      "Food poisoning from salmonella"
    ],
    "optDe": [
      "Verzehr ungeeigneter Wildkiefern (Pinus armandii); erzeugt tagelang anhaltenden metallischen Bittergeschmack",
      "Allergischer Schock",
      "Karies",
      "Salmonellen"
    ],
    "correct": 0,
    "expEn": "Armand's pine nuts induce reversible trigeminal taste distortion; always purchase authentic Pinus pinea.",
    "expDe": "Minderwertige chinesische Kiefernnüsse können für Wochen jeden Bissen metallisch-bitter schmecken lassen."
  },
  {
    "id": "q_spi_01",
    "category": "spices_herbs",
    "questionEn": "Why is authentic Saffron (Crocus sativus) the most expensive spice in the world?",
    "questionDe": "Warum ist echter Safran das teuerste Gewürz der Welt?",
    "optionsEn": [
      "Each flower yields only three delicate red stigmas, hand-picked requiring 150,000 flowers per kilogram",
      "It grows on mountain peaks",
      "It is made of gold dust",
      "It is aged 100 years"
    ],
    "optionsDe": [
      "Jede Blüte trägt nur 3 zarte Narbenschenkel; für 1 kg werden rund 150.000 Blüten von Hand gepflückt",
      "Wächst nur auf Berggipfeln",
      "Besteht aus Blattgold",
      "Muss 100 Jahre lagern"
    ],
    "correctIndex": 0,
    "explanationEn": "Crocin provides intense yellow color; safranal imparts bitter honey aroma; picrocrocin adds hay-like piquancy.",
    "explanationDe": "Handarbeit im Morgengrauen: Crocin färbt intensiv goldgelb, Safranal schenkt den erdigen Duft.",
    "qEn": "Why is authentic Saffron (Crocus sativus) the most expensive spice in the world?",
    "qDe": "Warum ist echter Safran das teuerste Gewürz der Welt?",
    "optEn": [
      "Each flower yields only three delicate red stigmas, hand-picked requiring 150,000 flowers per kilogram",
      "It grows on mountain peaks",
      "It is made of gold dust",
      "It is aged 100 years"
    ],
    "optDe": [
      "Jede Blüte trägt nur 3 zarte Narbenschenkel; für 1 kg werden rund 150.000 Blüten von Hand gepflückt",
      "Wächst nur auf Berggipfeln",
      "Besteht aus Blattgold",
      "Muss 100 Jahre lagern"
    ],
    "correct": 0,
    "expEn": "Crocin provides intense yellow color; safranal imparts bitter honey aroma; picrocrocin adds hay-like piquancy.",
    "expDe": "Handarbeit im Morgengrauen: Crocin färbt intensiv goldgelb, Safranal schenkt den erdigen Duft."
  },
  {
    "id": "q_spi_02",
    "category": "spices_herbs",
    "questionEn": "What is the botanical difference between true Ceylon Cinnamon and Cassia Cinnamon?",
    "questionDe": "Was unterscheidet echten Ceylon-Zimt von billigem Cassia-Zimt?",
    "optionsEn": [
      "Ceylon has delicate paper-thin rolled layers and minimal coumarin; Cassia is a thick single hard bark roll high in coumarin",
      "Ceylon is toxic",
      "Cassia has no aroma",
      "Ceylon is red"
    ],
    "optionsDe": [
      "Ceylon-Zimt besteht aus hauchdünnen gerollten Schichten mit kaum Cumarin; Cassia ist eine dicke, harte Rinde mit viel Cumarin",
      "Ceylon ist giftig",
      "Cassia hat kein Aroma",
      "Ceylon ist knallrot"
    ],
    "correctIndex": 0,
    "explanationEn": "Cassia cinnamon contains liver-toxic coumarin; delicate Ceylon cinnamon (Cinnamomum verum) is refined and safe.",
    "explanationDe": "Echter Ceylon-Zimt schmeckt edel-süßlich; Cassia ist holzig-scharf und enthält leberbelastendes Cumarin.",
    "qEn": "What is the botanical difference between true Ceylon Cinnamon and Cassia Cinnamon?",
    "qDe": "Was unterscheidet echten Ceylon-Zimt von billigem Cassia-Zimt?",
    "optEn": [
      "Ceylon has delicate paper-thin rolled layers and minimal coumarin; Cassia is a thick single hard bark roll high in coumarin",
      "Ceylon is toxic",
      "Cassia has no aroma",
      "Ceylon is red"
    ],
    "optDe": [
      "Ceylon-Zimt besteht aus hauchdünnen gerollten Schichten mit kaum Cumarin; Cassia ist eine dicke, harte Rinde mit viel Cumarin",
      "Ceylon ist giftig",
      "Cassia hat kein Aroma",
      "Ceylon ist knallrot"
    ],
    "correct": 0,
    "expEn": "Cassia cinnamon contains liver-toxic coumarin; delicate Ceylon cinnamon (Cinnamomum verum) is refined and safe.",
    "expDe": "Echter Ceylon-Zimt schmeckt edel-süßlich; Cassia ist holzig-scharf und enthält leberbelastendes Cumarin."
  },
  {
    "id": "q_spi_03",
    "category": "spices_herbs",
    "questionEn": "What gives Tellicherry Garbled Extra Bold black pepper its reputation?",
    "questionDe": "Was zeichnet Tellicherry Black Pepper (TGSEB) von der Malabarküste aus?",
    "optionsEn": [
      "Berries are left to ripen fully on the vine until orange-red, yielding maximum piperine heat and floral citrus oils",
      "It is dried in ovens",
      "It is soaked in lime",
      "It has zero pungency"
    ],
    "optionsDe": [
      "Vollreif geerntete dicke Beeren von der Malabarküste mit intensivem Piperin und warm-fruchtigen Terpenen",
      "Wird im Ofen gedörrt",
      "In Kalk gebadet",
      "Hat keine Schärfe"
    ],
    "correctIndex": 0,
    "explanationEn": "Extra bold berries have a large surface-to-heat ratio, packed with pinene and limonene aromatics.",
    "explanationDe": "Spät geerntete Beeren entwickeln neben edler Pfefferschärfe tiefe Noten von Waldbeeren und Holz.",
    "qEn": "What gives Tellicherry Garbled Extra Bold black pepper its reputation?",
    "qDe": "Was zeichnet Tellicherry Black Pepper (TGSEB) von der Malabarküste aus?",
    "optEn": [
      "Berries are left to ripen fully on the vine until orange-red, yielding maximum piperine heat and floral citrus oils",
      "It is dried in ovens",
      "It is soaked in lime",
      "It has zero pungency"
    ],
    "optDe": [
      "Vollreif geerntete dicke Beeren von der Malabarküste mit intensivem Piperin und warm-fruchtigen Terpenen",
      "Wird im Ofen gedörrt",
      "In Kalk gebadet",
      "Hat keine Schärfe"
    ],
    "correct": 0,
    "expEn": "Extra bold berries have a large surface-to-heat ratio, packed with pinene and limonene aromatics.",
    "expDe": "Spät geerntete Beeren entwickeln neben edler Pfefferschärfe tiefe Noten von Waldbeeren und Holz."
  },
  {
    "id": "q_spi_04",
    "category": "spices_herbs",
    "questionEn": "What active compound gives fresh Chili peppers their fiery heat on the Scoville scale?",
    "questionDe": "Welcher Inhaltsstoff erzeugt die brennende Schärfe in Chilis auf der Scoville-Skala?",
    "optionsEn": [
      "Capsaicin, which binds to heat and pain receptors (TRPV1) on the tongue",
      "Piperine",
      "Gingerol",
      "Sinigrin"
    ],
    "optionsDe": [
      "Capsaicin, das die Hitzerezeptoren (TRPV1) auf der Zunge stimuliert",
      "Piperin",
      "Gingerol",
      "Sinigrin"
    ],
    "correctIndex": 0,
    "explanationEn": "Capsaicin tricks nerve endings into perceiving burning heat (>43°C); dairy casein dissolves it best.",
    "explanationDe": "Capsaicin täuscht dem Gehirn Verbrennungshitze vor; Milchfett und Kasein lindern das Brennen.",
    "qEn": "What active compound gives fresh Chili peppers their fiery heat on the Scoville scale?",
    "qDe": "Welcher Inhaltsstoff erzeugt die brennende Schärfe in Chilis auf der Scoville-Skala?",
    "optEn": [
      "Capsaicin, which binds to heat and pain receptors (TRPV1) on the tongue",
      "Piperine",
      "Gingerol",
      "Sinigrin"
    ],
    "optDe": [
      "Capsaicin, das die Hitzerezeptoren (TRPV1) auf der Zunge stimuliert",
      "Piperin",
      "Gingerol",
      "Sinigrin"
    ],
    "correct": 0,
    "expEn": "Capsaicin tricks nerve endings into perceiving burning heat (>43°C); dairy casein dissolves it best.",
    "expDe": "Capsaicin täuscht dem Gehirn Verbrennungshitze vor; Milchfett und Kasein lindern das Brennen."
  },
  {
    "id": "q_spi_05",
    "category": "spices_herbs",
    "questionEn": "Why should whole spices (cumin, coriander, cardamom) be dry-toasted in a pan before grinding?",
    "questionDe": "Warum sollten ganze Gewürze (Kreuzkümmel, Koriander) vor dem Mahlen trocken angeröstet werden?",
    "optionsEn": [
      "Dry heat volatilizes essential oils and generates pyrazines, intensifying aroma depth dramatically",
      "To burn off germs",
      "To dry out mold",
      "To turn them black"
    ],
    "optionsDe": [
      "Hitze setzt ätherische Öle frei und bildet durch Maillard-Reaktion intensive Röst-Pyrazine",
      "Um Keime zu verbrennen",
      "Gegen Schimmel",
      "Damit sie schwarz werden"
    ],
    "correctIndex": 0,
    "explanationEn": "Roasting cracks outer cell walls and activates dormant aroma compounds before crushing.",
    "explanationDe": "Kurzes Rösten ohne Fett weckt schlafende Aromen und vertieft die Würzkraft um ein Vielfaches.",
    "qEn": "Why should whole spices (cumin, coriander, cardamom) be dry-toasted in a pan before grinding?",
    "qDe": "Warum sollten ganze Gewürze (Kreuzkümmel, Koriander) vor dem Mahlen trocken angeröstet werden?",
    "optEn": [
      "Dry heat volatilizes essential oils and generates pyrazines, intensifying aroma depth dramatically",
      "To burn off germs",
      "To dry out mold",
      "To turn them black"
    ],
    "optDe": [
      "Hitze setzt ätherische Öle frei und bildet durch Maillard-Reaktion intensive Röst-Pyrazine",
      "Um Keime zu verbrennen",
      "Gegen Schimmel",
      "Damit sie schwarz werden"
    ],
    "correct": 0,
    "expEn": "Roasting cracks outer cell walls and activates dormant aroma compounds before crushing.",
    "expDe": "Kurzes Rösten ohne Fett weckt schlafende Aromen und vertieft die Würzkraft um ein Vielfaches."
  },
  {
    "id": "q_spi_06",
    "category": "spices_herbs",
    "questionEn": "What is the difference between Green Cardamom and Black Cardamom?",
    "questionDe": "Wie unterscheidet sich Grüner Kardamom von Schwarzem Kardamom?",
    "optionsEn": [
      "Green cardamom is sweet, floral, and herbal; Black cardamom is dried over open wood fires, yielding deep smoky camphor notes",
      "Black cardamom is dyed",
      "Green cardamom is spicy like chili",
      "Black cardamom is sweet vanilla"
    ],
    "optionsDe": [
      "Grüner Kardamom schmeckt blumig-eukalyptisch; Schwarzer Kardamom wird über Holzfeuer getrocknet und schmeckt rauchig-harzig",
      "Schwarzer Kardamom ist gefärbt",
      "Grün ist scharf wie Chili",
      "Schwarz schmeckt nach Vanille"
    ],
    "correctIndex": 0,
    "explanationEn": "Black cardamom (Amomum subulatum) is essential for rustic North Indian curries and Vietnamese Pho broth.",
    "explanationDe": "Schwarzer Kardamom bringt Rauch und Harz in Schmorgerichte; grüner Kardamom verfeinert Süßspeisen.",
    "qEn": "What is the difference between Green Cardamom and Black Cardamom?",
    "qDe": "Wie unterscheidet sich Grüner Kardamom von Schwarzem Kardamom?",
    "optEn": [
      "Green cardamom is sweet, floral, and herbal; Black cardamom is dried over open wood fires, yielding deep smoky camphor notes",
      "Black cardamom is dyed",
      "Green cardamom is spicy like chili",
      "Black cardamom is sweet vanilla"
    ],
    "optDe": [
      "Grüner Kardamom schmeckt blumig-eukalyptisch; Schwarzer Kardamom wird über Holzfeuer getrocknet und schmeckt rauchig-harzig",
      "Schwarzer Kardamom ist gefärbt",
      "Grün ist scharf wie Chili",
      "Schwarz schmeckt nach Vanille"
    ],
    "correct": 0,
    "expEn": "Black cardamom (Amomum subulatum) is essential for rustic North Indian curries and Vietnamese Pho broth.",
    "expDe": "Schwarzer Kardamom bringt Rauch und Harz in Schmorgerichte; grüner Kardamom verfeinert Süßspeisen."
  },
  {
    "id": "q_spi_07",
    "category": "spices_herbs",
    "questionEn": "What gives freshly grated Nutmeg (Muskatnuss) its warm aroma and why should it be used sparingly?",
    "questionDe": "Welcher Stoff prägt das Aroma der Muskatnuss und warum sollte man sie sparsam dosieren?",
    "optionsEn": [
      "Myristicin and elemicin provide warm sweet depth, but in large doses (5g+) act as a toxic psychoactive hallucinogen",
      "Arsenic",
      "Caffeine",
      "Cyanide"
    ],
    "optionsDe": [
      "Myristicin verleiht den warmen Duft, wirkt aber in hohen Dosen (ab 5g) toxisch und halluzinogen",
      "Arsen",
      "Koffein",
      "Blausäure"
    ],
    "correctIndex": 0,
    "explanationEn": "A pinch enhances mashed potatoes and béchamel; excess causes nausea and toxicity.",
    "explanationDe": "Eine feine Prise adelt Kartoffelpüree; löffelweise verzehrt wirkt Muskat als Rauschgift.",
    "qEn": "What gives freshly grated Nutmeg (Muskatnuss) its warm aroma and why should it be used sparingly?",
    "qDe": "Welcher Stoff prägt das Aroma der Muskatnuss und warum sollte man sie sparsam dosieren?",
    "optEn": [
      "Myristicin and elemicin provide warm sweet depth, but in large doses (5g+) act as a toxic psychoactive hallucinogen",
      "Arsenic",
      "Caffeine",
      "Cyanide"
    ],
    "optDe": [
      "Myristicin verleiht den warmen Duft, wirkt aber in hohen Dosen (ab 5g) toxisch und halluzinogen",
      "Arsen",
      "Koffein",
      "Blausäure"
    ],
    "correct": 0,
    "expEn": "A pinch enhances mashed potatoes and béchamel; excess causes nausea and toxicity.",
    "expDe": "Eine feine Prise adelt Kartoffelpüree; löffelweise verzehrt wirkt Muskat als Rauschgift."
  },
  {
    "id": "q_spi_08",
    "category": "spices_herbs",
    "questionEn": "What is Star Anise (Sternanis) and which Asian classic spice blend features it?",
    "questionDe": "Was ist Sternanis und in welcher klassischen asiatischen Gewürzmischung ist er unverzichtbar?",
    "optionsEn": [
      "The dried star fruit of Illicium verum, providing anethole sweetness in Chinese Five-Spice and Vietnamese Pho",
      "A root related to ginger",
      "Caraway seeds pressed into stars",
      "Anise seeds mixed with sugar"
    ],
    "optionsDe": [
      "Die sternförmige Frucht von Illicium verum; Hauptbestandteil des chinesischen Fünf-Gewürze-Pulvers und von Pho",
      "Eine Ingwerwurzel",
      "Aus Kümmel gepresst",
      "Anissamen mit Zucker"
    ],
    "correctIndex": 0,
    "explanationEn": "Contains high levels of sweet anethole, imparting liquorice notes to braised pork belly and broths.",
    "explanationDe": "Sternanis duftet intensiv nach Lakritz und verleiht geschmortem Schweinebauch seinen Glanz.",
    "qEn": "What is Star Anise (Sternanis) and which Asian classic spice blend features it?",
    "qDe": "Was ist Sternanis und in welcher klassischen asiatischen Gewürzmischung ist er unverzichtbar?",
    "optEn": [
      "The dried star fruit of Illicium verum, providing anethole sweetness in Chinese Five-Spice and Vietnamese Pho",
      "A root related to ginger",
      "Caraway seeds pressed into stars",
      "Anise seeds mixed with sugar"
    ],
    "optDe": [
      "Die sternförmige Frucht von Illicium verum; Hauptbestandteil des chinesischen Fünf-Gewürze-Pulvers und von Pho",
      "Eine Ingwerwurzel",
      "Aus Kümmel gepresst",
      "Anissamen mit Zucker"
    ],
    "correct": 0,
    "expEn": "Contains high levels of sweet anethole, imparting liquorice notes to braised pork belly and broths.",
    "expDe": "Sternanis duftet intensiv nach Lakritz und verleiht geschmortem Schweinebauch seinen Glanz."
  },
  {
    "id": "q_spi_09",
    "category": "spices_herbs",
    "questionEn": "What active ginger compound transforms from fresh gingerol into sweeter shogaol when dried or cooked?",
    "questionDe": "Welcher Schärfestoff in frischem Ingwer wandelt sich beim Kochen und Trocknen in würziges Shogaol um?",
    "optionsEn": [
      "Gingerol",
      "Capsaicin",
      "Curcumin",
      "Menthol"
    ],
    "optionsDe": [
      "Gingerol",
      "Capsaicin",
      "Curcumin",
      "Menthol"
    ],
    "correctIndex": 0,
    "explanationEn": "Cooking or dehydration converts gingerol into shogaol, which is twice as pungent and deeply warming.",
    "explanationDe": "Frischer Ingwer schmeckt spritzig-scharf (Gingerol); getrockneter Ingwer heizt tiefer ein (Shogaol).",
    "qEn": "What active ginger compound transforms from fresh gingerol into sweeter shogaol when dried or cooked?",
    "qDe": "Welcher Schärfestoff in frischem Ingwer wandelt sich beim Kochen und Trocknen in würziges Shogaol um?",
    "optEn": [
      "Gingerol",
      "Capsaicin",
      "Curcumin",
      "Menthol"
    ],
    "optDe": [
      "Gingerol",
      "Capsaicin",
      "Curcumin",
      "Menthol"
    ],
    "correct": 0,
    "expEn": "Cooking or dehydration converts gingerol into shogaol, which is twice as pungent and deeply warming.",
    "expDe": "Frischer Ingwer schmeckt spritzig-scharf (Gingerol); getrockneter Ingwer heizt tiefer ein (Shogaol)."
  },
  {
    "id": "q_spi_10",
    "category": "spices_herbs",
    "questionEn": "What gives pure Vanilla beans (Vanilla planifolia) their legendary aroma?",
    "questionDe": "Welcher Stoff prägt das Bouquet echter Bourbon-Vanilleschoten?",
    "optionsEn": [
      "Vanillin and over 250 volatile aromatic esters developed during slow sweat curing of orchid seed pods",
      "Caramel sugar",
      "Clove oil",
      "Nutmeg essence"
    ],
    "optionsDe": [
      "Vanillin und über 250 Begleit-Aromen, gebildet beim monatelangen Fermentieren der Orchideenkapseln",
      "Karamellzucker",
      "Nelkenöl",
      "Muskatessenz"
    ],
    "correctIndex": 0,
    "explanationEn": "Synthetic vanillin lacks the smoky, prune, floral, and woody complexity of whole fermented beans.",
    "explanationDe": "Echte Orchideenschoten reifen monatelang in der Sonne, bis sich weiße Vanillinkristalle bilden.",
    "qEn": "What gives pure Vanilla beans (Vanilla planifolia) their legendary aroma?",
    "qDe": "Welcher Stoff prägt das Bouquet echter Bourbon-Vanilleschoten?",
    "optEn": [
      "Vanillin and over 250 volatile aromatic esters developed during slow sweat curing of orchid seed pods",
      "Caramel sugar",
      "Clove oil",
      "Nutmeg essence"
    ],
    "optDe": [
      "Vanillin und über 250 Begleit-Aromen, gebildet beim monatelangen Fermentieren der Orchideenkapseln",
      "Karamellzucker",
      "Nelkenöl",
      "Muskatessenz"
    ],
    "correct": 0,
    "expEn": "Synthetic vanillin lacks the smoky, prune, floral, and woody complexity of whole fermented beans.",
    "expDe": "Echte Orchideenschoten reifen monatelang in der Sonne, bis sich weiße Vanillinkristalle bilden."
  },
  {
    "id": "q_spi_11",
    "category": "spices_herbs",
    "questionEn": "What is Sumac in Middle Eastern and Levantine cooking?",
    "questionDe": "Was ist Sumach in der levantinischen Küche?",
    "optionsEn": [
      "Coarsely ground dried red berries of Rhus coriaria, offering a fruity, tangy citrus acid kick without liquid",
      "Hot red chili powder",
      "Ground pomegranate seeds",
      "Red salt"
    ],
    "optionsDe": [
      "Gerebelte getrocknete Steinfrüchte des Färberbaums mit fruchtig-zitroniger Säure ohne Flüssigkeitseintrag",
      "Scharfes Chilipulver",
      "Granatapfelkerne",
      "Rotes Wüstensalz"
    ],
    "correctIndex": 0,
    "explanationEn": "Sumac contains malic and citric acids, dusted over grilled meats, hummus, and fattoush salads.",
    "explanationDe": "Sumach ersetzt Zitronensaft auf gegrilltem Lamm, Zwiebelsalat und Dips ohne das Gericht zu wässern.",
    "qEn": "What is Sumac in Middle Eastern and Levantine cooking?",
    "qDe": "Was ist Sumach in der levantinischen Küche?",
    "optEn": [
      "Coarsely ground dried red berries of Rhus coriaria, offering a fruity, tangy citrus acid kick without liquid",
      "Hot red chili powder",
      "Ground pomegranate seeds",
      "Red salt"
    ],
    "optDe": [
      "Gerebelte getrocknete Steinfrüchte des Färberbaums mit fruchtig-zitroniger Säure ohne Flüssigkeitseintrag",
      "Scharfes Chilipulver",
      "Granatapfelkerne",
      "Rotes Wüstensalz"
    ],
    "correct": 0,
    "expEn": "Sumac contains malic and citric acids, dusted over grilled meats, hummus, and fattoush salads.",
    "expDe": "Sumach ersetzt Zitronensaft auf gegrilltem Lamm, Zwiebelsalat und Dips ohne das Gericht zu wässern."
  },
  {
    "id": "q_spi_12",
    "category": "spices_herbs",
    "questionEn": "What is the defining fresh herb in authentic Greek cuisine and Italian tomato sauces?",
    "questionDe": "Welches sonnige Kraut bildet das Herz der mediterranen Tomatengerichte und Pizza?",
    "optionsEn": [
      "Oregano (Origanum vulgare / Origanum dictamnus)",
      "Dill",
      "Tarragon",
      "Mint"
    ],
    "optionsDe": [
      "Oregano (Origanum vulgare / Echter Dost)",
      "Dill",
      "Estragon",
      "Pfefferminze"
    ],
    "correctIndex": 0,
    "explanationEn": "Carvacrol and thymol terpenes intensify when dried, blooming powerfully in hot olive oil.",
    "explanationDe": "Oregano ist eines der wenigen Kräuter, das getrocknet noch intensiver und feuriger schmeckt.",
    "qEn": "What is the defining fresh herb in authentic Greek cuisine and Italian tomato sauces?",
    "qDe": "Welches sonnige Kraut bildet das Herz der mediterranen Tomatengerichte und Pizza?",
    "optEn": [
      "Oregano (Origanum vulgare / Origanum dictamnus)",
      "Dill",
      "Tarragon",
      "Mint"
    ],
    "optDe": [
      "Oregano (Origanum vulgare / Echter Dost)",
      "Dill",
      "Estragon",
      "Pfefferminze"
    ],
    "correct": 0,
    "expEn": "Carvacrol and thymol terpenes intensify when dried, blooming powerfully in hot olive oil.",
    "expDe": "Oregano ist eines der wenigen Kräuter, das getrocknet noch intensiver und feuriger schmeckt."
  },
  {
    "id": "q_spi_13",
    "category": "spices_herbs",
    "questionEn": "What gives Rosemary (Rosmarin) its needle-like resilience and piney balsam aroma?",
    "questionDe": "Was verleiht Rosmarin seine nadelartige Robustheit und sein waldig-harziges Aroma?",
    "optionsEn": [
      "High concentration of camphor, cineole, and pinene essential oils in leathery drought-adapted leaves",
      "High sugar sap",
      "Salt crystals",
      "Vinegar sap"
    ],
    "optionsDe": [
      "Hohe Konzentration an Campher, Cineol und Pinen in den lederartigen Schutzblättern",
      "Süßer Pflanzensaft",
      "Salzkristalle",
      "Essigsäure"
    ],
    "correctIndex": 0,
    "explanationEn": "Rosemary infuses roasted potatoes and lamb without wilting; carnosic acid acts as a natural antioxidant.",
    "explanationDe": "Die ätherischen Öle halten selbst langen Ofengarzeiten stand und schützen Bratfette vor Oxidation.",
    "qEn": "What gives Rosemary (Rosmarin) its needle-like resilience and piney balsam aroma?",
    "qDe": "Was verleiht Rosmarin seine nadelartige Robustheit und sein waldig-harziges Aroma?",
    "optEn": [
      "High concentration of camphor, cineole, and pinene essential oils in leathery drought-adapted leaves",
      "High sugar sap",
      "Salt crystals",
      "Vinegar sap"
    ],
    "optDe": [
      "Hohe Konzentration an Campher, Cineol und Pinen in den lederartigen Schutzblättern",
      "Süßer Pflanzensaft",
      "Salzkristalle",
      "Essigsäure"
    ],
    "correct": 0,
    "expEn": "Rosemary infuses roasted potatoes and lamb without wilting; carnosic acid acts as a natural antioxidant.",
    "expDe": "Die ätherischen Öle halten selbst langen Ofengarzeiten stand und schützen Bratfette vor Oxidation."
  },
  {
    "id": "q_spi_14",
    "category": "spices_herbs",
    "questionEn": "What is Za'atar spice blend in the Levant?",
    "questionDe": "Woraus besteht die traditionelle orientalische Gewürzmischung Za'atar?",
    "optionsEn": [
      "Wild thyme/oregano, toasted sesame seeds, ground tart sumac, and sea salt",
      "Chili, garlic, and cumin",
      "Curry, turmeric, and ginger",
      "Cinnamon, cardamom, and clove"
    ],
    "optionsDe": [
      "Wilder Thymian/Bibernelle, geröstete Sesamsamen, fruchtiger Sumach und Meersalz",
      "Chili, Knoblauch und Kreuzkümmel",
      "Curry, Kurkuma und Ingwer",
      "Zimt, Kardamom und Nelken"
    ],
    "correctIndex": 0,
    "explanationEn": "Dipper with fresh pita bread in extra virgin olive oil for breakfast throughout the Middle East.",
    "explanationDe": "In Olivenöl getunkt und mit warmem Fladenbrot genossen: der Duft der Levante.",
    "qEn": "What is Za'atar spice blend in the Levant?",
    "qDe": "Woraus besteht die traditionelle orientalische Gewürzmischung Za'atar?",
    "optEn": [
      "Wild thyme/oregano, toasted sesame seeds, ground tart sumac, and sea salt",
      "Chili, garlic, and cumin",
      "Curry, turmeric, and ginger",
      "Cinnamon, cardamom, and clove"
    ],
    "optDe": [
      "Wilder Thymian/Bibernelle, geröstete Sesamsamen, fruchtiger Sumach und Meersalz",
      "Chili, Knoblauch und Kreuzkümmel",
      "Curry, Kurkuma und Ingwer",
      "Zimt, Kardamom und Nelken"
    ],
    "correct": 0,
    "expEn": "Dipper with fresh pita bread in extra virgin olive oil for breakfast throughout the Middle East.",
    "expDe": "In Olivenöl getunkt und mit warmem Fladenbrot genossen: der Duft der Levante."
  },
  {
    "id": "q_spi_15",
    "category": "spices_herbs",
    "questionEn": "Why must delicate herbs (basil, chervil, cilantro) be added at the very end of cooking?",
    "questionDe": "Warum sollten zarte Kräuter (Basilikum, Kerbel, Koriander) erst kurz vor dem Servieren zugegeben werden?",
    "optionsEn": [
      "Their delicate volatile essential oils (linalool, estragole) evaporate quickly and heat turns leaves bitter and brown",
      "They turn poisonous when boiled",
      "They dissolve water into steam",
      "They absorb all salt"
    ],
    "optionsDe": [
      "Ihre flüchtigen ätherischen Öle verdampfen bei Hitze rasch und die Blätter werden braun und bitter",
      "Sie werden beim Kochen giftig",
      "Sie lösen Wasser auf",
      "Sie schlucken das Salz"
    ],
    "correctIndex": 0,
    "explanationEn": "Heat destroys fresh green top notes; stir in off the flame to preserve garden vibrancy.",
    "explanationDe": "Hitze zerstört die feinen Aromen; zarte Kräuter immer erst beim Anrichten über das Gericht streuen.",
    "qEn": "Why must delicate herbs (basil, chervil, cilantro) be added at the very end of cooking?",
    "qDe": "Warum sollten zarte Kräuter (Basilikum, Kerbel, Koriander) erst kurz vor dem Servieren zugegeben werden?",
    "optEn": [
      "Their delicate volatile essential oils (linalool, estragole) evaporate quickly and heat turns leaves bitter and brown",
      "They turn poisonous when boiled",
      "They dissolve water into steam",
      "They absorb all salt"
    ],
    "optDe": [
      "Ihre flüchtigen ätherischen Öle verdampfen bei Hitze rasch und die Blätter werden braun und bitter",
      "Sie werden beim Kochen giftig",
      "Sie lösen Wasser auf",
      "Sie schlucken das Salz"
    ],
    "correct": 0,
    "expEn": "Heat destroys fresh green top notes; stir in off the flame to preserve garden vibrancy.",
    "expDe": "Hitze zerstört die feinen Aromen; zarte Kräuter immer erst beim Anrichten über das Gericht streuen."
  },
  {
    "id": "q_spi_16",
    "category": "spices_herbs",
    "questionEn": "What active compound gives Cloves (Gewürznelken) their intense numbing antiseptic flavor?",
    "questionDe": "Welcher Aromastoff dominiert in getrockneten Gewürznelken (Syzygium aromaticum)?",
    "optionsEn": [
      "Eugenol (making up 70-90% of clove essential oil)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "optionsDe": [
      "Eugenol (macht bis zu 90% des ätherischen Nelkenöls aus)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "correctIndex": 0,
    "explanationEn": "Eugenol has natural local anesthetic and antimicrobial properties, starring in glühwein and braised meats.",
    "explanationDe": "Eugenol betäubt sanft die Zunge und wärmt klassisch in Rotkohl, Lebkuchen und Glühwein.",
    "qEn": "What active compound gives Cloves (Gewürznelken) their intense numbing antiseptic flavor?",
    "qDe": "Welcher Aromastoff dominiert in getrockneten Gewürznelken (Syzygium aromaticum)?",
    "optEn": [
      "Eugenol (making up 70-90% of clove essential oil)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "optDe": [
      "Eugenol (macht bis zu 90% des ätherischen Nelkenöls aus)",
      "Menthol",
      "Thymol",
      "Vanillin"
    ],
    "correct": 0,
    "expEn": "Eugenol has natural local anesthetic and antimicrobial properties, starring in glühwein and braised meats.",
    "expDe": "Eugenol betäubt sanft die Zunge und wärmt klassisch in Rotkohl, Lebkuchen und Glühwein."
  },
  {
    "id": "q_spi_17",
    "category": "spices_herbs",
    "questionEn": "Why does freshly grated Horseradish (Meerrettich / Kren) produce a stinging nasal sensation?",
    "questionDe": "Was erzeugt das typische Stechen in der Nase bei frisch geriebenem Kren (Meerrettich)?",
    "optionsEn": [
      "Glucosinolate sinigrin is cleaved into volatile allyl isothiocyanate, identical to wasabi",
      "Capsaicin gas",
      "Black pepper fumes",
      "Acetic acid"
    ],
    "optionsDe": [
      "Das Senfölglykosid Sinigrin wird beim Reiben enzymatisch in flüchtiges Allylisothiocyanat gespalten",
      "Capsaicingas",
      "Pfefferstaub",
      "Essigdampf"
    ],
    "correctIndex": 0,
    "explanationEn": "Isothiocyanates evaporate and rise into the olfactory nasopharynx, clearing sinuses instantly.",
    "explanationDe": "Das flüchtige Senföl reizt die Nasenschleimhaut, verbrennt aber im Gegensatz zu Chili nicht die Zunge.",
    "qEn": "Why does freshly grated Horseradish (Meerrettich / Kren) produce a stinging nasal sensation?",
    "qDe": "Was erzeugt das typische Stechen in der Nase bei frisch geriebenem Kren (Meerrettich)?",
    "optEn": [
      "Glucosinolate sinigrin is cleaved into volatile allyl isothiocyanate, identical to wasabi",
      "Capsaicin gas",
      "Black pepper fumes",
      "Acetic acid"
    ],
    "optDe": [
      "Das Senfölglykosid Sinigrin wird beim Reiben enzymatisch in flüchtiges Allylisothiocyanat gespalten",
      "Capsaicingas",
      "Pfefferstaub",
      "Essigdampf"
    ],
    "correct": 0,
    "expEn": "Isothiocyanates evaporate and rise into the olfactory nasopharynx, clearing sinuses instantly.",
    "expDe": "Das flüchtige Senföl reizt die Nasenschleimhaut, verbrennt aber im Gegensatz zu Chili nicht die Zunge."
  },
  {
    "id": "q_spi_18",
    "category": "spices_herbs",
    "questionEn": "What is Juniper berry (Wacholderbeere) botanically and culinarily?",
    "questionDe": "Was ist die Wacholderbeere botanisch und gastronomisch?",
    "optionsEn": [
      "The female seed cone of Juniperus communis with fleshy merged scales, packed with pinene for game and sauerkraut",
      "A true stone fruit",
      "A citrus berry",
      "A dried mushroom"
    ],
    "optionsDe": [
      "Der fleischig verwachsene weibliche Zapfen von Juniperus communis; reich an waldigen Pinenen",
      "Eine echte Steinbeere",
      "Eine Zitrusfrucht",
      "Ein getrockneter Pilz"
    ],
    "correctIndex": 0,
    "explanationEn": "Juniper cuts through rich game fats (venison, wild boar) and gives London Dry Gin its defining identity.",
    "explanationDe": "Wacholder bändigt fettes Wildbret und verleiht Sauerkraut sowie Gin den typischen Nadelwald-Charakter.",
    "qEn": "What is Juniper berry (Wacholderbeere) botanically and culinarily?",
    "qDe": "Was ist die Wacholderbeere botanisch und gastronomisch?",
    "optEn": [
      "The female seed cone of Juniperus communis with fleshy merged scales, packed with pinene for game and sauerkraut",
      "A true stone fruit",
      "A citrus berry",
      "A dried mushroom"
    ],
    "optDe": [
      "Der fleischig verwachsene weibliche Zapfen von Juniperus communis; reich an waldigen Pinenen",
      "Eine echte Steinbeere",
      "Eine Zitrusfrucht",
      "Ein getrockneter Pilz"
    ],
    "correct": 0,
    "expEn": "Juniper cuts through rich game fats (venison, wild boar) and gives London Dry Gin its defining identity.",
    "expDe": "Wacholder bändigt fettes Wildbret und verleiht Sauerkraut sowie Gin den typischen Nadelwald-Charakter."
  },
  {
    "id": "q_oli_01",
    "category": "olives",
    "questionEn": "Why can fresh olives never be eaten straight from the olive tree?",
    "questionDe": "Warum kann man frisch geerntete Oliven niemals direkt vom Baum essen?",
    "optionsEn": [
      "They contain extremely bitter phenolic glycoside Oleuropein, which must be cured or brined out to become palatable",
      "They are rock-hard wood",
      "They contain snake venom",
      "They are sour like vinegar"
    ],
    "optionsDe": [
      "Sie enthalten das extrem bittere Phenolglykosid Oleuropein, das erst durch Wässern oder Salzen entbittert werden muss",
      "Sie sind hart wie Stein",
      "Sie enthalten Schlangengift",
      "Sie schmecken sauer wie Essig"
    ],
    "correctIndex": 0,
    "explanationEn": "Oleuropein protects olives from pests; water, brine, or lye curing leaches it out over weeks.",
    "explanationDe": "Frische Oliven schmecken unerträglich gallenbitter; traditionelles Einlegen baut das Oleuropein ab.",
    "qEn": "Why can fresh olives never be eaten straight from the olive tree?",
    "qDe": "Warum kann man frisch geerntete Oliven niemals direkt vom Baum essen?",
    "optEn": [
      "They contain extremely bitter phenolic glycoside Oleuropein, which must be cured or brined out to become palatable",
      "They are rock-hard wood",
      "They contain snake venom",
      "They are sour like vinegar"
    ],
    "optDe": [
      "Sie enthalten das extrem bittere Phenolglykosid Oleuropein, das erst durch Wässern oder Salzen entbittert werden muss",
      "Sie sind hart wie Stein",
      "Sie enthalten Schlangengift",
      "Sie schmecken sauer wie Essig"
    ],
    "correct": 0,
    "expEn": "Oleuropein protects olives from pests; water, brine, or lye curing leaches it out over weeks.",
    "expDe": "Frische Oliven schmecken unerträglich gallenbitter; traditionelles Einlegen baut das Oleuropein ab."
  },
  {
    "id": "q_oli_02",
    "category": "olives",
    "questionEn": "What distinguishes Kalamata Olives PDO from Greece?",
    "questionDe": "Was zeichnet echte griechische Kalamata-Oliven g.U. aus?",
    "optionsEn": [
      "Almond-shaped, deep aubergine/purple color, cured in red wine vinegar and olive oil brine, with fruity wine tang",
      "Artificially dyed black",
      "Stuffed with cheese on the tree",
      "Small green round shape"
    ],
    "optionsDe": [
      "Mandelförmig, tiefviolett gereift, in Rotweinessig und Salzlake entbittert, fruchtig-fleischig mit Weinnote",
      "Mit Eisensalz schwarz gefärbt",
      "Am Baum mit Käse gefüllt",
      "Winzig klein und rund"
    ],
    "correctIndex": 0,
    "explanationEn": "Harvested fully ripe by hand in Messinia; red wine vinegar curing creates signature savory acidity.",
    "explanationDe": "Vollreif geerntet und mit Weinessig veredelt: die Königin der griechischen Tafeloliven.",
    "qEn": "What distinguishes Kalamata Olives PDO from Greece?",
    "qDe": "Was zeichnet echte griechische Kalamata-Oliven g.U. aus?",
    "optEn": [
      "Almond-shaped, deep aubergine/purple color, cured in red wine vinegar and olive oil brine, with fruity wine tang",
      "Artificially dyed black",
      "Stuffed with cheese on the tree",
      "Small green round shape"
    ],
    "optDe": [
      "Mandelförmig, tiefviolett gereift, in Rotweinessig und Salzlake entbittert, fruchtig-fleischig mit Weinnote",
      "Mit Eisensalz schwarz gefärbt",
      "Am Baum mit Käse gefüllt",
      "Winzig klein und rund"
    ],
    "correct": 0,
    "expEn": "Harvested fully ripe by hand in Messinia; red wine vinegar curing creates signature savory acidity.",
    "expDe": "Vollreif geerntet und mit Weinessig veredelt: die Königin der griechischen Tafeloliven."
  },
  {
    "id": "q_oli_03",
    "category": "olives",
    "questionEn": "What is the green Castelvetrano (Nocellara del Belice) olive from Sicily celebrated for?",
    "questionDe": "Wofür ist die leuchtend grüne Nocellara del Belice (Castelvetrano) aus Sizilien berühmt?",
    "optionsEn": [
      "Vibrant emerald green color, crisp buttery crunch, and sweet mild nutty taste cured using the gentle Castelvetrano lye method",
      "Extremely sour taste",
      "Hard wooden core",
      "Cooked in tomato sauce"
    ],
    "optionsDe": [
      "Smaragdgrüne Farbe, knackig-buttriger Biss und süßlich-milder Geschmack durch milde Laugenentbitterung",
      "Extrem sauer",
      "Harter Kern",
      "In Tomatensauce gekocht"
    ],
    "correctIndex": 0,
    "explanationEn": "Gentle sodium hydroxide wash followed by rapid cold rinsing preserves raw bright green crunch.",
    "explanationDe": "Die milde Entbitterung bewahrt das saftige, buttrige Fruchtfleisch ohne beißende Salzigkeit.",
    "qEn": "What is the green Castelvetrano (Nocellara del Belice) olive from Sicily celebrated for?",
    "qDe": "Wofür ist die leuchtend grüne Nocellara del Belice (Castelvetrano) aus Sizilien berühmt?",
    "optEn": [
      "Vibrant emerald green color, crisp buttery crunch, and sweet mild nutty taste cured using the gentle Castelvetrano lye method",
      "Extremely sour taste",
      "Hard wooden core",
      "Cooked in tomato sauce"
    ],
    "optDe": [
      "Smaragdgrüne Farbe, knackig-buttriger Biss und süßlich-milder Geschmack durch milde Laugenentbitterung",
      "Extrem sauer",
      "Harter Kern",
      "In Tomatensauce gekocht"
    ],
    "correct": 0,
    "expEn": "Gentle sodium hydroxide wash followed by rapid cold rinsing preserves raw bright green crunch.",
    "expDe": "Die milde Entbitterung bewahrt das saftige, buttrige Fruchtfleisch ohne beißende Salzigkeit."
  },
  {
    "id": "q_oli_04",
    "category": "olives",
    "questionEn": "How can one tell naturally tree-ripened black olives from artificially blackened olives?",
    "questionDe": "Woran erkennt man naturreife schwarze Oliven im Vergleich zu chemisch geschwärzten Oliven?",
    "optionsEn": [
      "Artificially blackened olives are jet-black green olives oxidized with air and fixed with Ferrous gluconate (E579)",
      "Natural black olives are square",
      "Blackened olives have no stones",
      "Natural black olives are green inside"
    ],
    "optionsDe": [
      "Geschwärzte Oliven sind pechschwarz mit glatter Haut und enthalten Stabilisator Eisengluconat (E579)",
      "Echte schwarze Oliven sind viereckig",
      "Geschwärzte haben keine Kerne",
      "Naturreife sind innen weiß"
    ],
    "correctIndex": 0,
    "explanationEn": "Naturally ripe black olives have shriveled, matte skin and shades of purple, brown, and violet.",
    "explanationDe": "Naturreife Oliven schimmern violett-bräunlich; industriell geschwärzte sind kohlrabenschwarz und fest.",
    "qEn": "How can one tell naturally tree-ripened black olives from artificially blackened olives?",
    "qDe": "Woran erkennt man naturreife schwarze Oliven im Vergleich zu chemisch geschwärzten Oliven?",
    "optEn": [
      "Artificially blackened olives are jet-black green olives oxidized with air and fixed with Ferrous gluconate (E579)",
      "Natural black olives are square",
      "Blackened olives have no stones",
      "Natural black olives are green inside"
    ],
    "optDe": [
      "Geschwärzte Oliven sind pechschwarz mit glatter Haut und enthalten Stabilisator Eisengluconat (E579)",
      "Echte schwarze Oliven sind viereckig",
      "Geschwärzte haben keine Kerne",
      "Naturreife sind innen weiß"
    ],
    "correct": 0,
    "expEn": "Naturally ripe black olives have shriveled, matte skin and shades of purple, brown, and violet.",
    "expDe": "Naturreife Oliven schimmern violett-bräunlich; industriell geschwärzte sind kohlrabenschwarz und fest."
  },
  {
    "id": "q_oli_05",
    "category": "olives",
    "questionEn": "What defines French Niçoise (Cailletier) olives?",
    "questionDe": "Was zeichnet französische Niçoise-Oliven (Sorte Cailletier) aus?",
    "optionsEn": [
      "Tiny dark brown-purple olives cured in herb brine, offering nutty, smoky licorice complexity for Salade Niçoise",
      "Giant green pitted olives",
      "Stuffed with pimiento",
      "Sweet dessert olives"
    ],
    "optionsDe": [
      "Kleine, braun-violette Oliven mit nussig-rauchigem Kräuteraroma, unverzichtbar für Salade Niçoise",
      "Riesige grüne Riesenoliven",
      "Mit Paprika gefüllt",
      "Süße Dessertholiven"
    ],
    "correctIndex": 0,
    "explanationEn": "Small fruit with high flesh-to-pit ratio and delicate savory depth, paired with tuna and anchovies.",
    "explanationDe": "Die feine Cailletier-Olive schenkt dem echten Salade Niçoise seine provenzalische Seele.",
    "qEn": "What defines French Niçoise (Cailletier) olives?",
    "qDe": "Was zeichnet französische Niçoise-Oliven (Sorte Cailletier) aus?",
    "optEn": [
      "Tiny dark brown-purple olives cured in herb brine, offering nutty, smoky licorice complexity for Salade Niçoise",
      "Giant green pitted olives",
      "Stuffed with pimiento",
      "Sweet dessert olives"
    ],
    "optDe": [
      "Kleine, braun-violette Oliven mit nussig-rauchigem Kräuteraroma, unverzichtbar für Salade Niçoise",
      "Riesige grüne Riesenoliven",
      "Mit Paprika gefüllt",
      "Süße Dessertholiven"
    ],
    "correct": 0,
    "expEn": "Small fruit with high flesh-to-pit ratio and delicate savory depth, paired with tuna and anchovies.",
    "expDe": "Die feine Cailletier-Olive schenkt dem echten Salade Niçoise seine provenzalische Seele."
  },
  {
    "id": "q_oli_06",
    "category": "olives",
    "questionEn": "What is Spanish Manzanilla olive known for in tapas culture?",
    "questionDe": "Wofür ist die spanische Manzanilla-Olive in der Tapas-Kultur berühmt?",
    "optionsEn": [
      "Apple-shaped firm green olive with crisp bite and nutty brine flavor, ideal for pitting and stuffing with anchovy or pimiento",
      "It is black and soft",
      "It is dried in ovens",
      "It has no pit"
    ],
    "optionsDe": [
      "Apfelförmige, feste grüne Olive mit feinem Schmelz, ideal zum Entsteinen und Füllen mit Sardelle oder Paprika",
      "Sie ist schwarz und weich",
      "Im Ofen getrocknet",
      "Hat keinen Stein"
    ],
    "correctIndex": 0,
    "explanationEn": "Manzanilla ('little apple') is Spain's quintessential green cocktail and martini olive.",
    "explanationDe": "Die feste Textur und milde Würze machen die Manzanilla zum spanischen Bar-Klassiker.",
    "qEn": "What is Spanish Manzanilla olive known for in tapas culture?",
    "qDe": "Wofür ist die spanische Manzanilla-Olive in der Tapas-Kultur berühmt?",
    "optEn": [
      "Apple-shaped firm green olive with crisp bite and nutty brine flavor, ideal for pitting and stuffing with anchovy or pimiento",
      "It is black and soft",
      "It is dried in ovens",
      "It has no pit"
    ],
    "optDe": [
      "Apfelförmige, feste grüne Olive mit feinem Schmelz, ideal zum Entsteinen und Füllen mit Sardelle oder Paprika",
      "Sie ist schwarz und weich",
      "Im Ofen getrocknet",
      "Hat keinen Stein"
    ],
    "correct": 0,
    "expEn": "Manzanilla ('little apple') is Spain's quintessential green cocktail and martini olive.",
    "expDe": "Die feste Textur und milde Würze machen die Manzanilla zum spanischen Bar-Klassiker."
  },
  {
    "id": "q_oli_07",
    "category": "olives",
    "questionEn": "What are Moroccan Beldi or Thassos dry-cured black olives?",
    "questionDe": "Was sind marokkanische Beldi-Oliven oder schrumpelige Thassos-Oliven?",
    "optionsEn": [
      "Ripe black olives dry-cured in coarse salt (without liquid brine), shriveling into intense, chewy, concentrated prune-like bites",
      "Green olives soaked in milk",
      "Olives boiled in vinegar",
      "Sweet sugar olives"
    ],
    "optionsDe": [
      "In trockenem Salz gereifte schwarze Oliven, die schrumpfen und ein konzentriertes, getrocknetes Aroma entwickeln",
      "In Milch eingelegte Oliven",
      "In Essig gekochte Oliven",
      "Gezuckerte Oliven"
    ],
    "correctIndex": 0,
    "explanationEn": "Dry salt draws out water and oleuropein through osmosis, yielding concentrated umami leather.",
    "explanationDe": "Salzentzug lässt die Oliven wie Rosinen einschrumpfen; das Aroma ist intensiv, salzig und fleischig.",
    "qEn": "What are Moroccan Beldi or Thassos dry-cured black olives?",
    "qDe": "Was sind marokkanische Beldi-Oliven oder schrumpelige Thassos-Oliven?",
    "optEn": [
      "Ripe black olives dry-cured in coarse salt (without liquid brine), shriveling into intense, chewy, concentrated prune-like bites",
      "Green olives soaked in milk",
      "Olives boiled in vinegar",
      "Sweet sugar olives"
    ],
    "optDe": [
      "In trockenem Salz gereifte schwarze Oliven, die schrumpfen und ein konzentriertes, getrocknetes Aroma entwickeln",
      "In Milch eingelegte Oliven",
      "In Essig gekochte Oliven",
      "Gezuckerte Oliven"
    ],
    "correct": 0,
    "expEn": "Dry salt draws out water and oleuropein through osmosis, yielding concentrated umami leather.",
    "expDe": "Salzentzug lässt die Oliven wie Rosinen einschrumpfen; das Aroma ist intensiv, salzig und fleischig."
  },
  {
    "id": "q_oli_08",
    "category": "olives",
    "questionEn": "What is Spanish Gordal olive nicknamed?",
    "questionDe": "Welchen Spitznamen trägt die spanische Gordal Sevillana-Olive?",
    "optionsEn": [
      "'The Fat One' (La Reina) due to its enormous jumbo size, meaty flesh, and juicy bite",
      "The Tiny Olive",
      "The Red Devil",
      "The Bitter Seed"
    ],
    "optionsDe": [
      "'Die Dicke' (La Reina) wegen ihrer gigantischen Fruchtgröße und saftigen Fleischigkeit",
      "Die Winzige",
      "Der Rote Teufel",
      "Der Bitterkern"
    ],
    "correctIndex": 0,
    "explanationEn": "Gordal means fat; its immense size makes it a dramatic showpiece on charcuterie boards.",
    "explanationDe": "Wegen ihres fleischigen Volumens wird die Gordal gerne mit Orangenstücken oder Knoblauch mariniert.",
    "qEn": "What is Spanish Gordal olive nicknamed?",
    "qDe": "Welchen Spitznamen trägt die spanische Gordal Sevillana-Olive?",
    "optEn": [
      "'The Fat One' (La Reina) due to its enormous jumbo size, meaty flesh, and juicy bite",
      "The Tiny Olive",
      "The Red Devil",
      "The Bitter Seed"
    ],
    "optDe": [
      "'Die Dicke' (La Reina) wegen ihrer gigantischen Fruchtgröße und saftigen Fleischigkeit",
      "Die Winzige",
      "Der Rote Teufel",
      "Der Bitterkern"
    ],
    "correct": 0,
    "expEn": "Gordal means fat; its immense size makes it a dramatic showpiece on charcuterie boards.",
    "expDe": "Wegen ihres fleischigen Volumens wird die Gordal gerne mit Orangenstücken oder Knoblauch mariniert."
  },
  {
    "id": "q_oli_09",
    "category": "olives",
    "questionEn": "What traditional dish utilizes chopped cured black olives, capers, anchovies, and olive oil?",
    "questionDe": "Welche provenzalische Paste besteht aus gehackten schwarzen Oliven, Kapern, Sardellen und Olivenöl?",
    "optionsEn": [
      "Tapenade",
      "Guacamole",
      "Hummus",
      "Aioli"
    ],
    "optionsDe": [
      "Tapenade",
      "Guacamole",
      "Hummus",
      "Aioli"
    ],
    "correctIndex": 0,
    "explanationEn": "Tapenade takes its name from tapeno (Provençal for caper), pounded into a rich rustic bread spread.",
    "explanationDe": "Tapenade ist die Königin der südfranzösischen Vorspeisen auf geröstetem Landbrot.",
    "qEn": "What traditional dish utilizes chopped cured black olives, capers, anchovies, and olive oil?",
    "qDe": "Welche provenzalische Paste besteht aus gehackten schwarzen Oliven, Kapern, Sardellen und Olivenöl?",
    "optEn": [
      "Tapenade",
      "Guacamole",
      "Hummus",
      "Aioli"
    ],
    "optDe": [
      "Tapenade",
      "Guacamole",
      "Hummus",
      "Aioli"
    ],
    "correct": 0,
    "expEn": "Tapenade takes its name from tapeno (Provençal for caper), pounded into a rich rustic bread spread.",
    "expDe": "Tapenade ist die Königin der südfranzösischen Vorspeisen auf geröstetem Landbrot."
  },
  {
    "id": "q_oli_09b",
    "category": "olives",
    "questionEn": "What role do natural polyphenols in table olives play in longevity diets?",
    "questionDe": "Welche gesundheitliche Rolle spielen die Polyphenole in naturbelassenen Oliven?",
    "optionsEn": [
      "Potent antioxidant and anti-inflammatory free-radical scavengers supporting heart and arterial health",
      "They add cholesterol",
      "They turn into sugar",
      "They destroy vitamins"
    ],
    "optionsDe": [
      "Starke Antioxidantien (Hydroxytyrosol), die Zellen schützen und Entzündungen hemmen",
      "Sie erhöhen Cholesterin",
      "Sie werden zu Zucker",
      "Sie zerstören Vitamine"
    ],
    "correctIndex": 0,
    "explanationEn": "Hydroxytyrosol in olives is among nature's most powerful cardiovascular antioxidants.",
    "explanationDe": "Polyphenole schützen das Olivenöl vor Oxidation und stärken die Gefäße des Menschen.",
    "qEn": "What role do natural polyphenols in table olives play in longevity diets?",
    "qDe": "Welche gesundheitliche Rolle spielen die Polyphenole in naturbelassenen Oliven?",
    "optEn": [
      "Potent antioxidant and anti-inflammatory free-radical scavengers supporting heart and arterial health",
      "They add cholesterol",
      "They turn into sugar",
      "They destroy vitamins"
    ],
    "optDe": [
      "Starke Antioxidantien (Hydroxytyrosol), die Zellen schützen und Entzündungen hemmen",
      "Sie erhöhen Cholesterin",
      "Sie werden zu Zucker",
      "Sie zerstören Vitamine"
    ],
    "correct": 0,
    "expEn": "Hydroxytyrosol in olives is among nature's most powerful cardiovascular antioxidants.",
    "expDe": "Polyphenole schützen das Olivenöl vor Oxidation und stärken die Gefäße des Menschen."
  },
  {
    "id": "q_oli_11",
    "category": "olives",
    "questionEn": "Why are cracked green olives (Alcaparras / Tsakistes) bruised with a mallet before brining?",
    "questionDe": "Warum werden grüne Oliven vor dem Einlegen oft mit einem Holzhammer angeklopft (Tsakistes)?",
    "optionsEn": [
      "Cracking the flesh allows brine and citrus marinades to penetrate deep into the pit, speeding debittering",
      "To crack the stone inside",
      "To extract oil for frying",
      "To shape them flat"
    ],
    "optionsDe": [
      "Das Aufplatzen der Haut lässt Salzlake und Zitronenmarinade viel schneller zum Kern dringen",
      "Um den Stein zu zerschlagen",
      "Um Bratöl zu gewinnen",
      "Damit sie flach werden"
    ],
    "correctIndex": 0,
    "explanationEn": "Cracked olives absorb garlic, coriander, and wild fennel seasonings in half the time.",
    "explanationDe": "Durch die Risse diffundiert das bittere Oleuropein rasch aus und Kräuteraromen ziehen tief ein.",
    "qEn": "Why are cracked green olives (Alcaparras / Tsakistes) bruised with a mallet before brining?",
    "qDe": "Warum werden grüne Oliven vor dem Einlegen oft mit einem Holzhammer angeklopft (Tsakistes)?",
    "optEn": [
      "Cracking the flesh allows brine and citrus marinades to penetrate deep into the pit, speeding debittering",
      "To crack the stone inside",
      "To extract oil for frying",
      "To shape them flat"
    ],
    "optDe": [
      "Das Aufplatzen der Haut lässt Salzlake und Zitronenmarinade viel schneller zum Kern dringen",
      "Um den Stein zu zerschlagen",
      "Um Bratöl zu gewinnen",
      "Damit sie flach werden"
    ],
    "correct": 0,
    "expEn": "Cracked olives absorb garlic, coriander, and wild fennel seasonings in half the time.",
    "expDe": "Durch die Risse diffundiert das bittere Oleuropein rasch aus und Kräuteraromen ziehen tief ein."
  },
  {
    "id": "q_oli_12",
    "category": "olives",
    "questionEn": "What gives Picholine olives from southern France their distinction?",
    "questionDe": "Was zeichnet französische Picholine-Oliven aus?",
    "optionsEn": [
      "Firm elongated teardrop shape, pointed tip, crisp crunchy bite, and green herbal artichoke notes",
      "Squishy texture",
      "Yellow sweet taste",
      "Smoky peat aroma"
    ],
    "optionsDe": [
      "Längliche spitze Tropfenform, fester knackiger Biss und frische Aromen von grüner Artischocke",
      "Matschige Textur",
      "Süßlicher Geschmack",
      "Raucharoma"
    ],
    "correctIndex": 0,
    "explanationEn": "Picholine yields crisp cocktail table olives and grassy peppery virgin olive oil.",
    "explanationDe": "Die feste Hülle und der nussig-grasige Geschmack machen die Picholine zum Liebling Südfrankreichs.",
    "qEn": "What gives Picholine olives from southern France their distinction?",
    "qDe": "Was zeichnet französische Picholine-Oliven aus?",
    "optEn": [
      "Firm elongated teardrop shape, pointed tip, crisp crunchy bite, and green herbal artichoke notes",
      "Squishy texture",
      "Yellow sweet taste",
      "Smoky peat aroma"
    ],
    "optDe": [
      "Längliche spitze Tropfenform, fester knackiger Biss und frische Aromen von grüner Artischocke",
      "Matschige Textur",
      "Süßlicher Geschmack",
      "Raucharoma"
    ],
    "correct": 0,
    "expEn": "Picholine yields crisp cocktail table olives and grassy peppery virgin olive oil.",
    "expDe": "Die feste Hülle und der nussig-grasige Geschmack machen die Picholine zum Liebling Südfrankreichs."
  },
  {
    "id": "q_oli_13",
    "category": "olives",
    "questionEn": "What is an olive pit (stone) botanically?",
    "questionDe": "Was ist der Olivenkern botanisch gesehen?",
    "optionsEn": [
      "The hard lignified endocarp protecting the inner reproductive seed",
      "A crystallized salt deposit",
      "A dried wooden twig",
      "A clump of starch"
    ],
    "optionsDe": [
      "Das verholzte Endokarp (Stein), das den inneren Samen schützt",
      "Eine Salzkristallisation",
      "Ein verholzter Zweig",
      "Ein Stärkeklumpen"
    ],
    "correctIndex": 0,
    "explanationEn": "Olives are drupes (stone fruits); the pericarp is flesh and the endocarp is the protective pit.",
    "explanationDe": "Wie Kirschen oder Pfirsiche sind Oliven Steinobst mit verholztem Kern im saftigen Fruchtfleisch.",
    "qEn": "What is an olive pit (stone) botanically?",
    "qDe": "Was ist der Olivenkern botanisch gesehen?",
    "optEn": [
      "The hard lignified endocarp protecting the inner reproductive seed",
      "A crystallized salt deposit",
      "A dried wooden twig",
      "A clump of starch"
    ],
    "optDe": [
      "Das verholzte Endokarp (Stein), das den inneren Samen schützt",
      "Eine Salzkristallisation",
      "Ein verholzter Zweig",
      "Ein Stärkeklumpen"
    ],
    "correct": 0,
    "expEn": "Olives are drupes (stone fruits); the pericarp is flesh and the endocarp is the protective pit.",
    "expDe": "Wie Kirschen oder Pfirsiche sind Oliven Steinobst mit verholztem Kern im saftigen Fruchtfleisch."
  },
  {
    "id": "q_oli_14",
    "category": "olives",
    "questionEn": "Why are stuffed cocktail olives traditionally paired with the Dry Martini?",
    "questionDe": "Warum harmonieren Oliven perfekt mit einem klassischen Dry Martini?",
    "optionsEn": [
      "The savory olive brine salinity and oily coating contrast and smooth the dry juniper ethanol punch of gin",
      "Olives cool the drink down",
      "Olives add sugar",
      "Olives turn gin blue"
    ],
    "optionsDe": [
      "Die feine Salzigkeit und das Olivenöl puffern die scharfe Wacholder-Trockenheit des Gins harmonisch ab",
      "Oliven kühlen den Drink",
      "Oliven süßen den Drink",
      "Oliven färben den Gin blau"
    ],
    "correctIndex": 0,
    "explanationEn": "Olive brine balances dry vermouth botanicals; a 'Dirty Martini' adds a barspoon of olive brine directly.",
    "explanationDe": "Das Salz und die Lipide runden den Alkohol ab und machen den Martini unnachahmlich pikant.",
    "qEn": "Why are stuffed cocktail olives traditionally paired with the Dry Martini?",
    "qDe": "Warum harmonieren Oliven perfekt mit einem klassischen Dry Martini?",
    "optEn": [
      "The savory olive brine salinity and oily coating contrast and smooth the dry juniper ethanol punch of gin",
      "Olives cool the drink down",
      "Olives add sugar",
      "Olives turn gin blue"
    ],
    "optDe": [
      "Die feine Salzigkeit und das Olivenöl puffern die scharfe Wacholder-Trockenheit des Gins harmonisch ab",
      "Oliven kühlen den Drink",
      "Oliven süßen den Drink",
      "Oliven färben den Gin blau"
    ],
    "correct": 0,
    "expEn": "Olive brine balances dry vermouth botanicals; a 'Dirty Martini' adds a barspoon of olive brine directly.",
    "expDe": "Das Salz und die Lipide runden den Alkohol ab und machen den Martini unnachahmlich pikant."
  },
  {
    "id": "q_oli_15",
    "category": "olives",
    "questionEn": "What is the Lucques olive from Languedoc famous for?",
    "questionDe": "Wofür ist die französische Lucques-Olive aus dem Languedoc berühmt?",
    "optionsEn": [
      "Distinctive curved crescent-moon shape, bright green skin, and sweet fresh avocado-almond flavor",
      "Black square shape",
      "Chili spice",
      "Bitter vinegar taste"
    ],
    "optionsDe": [
      "Halbmondförmige, geschwungene Silhouette und sahnig-milder Geschmack nach Avocado und frischer Mandel",
      "Schwarze Würfelform",
      "Chilischärfe",
      "Essiggeschmack"
    ],
    "correctIndex": 0,
    "explanationEn": "Known as the 'Green Diamond' of Languedoc, difficult to harvest but unmatched in creamy crunch.",
    "explanationDe": "Wegen ihrer geschwungenen Mondsichel-Form und Buttrigkeit gilt sie als Haute-Cuisine-Delikatesse.",
    "qEn": "What is the Lucques olive from Languedoc famous for?",
    "qDe": "Wofür ist die französische Lucques-Olive aus dem Languedoc berühmt?",
    "optEn": [
      "Distinctive curved crescent-moon shape, bright green skin, and sweet fresh avocado-almond flavor",
      "Black square shape",
      "Chili spice",
      "Bitter vinegar taste"
    ],
    "optDe": [
      "Halbmondförmige, geschwungene Silhouette und sahnig-milder Geschmack nach Avocado und frischer Mandel",
      "Schwarze Würfelform",
      "Chilischärfe",
      "Essiggeschmack"
    ],
    "correct": 0,
    "expEn": "Known as the 'Green Diamond' of Languedoc, difficult to harvest but unmatched in creamy crunch.",
    "expDe": "Wegen ihrer geschwungenen Mondsichel-Form und Buttrigkeit gilt sie als Haute-Cuisine-Delikatesse."
  },
  {
    "id": "q_oli_16",
    "category": "olives",
    "questionEn": "How does olive harvesting time affect olive oil character?",
    "questionDe": "Wie beeinflusst der Erntezeitpunkt den Charakter des Olivenöls?",
    "optionsEn": [
      "Early harvest green olives yield peppery, bitter, high-polyphenol grass oil; late black olives yield mild, golden, buttery oil",
      "Early olives yield vinegar",
      "Late olives have no oil",
      "Harvest time has zero effect"
    ],
    "optionsDe": [
      "Früh geerntete grüne Oliven ergeben pfeffrig-herbes, polyphenolreiches Öl; späte reife Oliven mild-buttriges Öl",
      "Frühe Oliven ergeben Essig",
      "Späte haben kein Öl",
      "Erntezeitpunkt ist egal"
    ],
    "correctIndex": 0,
    "explanationEn": "Early harvest ('Raccolto precoce') sacrifices yield for explosive grassy piquancy and high antioxidants.",
    "explanationDe": "Grün gepflückt duftet das Öl nach Artischocke und Tomatenblatt mit pfeffrigem Kratzen im Hals.",
    "qEn": "How does olive harvesting time affect olive oil character?",
    "qDe": "Wie beeinflusst der Erntezeitpunkt den Charakter des Olivenöls?",
    "optEn": [
      "Early harvest green olives yield peppery, bitter, high-polyphenol grass oil; late black olives yield mild, golden, buttery oil",
      "Early olives yield vinegar",
      "Late olives have no oil",
      "Harvest time has zero effect"
    ],
    "optDe": [
      "Früh geerntete grüne Oliven ergeben pfeffrig-herbes, polyphenolreiches Öl; späte reife Oliven mild-buttriges Öl",
      "Frühe Oliven ergeben Essig",
      "Späte haben kein Öl",
      "Erntezeitpunkt ist egal"
    ],
    "correct": 0,
    "expEn": "Early harvest ('Raccolto precoce') sacrifices yield for explosive grassy piquancy and high antioxidants.",
    "expDe": "Grün gepflückt duftet das Öl nach Artischocke und Tomatenblatt mit pfeffrigem Kratzen im Hals."
  },
  {
    "id": "q_oli_17",
    "category": "olives",
    "questionEn": "What gives Gaeta olives from Lazio their Italian fame?",
    "questionDe": "Was zeichnet Gaeta-Oliven aus dem italienischen Latium aus?",
    "optionsEn": [
      "Purplish-black soft wrinkly olives cured in sea salt and water, starring in Pasta alla Puttanesca",
      "Bright green spicy olives",
      "Stuffed with cheese",
      "Deep fried in dough"
    ],
    "optionsDe": [
      "Violettschwarze, weiche Oliven mit feiner Würze, der Star in echter Pasta alla Puttanesca",
      "Helltürkise Chiligemüse",
      "Mit Käse gefüllt",
      "Im Teigmantel frittiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Gaeta olives deliver deep savory fruitiness that harmonizes with capers, garlic, and tomato sauce.",
    "explanationDe": "In der Puttanesca verschmilzt die weiche Gaeta-Olive mit Sardellen und Tomaten zu purer Harmonie.",
    "qEn": "What gives Gaeta olives from Lazio their Italian fame?",
    "qDe": "Was zeichnet Gaeta-Oliven aus dem italienischen Latium aus?",
    "optEn": [
      "Purplish-black soft wrinkly olives cured in sea salt and water, starring in Pasta alla Puttanesca",
      "Bright green spicy olives",
      "Stuffed with cheese",
      "Deep fried in dough"
    ],
    "optDe": [
      "Violettschwarze, weiche Oliven mit feiner Würze, der Star in echter Pasta alla Puttanesca",
      "Helltürkise Chiligemüse",
      "Mit Käse gefüllt",
      "Im Teigmantel frittiert"
    ],
    "correct": 0,
    "expEn": "Gaeta olives deliver deep savory fruitiness that harmonizes with capers, garlic, and tomato sauce.",
    "expDe": "In der Puttanesca verschmilzt die weiche Gaeta-Olive mit Sardellen und Tomaten zu purer Harmonie."
  },
  {
    "id": "q_oli_18",
    "category": "olives",
    "questionEn": "Why is brine-fermented table olive production considered a biological lactic fermentation?",
    "questionDe": "Warum ist die traditionelle Olivenentbitterung eine echte biologische Milchsäurefermentation?",
    "optionsEn": [
      "Natural airborne Lactobacillus and yeasts ferment fruit sugars into lactic acid in salt brine, preserving olives naturally",
      "Chemical bleach is added",
      "Alcoholic brewer yeast ferments beer",
      "Vinegar boils the olives"
    ],
    "optionsDe": [
      "Natürliche Milchsäurebakterien und Hefen vergären Fruchtzucker in der Salzlake zu konservierender Milchsäure",
      "Bleichmittel wird zugefügt",
      "Bierhefe gärt Alkohol",
      "Kochender Essig sterilisiert"
    ],
    "correctIndex": 0,
    "explanationEn": "Lactic acid drops pH below 4.5, naturally preserving olives with complex savory depth without pasteurization.",
    "explanationDe": "Ähnlich wie bei Sauerkraut senkt die Milchsäure den pH-Wert und macht die Oliven haltbar und aromatisch.",
    "qEn": "Why is brine-fermented table olive production considered a biological lactic fermentation?",
    "qDe": "Warum ist die traditionelle Olivenentbitterung eine echte biologische Milchsäurefermentation?",
    "optEn": [
      "Natural airborne Lactobacillus and yeasts ferment fruit sugars into lactic acid in salt brine, preserving olives naturally",
      "Chemical bleach is added",
      "Alcoholic brewer yeast ferments beer",
      "Vinegar boils the olives"
    ],
    "optDe": [
      "Natürliche Milchsäurebakterien und Hefen vergären Fruchtzucker in der Salzlake zu konservierender Milchsäure",
      "Bleichmittel wird zugefügt",
      "Bierhefe gärt Alkohol",
      "Kochender Essig sterilisiert"
    ],
    "correct": 0,
    "expEn": "Lactic acid drops pH below 4.5, naturally preserving olives with complex savory depth without pasteurization.",
    "expDe": "Ähnlich wie bei Sauerkraut senkt die Milchsäure den pH-Wert und macht die Oliven haltbar und aromatisch."
  },
  {
    "id": "q_oil_01",
    "category": "oils_vinegars",
    "questionEn": "What is the legal maximum free acidity (as oleic acid) for Extra Virgin Olive Oil (EVOO)?",
    "questionDe": "Wie hoch darf der freie Säuregehalt (Ölsäure) bei 'Natives Olivenöl Extra' gesetzlich maximal sein?",
    "optionsEn": [
      "Max 0.8% (0.8g per 100g); premium artisanal oils achieve under 0.2-0.3%",
      "Max 3.3%",
      "Max 10%",
      "Zero tolerance 0.00%"
    ],
    "optionsDe": [
      "Maximal 0,8% (Spitzenöle liegen meist unter 0,2–0,3%)",
      "Maximal 3,3%",
      "Maximal 10%",
      "Exakt 0,00%"
    ],
    "correctIndex": 0,
    "explanationEn": "Low acidity proves pristine, undamaged olives milled immediately without fermentation.",
    "explanationDe": "Niedrige freie Fettsäuren beweisen makellose, gesunde Oliven, die ohne Verzögerung gepresst wurden.",
    "qEn": "What is the legal maximum free acidity (as oleic acid) for Extra Virgin Olive Oil (EVOO)?",
    "qDe": "Wie hoch darf der freie Säuregehalt (Ölsäure) bei 'Natives Olivenöl Extra' gesetzlich maximal sein?",
    "optEn": [
      "Max 0.8% (0.8g per 100g); premium artisanal oils achieve under 0.2-0.3%",
      "Max 3.3%",
      "Max 10%",
      "Zero tolerance 0.00%"
    ],
    "optDe": [
      "Maximal 0,8% (Spitzenöle liegen meist unter 0,2–0,3%)",
      "Maximal 3,3%",
      "Maximal 10%",
      "Exakt 0,00%"
    ],
    "correct": 0,
    "expEn": "Low acidity proves pristine, undamaged olives milled immediately without fermentation.",
    "expDe": "Niedrige freie Fettsäuren beweisen makellose, gesunde Oliven, die ohne Verzögerung gepresst wurden."
  },
  {
    "id": "q_oil_02",
    "category": "oils_vinegars",
    "questionEn": "What causes the peaty peppery burn at the back of the throat when tasting great fresh EVOO?",
    "questionDe": "Was erzeugt das typische pfeffrige Kratzen im Hals bei frischem Spitzen-Olivenöl?",
    "optionsEn": [
      "Oleocanthal, a natural phenolic compound with potent anti-inflammatory effects identical to ibuprofen",
      "Added chili extract",
      "Rancid spoiled fats",
      "High alcohol content"
    ],
    "optionsDe": [
      "Oleocanthal, ein entzündungshemmendes Polyphenol mit ibuprofen-ähnlicher Wirkung",
      "Zusatz von Chili",
      "Verdorbenes ranziges Fett",
      "Hoher Alkoholgehalt"
    ],
    "correctIndex": 0,
    "explanationEn": "Oleocanthal stimulates the exact same pharyngeal receptors as ibuprofen; it is a mark of top quality.",
    "explanationDe": "Das Hustenreizen im Rachen beweist einen hohen Gehalt an bioaktivem, gesundheitsförderndem Oleocanthal.",
    "qEn": "What causes the peaty peppery burn at the back of the throat when tasting great fresh EVOO?",
    "qDe": "Was erzeugt das typische pfeffrige Kratzen im Hals bei frischem Spitzen-Olivenöl?",
    "optEn": [
      "Oleocanthal, a natural phenolic compound with potent anti-inflammatory effects identical to ibuprofen",
      "Added chili extract",
      "Rancid spoiled fats",
      "High alcohol content"
    ],
    "optDe": [
      "Oleocanthal, ein entzündungshemmendes Polyphenol mit ibuprofen-ähnlicher Wirkung",
      "Zusatz von Chili",
      "Verdorbenes ranziges Fett",
      "Hoher Alkoholgehalt"
    ],
    "correct": 0,
    "expEn": "Oleocanthal stimulates the exact same pharyngeal receptors as ibuprofen; it is a mark of top quality.",
    "expDe": "Das Hustenreizen im Rachen beweist einen hohen Gehalt an bioaktivem, gesundheitsförderndem Oleocanthal."
  },
  {
    "id": "q_oil_03",
    "category": "oils_vinegars",
    "questionEn": "What does 'Cold Pressed / Cold Extracted' mean under EU olive oil law?",
    "questionDe": "Was bedeutet die Angabe 'Kaltextraktion' bei Olivenöl gesetzlich?",
    "optionsEn": [
      "Milling and centrifugation conducted strictly below 27°C (80.6°F) to preserve volatile aromatics and antioxidants",
      "Pressed with ice cubes",
      "Harvested in winter frost",
      "Stored in freezers"
    ],
    "optionsDe": [
      "Verarbeitung und Zentrifugation bei maximal 27°C zur Schonung von Aromen und Vitaminen",
      "Mit Eiswürfeln gepresst",
      "Bei Frost geerntet",
      "Im Gefrierfach gelagert"
    ],
    "correctIndex": 0,
    "explanationEn": "Temperatures above 27°C yield more oil volume but degrade delicate polyphenols and grassy esters.",
    "explanationDe": "Über 27°C steigt die Ausbeute, aber die feinen Fruchtaromen und hitzeempfindlichen Polyphenole verbrennen.",
    "qEn": "What does 'Cold Pressed / Cold Extracted' mean under EU olive oil law?",
    "qDe": "Was bedeutet die Angabe 'Kaltextraktion' bei Olivenöl gesetzlich?",
    "optEn": [
      "Milling and centrifugation conducted strictly below 27°C (80.6°F) to preserve volatile aromatics and antioxidants",
      "Pressed with ice cubes",
      "Harvested in winter frost",
      "Stored in freezers"
    ],
    "optDe": [
      "Verarbeitung und Zentrifugation bei maximal 27°C zur Schonung von Aromen und Vitaminen",
      "Mit Eiswürfeln gepresst",
      "Bei Frost geerntet",
      "Im Gefrierfach gelagert"
    ],
    "correct": 0,
    "expEn": "Temperatures above 27°C yield more oil volume but degrade delicate polyphenols and grassy esters.",
    "expDe": "Über 27°C steigt die Ausbeute, aber die feinen Fruchtaromen und hitzeempfindlichen Polyphenole verbrennen."
  },
  {
    "id": "q_oil_04",
    "category": "oils_vinegars",
    "questionEn": "How is authentic Aceto Balsamico Tradizionale di Modena DOP produced?",
    "questionDe": "Wie wird echter traditioneller Aceto Balsamico Tradizionale DOP hergestellt?",
    "optionsEn": [
      "Cooked Trebbiano/Lambrusco grape must aged for at least 12 to 25+ years in batteries of graduating wood barrels",
      "Wine vinegar dyed with caramel",
      "Boiled balsamic syrup",
      "Cider vinegar aged in steel"
    ],
    "optionsDe": [
      "Eingekochter Traubenmost reift mindestens 12 bis 25 Jahre kaskadierend in einer Holzfass-Batterie",
      "Weinessig mit Zuckerkulör",
      "Eingedickter Balsamicosirup",
      "Apfelessig im Stahltank"
    ],
    "correctIndex": 0,
    "explanationEn": "Transferred through oak, chestnut, cherry, ash, and mulberry casks; evaporation creates syrupy nectar.",
    "explanationDe": "Das jährliche Umfüllen in immer kleinere Fässer aus verschiedenen Hölzern schenkt unvergleichliche Dichte.",
    "qEn": "How is authentic Aceto Balsamico Tradizionale di Modena DOP produced?",
    "qDe": "Wie wird echter traditioneller Aceto Balsamico Tradizionale DOP hergestellt?",
    "optEn": [
      "Cooked Trebbiano/Lambrusco grape must aged for at least 12 to 25+ years in batteries of graduating wood barrels",
      "Wine vinegar dyed with caramel",
      "Boiled balsamic syrup",
      "Cider vinegar aged in steel"
    ],
    "optDe": [
      "Eingekochter Traubenmost reift mindestens 12 bis 25 Jahre kaskadierend in einer Holzfass-Batterie",
      "Weinessig mit Zuckerkulör",
      "Eingedickter Balsamicosirup",
      "Apfelessig im Stahltank"
    ],
    "correct": 0,
    "expEn": "Transferred through oak, chestnut, cherry, ash, and mulberry casks; evaporation creates syrupy nectar.",
    "expDe": "Das jährliche Umfüllen in immer kleinere Fässer aus verschiedenen Hölzern schenkt unvergleichliche Dichte."
  },
  {
    "id": "q_oil_05",
    "category": "oils_vinegars",
    "questionEn": "What distinguishes commercial 'Aceto Balsamico di Modena IGP' from traditional DOP?",
    "questionDe": "Was unterscheidet billigen Supermarkt-Balsamico IGP vom traditionellen DOP-Balsamico?",
    "optionsEn": [
      "IGP is a blend of wine vinegar and concentrated must aged only 60 days to 3 years; caramel color is permitted",
      "IGP contains olive oil",
      "IGP is made of apples",
      "IGP is 100 years old"
    ],
    "optionsDe": [
      "IGP ist ein Verschnitt aus Weinessig und Traubenmost, reift oft nur 60 Tage; Zuckerkulör ist erlaubt",
      "IGP enthält Olivenöl",
      "IGP besteht aus Äpfeln",
      "IGP ist 100 Jahre alt"
    ],
    "correctIndex": 0,
    "explanationEn": "Commercial IGP is fluid and tart for daily salads; thick syrupy DOP is savored drop by drop over Parmesan.",
    "explanationDe": "Industrieller IGP-Balsamico ist dünnflüssig; dickflüssiger DOP-Tradizionale wird tropfenweise genossen.",
    "qEn": "What distinguishes commercial 'Aceto Balsamico di Modena IGP' from traditional DOP?",
    "qDe": "Was unterscheidet billigen Supermarkt-Balsamico IGP vom traditionellen DOP-Balsamico?",
    "optEn": [
      "IGP is a blend of wine vinegar and concentrated must aged only 60 days to 3 years; caramel color is permitted",
      "IGP contains olive oil",
      "IGP is made of apples",
      "IGP is 100 years old"
    ],
    "optDe": [
      "IGP ist ein Verschnitt aus Weinessig und Traubenmost, reift oft nur 60 Tage; Zuckerkulör ist erlaubt",
      "IGP enthält Olivenöl",
      "IGP besteht aus Äpfeln",
      "IGP ist 100 Jahre alt"
    ],
    "correct": 0,
    "expEn": "Commercial IGP is fluid and tart for daily salads; thick syrupy DOP is savored drop by drop over Parmesan.",
    "expDe": "Industrieller IGP-Balsamico ist dünnflüssig; dickflüssiger DOP-Tradizionale wird tropfenweise genossen."
  },
  {
    "id": "q_oil_06",
    "category": "oils_vinegars",
    "questionEn": "Why does cold-pressed Pumpkin Seed Oil (Kürbiskernöl) appear dark green in a spoon but ruby red in bright light?",
    "questionDe": "Warum schimmert steirisches Kürbiskernöl im Löffel dunkelgrün, im Gegenlicht aber rubinrot?",
    "optionsEn": [
      "Dichromatism (dichromatic optical effect caused by chlorophyll and protochlorophyll absorption spectra)",
      "Artificial food dye",
      "Bleeding oil defect",
      "Chemical refraction error"
    ],
    "optionsDe": [
      "Dichromatismus: ein physikalisches Phänomen, bei dem die Farbwahrnehmung von der Schichtdicke abhängt",
      "Künstlicher Farbstoff",
      "Ölfehler",
      "Lichtbrechungsfehler"
    ],
    "correctIndex": 0,
    "explanationEn": "Thin films let red light wavelengths pass; thick layers absorb all light except deep forest green.",
    "explanationDe": "In dünner Schicht leuchtet es rot, in dicker Schicht tief smaragdgrün: ein Zeichen höchster Reinheit.",
    "qEn": "Why does cold-pressed Pumpkin Seed Oil (Kürbiskernöl) appear dark green in a spoon but ruby red in bright light?",
    "qDe": "Warum schimmert steirisches Kürbiskernöl im Löffel dunkelgrün, im Gegenlicht aber rubinrot?",
    "optEn": [
      "Dichromatism (dichromatic optical effect caused by chlorophyll and protochlorophyll absorption spectra)",
      "Artificial food dye",
      "Bleeding oil defect",
      "Chemical refraction error"
    ],
    "optDe": [
      "Dichromatismus: ein physikalisches Phänomen, bei dem die Farbwahrnehmung von der Schichtdicke abhängt",
      "Künstlicher Farbstoff",
      "Ölfehler",
      "Lichtbrechungsfehler"
    ],
    "correct": 0,
    "expEn": "Thin films let red light wavelengths pass; thick layers absorb all light except deep forest green.",
    "expDe": "In dünner Schicht leuchtet es rot, in dicker Schicht tief smaragdgrün: ein Zeichen höchster Reinheit."
  },
  {
    "id": "q_oil_07",
    "category": "oils_vinegars",
    "questionEn": "What is the culinary smoke point of refined peanut oil versus extra virgin olive oil?",
    "questionDe": "Wie unterscheidet sich der Rauchpunkt von raffiniertem Erdnussöl von unfiltriertem Olivenöl?",
    "optionsEn": [
      "Refined peanut oil has a high smoke point (~230°C / 450°F); unrefined EVOO smokes around 180-190°C",
      "Both smoke at 100°C",
      "Olive oil never smokes",
      "Peanut oil smokes at 60°C"
    ],
    "optionsDe": [
      "Raffiniertes Erdnussöl hat einen hohen Rauchpunkt (~230°C); unfiltriertes Olivenöl raucht ab ca. 180–190°C",
      "Beide rauchen ab 100°C",
      "Olivenöl raucht nie",
      "Erdnussöl raucht bei 60°C"
    ],
    "correctIndex": 0,
    "explanationEn": "Refining removes free fatty acids and solids, enabling high-heat stir-frying and deep-frying without burning.",
    "explanationDe": "Raffiniertes Öl ist hitzestabil für Wok und Fritteuse; Rohöle verbrennen bei starker Hitze.",
    "qEn": "What is the culinary smoke point of refined peanut oil versus extra virgin olive oil?",
    "qDe": "Wie unterscheidet sich der Rauchpunkt von raffiniertem Erdnussöl von unfiltriertem Olivenöl?",
    "optEn": [
      "Refined peanut oil has a high smoke point (~230°C / 450°F); unrefined EVOO smokes around 180-190°C",
      "Both smoke at 100°C",
      "Olive oil never smokes",
      "Peanut oil smokes at 60°C"
    ],
    "optDe": [
      "Raffiniertes Erdnussöl hat einen hohen Rauchpunkt (~230°C); unfiltriertes Olivenöl raucht ab ca. 180–190°C",
      "Beide rauchen ab 100°C",
      "Olivenöl raucht nie",
      "Erdnussöl raucht bei 60°C"
    ],
    "correct": 0,
    "expEn": "Refining removes free fatty acids and solids, enabling high-heat stir-frying and deep-frying without burning.",
    "expDe": "Raffiniertes Öl ist hitzestabil für Wok und Fritteuse; Rohöle verbrennen bei starker Hitze."
  },
  {
    "id": "q_oil_08",
    "category": "oils_vinegars",
    "questionEn": "What makes Toasted Sesame Oil indispensable in Asian finishing seasoning?",
    "questionDe": "Warum wird dunkles geröstetes Sesamöl in der asiatischen Küche erst am Schluss zugegeben?",
    "optionsEn": [
      "Deep nutty aroma compounds decompose and turn bitter if used for high-heat frying; it is a finishing aroma oil",
      "It is explosive at high heat",
      "It is a solid wax",
      "It evaporates instantly"
    ],
    "optionsDe": [
      "Die intensiven Röstaromen verbrennen bei hoher Brathitze; es dient als reines Würzöl zum Parfümieren",
      "Es explodiert bei Hitze",
      "Es ist fest wie Wachs",
      "Es verdampft sofort"
    ],
    "correctIndex": 0,
    "explanationEn": "Rich in sesamol antioxidants; a few drops off the heat infuse stir-fries, ramen, and marinades with toasted depth.",
    "explanationDe": "Ein paar Tropfen über die fertige Suppe oder das Wokgericht genügen für nussige Perfektion.",
    "qEn": "What makes Toasted Sesame Oil indispensable in Asian finishing seasoning?",
    "qDe": "Warum wird dunkles geröstetes Sesamöl in der asiatischen Küche erst am Schluss zugegeben?",
    "optEn": [
      "Deep nutty aroma compounds decompose and turn bitter if used for high-heat frying; it is a finishing aroma oil",
      "It is explosive at high heat",
      "It is a solid wax",
      "It evaporates instantly"
    ],
    "optDe": [
      "Die intensiven Röstaromen verbrennen bei hoher Brathitze; es dient als reines Würzöl zum Parfümieren",
      "Es explodiert bei Hitze",
      "Es ist fest wie Wachs",
      "Es verdampft sofort"
    ],
    "correct": 0,
    "expEn": "Rich in sesamol antioxidants; a few drops off the heat infuse stir-fries, ramen, and marinades with toasted depth.",
    "expDe": "Ein paar Tropfen über die fertige Suppe oder das Wokgericht genügen für nussige Perfektion."
  },
  {
    "id": "q_oil_09",
    "category": "oils_vinegars",
    "questionEn": "What is Sherry Vinegar (Vinagre de Jerez DOP) aged in?",
    "questionDe": "Worin reift echter spanischer Sherry-Essig (Vinagre de Jerez DOP)?",
    "optionsEn": [
      "American oak barrels using the traditional Criaderas and Solera system for up to 10-20+ years",
      "Plastic tanks",
      "Glass demijohns in the sun",
      "Stainless steel silos"
    ],
    "optionsDe": [
      "In Fässern aus amerikanischer Eiche nach dem Solera-Verfahren für mindestens 2 bis über 20 Jahre",
      "In Plastikfässern",
      "In Glasballons an der Sonne",
      "In Stahltanks"
    ],
    "correctIndex": 0,
    "explanationEn": "Solera aging concentrates acetic acid and wood vanillins, creating mahogany color and complex dry nutty finish.",
    "explanationDe": "Das Solera-Verfahren verleiht dem Sherry-Essig Holzaromen, Nuancen von Nüssen und samtige Säure.",
    "qEn": "What is Sherry Vinegar (Vinagre de Jerez DOP) aged in?",
    "qDe": "Worin reift echter spanischer Sherry-Essig (Vinagre de Jerez DOP)?",
    "optEn": [
      "American oak barrels using the traditional Criaderas and Solera system for up to 10-20+ years",
      "Plastic tanks",
      "Glass demijohns in the sun",
      "Stainless steel silos"
    ],
    "optDe": [
      "In Fässern aus amerikanischer Eiche nach dem Solera-Verfahren für mindestens 2 bis über 20 Jahre",
      "In Plastikfässern",
      "In Glasballons an der Sonne",
      "In Stahltanks"
    ],
    "correct": 0,
    "expEn": "Solera aging concentrates acetic acid and wood vanillins, creating mahogany color and complex dry nutty finish.",
    "expDe": "Das Solera-Verfahren verleiht dem Sherry-Essig Holzaromen, Nuancen von Nüssen und samtige Säure."
  },
  {
    "id": "q_oil_10",
    "category": "oils_vinegars",
    "questionEn": "Why is Walnut Oil (Walnussöl) never used for high-heat frying?",
    "questionDe": "Warum darf kaltgepresstes Walnussöl niemals zum Braten verwendet werden?",
    "optionsEn": [
      "Extremely high in polyunsaturated fatty acids with a low smoke point (160°C); heat destroys omega-3s and creates bitter toxins",
      "It explodes in pans",
      "It turns into sugar",
      "It evaporates like alcohol"
    ],
    "optionsDe": [
      "Sehr empfindliche mehrfach ungesättigte Fettsäuren verbrennen ab 160°C und bilden Schadstoffe",
      "Es explodiert in der Pfanne",
      "Es wird zu Zucker",
      "Es verdampft wie Alkohol"
    ],
    "correctIndex": 0,
    "explanationEn": "Precious walnut oil is an exquisite finishing oil for root vegetable salads, goat cheese, and pumpkin soup.",
    "explanationDe": "Walnussöl gehört als kaltes Veredelungsöl über Feldsalat, Ziegenkäse oder feines Wurzelgemüse.",
    "qEn": "Why is Walnut Oil (Walnussöl) never used for high-heat frying?",
    "qDe": "Warum darf kaltgepresstes Walnussöl niemals zum Braten verwendet werden?",
    "optEn": [
      "Extremely high in polyunsaturated fatty acids with a low smoke point (160°C); heat destroys omega-3s and creates bitter toxins",
      "It explodes in pans",
      "It turns into sugar",
      "It evaporates like alcohol"
    ],
    "optDe": [
      "Sehr empfindliche mehrfach ungesättigte Fettsäuren verbrennen ab 160°C und bilden Schadstoffe",
      "Es explodiert in der Pfanne",
      "Es wird zu Zucker",
      "Es verdampft wie Alkohol"
    ],
    "correct": 0,
    "expEn": "Precious walnut oil is an exquisite finishing oil for root vegetable salads, goat cheese, and pumpkin soup.",
    "expDe": "Walnussöl gehört als kaltes Veredelungsöl über Feldsalat, Ziegenkäse oder feines Wurzelgemüse."
  },
  {
    "id": "q_oil_11",
    "category": "oils_vinegars",
    "questionEn": "What gives Japanese Rice Vinegar (Komezu) its culinary gentleness?",
    "questionDe": "Was macht japanischen Reisessig (Komezu) so bemerkenswert mild?",
    "optionsEn": [
      "Lower acetic acid concentration (~4-4.5% acidity) compared to European vinegars (6-8%), with sweet amino acid finish",
      "Contains no acid at all",
      "Diluted with 90% water",
      "Sweetened with corn syrup"
    ],
    "optionsDe": [
      "Geringerer Säuregehalt (~4–4,5%) im Vergleich zu europäischem Essig (6–8%) und feine Umami-Aminosäuren",
      "Enthält gar keine Säure",
      "Besteht zu 90% aus Wasser",
      "Mit Maissirup gesüßt"
    ],
    "correctIndex": 0,
    "explanationEn": "Soft acidity prevents curdling and perfectly seasons delicate sushi rice without overwhelming raw fish.",
    "explanationDe": "Milder Reisessig unterstreicht die Frische von rohem Fisch und würzt Sushireis harmonisch.",
    "qEn": "What gives Japanese Rice Vinegar (Komezu) its culinary gentleness?",
    "qDe": "Was macht japanischen Reisessig (Komezu) so bemerkenswert mild?",
    "optEn": [
      "Lower acetic acid concentration (~4-4.5% acidity) compared to European vinegars (6-8%), with sweet amino acid finish",
      "Contains no acid at all",
      "Diluted with 90% water",
      "Sweetened with corn syrup"
    ],
    "optDe": [
      "Geringerer Säuregehalt (~4–4,5%) im Vergleich zu europäischem Essig (6–8%) und feine Umami-Aminosäuren",
      "Enthält gar keine Säure",
      "Besteht zu 90% aus Wasser",
      "Mit Maissirup gesüßt"
    ],
    "correct": 0,
    "expEn": "Soft acidity prevents curdling and perfectly seasons delicate sushi rice without overwhelming raw fish.",
    "expDe": "Milder Reisessig unterstreicht die Frische von rohem Fisch und würzt Sushireis harmonisch."
  },
  {
    "id": "q_oil_12",
    "category": "oils_vinegars",
    "questionEn": "What is the biological role of the 'Mother of Vinegar' (Essigmutter)?",
    "questionDe": "Was ist die 'Essigmutter' bei der traditionellen Essigbereitung?",
    "optionsEn": [
      "A cellulose biofilm mat of symbiotic acetic acid bacteria (Acetobacter) that oxidize ethanol into acetic acid",
      "A fungal spore tablet",
      "A piece of yeast bread",
      "Mother plant roots"
    ],
    "optionsDe": [
      "Eine gallertartige Schicht aus Essigsäurebakterien (Acetobacter), die Alkohol mit Sauerstoff zu Essig veratmen",
      "Eine Schimmelpilztablette",
      "Ein Stück Sauerteigbrot",
      "Wurzeln der Mutterpflanze"
    ],
    "correctIndex": 0,
    "explanationEn": "Acetobacter colonies float at the liquid surface to access atmospheric oxygen, converting wine to vinegar.",
    "explanationDe": "Die Bakterien benötigen Sauerstoff und wandeln Wein oder Apfelmost auf natürliche Weise in Essig um.",
    "qEn": "What is the biological role of the 'Mother of Vinegar' (Essigmutter)?",
    "qDe": "Was ist die 'Essigmutter' bei der traditionellen Essigbereitung?",
    "optEn": [
      "A cellulose biofilm mat of symbiotic acetic acid bacteria (Acetobacter) that oxidize ethanol into acetic acid",
      "A fungal spore tablet",
      "A piece of yeast bread",
      "Mother plant roots"
    ],
    "optDe": [
      "Eine gallertartige Schicht aus Essigsäurebakterien (Acetobacter), die Alkohol mit Sauerstoff zu Essig veratmen",
      "Eine Schimmelpilztablette",
      "Ein Stück Sauerteigbrot",
      "Wurzeln der Mutterpflanze"
    ],
    "correct": 0,
    "expEn": "Acetobacter colonies float at the liquid surface to access atmospheric oxygen, converting wine to vinegar.",
    "expDe": "Die Bakterien benötigen Sauerstoff und wandeln Wein oder Apfelmost auf natürliche Weise in Essig um."
  },
  {
    "id": "q_oil_13",
    "category": "oils_vinegars",
    "questionEn": "Why is Flaxseed Oil (Leinöl) stored in dark refrigerated bottles and consumed within weeks?",
    "questionDe": "Warum muss Leinöl im Kühlschrank aufbewahrt und rasch verbraucht werden?",
    "optionsEn": [
      "Contains over 50% alpha-linolenic omega-3 acid, which oxidizes rapidly into bitter compounds upon exposure to light and warmth",
      "It turns toxic instantly",
      "It freezes into solid ice",
      "Bacteria grow inside"
    ],
    "optionsDe": [
      "Über 50% Alpha-Linolensäure (Omega-3) oxidieren bei Licht und Wärme extrem schnell zu bitterem Firnis",
      "Wird sofort giftig",
      "Gefriert zu Eis",
      "Bakterien vermehren sich"
    ],
    "correctIndex": 0,
    "explanationEn": "Fresh Leinöl has a sweet, nutty, grassy taste; oxidized oil tastes bitter like floor varnish.",
    "explanationDe": "Frisches Leinöl schmeckt buttrig-nussig und ist der gesunde Star zu Quark und Pellkartoffeln.",
    "qEn": "Why is Flaxseed Oil (Leinöl) stored in dark refrigerated bottles and consumed within weeks?",
    "qDe": "Warum muss Leinöl im Kühlschrank aufbewahrt und rasch verbraucht werden?",
    "optEn": [
      "Contains over 50% alpha-linolenic omega-3 acid, which oxidizes rapidly into bitter compounds upon exposure to light and warmth",
      "It turns toxic instantly",
      "It freezes into solid ice",
      "Bacteria grow inside"
    ],
    "optDe": [
      "Über 50% Alpha-Linolensäure (Omega-3) oxidieren bei Licht und Wärme extrem schnell zu bitterem Firnis",
      "Wird sofort giftig",
      "Gefriert zu Eis",
      "Bakterien vermehren sich"
    ],
    "correct": 0,
    "expEn": "Fresh Leinöl has a sweet, nutty, grassy taste; oxidized oil tastes bitter like floor varnish.",
    "expDe": "Frisches Leinöl schmeckt buttrig-nussig und ist der gesunde Star zu Quark und Pellkartoffeln."
  },
  {
    "id": "q_oil_14",
    "category": "oils_vinegars",
    "questionEn": "What is Apple Cider Vinegar (Apfelessig) praised for in vinaigrettes?",
    "questionDe": "Was zeichnet naturtrüben Apfelessig in Salatdressings aus?",
    "optionsEn": [
      "Mellow fruity malic and acetic acid balance with prebiotic pectin traces and cloudy fermentation nutrients",
      "Zero acid taste",
      "Sweet strawberry flavor",
      "It is carbonated like cider"
    ],
    "optionsDe": [
      "Harmonische Liaison aus Essig- und Äpfelsäure mit feiner Fruchtnote und unfiltrierten Nährstoffen",
      "Kein Säuregeschmack",
      "Erdbeeraroma",
      "Kohlensäurehaltig"
    ],
    "correctIndex": 0,
    "explanationEn": "Less aggressive than distilled white vinegar, ideal for cabbage salads, lentil stews, and pork glazes.",
    "explanationDe": "Apfelessig harmoniert wunderbar mit Rohkost, Linsengerichten und herzhaftem Schweinebraten.",
    "qEn": "What is Apple Cider Vinegar (Apfelessig) praised for in vinaigrettes?",
    "qDe": "Was zeichnet naturtrüben Apfelessig in Salatdressings aus?",
    "optEn": [
      "Mellow fruity malic and acetic acid balance with prebiotic pectin traces and cloudy fermentation nutrients",
      "Zero acid taste",
      "Sweet strawberry flavor",
      "It is carbonated like cider"
    ],
    "optDe": [
      "Harmonische Liaison aus Essig- und Äpfelsäure mit feiner Fruchtnote und unfiltrierten Nährstoffen",
      "Kein Säuregeschmack",
      "Erdbeeraroma",
      "Kohlensäurehaltig"
    ],
    "correct": 0,
    "expEn": "Less aggressive than distilled white vinegar, ideal for cabbage salads, lentil stews, and pork glazes.",
    "expDe": "Apfelessig harmoniert wunderbar mit Rohkost, Linsengerichten und herzhaftem Schweinebraten."
  },
  {
    "id": "q_oil_15",
    "category": "oils_vinegars",
    "questionEn": "What defines Avocado Oil for culinary applications?",
    "questionDe": "Was zeichnet Speise-Avocadoöl in der modernen Küche aus?",
    "optionsEn": [
      "Extracted from the fruit pulp (not the seed), rich in monounsaturated fats with an ultra-high smoke point (~270°C / 520°F)",
      "Extracted from tree bark",
      "Extracted from crushed leaves",
      "Has 0% fat"
    ],
    "optionsDe": [
      "Wird aus dem Fruchtfleisch gepresst; reich an Ölsäure mit extrem hohem Rauchpunkt bis zu 270°C",
      "Aus Rinde gepresst",
      "Aus Blättern destilliert",
      "Hat 0% Fett"
    ],
    "correctIndex": 0,
    "explanationEn": "Extra virgin avocado oil is emerald green; refined avocado oil handles searing steaks without smoking.",
    "explanationDe": "Das unraffinierte Öl schmeckt cremig nach Avocado; raffiniert ist es das hitzestabilste Bratöl.",
    "qEn": "What defines Avocado Oil for culinary applications?",
    "qDe": "Was zeichnet Speise-Avocadoöl in der modernen Küche aus?",
    "optEn": [
      "Extracted from the fruit pulp (not the seed), rich in monounsaturated fats with an ultra-high smoke point (~270°C / 520°F)",
      "Extracted from tree bark",
      "Extracted from crushed leaves",
      "Has 0% fat"
    ],
    "optDe": [
      "Wird aus dem Fruchtfleisch gepresst; reich an Ölsäure mit extrem hohem Rauchpunkt bis zu 270°C",
      "Aus Rinde gepresst",
      "Aus Blättern destilliert",
      "Hat 0% Fett"
    ],
    "correct": 0,
    "expEn": "Extra virgin avocado oil is emerald green; refined avocado oil handles searing steaks without smoking.",
    "expDe": "Das unraffinierte Öl schmeckt cremig nach Avocado; raffiniert ist es das hitzestabilste Bratöl."
  },
  {
    "id": "q_oil_16",
    "category": "oils_vinegars",
    "questionEn": "How does storing olive oil in clear glass bottles under supermarket lights damage quality?",
    "questionDe": "Warum schadet die Lagerung in Weißglasflaschen im Supermarktregal der Olivenölqualität?",
    "optionsEn": [
      "Photo-oxidation: Chlorophyll absorbs light energy, producing singlet oxygen that rapidly oxidizes lipids into rancid peroxides",
      "The oil turns into alcohol",
      "The bottle melts",
      "Color turns black"
    ],
    "optionsDe": [
      "Lichtinduzierte Photo-Oxidation: Chlorophyll regt Singulett-Sauerstoff an, der Fette ranzig zersetzt",
      "Das Öl wird Alkohol",
      "Die Flasche schmilzt",
      "Die Farbe wird schwarz"
    ],
    "correctIndex": 0,
    "explanationEn": "Always store olive oil in dark green/amber glass, tin containers, or cool dark pantries.",
    "explanationDe": "Olivenöl immer dunkel und kühl lagern; Licht zerstört Vitamine und macht das Öl kratzig-ranzig.",
    "qEn": "How does storing olive oil in clear glass bottles under supermarket lights damage quality?",
    "qDe": "Warum schadet die Lagerung in Weißglasflaschen im Supermarktregal der Olivenölqualität?",
    "optEn": [
      "Photo-oxidation: Chlorophyll absorbs light energy, producing singlet oxygen that rapidly oxidizes lipids into rancid peroxides",
      "The oil turns into alcohol",
      "The bottle melts",
      "Color turns black"
    ],
    "optDe": [
      "Lichtinduzierte Photo-Oxidation: Chlorophyll regt Singulett-Sauerstoff an, der Fette ranzig zersetzt",
      "Das Öl wird Alkohol",
      "Die Flasche schmilzt",
      "Die Farbe wird schwarz"
    ],
    "correct": 0,
    "expEn": "Always store olive oil in dark green/amber glass, tin containers, or cool dark pantries.",
    "expDe": "Olivenöl immer dunkel und kühl lagern; Licht zerstört Vitamine und macht das Öl kratzig-ranzig."
  },
  {
    "id": "q_oil_17",
    "category": "oils_vinegars",
    "questionEn": "What is Chinese Chinkiang Black Rice Vinegar?",
    "questionDe": "Was ist traditioneller chinesischer Chinkiang-Essig?",
    "optionsEn": [
      "A fermented black vinegar brewed from glutinous sticky rice and malt, offering rich, malty, smoky, umami complexity",
      "White vinegar colored with soy sauce",
      "Vinegar mixed with coal ash",
      "Black pepper vinegar"
    ],
    "optionsDe": [
      "Aus klebrigem Klebreis und Weizenkleie fermentierter schwarzer Essig mit malzig-rauchigem Umami",
      "Mit Sojasauce gefärbter Essig",
      "Mit Holzkohle versetzter Essig",
      "Pfefferessig"
    ],
    "correctIndex": 0,
    "explanationEn": "Essential dipping condiment for Xiaolongbao soup dumplings and braised spare ribs.",
    "explanationDe": "Chinkiang-Essig ist der Balsamico Asiens und der perfekte Partner für gedämpfte Dim Sum.",
    "qEn": "What is Chinese Chinkiang Black Rice Vinegar?",
    "qDe": "Was ist traditioneller chinesischer Chinkiang-Essig?",
    "optEn": [
      "A fermented black vinegar brewed from glutinous sticky rice and malt, offering rich, malty, smoky, umami complexity",
      "White vinegar colored with soy sauce",
      "Vinegar mixed with coal ash",
      "Black pepper vinegar"
    ],
    "optDe": [
      "Aus klebrigem Klebreis und Weizenkleie fermentierter schwarzer Essig mit malzig-rauchigem Umami",
      "Mit Sojasauce gefärbter Essig",
      "Mit Holzkohle versetzter Essig",
      "Pfefferessig"
    ],
    "correct": 0,
    "expEn": "Essential dipping condiment for Xiaolongbao soup dumplings and braised spare ribs.",
    "expDe": "Chinkiang-Essig ist der Balsamico Asiens und der perfekte Partner für gedämpfte Dim Sum."
  },
  {
    "id": "q_oil_18",
    "category": "oils_vinegars",
    "questionEn": "Why is Grapeseed Oil (Traubenkernöl) popular in fondue and mayonnaise?",
    "questionDe": "Warum ist raffiniertes Traubenkernöl für Fondue und Mayonnaise so beliebt?",
    "optionsEn": [
      "Extremely neutral, clean flavor profile and high smoke point (216°C), allowing delicate herbs and sauces to shine",
      "It tastes like sweet red wine",
      "It is colored purple",
      "It has zero calories"
    ],
    "optionsDe": [
      "Absolut geschmacksneutrales Profil und hohe Hitzestabilität (216°C); überdeckt keine Eigengeschmäcker",
      "Schmeckt nach Rotwein",
      "Ist violett gefärbt",
      "Hat keine Kalorien"
    ],
    "correctIndex": 0,
    "explanationEn": "Neutral grapeseed oil creates emulsified dressings where herbs, truffles, or lemon take center stage.",
    "explanationDe": "Da es keinen Eigengeschmack hat, lässt es feine Kräuter, Zitrone oder Trüffel voll zur Geltung kommen.",
    "qEn": "Why is Grapeseed Oil (Traubenkernöl) popular in fondue and mayonnaise?",
    "qDe": "Warum ist raffiniertes Traubenkernöl für Fondue und Mayonnaise so beliebt?",
    "optEn": [
      "Extremely neutral, clean flavor profile and high smoke point (216°C), allowing delicate herbs and sauces to shine",
      "It tastes like sweet red wine",
      "It is colored purple",
      "It has zero calories"
    ],
    "optDe": [
      "Absolut geschmacksneutrales Profil und hohe Hitzestabilität (216°C); überdeckt keine Eigengeschmäcker",
      "Schmeckt nach Rotwein",
      "Ist violett gefärbt",
      "Hat keine Kalorien"
    ],
    "correct": 0,
    "expEn": "Neutral grapeseed oil creates emulsified dressings where herbs, truffles, or lemon take center stage.",
    "expDe": "Da es keinen Eigengeschmack hat, lässt es feine Kräuter, Zitrone oder Trüffel voll zur Geltung kommen."
  }
];

function loadItems() {
  const saved = localStorage.getItem(STORAGE_KEY_ITEMS);
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      const overrideMap = {};
      parsed.forEach(it => {
        if (it && it.id) {
          overrideMap[it.id] = {
            isFavorite: it.isFavorite,
            stockQuantity: it.stockQuantity,
            inStock: it.inStock,
            userNotes: it.userNotes
          };
        }
      });
      return MASTER_ITEMS.map(m => {
        const ov = overrideMap[m.id];
        return ov ? { ...m, ...ov } : { ...m };
      });
    } catch(e) {
      console.error(e);
    }
  }
  return MASTER_ITEMS.map(m => ({ ...m }));
}

let items = loadItems();

function saveItems() {
  localStorage.setItem(STORAGE_KEY_ITEMS, JSON.stringify(items));
}

// FIREBASE CLOUD FIRESTORE SYNCHRONIZATION
const FIREBASE_CONFIG = {
  projectId: 'gastrodex-823d7',
  hostingUrl: 'https://gastrodex-823d7.web.app',
  firestoreRestEndpoint: 'https://firestore.googleapis.com/v1/projects/gastrodex-823d7/databases/(default)/documents'
};

async function syncWithFirebaseCloud() {
  try {
    const url = window.location.hostname.includes('gastrodex-823d7') 
      ? '/catalog_latest.json' 
      : `${FIREBASE_CONFIG.hostingUrl}/catalog_latest.json`;
    const res = await fetch(url, { cache: 'no-cache' });
    if (res.ok) {
      const data = await res.json();
      if (data && Array.isArray(data.items) && data.items.length > 0) {
        console.log(`🔥 Synchronized ${data.items.length} items from Firebase Cloud!`);
        const localOverrides = (items || []).reduce((acc, it) => {
          acc[it.id] = { isFavorite: it.isFavorite, stockQuantity: it.stockQuantity, inStock: it.inStock };
          return acc;
        }, {});
        items = data.items.map(remoteItem => {
          const ov = localOverrides[remoteItem.id];
          return ov ? { ...remoteItem, ...ov } : remoteItem;
        });
        saveItems();
        renderCatalog();
        renderInventoryList();
        const badge = document.getElementById('itemCountBadge');
        if (badge) badge.title = `🔥 Firebase Cloud Sync aktiv (${data.items.length} Einträge)`;
      }
    }
  } catch (err) {
    console.log('Firebase Cloud offline or pending deployment, using local offline cache:', err.message);
  }
}

// APP INITIALIZATION
document.addEventListener('DOMContentLoaded', () => {
  renderLanguageLabels();
  renderCategoryChips();
  renderCatalog();
  renderInventoryList();
  setupEventListeners();
  initQuizSession('all', 10);
  syncWithFirebaseCloud();
});

function toggleLanguage() {
  currentLang = (currentLang === 'de') ? 'en' : 'de';
  localStorage.setItem(STORAGE_KEY_LANG, currentLang);
  renderLanguageLabels();
  renderCategoryChips();
  renderCatalog();
  renderInventoryList();
  if (quizIsRevealed || !quizIsCompleted) {
    renderCurrentQuestion();
  }
  if (selectedItem) {
    showItemDetail(selectedItem.id);
  }
}

function renderLanguageLabels() {
  document.getElementById('langToggleBtn').innerHTML = (currentLang === 'de') ? '🇩🇪 DE' : '🇬🇧 EN';
  
  // Update UI strings based on language
  const isDe = (currentLang === 'de');
  document.getElementById('appSubtitle').textContent = isDe ? "Gastronomie & Hotellerie Wissenskompass" : "Hospitality & Gastronomy Encyclopedia";
  document.getElementById('searchInput').placeholder = isDe ? "Suche Spirituosen, Weine, Kaffee, Eier, Käse..." : "Search spirits, wine, coffee, eggs, cheese...";
  
  document.getElementById('tabCatalogLabel').textContent = isDe ? "Lexikon" : "Catalog";
  document.getElementById('tabWineLabel').textContent = isDe ? "Wein-Guide" : "Wine Guide";
  document.getElementById('tabCoffeeLabel').textContent = isDe ? "Kaffee-Labor" : "Coffee Lab";
  document.getElementById('tabScienceLabel').textContent = isDe ? "Wirkungslehre" : "Science";
  document.getElementById('tabQuizLabel').textContent = isDe ? "Quiz-Trainer" : "Staff Quiz";
  document.getElementById('tabInventoryLabel').textContent = isDe ? "Lagerbestand" : "Inventory";
}

const CATEGORIES = [
  {
    "id": "all",
    "titleDe": "✨ Alle Einträge",
    "titleEn": "✨ All Entries"
  },
  {
    "id": "spirits",
    "titleDe": "🥃 Spirituosen & Destillate",
    "titleEn": "🥃 Spirits & Distillates"
  },
  {
    "id": "wine",
    "titleDe": "🍷 Wein & Schaumweine",
    "titleEn": "🍷 Wine & Champagne"
  },
  {
    "id": "tea",
    "titleDe": "🍵 Teekunde & Aufgüsse",
    "titleEn": "🍵 Tea & Infusions"
  },
  {
    "id": "coffee",
    "titleDe": "☕ Kaffeespezialitäten",
    "titleEn": "☕ Coffee Specialties"
  },
  {
    "id": "pasta_rice",
    "titleDe": "🍝 Pasta & Reisvariationen",
    "titleEn": "🍝 Pasta & Rice Varieties"
  },
  {
    "id": "sauces_condiments",
    "titleDe": "🥣 Saucen, Dressings & Senf",
    "titleEn": "🥣 Sauces, Dressings & Mustard"
  },
  {
    "id": "soft_drinks",
    "titleDe": "🥤 Erfrischung & Mixer",
    "titleEn": "🥤 Soft Drinks & Mixers"
  },
  {
    "id": "dairy",
    "titleDe": "🥛 Milch & Molkerei",
    "titleEn": "🥛 Dairy & Milk Science"
  },
  {
    "id": "cheese",
    "titleDe": "🧀 Käsekunde & g.U.",
    "titleEn": "🧀 Cheese & DOP / g.U."
  },
  {
    "id": "eggs",
    "titleDe": "🍳 Eierspeisen & Eierkunde",
    "titleEn": "🍳 Egg Dishes & Science"
  },
  {
    "id": "vegetables",
    "titleDe": "🍄 Gemüse & Speisepilze",
    "titleEn": "🍄 Vegetables & Mushrooms"
  },
  {
    "id": "fruits",
    "titleDe": "🍓 Früchte & Beeren",
    "titleEn": "🍓 Fruits & Berries"
  },
  {
    "id": "nuts",
    "titleDe": "🥜 Nüsse & Saaten",
    "titleEn": "🥜 Nuts & Seeds"
  },
  {
    "id": "spices_herbs",
    "titleDe": "🌿 Gewürze & Kräuter",
    "titleEn": "🌿 Spices & Herbs"
  },
  {
    "id": "olives",
    "titleDe": "🫒 Oliven",
    "titleEn": "🫒 Olives"
  },
  {
    "id": "oils_vinegars",
    "titleDe": "🏺 Öle & Essig",
    "titleEn": "🏺 Oils & Vinegars"
  }
];

function renderCategoryChips() {
  const container = document.getElementById('categoryScroll');
  container.innerHTML = '';
  CATEGORIES.forEach(cat => {
    const chip = document.createElement('button');
    chip.className = `chip ${activeCategory === cat.id ? 'active' : ''}`;
    chip.textContent = (currentLang === 'de') ? cat.titleDe : cat.titleEn;
    chip.onclick = () => {
      activeCategory = cat.id;
      renderCategoryChips();
      renderCatalog();
    };
    container.appendChild(chip);
  });
}

function renderCatalog() {
  const grid = document.getElementById('catalogGrid');
  grid.innerHTML = '';

  const filtered = items.filter(item => {
    // category
    if (activeCategory !== 'all' && item.category !== activeCategory) return false;
    // stock filter
    if (filterOnlyStock && !item.inStock) return false;
    // favorite filter
    if (filterOnlyFav && !item.isFavorite) return false;
    // import filter
    if (filterImport !== null && item.isImport !== filterImport) return false;
    // search query
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const name = (currentLang === 'de' ? item.nameDe : item.nameEn).toLowerCase();
      const subtitle = (currentLang === 'de' ? item.subtitleDe : item.subtitleEn).toLowerCase();
      const tags = (item.tags || []).join(' ').toLowerCase();
      const origin = (item.origin || '').toLowerCase();
      if (!name.includes(q) && !subtitle.includes(q) && !tags.includes(q) && !origin.includes(q)) {
        return false;
      }
    }
    return true;
  });

  document.getElementById('itemCountBadge').textContent = `${filtered.length} ` + (currentLang === 'de' ? 'Einträge' : 'Items');

  filtered.forEach(item => {
    const card = document.createElement('div');
    card.className = 'item-card';
    card.onclick = () => showItemDetail(item.id);

    const title = (currentLang === 'de') ? item.nameDe : item.nameEn;
    const subtitle = (currentLang === 'de') ? item.subtitleDe : item.subtitleEn;
    const catObj = CATEGORIES.find(c => c.id === item.category);
    const catLabel = catObj ? (currentLang === 'de' ? catObj.titleDe : catObj.titleEn) : item.category;

    let coffeeBarHtml = '';
    if (item.coffeeLayers) {
      coffeeBarHtml = `
        <div class="coffee-mini-bar">
          <div class="coffee-bar-espresso" style="width: ${item.coffeeLayers.espresso}%"></div>
          <div class="coffee-bar-milk" style="width: ${item.coffeeLayers.milk}%"></div>
          <div class="coffee-bar-foam" style="width: ${item.coffeeLayers.foam}%"></div>
        </div>
      `;
    }

    const imgMarkup = item.imageUrl ? 
      `<img class="item-img" src="${item.imageUrl}" alt="${title}" loading="lazy" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" /><div class="item-placeholder" style="display:none;"><span class="placeholder-icon">${catLabel.split(' ')[0]}</span><span class="placeholder-title">${title}</span></div>` :
      `<div class="item-placeholder"><span class="placeholder-icon">${catLabel.split(' ')[0]}</span><span class="placeholder-title">${title}</span></div>`;

    card.innerHTML = `
      <div class="item-image-wrapper">
        ${imgMarkup}
        <div class="item-badges">
          <span class="badge">${catLabel.split(' ')[0]}</span>
          ${item.isImport ? '<span class="badge">✈️ Import</span>' : '<span class="badge">🌱 Regional</span>'}
        </div>
        <span class="badge-stock ${item.inStock ? 'in-stock' : 'out-stock'}">
          ${item.inStock ? '✓ ' + (currentLang === 'de' ? 'Auf Lager (' + item.stockQuantity + ')' : 'In Stock (' + item.stockQuantity + ')') : (currentLang === 'de' ? 'Nicht vorrätig' : 'Out of Stock')}
        </span>
      </div>
      <div class="item-body">
        <div class="item-title-row">
          <h3 class="item-title">${title}</h3>
          <span class="item-abv">${item.abv || ''}</span>
        </div>
        <p class="item-subtitle">${subtitle}</p>
        ${coffeeBarHtml}
        <div class="item-tags">
          ${(item.tags || []).map(t => `<span class="tag-pill">#${t}</span>`).join('')}
        </div>
      </div>
    `;
    grid.appendChild(card);
  });
}

function showItemDetail(id) {
  const item = items.find(i => i.id === id);
  if (!item) return;
  selectedItem = item;

  const isDe = (currentLang === 'de');
  const modal = document.getElementById('detailModal');
  const title = isDe ? item.nameDe : item.nameEn;
  const subtitle = isDe ? item.subtitleDe : item.subtitleEn;
  const taste = isDe ? item.tasteDe : item.tasteEn;
  const science = isDe ? item.scienceDe : item.scienceEn;
  const culinary = isDe ? item.culinaryDe : item.culinaryEn;
  const faq = isDe ? item.faqDe : item.faqEn;

  const detailImg = document.getElementById('detailImage');
  const detailPh = document.getElementById('detailPlaceholder');
  const catObj = CATEGORIES.find(c => c.id === item.category);
  const catIcon = catObj ? catObj.titleDe.split(' ')[0] : '🍽️';

  if (item.imageUrl && item.imageUrl.trim() !== '') {
    detailImg.style.display = 'block';
    detailImg.src = item.imageUrl;
    if (detailPh) detailPh.style.display = 'none';
    detailImg.onerror = () => {
      detailImg.style.display = 'none';
      if (detailPh) {
        detailPh.style.display = 'flex';
        detailPh.innerHTML = `<span class="placeholder-icon" style="font-size:3.5rem;">${catIcon}</span><span class="placeholder-title" style="font-size:1.1rem;margin-top:8px;">${title}</span>`;
      }
    };
  } else {
    detailImg.style.display = 'none';
    if (detailPh) {
      detailPh.style.display = 'flex';
      detailPh.innerHTML = `<span class="placeholder-icon" style="font-size:3.5rem;">${catIcon}</span><span class="placeholder-title" style="font-size:1.1rem;margin-top:8px;">${title}</span>`;
    }
  }

  document.getElementById('detailTitle').textContent = title;
  document.getElementById('detailSubtitle').textContent = subtitle;
  document.getElementById('detailOrigin').textContent = item.origin;

  // Category Badge
  const catBadge = document.getElementById('detailCategoryBadge');
  if (catBadge) {
    catBadge.textContent = catObj ? (isDe ? catObj.titleDe : catObj.titleEn) : '';
  }

  // Dynamic ABV: only show for spirits/wine or items with actual ABV percentage
  const abvEl = document.getElementById('detailAbv');
  const isAlcoholCat = item.category === 'spirits' || item.category === 'wine' || (item.abv && item.abv.includes('%'));
  if (abvEl) {
    if (isAlcoholCat) {
      abvEl.style.display = 'inline-block';
      abvEl.textContent = item.abv || '';
    } else {
      abvEl.style.display = 'none';
      abvEl.textContent = '';
    }
  }

  document.getElementById('detailTaste').textContent = taste || '-';
  document.getElementById('detailScience').textContent = science || '-';
  document.getElementById('detailCulinary').textContent = culinary || '-';
  document.getElementById('detailFaq').textContent = faq || '-';

  // Allergens section
  const allergenSec = document.getElementById('detailAllergenSection');
  const allergenTxt = document.getElementById('detailAllergens');
  if (allergenSec && allergenTxt) {
    if (item.allergens && item.allergens.length > 0 && !item.allergens.includes('None')) {
      allergenSec.style.display = 'block';
      allergenTxt.textContent = item.allergens.join(', ');
    } else {
      allergenSec.style.display = 'none';
    }
  }

  // Stock counter in detail modal
  document.getElementById('detailStockCount').textContent = item.stockQuantity;
  document.getElementById('detailLocation').textContent = item.storageLocation || (isDe ? 'Nicht zugewiesen' : 'Not assigned');

  modal.classList.add('active');
}

function closeDetailModal() {
  document.getElementById('detailModal').classList.remove('active');
}

function changeStockInDetail(delta) {
  if (!selectedItem) return;
  selectedItem.stockQuantity = Math.max(0, (selectedItem.stockQuantity || 0) + delta);
  selectedItem.inStock = selectedItem.stockQuantity > 0;
  document.getElementById('detailStockCount').textContent = selectedItem.stockQuantity;
  saveItems();
  renderCatalog();
  renderInventoryList();
}

// INVENTORY MANAGEMENT
function renderInventoryList() {
  const list = document.getElementById('inventoryList');
  if (!list) return;
  list.innerHTML = '';

  items.forEach(item => {
    const isDe = (currentLang === 'de');
    const title = isDe ? item.nameDe : item.nameEn;
    const row = document.createElement('div');
    row.className = 'item-card';
    row.style.marginBottom = '12px';

    row.innerHTML = `
      <div style="display: flex; gap: 12px; padding: 12px; align-items: center;">
        <img src="${item.imageUrl}" style="width: 65px; height: 65px; object-fit: cover; border-radius: 8px;" />
        <div style="flex-grow: 1;">
          <h4 style="font-size: 1rem; font-weight: 700;">${title}</h4>
          <p style="font-size: 0.8rem; color: var(--text-muted);">${item.storageLocation || (isDe ? 'Kein Lagerplatz' : 'No shelf')}</p>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
          <button class="stepper-btn" onclick="updateStock('${item.id}', -1)">-</button>
          <span style="font-weight: 800; min-width: 25px; text-align: center; color: var(--accent-gold);">${item.stockQuantity}</span>
          <button class="stepper-btn" onclick="updateStock('${item.id}', 1)">+</button>
          <button class="btn-secondary" onclick="openPhotoChanger('${item.id}')" title="${isDe ? 'Foto ändern' : 'Change photo'}">📷</button>
        </div>
      </div>
    `;
    list.appendChild(row);
  });
}

function updateStock(id, delta) {
  const item = items.find(i => i.id === id);
  if (!item) return;
  item.stockQuantity = Math.max(0, (item.stockQuantity || 0) + delta);
  item.inStock = item.stockQuantity > 0;
  saveItems();
  renderInventoryList();
  renderCatalog();
}

function openPhotoChanger(id) {
  const item = items.find(i => i.id === id);
  if (!item) return;
  const isDe = (currentLang === 'de');
  const promptText = isDe ? `Neue Bild-URL für "${item.nameDe}" eingeben:` : `Enter new image URL for "${item.nameEn}":`;
  const newUrl = prompt(promptText, item.imageUrl);
  if (newUrl && newUrl.trim() !== '') {
    item.imageUrl = newUrl.trim();
    saveItems();
    renderInventoryList();
    renderCatalog();
  }
}

// QUIZ SYSTEM (10 QUESTIONS WITH CATEGORY SELECTION)
function initQuizSession(cat = 'all', count = 10) {
  quizCategory = cat;
  quizTargetCount = count;
  quizCurrentIndex = 0;
  quizSelectedOption = null;
  quizIsRevealed = false;
  quizScore = 0;
  quizIsCompleted = false;

  let pool = MASTER_QUIZ;
  if (cat !== 'all') {
    pool = MASTER_QUIZ.filter(q => q.category === cat);
    if (pool.length === 0) pool = MASTER_QUIZ;
  }

  // Shuffle and sample
  activeQuizQuestions = [...pool].sort(() => 0.5 - Math.random()).slice(0, count);
  renderQuizUI();
}

function renderQuizUI() {
  const isDe = (currentLang === 'de');
  document.getElementById('quizCategoryDisplay').textContent = (quizCategory === 'all') ? 
    (isDe ? "✨ Mix durch alle Kategorien" : "✨ Mix all categories") : 
    (CATEGORIES.find(c => c.id === quizCategory)?.[isDe ? 'titleDe' : 'titleEn'] || quizCategory);

  if (quizIsCompleted) {
    document.getElementById('quizActiveCard').style.display = 'none';
    document.getElementById('quizCompletedCard').style.display = 'block';

    const percent = Math.round((quizScore / activeQuizQuestions.length) * 100);
    document.getElementById('quizScoreRate').textContent = `${percent}% ` + (isDe ? 'Erfolgsquote' : 'Score rate');
    document.getElementById('quizScoreRate').style.color = (percent >= 75) ? 'var(--success)' : 'var(--danger)';
    document.getElementById('quizScoreDetail').textContent = isDe ? 
      `${quizScore} von ${activeQuizQuestions.length} Fragen richtig beantwortet` : 
      `${quizScore} of ${activeQuizQuestions.length} questions answered correctly`;
  } else {
    document.getElementById('quizActiveCard').style.display = 'block';
    document.getElementById('quizCompletedCard').style.display = 'none';
    renderCurrentQuestion();
  }
}

function renderCurrentQuestion() {
  const currentQ = activeQuizQuestions[quizCurrentIndex];
  if (!currentQ) return;
  const isDe = (currentLang === 'de');

  document.getElementById('quizProgressText').textContent = isDe ? 
    `Frage ${quizCurrentIndex + 1} von ${activeQuizQuestions.length}` : 
    `Question ${quizCurrentIndex + 1} of ${activeQuizQuestions.length}`;
  
  const progressPercent = ((quizCurrentIndex) / activeQuizQuestions.length) * 100;
  document.getElementById('quizProgressFill').style.width = `${progressPercent}%`;

  document.getElementById('quizQuestionText').textContent = isDe ? (currentQ.qDe || currentQ.questionDe) : (currentQ.qEn || currentQ.questionEn);

  const optionsList = document.getElementById('quizOptionsList');
  optionsList.innerHTML = '';

  const opts = isDe ? (currentQ.optDe || currentQ.optionsDe || []) : (currentQ.optEn || currentQ.optionsEn || []);
  opts.forEach((optText, index) => {
    const optDiv = document.createElement('div');
    optDiv.className = 'quiz-option';

    if (quizIsRevealed) {
      const corr = currentQ.correct !== undefined ? currentQ.correct : currentQ.correctIndex;
    if (index === corr) {
        optDiv.classList.add('correct');
      } else if (index === quizSelectedOption) {
        optDiv.classList.add('incorrect');
      }
    } else if (index === quizSelectedOption) {
      optDiv.style.borderColor = 'var(--accent-gold)';
    }

    optDiv.onclick = () => {
      if (!quizIsRevealed) {
        answerQuestion(index);
      }
    };

    const letter = String.fromCharCode(65 + index);
    optDiv.innerHTML = `
      <div class="quiz-opt-letter">${letter}</div>
      <div style="flex-grow: 1;">${optText}</div>
    `;
    optionsList.appendChild(optDiv);
  });

  const expBox = document.getElementById('quizExplanationBox');
  const nextBtn = document.getElementById('quizNextBtn');

  if (quizIsRevealed) {
    expBox.style.display = 'block';
    expBox.innerHTML = `<strong>💡 ${isDe ? 'Erklärung & Gastronomie-Wissen' : 'Explanation & Knowledge'}:</strong><br/>` + 
      (isDe ? currentQ.expDe : currentQ.expEn);
    nextBtn.style.display = 'flex';
    nextBtn.textContent = (quizCurrentIndex + 1 < activeQuizQuestions.length) ? 
      (isDe ? "Nächste Frage ➜" : "Next Question ➜") : 
      (isDe ? "Ergebnis anzeigen" : "View Results");
  } else {
    expBox.style.display = 'none';
    nextBtn.style.display = 'none';
  }
}

function answerQuestion(index) {
  quizSelectedOption = index;
  quizIsRevealed = true;
  const currentQ = activeQuizQuestions[quizCurrentIndex];
  const corr = currentQ.correct !== undefined ? currentQ.correct : currentQ.correctIndex;
  if (index === corr) {
    quizScore++;
  }
  renderCurrentQuestion();
}

function nextQuestion() {
  if (quizCurrentIndex + 1 < activeQuizQuestions.length) {
    quizCurrentIndex++;
    quizSelectedOption = null;
    quizIsRevealed = false;
    renderCurrentQuestion();
  } else {
    quizIsCompleted = true;
    renderQuizUI();
  }
}

function shareQuizScore() {
  const isDe = (currentLang === 'de');
  const name = document.getElementById('quizStaffName').value.trim() || (isDe ? "Service-Mitarbeiter" : "Staff Member");
  const percent = Math.round((quizScore / activeQuizQuestions.length) * 100);
  const text = isDe ? 
    `📋 GastroDex Prüfungsergebnis für den Quizmaster / Barchef:\n` +
    `Mitarbeiter: ${name}\n` +
    `Ergebnis: ${quizScore} von ${activeQuizQuestions.length} richtig (${percent}%)\n` +
    `Kategorie: ${quizCategory}\n` +
    `Status: ${percent >= 75 ? '✅ BESTANDEN' : '⚠️ NACHSCHULUNG EMPFOHLEN'}` :
    `📋 GastroDex Quiz Report for Bar Manager:\n` +
    `Staff: ${name}\n` +
    `Score: ${quizScore} of ${activeQuizQuestions.length} correct (${percent}%)\n` +
    `Category: ${quizCategory}\n` +
    `Status: ${percent >= 75 ? '✅ PASSED' : '⚠️ FURTHER TRAINING NEEDED'}`;

  if (navigator.share) {
    navigator.share({ title: 'GastroDex Report', text });
  } else {
    navigator.clipboard.writeText(text);
    alert(isDe ? "Prüfungsbericht in die Zwischenablage kopiert! Kann jetzt in WhatsApp oder E-Mail eingefügt werden." : "Report copied to clipboard! You can paste it into WhatsApp or Email.");
  }
}

// NAVIGATION SWITCHER
function switchTab(tabId) {
  currentTab = tabId;
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('active'));

  document.getElementById(`tab-${tabId}`).classList.add('active');
  const targetPane = document.getElementById(`pane-${tabId}`);
  if (targetPane) targetPane.classList.add('active');

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function setupEventListeners() {
  document.getElementById('searchInput').addEventListener('input', (e) => {
    searchQuery = e.target.value;
    renderCatalog();
  });
}
